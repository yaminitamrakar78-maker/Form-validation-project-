// A class to encapsulate the calculator's logic and state.
class Calculator {
    /**
     * @param {Element} previousOperandElement - The display element for the previous operand.
     * @param {Element} currentOperandElement - The display element for the current operand.
     */
    constructor(previousOperandElement, currentOperandElement) {
        this.previousOperandElement = previousOperandElement;
        this.currentOperandElement = currentOperandElement;
        this.clear(); // Initialize the calculator to its default state.
    }

    // Resets all the values on the calculator.
    clear() {
        this.currentOperand = '0';
        this.previousOperand = '';
        this.operation = undefined;
    }

     // Deletes the last character from the current operand.
    delete() {
        // If the current operand is '0', do nothing.
        if (this.currentOperand === '0') return;

        // If there's more than one character, slice the last one off.
        if (this.currentOperand.length > 1) {
            this.currentOperand = this.currentOperand.slice(0, -1);
        } else {
            // If only one character is left, reset to '0'.
            this.currentOperand = '0';
        }
    }

    // Appends a number or a decimal point to the current operand.
    /**
     * @param {string} number - The number or decimal point to append.
     */
    appendNumber(number) {
        // Prevent multiple decimal points.
        if (number === '.' && this.currentOperand.includes('.')) return;

        // If the current operand is '0', replace it with the new number, otherwise append.
        if (this.currentOperand === '0' && number !== '.') {
            this.currentOperand = number;
        } else {
            this.currentOperand += number;
        }
    }

    // Sets the operation and moves the current operand to the previous.
    /**
     * @param {string} operation - The mathematical operation to perform.
     */
    chooseOperation(operation) {
        if (this.currentOperand === '') return;
        if (this.previousOperand !== '') {
            this.compute();
        }
        this.operation = operation;
        this.previousOperand = this.currentOperand;
        this.currentOperand = '';
    }

    // Performs the calculation.
    compute() {
        let computation;
        const prev = parseFloat(this.previousOperand);
        const current = parseFloat(this.currentOperand);
        if (isNaN(prev) || isNaN(current)) return;

        switch (this.operation) {
            case '+':
                computation = prev + current;
                break;
            case '-':
                computation = prev - current;
                break;
            case '*':
                computation = prev * current;
                break;
            case '/':
                computation = prev / current;
                break;
            case '%':
                computation = prev % current;
                break;
            default:
                return;
        }
        this.currentOperand = computation.toString();
        this.operation = undefined;
        this.previousOperand = '';
    }

    // Updates the display elements with the current and previous operands.
    updateDisplay() {
        this.currentOperandElement.innerText = this.currentOperand;
        if (this.operation != null) {
            this.previousOperandElement.innerText = `${this.previousOperand} ${this.operation}`;
        } else {
            this.previousOperandElement.innerText = '';
        }
    }
}

// --- Event Listeners and Initial Setup ---

// Select all the buttons and display elements from the HTML using their data attributes.
const numberButtons = document.querySelectorAll('[data-number]');
const operatorButtons = document.querySelectorAll('[data-operator]');
const equalsButton = document.querySelector('[data-equals]');
const allClearButton = document.querySelector('[data-all-clear]');
const deleteButton = document.querySelector('[data-delete]');
const previousOperandElement = document.querySelector('[data-previous-operand]');
const currentOperandElement = document.querySelector('[data-current-operand]');

// Create a new instance of the Calculator class.
const calculator = new Calculator(previousOperandElement, currentOperandElement);

// Add event listeners for number buttons.
numberButtons.forEach(button => {
    button.addEventListener('click', () => {
        calculator.appendNumber(button.innerText);
        calculator.updateDisplay();
    });
});

// Add event listeners for operator buttons.
operatorButtons.forEach(button => {
    button.addEventListener('click', () => {
        calculator.chooseOperation(button.innerText);
        calculator.updateDisplay();
    });
});

// Add event listener for the equals button.
equalsButton.addEventListener('click', button => {
    calculator.compute();
    calculator.updateDisplay();
});

// Add event listener for the all-clear button.
allClearButton.addEventListener('click', button => {
    calculator.clear();
    calculator.updateDisplay();
});

// Add event listener for the delete button.
deleteButton.addEventListener('click', () => {
    calculator.delete();
    calculator.updateDisplay();
});

// ... [existing event listeners for buttons] ...

// --- Keyboard Input Event Listener ---

window.addEventListener('keydown', e => {
    // Check if the pressed key is a number (0-9) or a decimal point.
    if (e.key >= '0' && e.key <= '9' || e.key === '.') {
        calculator.appendNumber(e.key);
        calculator.updateDisplay();
    }

    // Check if the pressed key is an operator.
    if (e.key === '+' || e.key === '-' || e.key === '*' || e.key === '/') {
        calculator.chooseOperation(e.key);
        calculator.updateDisplay();
    }

    // Map specific keyboard keys to calculator functions.
    switch (e.key) {
        case 'Enter': // 'Enter' key
            calculator.compute();
            calculator.updateDisplay();
            break;
        case 'Backspace': // 'Backspace' key
            calculator.delete();
            calculator.updateDisplay();
            break;
        case 'Escape': // 'Escape' key
            calculator.clear();
            calculator.updateDisplay();
            break;
        case '%': // '%' key
            calculator.chooseOperation('%');
            calculator.updateDisplay();
            break;
    }
});