# Write a Python program to check if a number is EVEN or ODD. 

u_inp = int(input(" Enter a Number to Check wether it is odd or even:"))
if u_inp == 0:
    print("you have entered 0. Kindly insert again.")
else:
    check = u_inp % 2
    if check==1:
        print(f"The given number is odd, and the nearest even number is {u_inp-1} and {u_inp+1}.")
    elif check==0:
        print(f"The given number is even, and the nearest odd number is {u_inp-1} and {u_inp+1}.")
    else:
        print("Enter a valid Number.")

 
h=input()