# Write a Python program to check if a number is Positive, Negative or Zero. 

Z = float(input("Enter a Number:- "))
if Z == 0:
    print("Entered Number is Zero.")
elif Z > 0:
    print("Entered Number is Positive.")
elif Z < 0:
    print("Entered Number is Negative.")
else:
    print("Invalid Input.")

h=input()