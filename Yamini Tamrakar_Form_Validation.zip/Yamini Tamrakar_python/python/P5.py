# Write a Python program to check if a number is PRIME or NOT.

num = int(input("Enter a Number to check for Prime:- "))
if num <= 1:
    print(f"{num} is not a Prime Number.(cannot be checked)")
elif num > 1:
    isPrime= True
    for i in range(2,int(num**0.5)+1):
        if num % i  == 0:
            isPrime = False
            break 
    if isPrime:
        print(f"{num} is a Prime-Number.")        
    else:
        print(f"{num} is not a Prime-Number.")
else:
    print("Invalid Input.")
h=input()
