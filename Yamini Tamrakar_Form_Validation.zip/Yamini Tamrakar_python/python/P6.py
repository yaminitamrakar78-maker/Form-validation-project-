# Write a Python program to check whether a string entered by the user is a valid decimal number or not.

inp = input("Enter any string:  ")

if inp.isdecimal() == True:
    print("Valid Decimal")
else:
    print("Invalid")

h=input()
