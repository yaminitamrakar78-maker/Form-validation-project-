# Write a Python program to get a Decimal number from user and convert it into Binary, Octal and Hexadecimal. 


inp = int(input("Enter a number:- "))
print(f"*"*40)
print(f"Binary Representation: {bin(inp)[2:]}")
print(f"Octal Representation: {oct(inp)[2:]}")
print(f"Hexa-Decimal Representation: {hex(inp)[2:].upper()}")

h=input()
