# Write a Python program to check if a year entered by the user is a Leap Year or NOT. 



yr = int(input("Enter an year to Check:- "))
if yr % 4 == 0:
    if yr % 100 == 0:
        if yr % 400 == 0:
            print(f"{yr} is a Leap-Year.")
        else:
            print(f"{yr} is not a Leap-Year.")
    else:
        print(f"{yr} is a Leap-Year.")
else:
    print(f"{yr} is not a Leap-Year.")

h=input()