# Write a Python program to find sum of natural numbers, up to N

n = int(input("Enter the number upto which sum is to be displayed: "))
print(f'='*8)
print(f"You want sum till {n}.")
sum = int(n*(n+1)/2)
print(f"The sum upto {n} numbers is {sum}.")

h=input()