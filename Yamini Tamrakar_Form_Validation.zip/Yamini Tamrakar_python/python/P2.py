# Write a Python program to check and print the types of at least 5 different inbuilt objects. 

print('')
a = 123
b = 12.3
c = "abc"
d = False
e = ['12',14+13j,234]
f = 25+14j
print(a,"|",type(a))
print(b,"|",type(b))
print(c,"|",type(c))
print(d,"|",type(d))
print(e,"|",type(e))
print(f,"|",type(f))
h=input()