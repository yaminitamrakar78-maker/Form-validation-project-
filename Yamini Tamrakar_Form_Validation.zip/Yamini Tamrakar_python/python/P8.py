# Write a Python program to check whether a string entered by the user is a palindrome or not. 


text = input("Enter a word to check for palindrome: ")
if text.lower() == text[::-1].lower():
    print(f"{text} is a Palindrome.")
else:
    print(f"{text} is not a Palindrome.")

h=input()