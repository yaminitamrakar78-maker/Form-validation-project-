import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import dotenv from "dotenv";
import mongoose from "mongoose";
import cors from "cors";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import multer from "multer";
import fs from "fs";

dotenv.config();

const __filename = import.meta.url ? fileURLToPath(import.meta.url) : '';
const __dirname = __filename ? path.dirname(__filename) : process.cwd();

// Use process.cwd() for project-root relative paths to ensure consistency in bundled environments
const rootDir = process.cwd();

// --- MongoDB Setup ---
const MONGODB_URI = process.env.MONGODB_URI || process.env.MONGO_URI;
console.log(`[DB] Using ${process.env.MONGODB_URI ? 'MONGODB_URI' : (process.env.MONGO_URI ? 'MONGO_URI' : 'NO URI FOUND')} from environment.`);
const JWT_SECRET = process.env.JWT_SECRET || "super_secret_local_key_for_dev";

async function connectDB() {
  console.log("[DB] Starting connection sequence...");
  if (!MONGODB_URI) {
    console.error("[DB] CRITICAL ERROR: NO MONGODB_URI FOUND.");
    console.error("[DB] Action required: Go to Settings -> Environment Variables and add MONGODB_URI with your connection string.");
    return;
  }
  
  const maskedUri = MONGODB_URI.replace(/:([^:@]{1,})@/, ':***@');
  console.log(`[DB] URI Detected: ${maskedUri}`);
  
  if (MONGODB_URI.includes("localhost") || MONGODB_URI.includes("127.0.0.1") || MONGODB_URI.startsWith("mongodb://localhost") || MONGODB_URI.startsWith("mongodb://127.0.0.1")) {
    console.info("[DB] Localhost MongoDB detected. This is typical for local development.");
    console.info("[DB] Note: In this cloud preview, you likely need a remote MongoDB Atlas URI.");
    console.info("[DB] If this connection fails, please provide a MONGODB_URI in Settings -> Environment Variables.");
  }

  try {
    console.log(`[DB] Attempting to connect to Mongoose...`);
    await mongoose.connect(MONGODB_URI, {
      serverSelectionTimeoutMS: 5000,
      connectTimeoutMS: 10000,
      socketTimeoutMS: 45000,
    });
    console.log("[DB] Success: Connected to MongoDB");
  } catch (err: any) {
    if (err.message.includes("ECONNREFUSED")) {
      console.warn("[DB] Connection refused. (Check if using a remote Atlas URI and have whitelisted 0.0.0.0/0)");
    } else {
      console.error("[DB] Connection failed:", err.message);
    }
  }
}

// --- Schemas ---
const schemaOptions = { 
  bufferCommands: false, // Disable buffering so it fails fast if not connected
  timestamps: true 
};

const userSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  name: { type: String, required: true },
  role: { type: String, enum: ["admin", "worker"], default: "worker" },
  points: { type: Number, default: 0 },
  accountStatus: { type: String, enum: ["active", "disabled"], default: "active" },
  mobile: String,
  address: String,
  city: String,
  wardNumber: String,
  photoUrl: String,
  profession: String,
  currentStreak: { type: Number, default: 0 },
  longestStreak: { type: Number, default: 0 },
  tasksCompleted: { type: Number, default: 0 },
  complaintsSubmitted: { type: Number, default: 0 },
  lastTaskDate: String,
}, schemaOptions);

const User = mongoose.model("User", userSchema);

const taskSchema = new mongoose.Schema({
  title: String,
  description: String,
  type: { type: String, enum: ["individual", "group"] },
  status: { type: String, enum: ["pending", "submitted", "approved", "rejected", "completed"], default: "pending" },
  pointsValue: { type: Number, default: 10 },
  workerId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  assignedUsers: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
  proofImageUrl: String,
  workerNotes: String,
  latitude: Number,
  longitude: Number,
  address: String,
  cleanlinessLevel: String,
  aiAnalysis: mongoose.Schema.Types.Mixed,
  aiVerificationResult: mongoose.Schema.Types.Mixed,
  completedAt: Date,
  adminActionAt: Date,
  rejectionReason: String,
}, schemaOptions);

const Task = mongoose.model("Task", taskSchema);

const taskLogSchema = new mongoose.Schema({
  taskId: { type: mongoose.Schema.Types.ObjectId, ref: "Task" },
  action: String,
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  userName: String,
  timestamp: { type: Date, default: Date.now },
  details: String,
}, schemaOptions);

const TaskLog = mongoose.model("TaskLog", taskLogSchema);

const settingsSchema = new mongoose.Schema({
  key: { type: String, unique: true, default: 'config' },
  autoApproveHabits: { type: Boolean, default: false },
  aiConfidenceThreshold: { type: Number, default: 0.8 },
}, schemaOptions);

const Settings = mongoose.model("Settings", settingsSchema);

const notificationSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  title: String,
  message: String,
  type: String,
  read: { type: Boolean, default: false },
  relatedId: String,
}, schemaOptions);

const Notification = mongoose.model("Notification", notificationSchema);

const habitSubmissionSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  taskTitle: String,
  points: Number,
  imageUrl: String,
  status: { type: String, default: "pending" },
  location: {
    lat: Number,
    lng: Number
  },
  adminActionAt: Date,
}, schemaOptions);

const HabitSubmission = mongoose.model("HabitSubmission", habitSubmissionSchema);

const noticeSchema = new mongoose.Schema({
  title: String,
  content: String,
  category: { type: String, enum: ["Urgent", "Update", "Info"] },
  issuedAt: { type: Date, default: Date.now },
}, schemaOptions);

const Notice = mongoose.model("Notice", noticeSchema);

const userPassSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  title: String,
  rewardTitle: String,
  rewardType: String,
  status: { type: String, enum: ["active", "expired", "pending", "used"], default: "active" },
  validUntil: Date,
  issuedAt: { type: Date, default: Date.now },
  usedCount: { type: Number, default: 0 },
  usageLimit: { type: Number, default: 1 },
  lastUsedAt: String,
  qrHash: String,
  passId: String,
}, schemaOptions);

const UserPass = mongoose.model("UserPass", userPassSchema);

const redeemRequestSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  userName: String,
  rewardId: String,
  rewardTitle: String,
  rewardType: String,
  points: Number,
  usageLimit: Number,
  validDurationDays: Number,
  status: { type: String, enum: ["pending", "approved", "rejected"], default: "pending" },
  createdAt: { type: Date, default: Date.now },
}, schemaOptions);

const RedeemRequest = mongoose.model("RedeemRequest", redeemRequestSchema);

const feedbackSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  message: String,
  status: { type: String, default: "pending" },
}, schemaOptions);

const Feedback = mongoose.model("Feedback", feedbackSchema);

const rewardSchema = new mongoose.Schema({
  title: String,
  pointsRequired: Number,
  image: String,
  type: { type: String, enum: ["voucher", "merchandise", "experience"] },
  description: String,
  validDurationDays: { type: Number, default: 30 },
  usageLimit: { type: Number, default: 1 }
}, schemaOptions);

const Reward = mongoose.model("Reward", rewardSchema);

// --- Multer Setup ---
const uploadDir = path.join(rootDir, "uploads");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, file.fieldname + "-" + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage,
  limits: { fileSize: 5 * 1024 * 1024 } // 5MB limit
});

// --- Middleware ---
const checkDBConnection = (req: any, res: any, next: any) => {
  if (mongoose.connection.readyState !== 1) {
    return res.status(503).json({ 
      error: "Database connection failed. Please ensure MONGODB_URI is correctly configured.",
      details: MONGODB_URI ? "Connection to database failed. Check your credentials and IP whitelist if using MongoDB Atlas." : "MONGODB_URI is missing from the environment.",
      action: "Go to the Settings menu in AI Studio, click on 'Environment Variables', and add MONGODB_URI with your remote MongoDB connection string (e.g. from MongoDB Atlas)."
    });
  }
  next();
};

const authenticateToken = (req: any, res: any, next: any) => {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];

  if (!token) return res.sendStatus(401);

  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) return res.sendStatus(403);
    
    req.user = user;
    next();
  });
};

async function startServer() {
  const app = express();
  const PORT = 3000;

  // 1. SATISFY PROXY IMMEDIATELY - Listen as early as possible
  const server = app.listen(PORT, "0.0.0.0", () => {
    console.log(`[READY] Server listening on port ${PORT} (PID: ${process.pid})`);
    
    // Background tasks that shouldn't block startup
    if (process.env.NODE_ENV !== "production") {
      console.log("[SERVER] Initializing Vite background...");
      import("vite").then(({ createServer: createViteServer }) => {
        return createViteServer({
          server: { middlewareMode: true },
          appType: "spa",
        });
      }).then(v => {
        vite = v;
        console.log("[SERVER] Vite initialization complete.");
      }).catch(err => {
        console.error("[SERVER] Vite initialization error:", err);
      });
    }

    connectDB().catch(err => {
      console.error("[DB] Initial connection attempt failed:", err.message);
    });
  });

  server.on('error', (err: any) => {
    console.error("[SERVER] Error during early listen:", err);
  });

  // 3. Middlewares
  app.use(cors({
    origin: true, // Allow all origins for better debugging in dev/cloud
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization']
  }));
  app.use(express.json({ limit: '10mb' }));
  app.use("/uploads", express.static(uploadDir));

  // 4. Logging
  app.use((req, res, next) => {
    const isHealthCheck = req.path === "/health" || req.path === "/api/health";
    const start = Date.now();
    res.on('finish', () => {
      const duration = Date.now() - start;
      // Reduced log level for health checks but still visible
      if (isHealthCheck) {
        if (res.statusCode >= 400) console.log(`[HEALTH-FAIL] ${req.method} ${req.url} - Status: ${res.statusCode} - Duration: ${duration}ms`);
      } else {
        console.log(`[REQUEST] ${new Date().toISOString()} - ${req.method} ${req.url} - Status: ${res.statusCode} - Duration: ${duration}ms`);
      }
    });
    next();
  });

  // 2. Health Checks (Fastest response)
  app.get("/health", (req, res) => res.status(200).send("OK"));
  app.get("/api/health", (req, res) => res.status(200).json({ status: "ok" }));

  // 5. API Routes Setup
  const apiRouter = express.Router();

  // Root of API
  apiRouter.get("/v1", (req, res) => {
    res.json({ message: "Raipur Smart Civic Sense API", version: "1.0.0" });
  });

  apiRouter.get("/", (req, res) => {
    res.json({ message: "Raipur Smart Civic Sense API" });
  });

  apiRouter.use((req, res, next) => {
    // These routes don't require a DB connection or are handled separately
    if (req.path === "/health" || req.path === "/" || req.path === "/upload" || req.path === "/v1") return next();
    checkDBConnection(req, res, next);
  });

  // --- Streak Helpers ---
  const updateStreak = async (userId: string) => {
    const user = await User.findById(userId);
    if (!user) return null;

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayStr = today.toDateString();

    const lastDate = user.lastTaskDate ? new Date(user.lastTaskDate) : null;
    if (lastDate) lastDate.setHours(0, 0, 0, 0);
    const lastDateStr = lastDate ? lastDate.toDateString() : null;

    if (lastDateStr === todayStr) return null;

    let newStreak = 1;
    const yesterday = new Date();
    yesterday.setDate(today.getDate() - 1);
    yesterday.setHours(0, 0, 0, 0);
    const yesterdayStr = yesterday.toDateString();

    if (lastDateStr === yesterdayStr) {
      newStreak = (user.currentStreak || 0) + 1;
    }

    let bonus = 0;
    let milestone = null;
    if (newStreak === 3) { bonus = 10; milestone = 3; }
    else if (newStreak === 7) { bonus = 25; milestone = 7; }
    else if (newStreak === 15) { bonus = 50; milestone = 15; }
    else if (newStreak === 30) { bonus = 100; milestone = 30; }

    user.currentStreak = newStreak;
    user.longestStreak = Math.max(newStreak, user.longestStreak || 0);
    user.lastTaskDate = today.toISOString();
    user.points = (user.points || 0) + bonus;
    await user.save();

    return { newStreak, bonus, milestone };
  };

  const checkAndResetStreak = async (userId: string) => {
    const user = await User.findById(userId);
    if (!user || !user.lastTaskDate || user.currentStreak === 0) return false;

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const lastDate = new Date(user.lastTaskDate);
    lastDate.setHours(0, 0, 0, 0);

    const diffDays = Math.round((today.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24));
    if (diffDays > 1) {
      user.currentStreak = 0;
      await user.save();
      return true;
    }
    return false;
  };

  apiRouter.post("/users/streak/check", authenticateToken, async (req: any, res) => {
    const reset = await checkAndResetStreak(req.user.id);
    res.json({ reset });
  });

  apiRouter.post("/users/streak/update", authenticateToken, async (req: any, res) => {
    const result = await updateStreak(req.user.id);
    res.json(result);
  });

  // --- Auth Routes ---
  apiRouter.post("/auth/register", async (req: any, res) => {
    try {
      const { email, password, name, role, mobile } = req.body;
      
      const hashedPassword = await bcrypt.hash(password, 10);
      const user = new User({ email, password: hashedPassword, name, mobile, role: role || "worker" });
      await user.save();
      const token = jwt.sign({ id: user._id.toString(), email: user.email, role: user.role }, JWT_SECRET);
      const responseBody = {
        token,
        user: {
          id: user._id.toString(),
          _id: user._id.toString(),
          email: user.email,
          name: user.name,
          mobile: user.mobile,
          role: user.role
        }
      };
      res.status(201).json(responseBody);
    } catch (err: any) {
      res.status(400).json({ error: err.message || "Registration failed" });
    }
  });

  apiRouter.post("/auth/login", async (req: any, res) => {
    try {
      const { email, password } = req.body;
      
      const user = await User.findOne({ email });
      if (!user) return res.status(401).json({ error: "Invalid credentials" });
      
      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) return res.status(401).json({ error: "Invalid credentials" });

      const token = jwt.sign({ id: user._id.toString(), email: user.email, role: user.role }, JWT_SECRET);
      const responseBody = {
        token,
        user: {
          id: user._id.toString(),
          _id: user._id.toString(),
          email: user.email,
          name: user.name,
          mobile: user.mobile,
          role: user.role
        }
      };
      res.json(responseBody);
    } catch (err: any) {
      res.status(500).json({ error: "Server error during login." });
    }
  });

  apiRouter.get("/auth/me", authenticateToken, async (req: any, res) => {
    try {
      const user = await User.findById(req.user.id).select("-password");
      if (!user) return res.status(404).json({ error: "User profile no longer exists." });
      res.json(user);
    } catch (err: any) {
      res.status(500).json({ error: "Failed to retrieve user profile." });
    }
  });

  // --- User Routes ---
  apiRouter.get("/users", authenticateToken, async (req: any, res) => {
    const users = await User.find().select("-password").sort("-points");
    res.json(users);
  });

  apiRouter.get("/users/:id", authenticateToken, async (req: any, res) => {
    const user = await User.findById(req.params.id).select("-password");
    if (!user) return res.status(404).json({ error: "User not found" });
    res.json(user);
  });

  apiRouter.patch("/users/:id", authenticateToken, async (req: any, res) => {
    if (req.user.role !== "admin") return res.sendStatus(403);
    const user = await User.findByIdAndUpdate(req.params.id, { ...req.body, updatedAt: new Date() }, { new: true }).select("-password");
    res.json(user);
  });

  apiRouter.patch("/users/profile", authenticateToken, async (req: any, res) => {
    const user = await User.findByIdAndUpdate(req.user.id, { ...req.body, updatedAt: new Date() }, { new: true }).select("-password");
    res.json(user);
  });

  apiRouter.get("/worker/stats", authenticateToken, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const [completed, pending, passesCount, currentPoints] = await Promise.all([
        Task.countDocuments({ 
          $or: [{ workerId: userId }, { assignedUsers: userId }],
          status: { $in: ["completed", "approved"] }
        }),
        Task.countDocuments({ 
          $or: [{ workerId: userId }, { assignedUsers: userId }],
          status: { $in: ["pending", "submitted"] }
        }),
        UserPass.countDocuments({ userId, status: "active" }),
        User.findById(userId).select("points")
      ]);

      const rank = await User.countDocuments({ points: { $gt: currentPoints?.points || 0 } }) + 1;

      res.json({ completed, pending, rank, activePasses: passesCount });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // --- Task Routes ---
  apiRouter.get("/tasks", authenticateToken, async (req: any, res) => {
    let query: any = {};
    if (req.user.role === "worker") {
      query = { $or: [{ workerId: req.user.id }, { assignedUsers: req.user.id }, { workerId: null }] };
    } else if (req.query.workerId) {
      query = { workerId: req.query.workerId };
    }
    const tasks = await Task.find(query).sort("-createdAt");
    res.json(tasks);
  });

  apiRouter.post("/tasks", authenticateToken, async (req: any, res) => {
    if (req.user.role !== "admin") return res.sendStatus(403);
    const task = new Task(req.body);
    await task.save();
    res.status(201).json(task);
  });

  apiRouter.patch("/tasks/:id", authenticateToken, async (req: any, res) => {
    const task = await Task.findByIdAndUpdate(req.params.id, { ...req.body, updatedAt: new Date() }, { new: true });
    res.json(task);
  });

  apiRouter.post("/tasks/:id/approve", authenticateToken, async (req: any, res) => {
    if (req.user.role !== "admin") return res.sendStatus(403);
    const task: any = await Task.findById(req.params.id);
    if (!task) return res.status(404).json({ error: "Task not found" });

    task.status = "approved";
    task.adminActionAt = new Date();
    await task.save();

    // Award points
    if (task.type === "group" && task.assignedUsers) {
      await User.updateMany(
        { _id: { $in: task.assignedUsers } },
        { $inc: { points: task.pointsValue, tasksCompleted: 1 } }
      );
    } else if (task.workerId) {
      await User.findByIdAndUpdate(task.workerId, {
        $inc: { points: task.pointsValue, tasksCompleted: 1 }
      });
    }

    // Update Streak
    await updateStreak(task.workerId);

    res.json(task);
  });

  apiRouter.post("/tasks/:id/reject", authenticateToken, async (req: any, res) => {
    if (req.user.role !== "admin") return res.sendStatus(403);
    const { reason } = req.body;
    const task = await Task.findByIdAndUpdate(req.params.id, {
      status: "rejected",
      rejectionReason: reason,
      adminActionAt: new Date()
    }, { new: true });
    res.json(task);
  });

  apiRouter.post("/habits/:id/approve", authenticateToken, async (req: any, res) => {
    if (req.user.role !== "admin") return res.sendStatus(403);
    const habit: any = await HabitSubmission.findById(req.params.id);
    if (!habit) return res.status(404).json({ error: "Habit not found" });

    habit.status = "approved";
    habit.adminActionAt = new Date();
    await habit.save();

    await User.findByIdAndUpdate(habit.userId, {
      $inc: { points: habit.points, tasksCompleted: 1 }
    });

    // Update Streak
    await updateStreak(habit.userId);

    res.json(habit);
  });

  apiRouter.post("/habits/:id/reject", authenticateToken, async (req: any, res) => {
    if (req.user.role !== "admin") return res.sendStatus(403);
    const { reason } = req.body;
    const habit = await HabitSubmission.findByIdAndUpdate(req.params.id, {
      status: "rejected",
      rejectionReason: reason,
      adminActionAt: new Date()
    }, { new: true });
    res.json(habit);
  });

  apiRouter.delete("/habits/:id", authenticateToken, async (req: any, res) => {
    if (req.user.role !== "admin") return res.sendStatus(403);
    await HabitSubmission.findByIdAndDelete(req.params.id);
    res.json({ message: "Submission deleted" });
  });

  apiRouter.delete("/tasks/:id", authenticateToken, async (req: any, res) => {
    if (req.user.role !== "admin") return res.sendStatus(403);
    await Task.findByIdAndDelete(req.params.id);
    res.sendStatus(204);
  });

  // --- Feedback ---
  apiRouter.post("/feedback", authenticateToken, async (req: any, res) => {
    const fb = new Feedback({ ...req.body, userId: req.user.id });
    await fb.save();
    res.status(201).json(fb);
  });

  // --- Task Logs ---
  apiRouter.get("/task-logs/:taskId", authenticateToken, async (req: any, res) => {
    const logs = await TaskLog.find({ taskId: req.params.taskId }).sort("-timestamp");
    res.json(logs);
  });

  apiRouter.post("/task-logs", authenticateToken, async (req: any, res) => {
    const log = new TaskLog({ ...req.body, userId: req.user.id });
    await log.save();
    res.status(201).json(log);
  });

  // --- Settings ---
  apiRouter.get("/settings", authenticateToken, async (req: any, res) => {
    let settings = await Settings.findOne({ key: "config" });
    if (!settings) {
      settings = new Settings({ key: "config" });
      await settings.save();
    }
    res.json(settings);
  });

  apiRouter.patch("/settings", authenticateToken, async (req: any, res) => {
    if (req.user.role !== "admin") return res.sendStatus(403);
    const settings = await Settings.findOneAndUpdate({ key: "config" }, req.body, { new: true, upsert: true });
    res.json(settings);
  });

  // --- Notifications ---
  apiRouter.get("/notifications", authenticateToken, async (req: any, res) => {
    const notifications = await Notification.find({ userId: req.user.id }).sort("-createdAt");
    res.json(notifications);
  });

  apiRouter.post("/notifications", authenticateToken, async (req: any, res) => {
    if (req.user.role !== "admin" && req.body.userId !== req.user.id) return res.sendStatus(403);
    const notification = new Notification(req.body);
    await notification.save();
    res.status(201).json(notification);
  });

  apiRouter.patch("/notifications/:id/read", authenticateToken, async (req: any, res) => {
    await Notification.findByIdAndUpdate(req.params.id, { read: true });
    res.sendStatus(204);
  });

  apiRouter.delete("/notifications/:id", authenticateToken, async (req: any, res) => {
    await Notification.findByIdAndDelete(req.params.id);
    res.sendStatus(204);
  });

  // --- Habit Submissions ---
  apiRouter.get("/habits", authenticateToken, async (req: any, res) => {
    let query: any = {};
    if (req.user.role !== "admin") {
      query.userId = req.user.id;
    }
    const habits = await HabitSubmission.find(query).sort("-createdAt");
    res.json(habits);
  });

  apiRouter.post("/habits", authenticateToken, async (req: any, res) => {
    const habit = new HabitSubmission({ ...req.body, userId: req.user.id });
    await habit.save();
    res.status(201).json(habit);
  });

  apiRouter.patch("/habits/:id", authenticateToken, async (req: any, res) => {
    if (req.user.role !== "admin") return res.sendStatus(403);
    const habit = await HabitSubmission.findByIdAndUpdate(req.params.id, { ...req.body, adminActionAt: new Date() }, { new: true });
    res.json(habit);
  });

  // --- Notices ---
  apiRouter.get("/notices", authenticateToken, async (req: any, res) => {
    const notices = await Notice.find().sort("-issuedAt");
    res.json(notices);
  });

  apiRouter.post("/notices", authenticateToken, async (req: any, res) => {
    if (req.user.role !== "admin") return res.sendStatus(403);
    const notice = new Notice(req.body);
    await notice.save();
    res.status(201).json(notice);
  });

  apiRouter.delete("/notices/:id", authenticateToken, async (req: any, res) => {
    if (req.user.role !== "admin") return res.sendStatus(403);
    await Notice.findByIdAndDelete(req.params.id);
    res.json({ message: "Notice deleted" });
  });

  // --- User Passes ---
  apiRouter.get("/passes", authenticateToken, async (req: any, res) => {
    const passes = await UserPass.find({ userId: req.user.id }).sort("-issuedAt");
    res.json(passes);
  });

  apiRouter.get("/passes/:id", authenticateToken, async (req: any, res) => {
    const pass = await UserPass.findById(req.params.id);
    if (!pass) return res.status(404).json({ error: "Pass not found" });
    // Check ownership or admin
    if (req.user.role !== "admin" && pass.userId.toString() !== req.user.id) {
       return res.sendStatus(403);
    }
    res.json(pass);
  });

  apiRouter.post("/passes/:id/use", authenticateToken, async (req: any, res) => {
    // Only admins or workers can use a pass on behalf of a user
    if (req.user.role !== "admin") return res.sendStatus(403);
    
    const pass = await UserPass.findById(req.params.id);
    if (!pass) return res.status(404).json({ error: "Pass not found" });

    if (pass.status === "used" || pass.status === "expired") {
      return res.status(400).json({ error: "Pass is no longer active" });
    }

    pass.usedCount += 1;
    if (pass.usedCount >= pass.usageLimit) {
      pass.status = "used";
    }
    pass.lastUsedAt = new Date().toISOString();
    await pass.save();

    res.json(pass);
  });

  apiRouter.post("/passes", authenticateToken, async (req: any, res) => {
    const pass = new UserPass({ ...req.body, userId: req.user.id });
    await pass.save();
    res.status(201).json(pass);
  });

  // --- Rewards ---
  apiRouter.get("/rewards", async (req, res) => {
    const rewards = await Reward.find();
    res.json(rewards);
  });

  apiRouter.post("/rewards", authenticateToken, async (req: any, res) => {
    if (req.user.role !== "admin") return res.sendStatus(403);
    const reward = new Reward(req.body);
    await reward.save();
    res.status(201).json(reward);
  });

  apiRouter.delete("/rewards/:id", authenticateToken, async (req: any, res) => {
    if (req.user.role !== "admin") return res.sendStatus(403);
    await Reward.findByIdAndDelete(req.params.id);
    res.sendStatus(204);
  });

  // --- Upload Route ---
  apiRouter.post("/upload", authenticateToken, upload.single("image"), (req: any, res) => {
    if (!req.file) return res.status(400).json({ error: "No file uploaded" });
    const url = `${req.protocol}://${req.get("host")}/uploads/${req.file.filename}`;
    res.json({ url });
  });

  apiRouter.get("/feedback", authenticateToken, async (req: any, res) => {
    if (req.user.role !== "admin") return res.sendStatus(403);
    const feedback = await Feedback.find().populate("userId", "name email").sort("-createdAt");
    res.json(feedback);
  });

  apiRouter.delete("/feedback/:id", authenticateToken, async (req: any, res) => {
    if (req.user.role !== "admin") return res.sendStatus(403);
    await Feedback.findByIdAndDelete(req.params.id);
    res.sendStatus(204);
  });
  apiRouter.get("/redeem", authenticateToken, async (req: any, res) => {
    const q: any = {};
    if (req.user.role !== "admin") {
      q.userId = req.user.id;
    } else if (req.query.userId) {
      q.userId = req.query.userId;
    }
    const requests = await RedeemRequest.find(q).sort("-createdAt");
    res.json(requests);
  });

  apiRouter.post("/redeem", authenticateToken, async (req: any, res) => {
    const request = new RedeemRequest({ ...req.body, userId: req.user.id });
    await request.save();
    res.status(201).json(request);
  });

  apiRouter.post("/redeem/:id/approve", authenticateToken, async (req: any, res) => {
    if (req.user.role !== "admin") return res.sendStatus(403);
    
    const session = await mongoose.startSession();
    session.startTransaction();
    try {
      const request = await RedeemRequest.findById(req.params.id).session(session);
      if (!request || request.status !== "pending") throw new Error("Request not found or not pending");

      const user = await User.findById(request.userId).session(session);
      if (!user || user.points < request.points) throw new Error("Insufficient points");

      // 1. Update Request
      request.status = "approved";
      (request as any).updatedAt = new Date();
      await request.save({ session });

      // 2. Deduct Points
      user.points -= request.points;
      await user.save({ session });

      // 3. Create Pass
      const passId = new mongoose.Types.ObjectId().toString();
      const pass = new UserPass({
        userId: user._id,
        userName: user.name,
        rewardTitle: request.rewardTitle,
        rewardType: request.rewardType,
        issuedAt: new Date().toISOString(),
        validFrom: new Date().toISOString(),
        validTill: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days
        qrHash: Math.random().toString(36).substring(7), // Simple hash for now
        status: "active"
      });
      await pass.save({ session });

      // 4. Create Notification
      const notification = new Notification({
        userId: user._id,
        title: "🎉 Your pass is ready!",
        message: `Your request for "${request.rewardTitle}" has been approved.`,
        type: "reward",
        read: false,
        createdAt: new Date()
      });
      await notification.save({ session });

      await session.commitTransaction();
      res.json({ message: "Request approved" });
    } catch (err: any) {
      await session.abortTransaction();
      res.status(400).json({ error: err.message });
    } finally {
      session.endSession();
    }
  });

  apiRouter.post("/redeem/:id/reject", authenticateToken, async (req: any, res) => {
    if (req.user.role !== "admin") return res.sendStatus(403);
    
    const request = await RedeemRequest.findByIdAndUpdate(req.params.id, { 
      status: "rejected", 
      updatedAt: new Date() 
    }, { new: true });
    
    if (request) {
      const notification = new Notification({
        userId: request.userId,
        title: "❌ Redeem request rejected",
        message: `Your reward claim for "${request.rewardTitle}" was rejected.`,
        type: "rejection",
        read: false,
        createdAt: new Date()
      });
      await notification.save();
    }
    
    res.json({ message: "Request rejected" });
  });

  // API Route for sending emails (retained from original)
  apiRouter.post("/send-email", async (req, res) => {
    const { to, subject, html } = req.body;
    console.log(`[EMAIL SIMULATION] To: ${to} | Subject: ${subject}`);
    res.json({ success: true });
  });

  // --- Admin Routes ---
  apiRouter.get("/admin/stats", authenticateToken, async (req: any, res) => {
    if (req.user.role !== "admin") return res.sendStatus(403);
    
    try {
      const [userCount, taskCount, completedCount, pendingCount, feedbackCount] = await Promise.all([
        User.countDocuments(),
        Task.countDocuments(),
        Task.countDocuments({ status: { $in: ["completed", "approved"] } }),
        Task.countDocuments({ status: { $in: ["pending", "submitted"] } }),
        Feedback.countDocuments()
      ]);

      const cleanlinessStats = await Task.aggregate([
        { $group: { _id: "$cleanlinessLevel", count: { $sum: 1 } } }
      ]);

      const cleanliness: any = { clean: 0, moderate: 0, dirty: 0 };
      cleanlinessStats.forEach(s => {
        if (s._id) cleanliness[s._id] = s.count;
      });

      res.json({
        users: userCount,
        tasks: taskCount,
        completedTasks: completedCount,
        pendingTasks: pendingCount,
        totalFeedback: feedbackCount,
        cleanlinessIndex: taskCount > 0 ? Math.round((cleanliness.clean / taskCount) * 100) : 0,
        ...cleanliness
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Catch-all for API routes to prevent falling through to Vite/SPA handler
  apiRouter.use((req, res) => {
    console.warn(`404 API Route Not Found: ${req.method} ${req.originalUrl}`);
    res.status(404).json({ 
      error: "API endpoint not found", 
      path: req.originalUrl,
      method: req.method 
    });
  });

  app.use("/api", apiRouter);

  // 6. Vite/Frontend Middleware Handler
  let vite: any;
  app.use(async (req, res, next) => {
    if (req.path.startsWith("/api") || req.path.startsWith("/uploads")) {
      return next();
    }

    if (process.env.NODE_ENV !== "production") {
      if (vite) {
        return vite.middlewares(req, res, next);
      } else {
        res.setHeader("Content-Type", "text/html");
        return res.status(200).send(`
          <!DOCTYPE html>
          <html>
            <head>
              <title>System Initializing</title>
              <meta http-equiv="refresh" content="3">
              <style>
                body { font-family: system-ui, sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; background: #f3f4f6; color: #374151; }
                .card { background: white; padding: 2rem; border-radius: 0.75rem; box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1); text-align: center; }
              </style>
            </head>
            <body>
              <div class="card">
                <h2>System Initializing</h2>
                <p>The server is up, but the UI is warming up. Please wait...</p>
              </div>
            </body>
          </html>
        `);
      }
    } else {
      next();
    }
  });

  if (process.env.NODE_ENV === "production") {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  // 7. Final Error Handler
  app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
    console.error(`[FATAL ERROR] ${req.method} ${req.url}:`, err);
    res.status(500).json({ error: "Internal Server Error" });
  });

  // 8. Wait for registration promise (no-op now but keeps structure)
  return Promise.resolve(server);
}

startServer().catch(err => {
  console.error("CRITICAL: Failed to start server:", err);
  process.exit(1);
});
