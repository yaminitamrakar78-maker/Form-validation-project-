# Firestore Security Specification

## Data Invariants
1. A user's profile can only be created by the user themselves during registration.
2. The `role` field on a user's profile is immutable by the user after creation (or protected by admin).
3. Points can only be updated via system actions (approved tasks/habits) - in Firestore rules this is tricky without functions, so we'll enforce that only certain fields can be updated by workers and certain by admins.
4. Tasks can be created by admins. Submitted by workers. Approved/Rejected by admins.
5. Notices are created/deleted by admins. Visible to all.
6. Feedback is created by users. Read/Managed by admins.
7. Redeem requests are created by users. Approved/Rejected by admins.
8. Digital passes are created when a redeem request is approved (usually via admin or function, but if direct Firestore, we need careful rules).

## The Dirty Dozen (Attacker Payloads)
1. **The Identity Spoof**: Create a user profile for a different UID.
2. **The Privilege Escalation**: Update own profile to set `role: 'admin'`.
3. **The Point Injection**: Update own profile to increase `points` to 99999.
4. **The Ghost Task**: Create a task as a worker and set status to 'approved'.
5. **The Task Steal**: Worker updates a task they aren't assigned to.
6. **The Pass Forge**: Create a digital pass manually without spending points.
7. **The Notice Sabotage**: Non-admin deleting a city notice.
8. **The PII Scrape**: Non-admin reading all user profiles to get emails/mobile numbers.
9. **The Feedback Tamper**: User updating another user's feedback or marking it resolved.
10. **The Redeem Spam**: Creating thousands of redeem requests to exhaust system resources.
11. **The ID Poisoning**: Using a 1MB string as a document ID.
12. **The Time Travel**: Setting `createdAt` to a date in the past to appear as an early adopter.

## Test Runner (firestore.rules.test.ts)
(Logic for testing will be implemented in the rules generation phase)
