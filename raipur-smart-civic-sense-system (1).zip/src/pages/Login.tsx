import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { LogIn, Loader2, Mail, Lock, ArrowRight, ShieldCheck } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner';
import { api } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import raipurLogo from "@/assets/raipur-logo.png";

export const Login: React.FC = () => {
  const [logoError, setLogoError] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { user, profile, login, resetPassword, signInWithGoogle, isOffline } = useAuth();
  const [apiStatus, setApiStatus] = useState<string | null>(null);
  const [googleLoading, setGoogleLoading] = useState(false);

  useEffect(() => {
    if (isOffline) {
      toast.warning("Network Warning", { 
        description: "Your browser reports being offline. Please check your connection. If you are behind a corporate firewall, Firebase might be blocked.",
        duration: Infinity,
        id: 'offline-toast',
        action: {
          label: 'Retry',
          onClick: () => window.location.reload()
        }
      });
    } else {
      toast.dismiss('offline-toast');
    }
  }, [isOffline]);

  useEffect(() => {
    if (user && profile) {
      console.log(`[Login] Authenticated user detected (${profile.role}), redirecting...`);
      if (profile.role === 'admin') {
        navigate('/admin/dashboard', { replace: true });
      } else {
        navigate('/user/dashboard', { replace: true });
      }
    }
  }, [user, profile, navigate]);

  useEffect(() => {
    const checkApi = async () => {
      try {
        const data = await api.health();
        if (data.status === 'ok') {
          setApiStatus('ok');
        } else {
          setApiStatus('initializing');
        }
      } catch (err) {
        setApiStatus('connecting');
      }
    };
    checkApi();
    const interval = setInterval(checkApi, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await login({ email, password });
      toast.success("Welcome back!", { description: "You have successfully authenticated." });
    } catch (error: any) {
      toast.error("Authentication Failed", { description: error.message });
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setGoogleLoading(true);
    try {
      await signInWithGoogle();
      toast.success("Google Authentication Successful", { description: "Welcome to the Municipal Portal." });
    } catch (error: any) {
      toast.error("Google Login Failed", { description: error.message });
    } finally {
      setGoogleLoading(false);
    }
  };

  const handleForgotPassword = async () => {
    if (!email) {
      toast.error("Email Required", { description: "Please enter your registered email address first." });
      return;
    }
    
    try {
      await resetPassword(email);
      toast.success("Reset Email Sent", { description: "Please check your inbox for password reset instructions." });
    } catch (error: any) {
      toast.error("Reset Failed", { description: error.message });
    }
  };

  return (
    <div className="min-h-screen bg-white flex flex-col">
      {/* Official Top Strip */}
      <div className="bg-[#111827] text-white py-2 px-6 flex justify-between items-center text-[10px] font-black uppercase tracking-[0.2em] relative overflow-hidden shrink-0">
        <div className="absolute inset-0 bg-gradient-to-r from-orange-500/10 via-transparent to-green-500/10" />
        <div className="relative z-10">Raipur Municipal Corporation | Official Gateway</div>
        <div className="relative z-10 hidden sm:block">Govt. of Chhattisgarh</div>
      </div>

      <div className="flex-1 flex flex-col relative overflow-hidden">
        {/* Background Decorative Blur */}
        <div className="absolute top-[20%] left-[-10%] w-[50%] h-[50%] bg-orange-500/5 rounded-full blur-[120px] pointer-events-none" />
        <div className="absolute bottom-[20%] right-[-10%] w-[50%] h-[50%] bg-green-500/5 rounded-full blur-[120px] pointer-events-none" />

        <div className="container mx-auto px-6 flex-1 flex flex-col items-center justify-center py-20 relative z-10">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="w-full max-w-xl"
          >
            {/* Header Branding */}
            <div className="flex flex-col items-center text-center mb-12">
              <Link to="/" className="group mb-8">
                {!logoError ? (
                  <img 
                    src={raipurLogo} 
                    alt="Logo" 
                    className="w-20 h-20 bg-white p-2 rounded-[2rem] shadow-2xl shadow-gray-200 border-2 border-white group-hover:scale-110 transition-transform duration-500" 
                    onError={() => setLogoError(true)}
                  />
                ) : (
                  <div className="w-20 h-20 bg-white rounded-[2rem] flex items-center justify-center text-orange-600 font-black text-2xl shadow-2xl shadow-gray-200 border-2 border-white group-hover:scale-110 transition-transform duration-500">RMC</div>
                )}
              </Link>
              <h1 className="text-4xl md:text-5xl font-black text-[#111827] tracking-tight uppercase leading-none mb-4">
                Personnel <span className="text-orange-500">Portal</span>
              </h1>
              <p className="text-sm font-bold text-gray-400 uppercase tracking-[0.3em]">Official Access Gateway</p>
            </div>

            {/* Login Card */}
            <div className="bg-white rounded-[3rem] p-10 md:p-14 border border-gray-100 shadow-2xl shadow-gray-200/50 relative overflow-hidden group">
              <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-orange-500 via-white to-green-500 opacity-20" />
              
              <div className="mb-10 text-center">
                <h2 className="text-xl font-black text-[#111827] tracking-tighter uppercase mb-2">Secure Authentication</h2>
                <p className="text-gray-400 text-sm font-medium">Verify your official credentials to proceed.</p>
              </div>

              {apiStatus && apiStatus !== 'ok' && (
                <div className="mb-8 flex items-center justify-center gap-3 p-4 bg-gray-50 border border-gray-100 rounded-3xl animate-pulse">
                  <div className="w-2 h-2 bg-orange-500 rounded-full animate-ping" />
                  <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest">
                    System Protocol: {apiStatus.toUpperCase()}
                  </span>
                </div>
              )}

              <form onSubmit={handleLogin} className="space-y-6">
                <div>
                  <label className="text-[10px] font-black text-[#111827] uppercase tracking-widest ml-4 mb-2 block">Official Email ID</label>
                  <div className="relative group/input">
                    <Mail className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-300 group-focus-within/input:text-orange-500 transition-colors" size={20} />
                    <input
                      required
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full pl-16 pr-8 py-5 bg-gray-50 border-2 border-transparent rounded-[2rem] font-bold text-[#111827] outline-none transition-all focus:border-orange-500 focus:bg-white placeholder:text-gray-300"
                      placeholder="name@rmc.gov.in"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between items-center ml-4 mb-2">
                    <label className="text-[10px] font-black text-[#111827] uppercase tracking-widest block">Access Password</label>
                    <button 
                      type="button" 
                      onClick={handleForgotPassword}
                      className="text-[9px] font-black text-orange-600 hover:text-orange-700 uppercase tracking-widest transition-colors"
                    >
                      Recovery?
                    </button>
                  </div>
                  <div className="relative group/input">
                    <Lock className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-300 group-focus-within/input:text-orange-500 transition-colors" size={20} />
                    <input
                      required
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full pl-16 pr-8 py-5 bg-gray-50 border-2 border-transparent rounded-[2rem] font-bold text-[#111827] outline-none transition-all focus:border-orange-500 focus:bg-white placeholder:text-gray-300"
                      placeholder="••••••••"
                    />
                  </div>
                </div>

                <div className="pt-4 space-y-6">
                  <button
                    type="submit"
                    disabled={loading || googleLoading}
                    className="w-full bg-[#111827] text-white py-6 rounded-[2rem] font-black uppercase tracking-[0.3em] text-[11px] transition-all hover:bg-black active:scale-95 shadow-2xl shadow-gray-200 flex items-center justify-center gap-4 group"
                  >
                    {loading ? (
                      <Loader2 className="animate-spin" size={20} />
                    ) : (
                      <>
                        <LogIn size={20} />
                        Authorize Secure Session
                      </>
                    )}
                  </button>

                  <div className="relative">
                    <div className="absolute inset-0 flex items-center">
                      <div className="w-full border-t border-gray-100"></div>
                    </div>
                    <div className="relative flex justify-center">
                      <span className="bg-white px-6 text-[9px] font-black text-gray-300 uppercase tracking-[0.4em]">Official Federation</span>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={handleGoogleLogin}
                    disabled={loading || googleLoading}
                    className="w-full bg-white border-2 border-gray-100 text-[#111827] py-5 rounded-[2rem] font-black uppercase tracking-[0.2em] text-[10px] transition-all hover:border-orange-500 hover:bg-orange-50/5 active:scale-95 flex items-center justify-center gap-4 group shadow-sm"
                  >
                    {googleLoading ? (
                      <Loader2 className="animate-spin text-orange-500" size={18} />
                    ) : (
                      <>
                        <svg className="w-5 h-5 group-hover:scale-110 transition-transform" viewBox="0 0 24 24">
                          <path
                            d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                            fill="#4285F4"
                          />
                          <path
                            d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                            fill="#34A853"
                          />
                          <path
                            d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                            fill="#FBBC05"
                          />
                          <path
                            d="M12 5.38c1.62 0 3.06.56 4.21 1.66l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                            fill="#EA4335"
                          />
                        </svg>
                        Network Sign In
                      </>
                    )}
                  </button>
                </div>
              </form>

              <div className="mt-12 text-center">
                <p className="text-[11px] font-bold text-gray-400 uppercase tracking-widest">
                  Not Enrolled Yet?{' '}
                  <Link to="/register" className="text-green-600 hover:text-green-700 font-black ml-2 underline underline-offset-4 transition-colors">
                    Initialize Enrollment
                  </Link>
                </p>
              </div>
            </div>

            {/* Verification Footer */}
            <div className="mt-12 flex items-center justify-center gap-10">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-orange-50 flex items-center justify-center">
                  <ShieldCheck className="text-orange-600" size={20} />
                </div>
                <div className="flex flex-col">
                  <span className="text-[9px] font-black text-[#111827] uppercase tracking-widest leading-none">Encrypted</span>
                  <span className="text-[8px] font-bold text-gray-400 uppercase tracking-widest mt-1">SSL Protected</span>
                </div>
              </div>
              <div className="w-px h-8 bg-gray-100" />
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-green-50 flex items-center justify-center">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                </div>
                <div className="flex flex-col">
                  <span className="text-[9px] font-black text-[#111827] uppercase tracking-widest leading-none">Status</span>
                  <span className="text-[8px] font-bold text-gray-400 uppercase tracking-widest mt-1">Infrastructure Active</span>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

