// Merit Rewards Page
import React, { useState, useEffect } from 'react';
import { api } from '../../lib/api';
import { useAuth } from '../../context/AuthContext';
import { RedeemRequest } from '../../types';
import { Gift, Star, Clock, CheckCircle2, XCircle, ChevronRight, Wallet, Ticket, AlertCircle, Timer } from 'lucide-react';
import { motion } from 'motion/react';
import { cn, safeGetDate } from '../../lib/utils';
import { REWARDS } from '../../constants';
import { toast } from 'sonner';

export const WorkerRewards: React.FC = () => {
  const { profile } = useAuth();
  const [requests, setRequests] = useState<RedeemRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const fetchRewards = async () => {
    if (!profile) return;
    setLoading(true);
    try {
      const data = await api.redeem.getAll(profile?.uid);
      setRequests(data);
    } catch (error) {
      console.error("Fetch rewards failed:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRewards();
  }, [(profile as any)?.uid || (profile as any)?._id]);

  const handleRedeem = async (reward: typeof REWARDS[0]) => {
    if (!profile) return;
    setIsSubmitting(true);
    
    try {
      if (profile.points < reward.points) {
        toast.error("Insufficient points balance!");
        setIsSubmitting(false);
        return;
      }

      await api.redeem.create({
        userName: profile.name,
        rewardId: reward.id,
        rewardTitle: reward.title,
        rewardType: reward.type,
        points: reward.points,
        usageLimit: reward.usageLimit,
        validDurationDays: reward.validDurationDays,
      });

      // Notify admin
      await api.notifications.create({
        userId: 'admin',
        title: 'New Redeem Request',
        message: `${profile.name} requested ${reward.title}`,
        type: 'info'
      });

      toast.success('Redemption Request Sent!', {
        description: 'Waiting for admin approval. Points will be deducted after approval.',
        icon: <Clock className="text-amber-500" />
      });
      fetchRewards();
    } catch (error: any) {
      console.error("Redeem error:", error);
      toast.error("Failed to submit request");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto pb-12">
      {/* Header with Balance */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-[#111827] text-white p-6 md:p-10 rounded-[2.5rem] relative overflow-hidden mb-10 shadow-2xl shadow-green-900/10"
      >
        <div className="relative z-10 flex flex-col md:flex-row md:items-center gap-6">
          <div className="w-16 h-16 flex items-center justify-center bg-white rounded-full shadow-lg border border-white/20 p-1 hidden sm:flex text-green-600">
            <Gift size={32} />
          </div>
          <div>
            <div className="flex items-center gap-2 text-green-400 text-[10px] font-black uppercase tracking-[0.2em] mb-4">
               <div className="w-5 h-5 rounded-full bg-green-400/20 flex items-center justify-center">
                 <Star size={10} fill="currentColor" />
               </div>
               Merit Rewards Program
            </div>
            <h2 className="text-3xl md:text-5xl font-black mb-1 tracking-tight leading-tight uppercase">Raipur Municipal Corporation</h2>
            <p className="text-orange-500 font-bold uppercase tracking-widest text-sm mb-8">Smart Civic Sense System</p>
            <div className="inline-flex flex-col bg-white/5 backdrop-blur-md border border-white/10 p-6 rounded-3xl">
              <span className="text-sm text-gray-400 font-bold uppercase tracking-widest mb-1">Available Balance</span>
              <div className="flex items-baseline gap-2">
                <span className="text-5xl font-black text-white">{profile?.points?.toLocaleString() || 0}</span>
                <span className="text-green-400 font-bold text-lg">PTS</span>
              </div>
            </div>
          </div>
        </div>
        
        {/* Background Graphic */}
        <div className="absolute right-0 top-0 bottom-0 w-1/2 bg-gradient-to-l from-green-500/10 to-transparent"></div>
        <div className="absolute -right-12 top-1/2 -translate-y-1/2 opacity-5 blur-sm rotate-12">
            <Wallet size={300} />
        </div>
      </motion.div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-10 items-start">
        <div className="xl:col-span-2 space-y-10">
          {/* Info Card */}
          <section className="bg-white p-8 md:p-10 rounded-[3rem] border border-gray-100 shadow-xl shadow-gray-200/20">
            <div className="flex items-center gap-4 mb-4">
               <div className="w-12 h-12 rounded-2xl bg-indigo-50 flex items-center justify-center text-indigo-600 shadow-inner">
                  <Ticket size={24} />
               </div>
               <div>
                 <h3 className="text-xl font-black text-[#111827] uppercase tracking-tight">Smart Digital Passes</h3>
                 <p className="text-gray-400 text-xs font-medium">Earn point through civic actions and redeem for travel, parking, and leisure.</p>
               </div>
            </div>
            <div className="flex items-center gap-2 mt-2 p-4 bg-blue-50 rounded-2xl text-[10px] font-bold text-blue-700 uppercase tracking-widest border border-blue-100/50">
               <Timer size={14} /> 
               Approved redemptions generate a secure, scannable QR pass in your "My Passes" section.
            </div>
          </section>

          {/* Available Rewards */}
          <section className="space-y-6">
            <div className="flex items-center justify-between px-2">
              <h3 className="text-2xl font-black text-[#111827] tracking-tight">Voucher Store</h3>
              <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-[10px] font-black tracking-widest uppercase">Ecosystem Partners</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {REWARDS.map((reward, idx) => (
                <motion.div 
                  key={reward.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  className="bg-white p-6 rounded-[2.5rem] border border-gray-100 shadow-sm flex flex-col justify-between group hover:border-indigo-400 hover:shadow-xl hover:shadow-indigo-900/5 transition-all duration-300"
                >
                  <div>
                    <div className={cn(
                      "w-16 h-16 rounded-2xl flex items-center justify-center text-3xl mb-6 transition-colors shadow-inner",
                      reward.type === 'bus' ? "bg-blue-50 text-blue-600" :
                      reward.type === 'parking' ? "bg-amber-50 text-amber-600" :
                      reward.type === 'movie' ? "bg-rose-50 text-rose-600" : "bg-purple-50 text-purple-600"
                    )}>
                      {reward.type === 'bus' ? '🚌' : reward.type === 'parking' ? '🅿️' : reward.type === 'movie' ? '🎬' : '🎪'}
                    </div>
                    <h4 className="text-lg font-black text-gray-900 mb-2 leading-tight">{reward.title}</h4>
                    <p className="text-sm text-gray-400 font-medium mb-6 leading-relaxed line-clamp-2">{reward.description}</p>
                  </div>
                  
                  <div className="flex items-center justify-between pt-4 border-t border-gray-50">
                    <div className="flex flex-col">
                      <span className="text-[10px] text-gray-400 font-black uppercase tracking-widest mb-0.5">Price</span>
                      <span className="text-indigo-600 text-xl font-black">{reward.points} <span className="text-[10px]">PTS</span></span>
                    </div>
                    <button
                      onClick={() => handleRedeem(reward)}
                      disabled={isSubmitting || (profile?.points || 0) < reward.points}
                      className={cn(
                        "px-6 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all",
                        (profile?.points || 0) >= reward.points
                          ? "bg-indigo-600 text-white hover:bg-black shadow-lg shadow-indigo-100 active:scale-95"
                          : "bg-gray-100 text-gray-400 cursor-not-allowed"
                      )}
                    >
                      Redeem
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>
          </section>
        </div>

        {/* Recent Requests Sidebar */}
        <aside className="xl:col-span-1 xl:sticky xl:top-8 self-start">
          <div className="bg-white rounded-[3rem] border border-gray-100 shadow-2xl shadow-gray-200/40 overflow-hidden flex flex-col">
            <div className="p-8 border-b border-gray-50 flex items-center justify-between bg-gray-50/50">
              <h3 className="text-xl font-black text-[#111827] tracking-tight">Recent History</h3>
              <Clock className="text-gray-300" size={20} />
            </div>
            
            <div className="overflow-y-auto max-h-[500px] xl:max-h-[800px] divide-y divide-gray-50 custom-scrollbar">
              {loading ? (
                 <div className="p-8 space-y-6">
                   {[1, 2, 3, 4].map(i => (
                     <div key={i} className="flex items-center justify-between animate-pulse">
                       <div className="flex items-center gap-4">
                         <div className="w-12 h-12 bg-gray-100 rounded-2xl"></div>
                         <div className="space-y-2">
                           <div className="h-4 w-28 bg-gray-100 rounded"></div>
                           <div className="h-3 w-16 bg-gray-50 rounded"></div>
                         </div>
                       </div>
                       <div className="h-8 w-16 bg-gray-100 rounded-full"></div>
                     </div>
                   ))}
                 </div>
              ) : requests.length === 0 ? (
                 <div className="p-16 text-center">
                   <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4">
                     <Clock className="text-gray-300" size={32} />
                   </div>
                   <p className="text-gray-400 font-bold text-sm tracking-tight">No redemptions found in<br />your history.</p>
                 </div>
              ) : (
                <div className="divide-y divide-gray-50">
                    {requests.map((req) => (
                        <div key={(req as any)._id || req.id} className="p-6 flex flex-col gap-4 hover:bg-gray-50 transition-colors">
                            <div className="flex items-start justify-between">
                                <div className="flex items-center gap-4">
                                    <div className={cn(
                                        "w-12 h-12 rounded-2xl flex items-center justify-center shadow-inner shrink-0",
                                        req.status === 'approved' ? "bg-green-50 text-green-600" :
                                        req.status === 'rejected' ? "bg-rose-50 text-rose-600" : "bg-amber-50 text-amber-600"
                                    )}>
                                        {req.status === 'approved' ? <CheckCircle2 size={24} /> :
                                         req.status === 'rejected' ? <XCircle size={24} /> : <Clock size={24} />}
                                    </div>
                                    <div className="min-w-0">
                                        <p className="font-black text-gray-900 leading-tight mb-1 truncate text-sm">
                                          {req.rewardTitle || `${req.points} Points Redeem`}
                                        </p>
                                        <div className="flex items-center gap-2">
                                          <span className="text-[10px] font-mono text-gray-400 bg-gray-100 px-1.5 py-0.5 rounded">
                                            {req.createdAt ? safeGetDate(req.createdAt).toLocaleDateString() : '...'}
                                          </span>
                                          <span className="text-[10px] font-mono text-gray-400">
                                            {req.createdAt ? safeGetDate(req.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : ''}
                                          </span>
                                        </div>
                                    </div>
                                </div>
                                <div className="text-right shrink-0">
                                  <span className="text-sm font-black text-gray-900 block leading-none">-{req.points}</span>
                                  <span className="text-[8px] font-bold text-gray-400 uppercase tracking-widest">PTS</span>
                                </div>
                            </div>
                            
                            <div className={cn(
                                "text-[9px] font-black uppercase tracking-[0.15em] px-4 py-2 rounded-xl border flex items-center gap-2 w-full justify-center",
                                req.status === 'approved' ? "bg-green-50 text-green-700 border-green-100" :
                                req.status === 'rejected' ? "bg-rose-50 text-rose-700 border-rose-100" : 
                                "bg-amber-50 text-amber-700 border-amber-100 shadow-inner"
                            )}>
                                <div className={cn(
                                  "w-1.5 h-1.5 rounded-full",
                                  req.status === 'approved' ? "bg-green-500" :
                                  req.status === 'rejected' ? "bg-rose-500" : "bg-amber-500 animate-pulse"
                                )} />
                                {req.status === 'pending' ? 'Verification in progress' : 
                                 req.status === 'approved' ? 'Claim Fulfilled' : 'Request Rejected'}
                            </div>
                        </div>
                    ))}
                </div>
              )}
            </div>
            <div className="p-6 bg-gray-50/50 border-t border-gray-100">
               <p className="text-[10px] text-center text-gray-400 font-bold uppercase tracking-[0.2em]">End of recent history</p>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
};

export default WorkerRewards;
