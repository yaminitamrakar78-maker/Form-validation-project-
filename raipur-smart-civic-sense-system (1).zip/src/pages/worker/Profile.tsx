import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../lib/api';
import { 
  User, 
  Mail, 
  Phone, 
  MapPin, 
  Hash, 
  Calendar, 
  Edit3, 
  Save, 
  Camera, 
  Trophy, 
  Star, 
  Flame, 
  CheckCircle2, 
  History,
  Loader2,
  Award,
  Zap,
  ChevronRight,
  ShieldCheck,
  MessageSquare,
  Sparkles,
  Globe,
  Briefcase
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn, safeGetDate, compressImage } from '../../lib/utils';
import { format } from 'date-fns';
import { toast } from 'sonner';

export const Profile: React.FC = () => {
  const { profile, user: authUser } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: profile?.name || '',
    mobile: profile?.mobile || '',
    address: profile?.address || '',
    city: profile?.city || '',
    wardNumber: profile?.wardNumber || '',
    profession: profile?.profession || '',
  });
  const [recentActivity, setRecentActivity] = useState<any[]>([]);
  const [activityLoading, setActivityLoading] = useState(true);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (profile) {
      setFormData({
        name: profile.name || '',
        mobile: profile.mobile || '',
        address: profile.address || '',
        city: profile.city || 'Raipur',
        wardNumber: profile.wardNumber || '',
        profession: profile.profession || '',
      });
      fetchActivity();
    }
  }, [profile]);

  const fetchActivity = async () => {
    if (!profile?.uid) return;
    setActivityLoading(true);
    try {
      const [tasks, habits, redeems] = await Promise.all([
        api.tasks.getAll(profile.uid),
        api.habits.getAll(profile.uid),
        api.redeem.getAll(profile.uid)
      ]);

      const activities = [
        ...tasks.map((t: any) => ({
          id: t.id,
          type: 'task',
          title: t.title,
          date: t.createdAt,
          status: t.status,
          points: t.pointsValue
        })),
        ...habits.map((h: any) => ({
          id: h.id,
          type: 'habit',
          title: h.taskTitle,
          date: h.createdAt,
          status: h.status,
          points: h.points
        })),
        ...redeems.map((r: any) => ({
          id: r.id,
          type: 'redeem',
          title: `Redeem: ${r.rewardTitle}`,
          date: r.createdAt,
          status: r.status,
          points: -r.points
        }))
      ].sort((a, b) => safeGetDate(b.date).getTime() - safeGetDate(a.date).getTime()).slice(0, 10);

      setRecentActivity(activities);
    } catch (error) {
      console.error("Error fetching activity:", error);
    } finally {
      setActivityLoading(false);
    }
  };

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile?.uid) return;

    // Validation
    if (!formData.name || !formData.mobile || !formData.address || !formData.wardNumber || !formData.city || !formData.profession) {
      toast.error("All identification fields are mandatory");
      return;
    }

    if (!/^\d{10}$/.test(formData.mobile)) {
      toast.error("Mobile number must be exactly 10 digits");
      return;
    }

    setLoading(true);
    try {
      await api.users.updateProfile(formData);
      toast.success("Profile records synchronized successfully");
      setIsEditing(false);
    } catch (error) {
      console.error("Profile update failed:", error);
      toast.error("Failed to update profile");
    } finally {
      setLoading(false);
    }
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !profile?.uid) return;

    try {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64 = reader.result as string;
        const compressed = await compressImage(base64, 400, 0.6);
        setLoading(true);
        try {
          await api.users.updateProfile({ photoUrl: compressed });
          toast.success("Identity portrait updated");
        } catch (error) {
          console.error("Photo upload failed:", error);
          toast.error("Failed to update photo");
        } finally {
          setLoading(false);
        }
      };
      reader.readAsDataURL(file);
    } catch (error) {
      toast.error("Portrait processing failed");
    }
  };

  const getRankBadge = (points: number) => {
    if (points >= 1000) return { label: 'Civic Legend', icon: Trophy, color: 'text-amber-500', bg: 'bg-amber-50' };
    if (points >= 500) return { label: 'Swachh Hero', icon: Award, color: 'text-indigo-500', bg: 'bg-indigo-50' };
    if (points >= 200) return { label: 'Elite Citizen', icon: Zap, color: 'text-emerald-500', bg: 'bg-emerald-50' };
    return { label: 'Rising Citizen', icon: Star, color: 'text-blue-500', bg: 'bg-blue-50' };
  };

  const rank = getRankBadge(profile?.points || 0);

  return (
    <div className="space-y-8 pb-12">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h2 className="text-3xl font-black text-[#111827] tracking-tight uppercase">Identity Management</h2>
          <p className="text-[#6B7280] mt-1 font-bold uppercase tracking-widest text-[9px]">Raipur Municipal Corporation | Personal Portal</p>
        </div>
        {!isEditing ? (
          <button 
            onClick={() => setIsEditing(true)}
            className="flex items-center gap-2 px-6 py-3 bg-[#111827] text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-black transition-all shadow-xl shadow-gray-200"
          >
            <Edit3 size={14} />
            Modify Profile
          </button>
        ) : (
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setIsEditing(false)}
              className="px-6 py-3 bg-gray-50 text-gray-500 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-gray-100 transition-all"
            >
              Cancel
            </button>
            <button 
              form="profile-form"
              type="submit"
              disabled={loading}
              className="flex items-center gap-2 px-6 py-3 bg-green-600 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-green-700 transition-all shadow-xl shadow-green-200"
            >
              {loading ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />}
              Persist Changes
            </button>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Profile Card & Stats */}
        <div className="lg:col-span-1 space-y-8">
          {/* Identity Card */}
          <div className="bg-white p-8 rounded-[3rem] border border-gray-100 shadow-xl relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-64 h-64 bg-green-50/50 rounded-full -mr-32 -mt-32 blur-3xl pointer-events-none group-hover:bg-green-100/50 transition-colors"></div>
            
            <div className="relative flex flex-col items-center">
              <div className="relative mb-6">
                <div className="w-32 h-32 rounded-[2.5rem] bg-gray-100 border-4 border-white shadow-2xl overflow-hidden group/photo">
                  {profile?.photoUrl ? (
                    <img src={profile.photoUrl} alt={profile.name} className="w-full h-full object-cover transition-transform duration-500 group-hover/photo:scale-110" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-4xl font-black text-gray-300">
                      {profile?.name.charAt(0)}
                    </div>
                  )}
                  <button 
                    onClick={() => fileInputRef.current?.click()}
                    className="absolute inset-0 bg-black/40 opacity-0 group-hover/photo:opacity-100 transition-opacity flex flex-col items-center justify-center text-white gap-2"
                  >
                    <Camera size={24} />
                    <span className="text-[8px] font-black uppercase tracking-widest">Change</span>
                  </button>
                  <input 
                    type="file" 
                    ref={fileInputRef}
                    onChange={handlePhotoUpload}
                    accept="image/*"
                    className="hidden"
                  />
                </div>
                <div className="absolute -bottom-2 -right-2 w-10 h-10 bg-green-500 rounded-2xl flex items-center justify-center text-white shadow-lg border-4 border-white">
                  <ShieldCheck size={18} />
                </div>
              </div>

              <div className="text-center">
                <h3 className="text-2xl font-black text-[#111827] tracking-tight truncate max-w-full">{profile?.name}</h3>
                <div className="flex items-center justify-center gap-1.5 mt-1">
                  <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                  <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{profile?.role} Clearance</span>
                </div>
              </div>

              {/* Rank Badge */}
              <div className={cn("mt-6 px-6 py-3 rounded-2xl flex items-center gap-3 border transition-all", rank.bg, "border-transparent hover:border-current")}>
                 <rank.icon className={cn("text-xl", rank.color)} />
                 <div className="text-left">
                   <p className="text-[8px] font-black text-gray-400 uppercase tracking-widest leading-none mb-0.5">Current Rank</p>
                   <p className={cn("text-sm font-black uppercase tracking-tight", rank.color)}>{rank.label}</p>
                 </div>
              </div>
            </div>

            <div className="mt-8 pt-8 border-t border-gray-50 space-y-4">
              <div className="flex items-center gap-4 text-gray-500">
                <div className="w-8 h-8 rounded-lg bg-gray-50 flex items-center justify-center text-gray-400">
                  <Mail size={14} />
                </div>
                <span className="text-xs font-bold truncate">{profile?.email}</span>
              </div>
              <div className="flex items-center gap-4 text-gray-500">
                <div className="w-8 h-8 rounded-lg bg-gray-50 flex items-center justify-center text-gray-400">
                  <Calendar size={14} />
                </div>
                <span className="text-xs font-bold">Joined {profile?.createdAt ? format(safeGetDate(profile.createdAt), 'MMM yyyy') : '--'}</span>
              </div>
            </div>
          </div>

          {/* Quick Stats Grid */}
          <div className="grid grid-cols-2 gap-4">
             <div className="bg-white p-5 rounded-[2rem] border border-gray-100 shadow-sm group hover:scale-[1.02] transition-all">
                <div className="w-10 h-10 bg-orange-50 rounded-xl flex items-center justify-center text-orange-600 mb-3 group-hover:bg-orange-500 group-hover:text-white transition-all">
                  <Star size={20} className="fill-current" />
                </div>
                <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest">Total Points</p>
                <p className="text-xl font-black text-[#111827]">{profile?.points || 0}</p>
             </div>
             <div className="bg-white p-5 rounded-[2rem] border border-gray-100 shadow-sm group hover:scale-[1.02] transition-all">
                <div className="w-10 h-10 bg-emerald-50 rounded-xl flex items-center justify-center text-emerald-600 mb-3 group-hover:bg-emerald-500 group-hover:text-white transition-all">
                  <CheckCircle2 size={20} />
                </div>
                <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest">Tasks Done</p>
                <p className="text-xl font-black text-[#111827]">{profile?.tasksCompleted || 0}</p>
             </div>
             <div className="bg-white p-5 rounded-[2rem] border border-gray-100 shadow-sm group hover:scale-[1.02] transition-all">
                <div className="w-10 h-10 bg-amber-50 rounded-xl flex items-center justify-center text-amber-600 mb-3 group-hover:bg-amber-500 group-hover:text-white transition-all">
                  <Flame size={20} className="fill-current" />
                </div>
                <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest">Current Streak</p>
                <p className="text-xl font-black text-[#111827]">{profile?.currentStreak || 0} Days</p>
             </div>
             <div className="bg-white p-5 rounded-[2rem] border border-gray-100 shadow-sm group hover:scale-[1.02] transition-all">
                <div className="w-10 h-10 bg-rose-50 rounded-xl flex items-center justify-center text-rose-600 mb-3 group-hover:bg-rose-500 group-hover:text-white transition-all">
                  <MessageSquare size={20} />
                </div>
                <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest">Complaints</p>
                <p className="text-xl font-black text-[#111827]">{profile?.complaintsSubmitted || 0}</p>
             </div>
          </div>
        </div>

        {/* Right Column: Information & Activity */}
        <div className="lg:col-span-2 space-y-8">
          {/* Information Form */}
          <div className="bg-white p-10 rounded-[3rem] border border-gray-100 shadow-xl">
             <div className="flex items-center gap-3 mb-8">
               <div className="w-10 h-10 rounded-2xl bg-[#111827] flex items-center justify-center text-white">
                 <User size={20} />
               </div>
               <h3 className="text-xl font-black text-[#111827] uppercase tracking-tight">Professional Records</h3>
             </div>

             <form id="profile-form" onSubmit={handleUpdateProfile} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] ml-2">Full Name</label>
                    <div className="relative">
                      <User className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-300" size={18} />
                      <input 
                        type="text" 
                        disabled={!isEditing}
                        value={formData.name}
                        onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                        className="w-full pl-12 pr-4 py-4 bg-gray-50/50 border-2 border-transparent rounded-2xl focus:border-green-500 focus:bg-white transition-all font-bold disabled:opacity-70"
                        placeholder="Authorized Name"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] ml-2">Mobile Contact</label>
                    <div className="relative">
                      <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-300" size={18} />
                      <input 
                        type="tel" 
                        disabled={!isEditing}
                        value={formData.mobile}
                        onChange={(e) => setFormData(prev => ({ ...prev, mobile: e.target.value }))}
                        className="w-full pl-12 pr-4 py-4 bg-gray-50/50 border-2 border-transparent rounded-2xl focus:border-green-500 focus:bg-white transition-all font-bold disabled:opacity-70"
                        placeholder="+91 XXXXX XXXXX"
                      />
                    </div>
                  </div>
                  <div className="space-y-2 md:col-span-1">
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] ml-2">Ward Number</label>
                    <div className="relative">
                      <Hash className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-300" size={18} />
                      <input 
                        type="text" 
                        disabled={!isEditing}
                        value={formData.wardNumber}
                        onChange={(e) => setFormData(prev => ({ ...prev, wardNumber: e.target.value }))}
                        className="w-full pl-12 pr-4 py-4 bg-gray-50/50 border-2 border-transparent rounded-2xl focus:border-green-500 focus:bg-white transition-all font-bold disabled:opacity-70"
                        placeholder="RMC Ward No."
                      />
                    </div>
                  </div>
                  <div className="space-y-2 md:col-span-1">
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] ml-2 text-indigo-600">Profession / Occupation</label>
                    <div className="relative">
                      <Briefcase className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-300" size={18} />
                      <input 
                        type="text" 
                        disabled={!isEditing}
                        value={formData.profession}
                        onChange={(e) => setFormData(prev => ({ ...prev, profession: e.target.value }))}
                        className="w-full pl-12 pr-4 py-4 bg-gray-50/50 border-2 border-transparent rounded-2xl focus:border-indigo-500 focus:bg-white transition-all font-bold disabled:opacity-70"
                        placeholder="e.g. Student, Teacher, Engineer"
                      />
                    </div>
                  </div>
                  <div className="space-y-2 md:col-span-1">
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] ml-2 text-indigo-600">City / Municipality</label>
                    <div className="relative">
                      <Globe className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-300" size={18} />
                      <input 
                        type="text" 
                        disabled={!isEditing}
                        value={formData.city}
                        onChange={(e) => setFormData(prev => ({ ...prev, city: e.target.value }))}
                        className="w-full pl-12 pr-4 py-4 bg-gray-50/50 border-2 border-transparent rounded-2xl focus:border-indigo-500 focus:bg-white transition-all font-bold disabled:opacity-70"
                        placeholder="Authorized City (e.g. Raipur)"
                      />
                    </div>
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] ml-2">Residential / Office Address</label>
                  <div className="relative">
                    <MapPin className="absolute left-4 top-10 -translate-y-1/2 text-gray-300" size={18} />
                    <textarea 
                      disabled={!isEditing}
                      value={formData.address}
                      onChange={(e) => setFormData(prev => ({ ...prev, address: e.target.value }))}
                      className="w-full pl-12 pr-4 py-4 bg-gray-50/50 border-2 border-transparent rounded-2xl focus:border-green-500 focus:bg-white transition-all font-bold disabled:opacity-70 min-h-[120px] resize-none"
                      placeholder="Complete residential coordinates strictly inside Raipur limits..."
                    ></textarea>
                  </div>
                </div>
             </form>
          </div>

          {/* User Activity Section */}
          <div className="bg-white p-10 rounded-[3rem] border border-gray-100 shadow-xl overflow-hidden relative">
            <div className="flex items-center justify-between mb-8">
               <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-amber-50 flex items-center justify-center text-amber-600">
                    <History size={20} />
                  </div>
                  <h3 className="text-xl font-black text-[#111827] uppercase tracking-tight">Civic Activity Log</h3>
               </div>
               <button className="text-[9px] font-black text-gray-400 hover:text-green-600 uppercase tracking-[0.2em] transition-colors">Audit Full Logs</button>
            </div>

            <div className="space-y-4">
              {activityLoading ? (
                <div className="p-10 flex flex-col items-center justify-center gap-4">
                  <Loader2 className="animate-spin text-green-600" size={32} />
                  <p className="text-[9px] font-black text-gray-400 uppercase tracking-[0.2em]">Synchronizing Records...</p>
                </div>
              ) : recentActivity.length === 0 ? (
                <div className="p-10 text-center space-y-3">
                  <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center text-gray-200 mx-auto">
                    <History size={32} />
                  </div>
                  <p className="text-gray-400 font-bold">No recent civic deployment history found.</p>
                </div>
              ) : (
                recentActivity.map((activity) => (
                  <div key={activity.id} className="group flex items-center gap-5 p-5 bg-gray-50 rounded-3xl border border-gray-100/50 hover:bg-white hover:shadow-xl hover:shadow-gray-100 transition-all">
                    <div className={cn(
                      "w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 shadow-sm",
                      activity.type === 'task' ? "bg-green-100 text-green-600" : 
                      activity.type === 'habit' ? "bg-amber-100 text-amber-600" :
                      "bg-indigo-100 text-indigo-600"
                    )}>
                      {activity.type === 'task' ? <CheckCircle2 size={24} /> : 
                       activity.type === 'habit' ? <Sparkles size={24} /> :
                       <Zap size={24} />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-[8px] font-black uppercase tracking-widest text-gray-400">
                          {activity.type === 'task' ? 'Municipal Task' : 
                           activity.type === 'habit' ? 'Daily Habit' : 
                           'Reward Redemption'}
                        </span>
                        <div className="w-1 h-1 rounded-full bg-gray-200" />
                        <span className="text-[8px] font-black uppercase tracking-widest text-gray-400">
                          {activity.date ? format(safeGetDate(activity.date), 'MMM dd, HH:mm') : 'Recently'}
                        </span>
                      </div>
                      <h4 className="text-sm font-black text-gray-800 uppercase tracking-tight group-hover:text-[#111827] transition-colors truncate">{activity.title}</h4>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="text-right flex flex-col items-end gap-1">
                        <span className={cn(
                          "px-3 py-1 rounded-full text-[8px] font-black uppercase tracking-widest",
                          activity.status === 'approved' ? "bg-green-100 text-green-700" : 
                          activity.status === 'rejected' ? "bg-rose-100 text-rose-700" : 
                          "bg-blue-100 text-blue-700"
                        )}>
                          {activity.status}
                        </span>
                        {activity.points && (
                          <span className={cn(
                            "text-[10px] font-black tabular-nums",
                            activity.points > 0 ? "text-green-600" : "text-rose-600"
                          )}>
                            {activity.points > 0 ? '+' : ''}{activity.points}
                          </span>
                        )}
                      </div>
                      <ChevronRight size={16} className="text-gray-300 group-hover:translate-x-1 group-hover:text-green-500 transition-all" />
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
