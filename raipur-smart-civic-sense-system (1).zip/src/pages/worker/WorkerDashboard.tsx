import React, { useState, useEffect } from 'react';
import { Trophy, CheckCircle2, Star, Clock, Loader2, ArrowRight, AlertTriangle, Ticket, Flame, Sparkles, PartyPopper, Bell, LayoutDashboard } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { api } from '../../lib/api';
import { Link } from 'react-router-dom';
import { Notice } from '../../types';
import { cn } from '../../lib/utils';
import { DailyHabitSection } from '../../components/DailyHabitSection';
import { motion, AnimatePresence } from 'motion/react';

export const WorkerDashboard: React.FC = () => {
  const { profile } = useAuth();
  const [stats, setStats] = useState({
    completed: 0,
    pending: 0,
    rank: 0,
    activePasses: 0
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [topUsers, setTopUsers] = useState<any[]>([]);
  const [showCelebration, setShowCelebration] = useState(false);
  const [milestoneCelebrated, setMilestoneCelebrated] = useState<number | null>(null);

  const getNextReward = (streak: number) => {
    if (streak < 3) return { next: 3, bonus: 10, label: 'Early Bird' };
    if (streak < 7) return { next: 7, bonus: 25, label: 'Weekly Warrior' };
    if (streak < 15) return { next: 15, bonus: 50, label: 'Consistent Citizen' };
    if (streak < 30) return { next: 30, bonus: 100, label: 'Civic Legend' };
    return { next: streak + (7 - (streak % 7)), bonus: 50, label: 'Undefeated' };
  };

  const getMotivationalMessage = (streak: number) => {
    if (streak === 0) return "Start a streak today to earn bonus points!";
    if (streak < 3) return "Great start! Keep it up for the 3-day bonus. 🚀";
    if (streak < 7) return "You're consistent! Reach 7 days for a big reward. 💎";
    if (streak < 15) return "Incredible consistency! You're a civic hero. 🏆";
    return "You're a legend! Your consistency is inspiring. 🔥";
  };

  const nextReward = getNextReward(profile?.currentStreak || 0);
  const progressPercent = nextReward 
    ? Math.min(100, ((profile?.currentStreak || 0) / nextReward.next) * 100)
    : 100;

  useEffect(() => {
    const streak = profile?.currentStreak || 0;
    const milestones = [3, 7, 15, 30];
    // Check local storage to see if we've already celebrated this specific streak count
    const lastCelebrated = localStorage.getItem(`celebrated_streak_${profile?.uid}`);
    
    if (milestones.includes(streak) && lastCelebrated !== String(streak)) {
      setShowCelebration(true);
      setMilestoneCelebrated(streak);
      localStorage.setItem(`celebrated_streak_${profile?.uid}`, String(streak));
    }
  }, [profile?.currentStreak, profile?.uid]);

  const [notices, setNotices] = useState<Notice[]>([]);

  useEffect(() => {
    const fetchWorkerStats = async () => {
      if (!profile) return;
      try {
        const data = await api.users.getWorkerStats();
        setStats(data);
        setError(null);
      } catch (err: any) {
        console.error("Error fetching worker stats:", err);
        setError(err.message || "Unable to load performance metrics.");
      } finally {
        setLoading(false);
      }
    };

    const fetchTopUsers = async () => {
      try {
        const data = await api.users.getAll();
        setTopUsers(data.slice(0, 5));
      } catch (err) {
        console.error("Leaderboard preview failed:", err);
      }
    };

    const fetchNotices = async () => {
      try {
        const data = await api.notices.getAll();
        setNotices(data.slice(0, 2));
      } catch (err) {
        console.error("Notice fetch failed:", err);
      }
    };

    fetchWorkerStats();
    fetchTopUsers();
    fetchNotices();
  }, [profile]);

  // Generate some realistic weekly data based on total completed
  const weeklyStats = [
    { name: 'Mon', tasks: Math.floor(stats.completed / 6) },
    { name: 'Tue', tasks: Math.floor(stats.completed / 5) },
    { name: 'Wed', tasks: Math.floor(stats.completed / 7) },
    { name: 'Thu', tasks: Math.floor(stats.completed / 4) },
    { name: 'Fri', tasks: Math.floor(stats.completed / 5) },
    { name: 'Sat', tasks: Math.floor(stats.completed / 3) },
    { name: 'Sun', tasks: 0 },
  ];

  const statCards = [
    { label: 'Completed Tasks', value: stats.completed, icon: CheckCircle2, color: 'text-green-600', bg: 'bg-green-100' },
    { label: 'Active Passes', value: stats.activePasses, icon: Ticket, color: 'text-indigo-600', bg: 'bg-indigo-100' },
    { label: 'Total Points', value: profile?.points || '0', icon: Star, color: 'text-yellow-600', bg: 'bg-yellow-100' },
    { label: 'Global Rank', value: `#${stats.rank}`, icon: Trophy, color: 'text-blue-600', bg: 'bg-blue-100' },
  ];

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4">
        <Loader2 className="animate-spin text-green-600" size={40} />
        <p className="text-gray-400 font-bold uppercase tracking-widest text-xs">Loading Personnel File...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4 text-center p-8 bg-amber-50 rounded-3xl border border-amber-100">
        <AlertTriangle className="text-amber-500" size={48} />
        <h2 className="text-2xl font-bold text-amber-900">Performance Data Unavailable</h2>
        <p className="text-amber-700 max-w-sm">{error}</p>
        <button 
          onClick={() => window.location.reload()}
          className="mt-4 px-6 py-3 bg-amber-600 text-white rounded-xl font-bold hover:bg-amber-700 transition-colors"
        >
          Check Connectivity
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-8 relative">
      <AnimatePresence>
        {showCelebration && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowCelebration(false)}
              className="absolute inset-0 bg-[#111827]/90 backdrop-blur-xl"
            />
            
            {/* Confetti-like elements */}
            <div className="absolute inset-0 pointer-events-none overflow-hidden">
                {[...Array(20)].map((_, i) => (
                    <motion.div
                        key={i}
                        initial={{ 
                            top: "50%", 
                            left: "50%", 
                            opacity: 1,
                            scale: 0
                        }}
                        animate={{ 
                            top: `${Math.random() * 100}%`,
                            left: `${Math.random() * 100}%`,
                            opacity: 0,
                            scale: [0, 1.5, 0],
                            rotate: 360
                        }}
                        transition={{ 
                            duration: 2 + Math.random() * 2, 
                            repeat: Infinity,
                            delay: Math.random() * 0.5
                        }}
                        className={cn(
                            "absolute w-4 h-4 rounded-lg",
                            ["bg-orange-400", "bg-yellow-400", "bg-green-400", "bg-blue-400"][i % 4]
                        )}
                    />
                ))}
            </div>

            <motion.div 
              initial={{ scale: 0.8, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.8, opacity: 0, y: 20 }}
              className="bg-white rounded-[3rem] p-10 max-w-md w-full text-center relative z-10 shadow-2xl overflow-hidden"
            >
              <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-orange-500 via-amber-500 to-yellow-400" />
              
              <div className="w-24 h-24 bg-gradient-to-br from-orange-400 to-amber-600 rounded-3xl flex items-center justify-center mx-auto mb-8 shadow-2xl shadow-orange-200 rotate-12">
                <Flame size={48} className="text-white fill-white animate-pulse" />
              </div>

              <h2 className="text-3xl font-black text-[#111827] uppercase tracking-tighter mb-2">
                {milestoneCelebrated}-Day Milestone!
              </h2>
              <p className="text-gray-500 font-bold uppercase tracking-widest text-[10px] mb-8">
                Consistency is the key to civic excellence
              </p>

              <div className="bg-orange-50 rounded-2xl p-6 mb-8 border border-orange-100">
                <div className="flex items-center justify-center gap-2 text-orange-600 mb-1">
                    <Sparkles size={16} />
                    <span className="text-xs font-black uppercase tracking-widest">Bonus Awarded</span>
                </div>
                <div className="text-4xl font-black text-orange-600">
                   +{nextReward?.bonus || 50} <span className="text-lg">PTS</span>
                </div>
              </div>

              <button 
                onClick={() => setShowCelebration(false)}
                className="w-full py-4 bg-[#111827] text-white rounded-2xl font-black uppercase tracking-[0.2em] text-xs hover:bg-black transition-all shadow-xl shadow-gray-200"
              >
                Accept Rewards
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <div className="flex items-center gap-6">
        <div className="w-16 h-16 flex items-center justify-center bg-indigo-600 rounded-full shadow-lg border border-white p-1 text-white hidden sm:flex">
          <LayoutDashboard size={32} />
        </div>
        <div>
          <div className="flex items-center gap-3 mb-2">
              <span className="text-[10px] font-black text-orange-600 uppercase tracking-[0.2em] bg-orange-50 px-4 py-1.5 rounded-full border border-orange-100/50 shadow-sm">Official Municipal Personnel Portal</span>
          </div>
          <h2 className="text-3xl font-black text-[#111827] tracking-tight uppercase">Raipur Municipal Corporation</h2>
          <p className="text-orange-500 mt-1 font-bold uppercase tracking-widest text-xs">Smart Civic Sense System</p>
        </div>
      </div>

      {/* Compact Civic Banner */}
      <div className="relative bg-[#111827] rounded-[2.5rem] overflow-hidden border border-white/10 shadow-2xl shadow-gray-200">
        <div className="absolute inset-0 bg-gradient-to-r from-orange-500/10 via-transparent to-green-500/10" />
        <div className="relative z-10 px-8 py-8 md:px-10 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex flex-col md:flex-row items-center gap-6 text-center md:text-left">
            <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center p-2 shadow-xl shrink-0 border border-gray-100">
              <Sparkles className="w-10 h-10 text-orange-500" />
            </div>
            <div className="space-y-1">
              <div className="flex items-center justify-center md:justify-start gap-2 mb-1">
                <Star size={12} className="text-orange-400 fill-orange-400" />
                <span className="text-white text-[10px] font-black uppercase tracking-[0.2em]">Official Municipal Mission</span>
              </div>
              <h2 className="text-2xl md:text-3xl font-black text-white tracking-tighter uppercase leading-none">Raipur Municipal Corporation</h2>
              <p className="text-orange-400 text-xs font-bold uppercase tracking-widest leading-none">Smart Civic Sense System</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="bg-white/5 backdrop-blur-md border border-white/10 px-6 py-3 rounded-2xl hidden sm:block">
              <div className="flex items-center gap-2">
                <Flame size={14} className="text-orange-400 fill-orange-400" />
                <span className="text-white text-[10px] font-black uppercase tracking-widest whitespace-nowrap">Active Citizen Shield</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Streak Stats */}
        <div className="md:col-span-1 grid grid-cols-2 gap-4">
          <div className="bg-[#111827] p-6 rounded-[2.5rem] text-white flex flex-col justify-between shadow-xl shadow-gray-200 relative overflow-hidden group">
            <div className="absolute -right-4 -top-4 w-24 h-24 bg-orange-500/10 rounded-full blur-2xl group-hover:bg-orange-500/20 transition-all" />
            <div className="flex items-center justify-between">
              <div className="w-10 h-10 bg-orange-500 rounded-2xl flex items-center justify-center shadow-lg shadow-orange-500/20">
                <Flame size={20} className="text-white fill-white animate-pulse" />
              </div>
              <span className="text-[10px] font-black uppercase tracking-widest text-orange-400">Current</span>
            </div>
            <div>
              <p className="text-3xl font-black">{profile?.currentStreak || 0}</p>
              <p className="text-[10px] font-black uppercase tracking-widest text-gray-500">Day Streak</p>
            </div>
          </div>
          <div className="bg-white p-6 rounded-[2.5rem] border border-gray-100 flex flex-col justify-between shadow-sm relative overflow-hidden group">
            <div className="absolute -right-4 -top-4 w-24 h-24 bg-indigo-500/5 rounded-full blur-2xl group-hover:bg-indigo-500/10 transition-all" />
            <div className="flex items-center justify-between">
              <div className="w-10 h-10 bg-indigo-50 rounded-2xl flex items-center justify-center text-indigo-600 shadow-sm border border-indigo-100">
                <Trophy size={20} strokeWidth={3} />
              </div>
              <span className="text-[10px] font-black uppercase tracking-widest text-[#111827]">Best</span>
            </div>
            <div>
              <p className="text-3xl font-black text-[#111827]">{profile?.longestStreak || 0}</p>
              <p className="text-[10px] font-black uppercase tracking-widest text-gray-400">Personal Record</p>
            </div>
          </div>
        </div>

        {/* Reward Progress */}
        <div className="md:col-span-2 bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm flex flex-col justify-between relative overflow-hidden group">
          <div className="absolute -right-20 -top-20 w-64 h-64 bg-green-500/5 rounded-full blur-3xl group-hover:bg-green-500/10 transition-all pointer-events-none" />
          
          <div className="flex justify-between items-start relative z-10">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <h3 className="text-lg font-black text-[#111827] uppercase tracking-tight">Streak Progress</h3>
                {nextReward && (
                    <span className="px-2 py-0.5 bg-indigo-50 text-indigo-600 text-[8px] font-black uppercase tracking-widest rounded-md border border-indigo-100">
                        {nextReward.label}
                    </span>
                )}
              </div>
              <p className="text-xs text-gray-400 font-medium">
                {getMotivationalMessage(profile?.currentStreak || 0)}
              </p>
            </div>
            {nextReward && (
              <div className="flex flex-col items-end">
                <div className="bg-green-50 text-green-700 px-4 py-2 rounded-2xl text-[10px] font-black uppercase tracking-widest border border-green-100 shadow-sm">
                   +{nextReward.bonus} PTS
                </div>
                <div className="flex items-center gap-1 mt-2 text-gray-400">
                    <Sparkles size={10} className="text-amber-400" />
                    <span className="text-[9px] font-black uppercase tracking-tighter">Milestone Reward</span>
                </div>
              </div>
            )}
          </div>
          
          <div className="space-y-4 mt-6 relative z-10">
            <div className="flex justify-between items-end">
              <div className="flex items-center gap-3">
                <div className="flex flex-col">
                    <span className="text-[9px] font-black text-gray-300 uppercase tracking-widest">Completed</span>
                    <span className="text-sm font-black text-[#111827] leading-none">{profile?.currentStreak || 0} Days</span>
                </div>
                <div className="h-6 w-[1px] bg-gray-100 mx-1" />
                <div className="flex flex-col">
                    <span className="text-[9px] font-black text-gray-300 uppercase tracking-widest">Target</span>
                    <span className="text-sm font-black text-gray-400 shadow-sm px-2 bg-gray-50 rounded-lg leading-none">{nextReward?.next || '--'} Days</span>
                </div>
              </div>
              <div className="bg-[#111827] text-white px-3 py-1 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-gray-200">
                {Math.round(progressPercent)}% Full
              </div>
            </div>
            <div className="h-4 bg-gray-50 rounded-full overflow-hidden border border-gray-100 shadow-inner relative">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${progressPercent}%` }}
                transition={{ duration: 1.5, ease: [0.22, 1, 0.36, 1] }}
                className="h-full bg-gradient-to-r from-orange-500 via-amber-500 to-yellow-400 rounded-full shadow-[0_0_15px_rgba(249,115,22,0.3)] relative"
              >
                <div className="absolute inset-0 bg-[linear-gradient(45deg,rgba(255,255,255,0.15)_25%,transparent_25%,transparent_50%,rgba(255,255,255,0.15)_50%,rgba(255,255,255,0.15)_75%,transparent_75%,transparent)] bg-[length:1rem_1rem] animate-[sweep_2s_linear_infinity]" />
                {progressPercent > 5 && (
                  <div className="absolute inset-0 flex items-center justify-end px-1">
                    <div className="w-1.5 h-1.5 bg-white rounded-full animate-ping opacity-50" />
                  </div>
                )}
              </motion.div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((stat) => (
          <div key={stat.label} className="bg-white p-6 rounded-2xl border border-[#E5E7EB] shadow-sm hover:shadow-md transition-shadow">
            <div className={`w-12 h-12 ${stat.bg} rounded-xl flex items-center justify-center mb-4`}>
              <stat.icon className={stat.color} size={24} />
            </div>
            <p className="text-sm font-medium text-[#6B7280] uppercase tracking-wider">{stat.label}</p>
            <p className="text-2xl font-bold text-[#111827] mt-1">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <DailyHabitSection />
          
          {/* Performance Chart */}
          <div className="bg-white p-6 rounded-3xl border border-[#E5E7EB] shadow-sm">
            <h3 className="text-lg font-bold text-[#111827] mb-6 uppercase tracking-wider">Weekly Performance</h3>
            <div className="h-[300px] w-full relative">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={weeklyStats}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
                  <XAxis 
                      dataKey="name" 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fill: '#6B7280', fontSize: 12 }} 
                  />
                  <YAxis 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fill: '#6B7280', fontSize: 12 }} 
                  />
                  <Tooltip 
                      cursor={{ fill: 'rgba(5, 150, 105, 0.05)' }}
                      contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)' }}
                  />
                  <Bar dataKey="tasks" fill="#10B981" radius={[4, 4, 0, 0]} barSize={40} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        <div className="lg:col-span-1 space-y-8">
          {/* Civic Notice Section */}
          <div className="bg-gradient-to-br from-indigo-600 to-blue-700 p-8 rounded-3xl text-white relative overflow-hidden shadow-xl shadow-blue-200">
            <div className="absolute -right-8 -top-8 w-32 h-32 bg-white/10 rounded-full blur-2xl" />
            <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center">
                    <Bell size={20} className="text-white animate-bounce" />
                </div>
                <div>
                   <h3 className="text-lg font-black uppercase tracking-tight leading-none">Civic Notices</h3>
                   <p className="text-[10px] font-bold text-blue-200 uppercase tracking-widest mt-1">Official Circulars</p>
                </div>
            </div>
            
            <div className="space-y-6">
                {notices.length > 0 ? (
                  notices.map((notice, i) => (
                    <React.Fragment key={notice.id}>
                      <div className="space-y-2">
                          <div className="flex items-center justify-between">
                              <span className="text-[9px] font-black uppercase tracking-widest text-[#FFF]/60">
                                {new Date(notice.issuedAt).toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' })}
                              </span>
                              {notice.category && (
                                <span className={cn(
                                  "text-[8px] font-black px-2 py-0.5 rounded-md uppercase tracking-widest text-white shadow-sm",
                                  notice.category === 'Urgent' ? "bg-orange-500" : 
                                  notice.category === 'Update' ? "bg-blue-400" : "bg-green-500"
                                )}>
                                  {notice.category}
                                </span>
                              )}
                          </div>
                          <h4 className="text-sm font-black uppercase tracking-tight line-clamp-1">{notice.title}</h4>
                          <p className="text-xs font-medium text-blue-50 leading-relaxed line-clamp-2">{notice.content}</p>
                      </div>
                      {i < notices.length - 1 && <div className="h-[1px] bg-white/10" />}
                    </React.Fragment>
                  ))
                ) : (
                  <div className="py-4 text-center">
                    <p className="text-[10px] font-black uppercase tracking-widest text-blue-200">No active bulletins</p>
                  </div>
                )}
            </div>

            <Link to="/worker/notices" className="mt-8 w-full py-4 bg-white text-blue-600 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-gray-50 transition-all flex items-center justify-center gap-2">
                View All Bulletins <ArrowRight size={14} />
            </Link>
          </div>

          {/* Weekly Leaderboard Preview */}
          <div className="bg-white p-8 rounded-3xl border border-[#E5E7EB] shadow-sm flex flex-col justify-between h-fit">
            <div>
              <div className="flex items-center justify-between mb-8">
                <h3 className="text-xl font-bold text-[#111827]">Top Performers</h3>
                <Trophy className="text-yellow-500" size={24} />
              </div>
              
              <div className="space-y-4">
                {topUsers.map((user, i) => (
                  <div key={user.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-2xl border border-gray-100 group hover:bg-green-50 transition-colors">
                    <div className="flex items-center gap-3">
                      <span className="text-xs font-black text-gray-400 w-4">{i + 1}</span>
                      <div className="w-10 h-10 rounded-full bg-white border border-gray-100 flex items-center justify-center overflow-hidden">
                        {user.photoUrl ? <img src={user.photoUrl} alt="" className="w-full h-full object-cover" /> : user.name?.[0]}
                      </div>
                      <div>
                        <p className="text-sm font-bold text-[#111827] truncate max-w-[100px]">{user.name}</p>
                        <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">{user.points} pts</p>
                      </div>
                    </div>
                    {i === 0 && <Star size={16} className="text-yellow-500 fill-yellow-500" />}
                  </div>
                ))}
              </div>
            </div>
            
            <Link to="/worker/leaderboard" className="mt-8 flex items-center justify-center gap-2 w-full py-4 bg-[#111827] text-white rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-green-600 transition-colors group">
              Full Rankings <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};
