import React, { useState, useEffect } from 'react';
import { api } from '../../lib/api';
import { useAuth } from '../../context/AuthContext';
import { DigitalPass } from '../../types';
import { Ticket, Calendar, QrCode, Download, Share2, Clock, AlertCircle, CheckCircle2, XCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { format, isAfter, parseISO } from 'date-fns';
import { cn, safeGetDate } from '../../lib/utils';
import QRCode from 'qrcode';
import { jsPDF } from 'jspdf';
import { toast } from 'sonner';

export const WorkerPasses: React.FC = () => {
  const { profile } = useAuth();
  const [passes, setPasses] = useState<DigitalPass[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedPass, setSelectedPass] = useState<DigitalPass | null>(null);
  const [qrDataUrl, setQrDataUrl] = useState<string | null>(null);

  const fetchPasses = async () => {
    if (!profile) {
      if (!loading) setLoading(true);
      return;
    }

    setLoading(true);
    try {
      const data = await api.passes.getAll();
      setPasses(data);
    } catch (error) {
      console.error("Fetch error:", error);
      toast.error("Failed to fetch passes from vault");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPasses();
  }, [(profile as any)?.uid || (profile as any)?._id]);

  useEffect(() => {
    if (selectedPass) {
      const generateQR = async () => {
        try {
          const payload = JSON.stringify({
            passId: selectedPass.passId,
            qrHash: selectedPass.qrHash
          });
          const url = await QRCode.toDataURL(payload, {
            width: 400,
            margin: 2,
            color: {
              dark: '#111827',
              light: '#ffffff'
            }
          });
          setQrDataUrl(url);
        } catch (err) {
          console.error(err);
          toast.error("Failed to generate QR Code");
        }
      };
      generateQR();
    } else {
      setQrDataUrl(null);
    }
  }, [selectedPass]);

  const downloadPDF = async (pass: DigitalPass) => {
    try {
      const doc = new jsPDF();
      const qrPayload = JSON.stringify({ passId: pass.passId, qrHash: pass.qrHash });
      const qrUrl = await QRCode.toDataURL(qrPayload);

      // PDF Content
      doc.setFillColor(17, 24, 39);
      doc.rect(0, 0, 210, 40, 'F');
      
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(22);
      doc.text("SMART CIVIC PASS", 105, 25, { align: 'center' });
      
      doc.setTextColor(0, 0, 0);
      doc.setFontSize(16);
      doc.text(pass.rewardTitle, 105, 60, { align: 'center' });
      
      doc.setFontSize(12);
      doc.text(`Beneficiary: ${pass.userName}`, 20, 80);
      doc.text(`Pass ID: ${pass.passId}`, 20, 90);
      doc.text(`Issued: ${format(safeGetDate(pass.issuedAt), 'PPP')}`, 20, 100);
      doc.text(`Valid Till: ${format(safeGetDate(pass.validTill), 'PPP')}`, 20, 110);
      doc.text(`Type: ${pass.rewardType.toUpperCase()}`, 20, 120);
      
      doc.addImage(qrUrl, 'PNG', 55, 140, 100, 100);
      
      doc.setFontSize(10);
      doc.setTextColor(150, 150, 150);
      doc.text("Scan this QR code at municipal check posts to avail benefits.", 105, 260, { align: 'center' });
      doc.text("Non-transferable. Valid only with government ID.", 105, 265, { align: 'center' });
      doc.text("Official Portal of Raipur Municipal Corporation", 105, 280, { align: 'center' });

      doc.save(`CivicPass_${pass.passId}.pdf`);
      toast.success("Pass Downloaded!");
    } catch (err) {
      console.error(err);
      toast.error("PDF generation failed");
    }
  };

  const getStatusColor = (pass: DigitalPass) => {
    const expired = isAfter(new Date(), safeGetDate(pass.validTill));
    if (expired) return 'bg-gray-100 text-gray-400 border-gray-200';
    if (pass.status === 'used') return 'bg-rose-50 text-rose-600 border-rose-100';
    return 'bg-green-50 text-green-700 border-green-100';
  };

  return (
    <div className="max-w-7xl mx-auto pb-12">
      <header className="mb-12 flex justify-between items-end">
        <div className="flex items-center gap-6">
          <div className="w-16 h-16 flex items-center justify-center bg-indigo-600 rounded-full shadow-lg border border-gray-100 p-1 text-white">
            <Ticket size={32} />
          </div>
          <div>
            <h2 className="text-3xl md:text-5xl font-black text-[#111827] tracking-tight uppercase">Raipur Municipal Corporation</h2>
            <p className="text-orange-500 font-bold uppercase tracking-widest text-[10px] mt-1">Smart Civic Sense System</p>
          </div>
        </div>
        {passes.length > 0 && (
          <div className="bg-green-50 text-green-700 px-4 py-2 rounded-2xl text-[10px] font-black uppercase tracking-widest border border-green-100">
            Total Passes: {passes.length}
          </div>
        )}
      </header>

      {loading ? (
        <div className="flex items-center justify-center p-20 text-gray-400 uppercase tracking-widest text-xs font-black">
          Decrypting your vault...
        </div>
      ) : passes.length === 0 ? (
        <div className="bg-white rounded-[3rem] p-20 text-center border border-gray-100 shadow-sm">
           <div className="w-24 h-24 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-6 text-gray-200">
             <Ticket size={48} />
           </div>
           <h3 className="text-2xl font-black text-gray-900 mb-2">Your vault is empty</h3>
           <p className="text-gray-400 font-medium mb-8">Redeem your merit points to earn digital passes.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {passes.map(pass => (
            <motion.div
              layoutId={(pass as any)._id || pass.id}
              key={(pass as any)._id || pass.id}
              onClick={() => setSelectedPass(pass)}
              className="bg-white rounded-[2.5rem] border border-gray-100 shadow-sm overflow-hidden group hover:shadow-xl hover:border-indigo-200 transition-all cursor-pointer"
            >
              <div className={cn(
                "h-32 p-6 flex flex-col justify-between transition-colors relative overflow-hidden",
                pass.rewardType === 'bus' ? "bg-blue-600" :
                pass.rewardType === 'parking' ? "bg-amber-600" :
                pass.rewardType === 'movie' ? "bg-rose-600" : "bg-purple-600"
              )}>
                <div className="flex items-center justify-between relative z-10">
                  <span className="text-[10px] font-black text-white/70 uppercase tracking-widest">Digital Token</span>
                  <Ticket className="text-white/30" size={20} />
                </div>
                <h3 className="text-xl font-black text-white relative z-10 leading-tight uppercase">{pass.rewardTitle}</h3>
                
                {/* Decorative BG pattern */}
                <div className="absolute top-0 right-0 p-4 opacity-10">
                   <QrCode size={120} />
                </div>
              </div>

              <div className="p-8 space-y-6">
                <div className="flex items-center justify-between">
                  <div className="flex flex-col">
                    <span className="text-[10px] text-gray-400 font-black uppercase tracking-widest mb-1">Validity</span>
                    <div className="flex items-center gap-1.5 text-sm font-bold text-gray-700">
                      <Calendar size={14} className="text-indigo-500" />
                      Till {format(safeGetDate(pass.validTill), 'MMM dd, yyyy')}
                    </div>
                  </div>
                  <div className={cn(
                    "px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest border",
                    getStatusColor(pass)
                  )}>
                    {isAfter(new Date(), safeGetDate(pass.validTill)) ? 'Expired' : pass.status}
                  </div>
                </div>

                <div className="flex items-center gap-4 pt-4 border-t border-gray-50">
                  <button 
                    onClick={(e) => { e.stopPropagation(); setSelectedPass(pass); }}
                    className="flex-1 bg-[#111827] text-white py-3 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-black transition-colors flex items-center justify-center gap-2"
                  >
                    <QrCode size={14} /> Open QR
                  </button>
                  <button 
                    onClick={(e) => { e.stopPropagation(); downloadPDF(pass); }}
                    className="w-12 h-12 bg-gray-50 text-gray-400 hover:bg-gray-100 rounded-xl flex items-center justify-center transition-colors"
                  >
                    <Download size={18} />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {/* QR Zoom Modal */}
      <AnimatePresence>
        {selectedPass && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-black/80 backdrop-blur-sm"
            onClick={() => setSelectedPass(null)}
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="bg-white rounded-[3rem] w-full max-w-lg overflow-hidden shadow-2xl"
              onClick={e => e.stopPropagation()}
            >
              <div className={cn(
                "p-10 flex flex-col items-center text-center",
                selectedPass.rewardType === 'bus' ? "bg-blue-600" :
                selectedPass.rewardType === 'parking' ? "bg-amber-600" :
                selectedPass.rewardType === 'movie' ? "bg-rose-600" : "bg-purple-600"
              )}>
                <button 
                  onClick={() => setSelectedPass(null)}
                  className="absolute top-6 right-6 text-white/50 hover:text-white"
                >
                  <XCircle size={32} />
                </button>
                <div className="w-20 h-20 bg-white/20 rounded-3xl flex items-center justify-center text-white mb-6 backdrop-blur-md">
                   <Ticket size={40} />
                </div>
                <h3 className="text-3xl font-black text-white leading-tight uppercase">{selectedPass.rewardTitle}</h3>
                <p className="text-white/70 font-bold uppercase tracking-widest text-xs mt-2">Valid for 1-time verification</p>
              </div>

              <div className="p-10 flex flex-col items-center">
                <div className="bg-gray-50 p-6 rounded-[2.5rem] border-4 border-gray-100 mb-8 relative">
                   {qrDataUrl ? (
                     <img src={qrDataUrl} alt="Pass QR" className="w-64 h-64 grayscale contrast-125" />
                   ) : (
                     <div className="w-64 h-64 flex items-center justify-center">
                        <Clock className="animate-spin text-gray-300" size={32} />
                     </div>
                   )}
                   <div className="absolute inset-x-0 bottom-0 py-2 bg-white/80 backdrop-blur-sm text-center border-t border-gray-100 rounded-b-[2rem]">
                      <span className="text-[10px] font-mono font-black text-gray-400"># {selectedPass.passId}</span>
                   </div>
                </div>

                <div className="w-full grid grid-cols-2 gap-4">
                   <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100 flex flex-col items-center">
                      <span className="text-[8px] font-black text-gray-400 uppercase tracking-widest mb-1">Status</span>
                      <span className="text-sm font-black text-[#111827] uppercase">{selectedPass.status}</span>
                   </div>
                   <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100 flex flex-col items-center">
                      <span className="text-[8px] font-black text-gray-400 uppercase tracking-widest mb-1">Expiry</span>
                      <span className="text-sm font-black text-[#111827] uppercase">{format(safeGetDate(selectedPass.validTill), 'MMM dd')}</span>
                   </div>
                </div>

                <div className="mt-8 flex items-center gap-4 w-full">
                   <button 
                     onClick={() => downloadPDF(selectedPass)}
                     className="flex-1 bg-[#111827] text-white py-5 rounded-2xl font-black uppercase tracking-widest flex items-center justify-center gap-3 hover:bg-black transition-all active:scale-95 shadow-xl"
                   >
                     <Download size={20} /> Download PDF
                   </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
