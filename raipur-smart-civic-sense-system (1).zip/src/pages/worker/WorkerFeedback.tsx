import React, { useState } from 'react';
import { api } from '../../lib/api';
import { useAuth } from '../../context/AuthContext';
import { MessageSquare, Send, CheckCircle2, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const WorkerFeedback: React.FC = () => {
  const { profile, refreshProfile } = useAuth();
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim() || !profile) return;

    setSubmitting(true);
    try {
      await api.feedback.submit({
        subject: subject || 'No Subject',
        message: message,
      });

      // Increment user complaint count (this should ideally be done in the backend, 
      // but we'll do it manually here if we want to update the profile immediately)
      await api.users.updateProfile({
        complaintsSubmitted: (profile.complaintsSubmitted || 0) + 1
      });
      refreshProfile();

      setSubmitted(true);
      setMessage('');
      setSubject('');
      setTimeout(() => setSubmitted(false), 5000);
    } catch (error) {
      console.error("Feedback submission failed:", error);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-12 py-8">
      <div className="text-center space-y-4">
        <div className="w-20 h-20 bg-green-100 text-green-600 rounded-3xl flex items-center justify-center mx-auto mb-6 transform -rotate-6">
          <MessageSquare size={40} />
        </div>
        <h2 className="text-4xl font-black text-[#111827] tracking-tight">Have something to say?</h2>
        <p className="text-[#6B7280] text-lg max-w-md mx-auto">
          Your feedback helps us build a better system for everyone. Suggest improvements or report issues.
        </p>
      </div>

      <div className="bg-white p-8 md:p-12 rounded-[2.5rem] border border-gray-100 shadow-xl shadow-gray-100/50 relative overflow-hidden">
        <AnimatePresence mode="wait">
          {!submitted ? (
            <motion.form
              key="form"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              onSubmit={handleSubmit}
              className="space-y-8"
            >
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-400 uppercase tracking-widest ml-1">Subject</label>
                <input
                  required
                  type="text"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="What is this regarding? (e.g. Broken Task, App Bug)"
                  className="w-full bg-gray-50 border-2 border-transparent focus:border-green-500 focus:bg-white rounded-2xl p-6 text-gray-800 placeholder-gray-400 transition-all outline-none font-bold"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-400 uppercase tracking-widest ml-1">Your Message</label>
                <textarea
                  required
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Tell us about your experience..."
                  rows={6}
                  className="w-full bg-gray-50 border-2 border-transparent focus:border-green-500 focus:bg-white rounded-2xl p-6 text-gray-800 placeholder-gray-400 transition-all outline-none resize-none text-lg leading-relaxed"
                />
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="w-full bg-[#111827] text-white font-black py-4 rounded-2xl flex items-center justify-center gap-3 hover:bg-black transition-all shadow-lg shadow-gray-200 group active:scale-[0.98]"
              >
                {submitting ? (
                  <Loader2 className="animate-spin" size={24} />
                ) : (
                  <>
                    <Send size={24} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                    Submit Feedback
                  </>
                )}
              </button>
            </motion.form>
          ) : (
            <motion.div
              key="success"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center py-8 space-y-6"
            >
              <div className="w-24 h-24 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle2 size={48} />
              </div>
              <div className="space-y-2">
                <h3 className="text-2xl font-bold text-gray-900">Feedback Received!</h3>
                <p className="text-gray-500">Thank you for your valuable input. We'll review it shortly.</p>
              </div>
              <button
                onClick={() => setSubmitted(false)}
                className="text-green-600 font-bold hover:underline"
              >
                Send another message
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Decorative pattern */}
        <div className="absolute top-0 right-0 p-4 opacity-[0.03] select-none pointer-events-none">
          <MessageSquare size={120} />
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
         <div className="p-6">
            <h4 className="font-bold text-gray-900 mb-2">Private</h4>
            <p className="text-xs text-gray-500">Your feedback is only visible to system admins.</p>
         </div>
         <div className="p-6">
            <h4 className="font-bold text-gray-900 mb-2">Responsive</h4>
            <p className="text-xs text-gray-500">We aim to address critical issues within 24 hours.</p>
         </div>
         <div className="p-6">
            <h4 className="font-bold text-gray-900 mb-2">Helpful</h4>
            <p className="text-xs text-gray-500">We take every suggestion into serious consideration.</p>
         </div>
      </div>
    </div>
  );
};
