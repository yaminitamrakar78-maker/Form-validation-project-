import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Loader2, Mail, Lock, User, Phone, ArrowRight, ShieldCheck, CheckCircle } from 'lucide-react';
import { motion } from 'motion/react';
import { toast } from 'sonner';
import { useAuth } from '../context/AuthContext';
import raipurLogo from "@/assets/raipur-logo.png";

export const Register: React.FC = () => {
  const [logoError, setLogoError] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [mobile, setMobile] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { user, profile, register } = useAuth();

  useEffect(() => {
    if (user && profile) {
      console.log(`[Register] Authenticated user detected (${profile.role}), redirecting...`);
      if (profile.role === 'admin') {
        navigate('/admin/dashboard', { replace: true });
      } else {
        navigate('/user/dashboard', { replace: true });
      }
    }
  }, [user, profile, navigate]);

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password.length < 6) {
      toast.error("Password too short", { description: "Password must be at least 6 characters long." });
      return;
    }
    if (mobile.length < 10) {
      toast.error("Invalid mobile number", { description: "Please enter a valid 10-digit mobile number." });
      return;
    }

    setLoading(true);
    try {
      await register({ name, email, mobile, password, role: 'worker' });
      toast.success("Account created successfully!");
      navigate('/user/dashboard');
    } catch (error: any) {
      toast.error("Registration failed", { description: error.message });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-white flex flex-col">
      {/* Official Top Strip */}
      <div className="bg-[#111827] text-white py-2 px-6 flex justify-between items-center text-[10px] font-black uppercase tracking-[0.2em] relative overflow-hidden shrink-0">
        <div className="absolute inset-0 bg-gradient-to-r from-orange-500/10 via-transparent to-green-500/10" />
        <div className="relative z-10">Raipur Municipal Corporation | Enrollment Portal</div>
        <div className="relative z-10 hidden sm:block">Govt. of Chhattisgarh</div>
      </div>

      <div className="flex-1 flex flex-col relative overflow-hidden">
        {/* Background Decorative Blur */}
        <div className="absolute top-[20%] right-[-10%] w-[50%] h-[50%] bg-green-500/5 rounded-full blur-[120px] pointer-events-none" />
        <div className="absolute bottom-[20%] left-[-10%] w-[50%] h-[50%] bg-orange-500/5 rounded-full blur-[120px] pointer-events-none" />

        <div className="container mx-auto px-6 flex-1 flex flex-col items-center justify-center py-20 relative z-10">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="w-full max-w-xl"
          >
            {/* Header Branding */}
            <div className="flex flex-col items-center text-center mb-12">
              <Link to="/" className="group mb-8">
                {!logoError ? (
                  <img 
                    src={raipurLogo} 
                    alt="Logo" 
                    className="w-20 h-20 bg-white p-2 rounded-[2rem] shadow-2xl shadow-gray-200 border-2 border-white group-hover:scale-110 transition-transform duration-500" 
                    onError={() => setLogoError(true)}
                  />
                ) : (
                  <div className="w-20 h-20 bg-white rounded-[2rem] flex items-center justify-center text-green-600 font-black text-2xl shadow-2xl shadow-gray-200 border-2 border-white group-hover:scale-110 transition-transform duration-500">RMC</div>
                )}
              </Link>
              <h1 className="text-4xl md:text-5xl font-black text-[#111827] tracking-tight uppercase leading-none mb-4">
                Initialize <span className="text-green-600">Account</span>
              </h1>
              <p className="text-sm font-bold text-gray-400 uppercase tracking-[0.3em]">Official Enrollment Form</p>
            </div>

            {/* Register Card */}
            <div className="bg-white rounded-[3rem] p-10 md:p-14 border border-gray-100 shadow-2xl shadow-gray-200/50 relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-green-500 via-white to-orange-500 opacity-20" />
              
              <div className="mb-10 text-center">
                <h2 className="text-xl font-black text-[#111827] tracking-tighter uppercase mb-2">Create Personnel ID</h2>
                <p className="text-gray-400 text-sm font-medium">Verify your official identity to begin service.</p>
              </div>

              <form onSubmit={handleRegister} className="space-y-6">
                <div>
                  <label className="text-[10px] font-black text-[#111827] uppercase tracking-widest ml-4 mb-2 block">Representative Full Name</label>
                  <div className="relative group/input">
                    <User className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-300 group-focus-within/input:text-green-500 transition-colors" size={20} />
                    <input
                      required
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full pl-16 pr-8 py-5 bg-gray-50 border-2 border-transparent rounded-[2rem] font-bold text-[#111827] outline-none transition-all focus:border-green-500 focus:bg-white placeholder:text-gray-300"
                      placeholder="Enter your full name"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] font-black text-[#111827] uppercase tracking-widest ml-4 mb-2 block">Official Email Address</label>
                  <div className="relative group/input">
                    <Mail className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-300 group-focus-within/input:text-green-500 transition-colors" size={20} />
                    <input
                      required
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full pl-16 pr-8 py-5 bg-gray-50 border-2 border-transparent rounded-[2rem] font-bold text-[#111827] outline-none transition-all focus:border-green-500 focus:bg-white placeholder:text-gray-300"
                      placeholder="name@rmc.gov.in"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] font-black text-[#111827] uppercase tracking-widest ml-4 mb-2 block">Verified Mobile Number</label>
                  <div className="relative group/input">
                    <Phone className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-300 group-focus-within/input:text-green-500 transition-colors" size={20} />
                    <input
                      required
                      type="tel"
                      maxLength={10}
                      value={mobile}
                      onChange={(e) => setMobile(e.target.value.replace(/\D/g, ''))}
                      className="w-full pl-16 pr-8 py-5 bg-gray-50 border-2 border-transparent rounded-[2rem] font-bold text-[#111827] outline-none transition-all focus:border-green-500 focus:bg-white placeholder:text-gray-300"
                      placeholder="10-digit mobile number"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] font-black text-[#111827] uppercase tracking-widest ml-4 mb-2 block">Secure Network Password</label>
                  <div className="relative group/input">
                    <Lock className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-300 group-focus-within/input:text-green-500 transition-colors" size={20} />
                    <input
                      required
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full pl-16 pr-8 py-5 bg-gray-50 border-2 border-transparent rounded-[2rem] font-bold text-[#111827] outline-none transition-all focus:border-green-500 focus:bg-white placeholder:text-gray-300"
                      placeholder="Minimum 6 characters"
                    />
                  </div>
                </div>

                <div className="pt-4">
                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-[#111827] text-white py-6 rounded-[2rem] font-black uppercase tracking-[0.3em] text-[11px] transition-all hover:bg-black active:scale-95 shadow-2xl shadow-gray-200 flex items-center justify-center gap-4 group"
                  >
                    {loading ? (
                      <Loader2 className="animate-spin" size={20} />
                    ) : (
                      <>
                        <ShieldCheck size={20} />
                        Register Official Application
                      </>
                    )}
                  </button>
                </div>
              </form>

              <div className="mt-12 text-center">
                <p className="text-[11px] font-bold text-gray-400 uppercase tracking-widest">
                  Already have an official account?{' '}
                  <Link to="/login" className="text-orange-600 hover:text-orange-700 font-black ml-2 underline underline-offset-4 transition-colors">
                    Access Portal Login
                  </Link>
                </p>
              </div>
            </div>

            {/* Verification Footer */}
            <div className="mt-12 flex items-center justify-center gap-10">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-green-50 flex items-center justify-center">
                  <CheckCircle className="text-green-600" size={20} />
                </div>
                <div className="flex flex-col">
                  <span className="text-[9px] font-black text-[#111827] uppercase tracking-widest leading-none">Security</span>
                  <span className="text-[8px] font-bold text-gray-400 uppercase tracking-widest mt-1">SSL Protected</span>
                </div>
              </div>
              <div className="w-px h-8 bg-gray-100" />
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-orange-50 flex items-center justify-center">
                  <ShieldCheck className="text-orange-600" size={20} />
                </div>
                <div className="flex flex-col">
                  <span className="text-[9px] font-black text-[#111827] uppercase tracking-widest leading-none">Identity</span>
                  <span className="text-[8px] font-bold text-gray-400 uppercase tracking-widest mt-1">Verified Personnel</span>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};
