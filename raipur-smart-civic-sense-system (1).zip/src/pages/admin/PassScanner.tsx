import React, { useState, useEffect, useRef } from 'react';
import { Html5QrcodeScanner } from 'html5-qrcode';
import { api } from '../../lib/api';
import { DigitalPass } from '../../types';
import { QrCode, ShieldCheck, ShieldAlert, CheckCircle2, XCircle, Info, RefreshCcw, User, Ticket, Calendar } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { format, isAfter, parseISO } from 'date-fns';
import { cn, safeGetDate } from '../../lib/utils';
import { toast } from 'sonner';

export const PassScanner: React.FC = () => {
  const [scanResult, setScanResult] = useState<{ passId: string; qrHash: string } | null>(null);
  const [passData, setPassData] = useState<DigitalPass | null>(null);
  const [verificationStatus, setVerificationStatus] = useState<'idle' | 'verifying' | 'valid' | 'invalid' | 'used'>('idle');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const scannerRef = useRef<Html5QrcodeScanner | null>(null);

  useEffect(() => {
    const scanner = new Html5QrcodeScanner(
      "reader",
      { fps: 10, qrbox: { width: 250, height: 250 } },
      false
    );

    scanner.render(onScanSuccess, onScanError);
    scannerRef.current = scanner;

    return () => {
      scanner.clear().catch(err => console.error("Failed to clear scanner", err));
    };
  }, []);

  async function onScanSuccess(decodedText: string) {
    try {
      if (verificationStatus === 'verifying') return;
      
      const data = JSON.parse(decodedText);
      if (data.passId && data.qrHash) {
        setScanResult(data);
        verifyPass(data.passId, data.qrHash);
        
        // Pause scanner if possible or just rely on state
        if (scannerRef.current) {
          // scannerRef.current.pause(); // Scanner API might vary
        }
      }
    } catch (err) {
      console.error("Invalid QR format", err);
    }
  }

  function onScanError(err: string) {
    // console.warn(err);
  }

  const verifyPass = async (passId: string, qrHash: string) => {
    setVerificationStatus('verifying');
    setErrorMsg(null);
    try {
      const data = await api.passes.getById(passId);

      if (!data) {
        setVerificationStatus('invalid');
        setErrorMsg("Pass not found in system.");
        return;
      }

      setPassData(data);

      // 1. Validate Hash
      if (data.qrHash !== qrHash) {
        setVerificationStatus('invalid');
        setErrorMsg("Security hash mismatch. Pass may be forged.");
        return;
      }

      // 2. Check Expiry
      const expired = isAfter(new Date(), safeGetDate(data.validTill));
      if (expired || data.status === 'expired') {
        setVerificationStatus('invalid');
        setErrorMsg(`Pass expired on ${format(safeGetDate(data.validTill), 'PPP')}`);
        return;
      }

      // 3. Check Usage Limit
      if (data.usedCount >= data.usageLimit || data.status === 'used') {
        setVerificationStatus('used');
        setErrorMsg("This pass has already reached its usage limit.");
        return;
      }

      setVerificationStatus('valid');
      toast.success("Pass Validated Successfully!");
    } catch (err: any) {
      console.error(err);
      setVerificationStatus('invalid');
      setErrorMsg(err.message || "Operation failed.");
    }
  };

  const handleGrantBenefit = async () => {
    if (!passData) return;
    
    setVerificationStatus('verifying');
    try {
      const updatedPass = await api.passes.use((passData as any)._id || passData.passId);

      toast.success("Benefit Granted!", {
        description: `Pass usage updated. Status: ${updatedPass.status.toUpperCase()}`
      });
      
      resetScanner();
    } catch (err: any) {
      console.error(err);
      toast.error(err.message || "Failed to update pass status");
      setVerificationStatus('valid');
    }
  };

  const resetScanner = () => {
    setScanResult(null);
    setPassData(null);
    setVerificationStatus('idle');
    setErrorMsg(null);
  };

  return (
    <div className="max-w-4xl mx-auto pb-12">
      <header className="mb-10 text-center">
        <div className="w-16 h-16 bg-[#111827] text-white rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-xl">
           <QrCode size={32} />
        </div>
        <h2 className="text-4xl font-black text-[#111827] tracking-tight uppercase">Verification Desk</h2>
        <p className="text-gray-400 font-bold uppercase tracking-widest text-[10px] mt-2">Field Officer Scanning Portal</p>
      </header>

      <div className="grid grid-cols-1 gap-8">
        <AnimatePresence mode="wait">
          {verificationStatus === 'idle' ? (
            <motion.div
              key="scanner"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white p-8 rounded-[3rem] border border-gray-100 shadow-xl overflow-hidden"
            >
              <div id="reader" className="w-full bg-gray-50 rounded-[2rem] overflow-hidden"></div>
              <div className="mt-8 p-6 bg-blue-50 rounded-2xl border border-blue-100 flex items-start gap-4">
                 <Info className="text-blue-500 shrink-0" size={20} />
                 <div>
                   <p className="text-blue-800 font-bold text-sm uppercase tracking-tight">Instructions</p>
                   <p className="text-blue-600 text-xs">Align the digital pass QR code within the frame. Verification will start automatically.</p>
                 </div>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="result"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="bg-white rounded-[3rem] border border-gray-100 shadow-2xl overflow-hidden"
            >
              <div className={cn(
                "p-10 text-center flex flex-col items-center",
                verificationStatus === 'valid' ? "bg-green-600" :
                verificationStatus === 'used' ? "bg-amber-500" :
                verificationStatus === 'verifying' ? "bg-indigo-600" : "bg-rose-600"
              )}>
                <div className="w-24 h-24 bg-white/20 rounded-full flex items-center justify-center text-white mb-6 backdrop-blur-md">
                   {verificationStatus === 'valid' ? <CheckCircle2 size={48} /> :
                    verificationStatus === 'verifying' ? <RefreshCcw size={48} className="animate-spin" /> :
                    <XCircle size={48} />}
                </div>
                <h3 className="text-3xl font-black text-white uppercase tracking-tight">
                  {verificationStatus === 'verifying' ? 'Verifying Authentication...' :
                   verificationStatus === 'valid' ? 'Valid Civic Pass' :
                   verificationStatus === 'used' ? 'Access Denied' : 'Invalid Credentials'}
                </h3>
                {errorMsg && <p className="text-white/80 font-bold uppercase tracking-widest text-[10px] mt-2">{errorMsg}</p>}
              </div>

              {passData && (
                 <div className="p-10 space-y-8">
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="flex items-center gap-4 p-6 bg-gray-50 rounded-3xl border border-gray-100">
                         <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-indigo-600 shadow-sm">
                            <User size={24} />
                         </div>
                         <div>
                            <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Beneficiary</span>
                            <p className="text-lg font-black text-[#111827] tracking-tight">{passData.userName}</p>
                         </div>
                      </div>
                      <div className="flex items-center gap-4 p-6 bg-gray-50 rounded-3xl border border-gray-100">
                         <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-indigo-600 shadow-sm">
                            <Ticket size={24} />
                         </div>
                         <div>
                            <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Benefit Type</span>
                            <p className="text-lg font-black text-[#111827] tracking-tight uppercase">{passData.rewardTitle}</p>
                         </div>
                      </div>
                   </div>

                   <div className="p-6 bg-[#111827] rounded-[2rem] text-white">
                      <div className="flex items-center justify-between mb-4">
                         <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Pass Details</span>
                         <span className="text-[10px] font-mono text-indigo-400"># {passData.passId}</span>
                      </div>
                      <div className="space-y-3">
                         <div className="flex justify-between text-sm">
                            <span className="text-gray-400 font-bold uppercase tracking-tight">Valid From</span>
                            <span className="font-bold">{format(safeGetDate(passData.validFrom), 'PPP')}</span>
                         </div>
                         <div className="flex justify-between text-sm">
                            <span className="text-gray-400 font-bold uppercase tracking-tight">Expires On</span>
                            <span className="font-bold">{format(safeGetDate(passData.validTill), 'PPP')}</span>
                         </div>
                         <div className="flex justify-between text-sm">
                            <span className="text-gray-400 font-bold uppercase tracking-tight">Usage Record</span>
                            <span className="font-bold">{passData.usedCount} / {passData.usageLimit} SCANS</span>
                         </div>
                      </div>
                   </div>

                   <div className="flex items-center gap-4">
                      <button 
                        onClick={resetScanner}
                        className="flex-1 px-8 py-5 rounded-2xl bg-gray-100 text-gray-600 font-black uppercase tracking-widest text-xs hover:bg-gray-200 transition-all flex items-center justify-center gap-2"
                      >
                        <RefreshCcw size={16} /> New Scan
                      </button>
                      {verificationStatus === 'valid' && (
                        <button 
                          onClick={handleGrantBenefit}
                          className="flex-[2] px-8 py-5 rounded-2xl bg-green-600 text-white font-black uppercase tracking-widest text-xs shadow-xl shadow-green-100 hover:bg-green-700 transition-all active:scale-95 flex items-center justify-center gap-2"
                        >
                          <ShieldCheck size={20} /> Grant Access
                        </button>
                      )}
                      {(verificationStatus === 'invalid' || verificationStatus === 'used') && (
                        <div className="flex-[2] flex items-center justify-center gap-2 text-rose-600 font-black uppercase tracking-widest text-xs">
                           <ShieldAlert size={20} /> Security Violation
                        </div>
                      )}
                   </div>
                 </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};
