import React, { useState, useEffect } from 'react';
import { api } from '../../lib/api';
import { Notice } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { 
  Bell, 
  Plus, 
  Trash2, 
  Calendar, 
  User, 
  X, 
  Loader2,
  Megaphone,
  Search,
  BellRing
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { format } from 'date-fns';
import { cn } from '../../lib/utils';
import { toast } from 'sonner';

export const AdminNotices: React.FC = () => {
  const { profile } = useAuth();
  const [notices, setNotices] = useState<Notice[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [search, setSearch] = useState('');

  const [newNotice, setNewNotice] = useState({
    title: '',
    content: '',
    category: 'Update' as 'Urgent' | 'Update' | 'Event'
  });

  useEffect(() => {
    fetchNotices();
  }, []);

  const fetchNotices = async () => {
    setLoading(true);
    try {
      const data = await api.notices.getAll();
      setNotices(data);
    } catch (error) {
      console.error("Error fetching notices:", error);
      toast.error("Failed to load bulletins.");
    } finally {
      setLoading(false);
    }
  };

  const handleAddNotice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;
    setIsSubmitting(true);
    try {
      await api.notices.create({
        ...newNotice,
        authorId: profile.uid,
        issuedAt: new Date().toISOString()
      });
      setIsModalOpen(false);
      setNewNotice({ title: '', content: '', category: 'Update' });
      fetchNotices();
      toast.success("Notice broadcasted successfully.");
    } catch (error) {
      console.error("Error adding notice:", error);
      toast.error("Failed to broadcast notice");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteNotice = async (id: string) => {
    if (!confirm("Are you sure you want to retract this notice?")) return;
    try {
      await api.notices.delete(id);
      setNotices(notices.filter(n => (n as any)._id !== id));
      toast.success("Notice retracted.");
    } catch (error) {
      console.error("Error deleting notice:", error);
      toast.error("Failed to delete notice");
    }
  };

  const filteredNotices = notices.filter(n => 
    n.title.toLowerCase().includes(search.toLowerCase()) || 
    n.content.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-8 pb-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-6">
          <div className="w-16 h-16 flex items-center justify-center bg-blue-600 rounded-full shadow-lg border-2 border-white text-white">
            <BellRing size={32} />
          </div>
          <div>
            <h2 className="text-3xl md:text-4xl font-black text-[#111827] tracking-tight uppercase">Raipur Municipal Corporation</h2>
            <p className="text-orange-500 font-bold uppercase tracking-widest text-[10px] mt-1">Smart Civic Sense System</p>
          </div>
        </div>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="bg-green-600 text-white px-6 py-4 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-green-700 transition-all shadow-lg shadow-green-100 active:scale-95"
        >
          <Plus size={20} strokeWidth={3} />
          Post Bulletin
        </button>
      </div>

      {/* Search */}
      <div className="bg-white p-4 rounded-3xl border border-gray-100 shadow-sm">
        <div className="relative w-full">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
          <input 
            type="text" 
            placeholder="Search bulletins..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-12 pr-4 py-3 bg-gray-50 border-none rounded-2xl focus:ring-2 focus:ring-green-500 transition-all font-medium"
          />
        </div>
      </div>

      {loading ? (
        <div className="p-20 flex flex-col items-center justify-center gap-4">
          <Loader2 className="animate-spin text-green-600" size={40} />
          <p className="text-gray-400 font-bold uppercase tracking-widest text-xs">Accessing Archives...</p>
        </div>
      ) : filteredNotices.length === 0 ? (
        <div className="p-20 text-center space-y-4 bg-white rounded-[2.5rem] border border-gray-100">
          <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto text-gray-200">
             <Megaphone size={32} />
          </div>
          <p className="text-gray-400 font-bold uppercase tracking-widest text-xs">No civic notices available.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredNotices.map((notice) => (
            <motion.div 
              layout
              key={notice.id}
              className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm hover:shadow-xl transition-all group"
            >
              <div className="flex justify-between items-start mb-6">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-green-50 flex items-center justify-center text-green-600">
                    <Megaphone size={20} />
                  </div>
                  {notice.category && (
                    <span className={cn(
                      "text-[8px] font-black px-2 py-1 rounded-md uppercase tracking-widest text-white shadow-sm",
                      notice.category === 'Urgent' ? "bg-orange-500" : 
                      notice.category === 'Update' ? "bg-blue-400" : "bg-green-500"
                    )}>
                      {notice.category}
                    </span>
                  )}
                </div>
                <button 
                  onClick={() => handleDeleteNotice(notice.id)}
                  className="p-2 rounded-xl text-gray-300 hover:text-rose-500 hover:bg-rose-50 transition-all"
                >
                  <Trash2 size={18} />
                </button>
              </div>
              
              <h3 className="text-xl font-black text-[#111827] uppercase tracking-tight mb-3 group-hover:text-green-600 transition-colors">
                {notice.title}
              </h3>
              <p className="text-gray-600 text-sm leading-relaxed mb-6 font-medium">
                {notice.content}
              </p>

              <div className="flex items-center justify-between pt-6 border-t border-gray-50">
                <div className="flex items-center gap-2 text-[10px] font-black text-gray-400 uppercase tracking-widest">
                  <Calendar size={14} />
                  {format(new Date(notice.issuedAt), 'MMM dd, yyyy')}
                </div>
                <div className="flex items-center gap-2 text-[10px] font-black text-green-600 uppercase tracking-widest px-3 py-1 bg-green-50 rounded-full">
                  OFFICIAL BROADCAST
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {/* Add Notice Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsModalOpen(false)}
              className="absolute inset-0 bg-[#111827]/80 backdrop-blur-md"
            />
            <motion.div 
              initial={{ scale: 0.95, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 20 }}
              className="bg-white rounded-[3rem] shadow-2xl w-full max-w-xl overflow-hidden relative z-10"
            >
              <div className="p-10">
                <div className="flex justify-between items-center mb-10">
                  <div>
                    <h3 className="text-3xl font-black text-[#111827] tracking-tight">Issue Bulletin</h3>
                    <p className="text-gray-400 font-bold uppercase tracking-widest text-[10px] mt-1">Direct communication with citizens</p>
                  </div>
                  <button onClick={() => setIsModalOpen(false)} className="w-12 h-12 rounded-2xl bg-gray-50 flex items-center justify-center text-gray-400 hover:text-rose-500 hover:bg-rose-50 transition-all">
                    <X size={24} />
                  </button>
                </div>

                <form onSubmit={handleAddNotice} className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Headline</label>
                    <input 
                      required
                      type="text" 
                      placeholder="e.g., Mandatory Safety Gear Update"
                      value={newNotice.title}
                      onChange={(e) => setNewNotice({...newNotice, title: e.target.value})}
                      className="w-full bg-gray-50 border-2 border-transparent focus:border-green-500 focus:bg-white rounded-2xl p-5 text-gray-800 font-bold placeholder-gray-300 transition-all focus:ring-0 outline-none"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Full Content</label>
                    <textarea 
                      required
                      rows={6}
                      placeholder="Detail the announcement here..."
                      value={newNotice.content}
                      onChange={(e) => setNewNotice({...newNotice, content: e.target.value})}
                      className="w-full bg-gray-50 border-2 border-transparent focus:border-green-500 focus:bg-white rounded-2xl p-5 text-gray-800 font-bold placeholder-gray-300 transition-all focus:ring-0 outline-none resize-none"
                    />
                  </div>

                  <div className="space-y-4">
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Category</label>
                    <div className="flex gap-4">
                      {(['Urgent', 'Update', 'Event'] as const).map(cat => (
                        <button
                          key={cat}
                          type="button"
                          onClick={() => setNewNotice({...newNotice, category: cat})}
                          className={cn(
                            "flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all border-2",
                            newNotice.category === cat 
                              ? "bg-[#111827] text-white border-[#111827]" 
                              : "bg-white text-gray-400 border-gray-100 hover:border-gray-200"
                          )}
                        >
                          {cat}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="pt-4 flex gap-4">
                    <button
                      type="button"
                      onClick={() => setIsModalOpen(false)}
                      className="flex-1 font-black py-5 rounded-[1.5rem] bg-gray-50 text-gray-400 hover:bg-gray-100 transition-all"
                    >
                      CANCEL
                    </button>
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="flex-[2] bg-[#111827] text-white font-black py-5 rounded-[1.5rem] flex items-center justify-center gap-3 hover:bg-black transition-all shadow-xl shadow-gray-200"
                    >
                      {isSubmitting ? (
                        <Loader2 className="animate-spin" size={24} />
                      ) : (
                        <>
                          <Megaphone size={24} />
                          BROADCAST NOW
                        </>
                      )}
                    </button>
                  </div>
                </form>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
