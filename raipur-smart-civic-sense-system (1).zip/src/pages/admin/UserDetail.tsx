import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { api } from '../../lib/api';
import { UserProfile, Task } from '../../types';
import { 
  ArrowLeft, 
  MapPin, 
  Calendar, 
  CheckCircle2, 
  Clock, 
  Award,
  Loader2,
  TrendingUp,
  History,
  ShieldCheck,
  Upload,
  Phone,
  Hash,
  Mail,
  User as UserIcon,
  Ban,
  ShieldAlert,
  Globe,
  Briefcase,
  Gift,
  Trophy,
  ChevronLeft
} from 'lucide-react';
import { motion } from 'motion/react';
import { format } from 'date-fns';
import { cn, safeGetDate } from '../../lib/utils';
import { toast } from 'sonner';

export const UserDetail: React.FC = () => {
  const { userId } = useParams<{ userId: string }>();
  const navigate = useNavigate();
  const [user, setUser] = useState<UserProfile | null>(null);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [redeems, setRedeems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (userId) {
      fetchUserData();
    }
  }, [userId]);

  const fetchUserData = async () => {
    if (!userId) return;
    
    setLoading(true);
    try {
      const userData = await api.users.getById(userId);
      setUser(userData);

      const fetchedTasks = await api.tasks.getAll(userId);
      setTasks(fetchedTasks);

      const fetchedRedeems = await api.redeem.getAll(userId);
      setRedeems(fetchedRedeems);
    } catch (error) {
      console.error("Error fetching user detail:", error);
      toast.error("Failed to sync identity record.");
    } finally {
      setLoading(false);
    }
  };

  const handleToggleStatus = async () => {
    if (!user || !userId) return;
    const newStatus = user.accountStatus === 'disabled' ? 'active' : 'disabled';
    const confirmed = window.confirm(
      `CRITICAL ACTION: ${newStatus.toUpperCase()} account for ${user.name}?\n\nThis will immediately affect their access to the system.`
    );

    if (!confirmed) return;

    try {
      await api.users.update(userId, { accountStatus: newStatus });
      setUser(prev => prev ? { ...prev, accountStatus: newStatus as any } : null);
      toast.success(`User account ${newStatus}`);
    } catch (error) {
      console.error("Status modification failed:", error);
      toast.error("Status modification failed.");
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4">
        <Loader2 className="animate-spin text-green-600" size={40} />
        <p className="text-gray-400 font-black uppercase tracking-widest text-xs">Accessing Identity Record...</p>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="text-center p-20">
        <h2 className="text-2xl font-black text-gray-400">Citizen Not Found</h2>
        <button onClick={() => navigate('/admin/users')} className="mt-4 text-green-600 font-bold hover:underline underline-offset-4 flex items-center gap-2 mx-auto">
          <ArrowLeft size={16} />
          Return to Roster
        </button>
      </div>
    );
  }

  const completedCount = tasks.filter(t => t.status === 'completed' || t.status === 'approved').length;
  const pendingCount = tasks.filter(t => t.status === 'pending' || t.status === 'submitted').length;

  return (
    <div className="space-y-8 pb-12">
      <button 
        onClick={() => navigate('/admin/users')}
        className="group flex items-center gap-2 text-[10px] font-black text-gray-400 uppercase tracking-widest hover:text-green-600 transition-colors"
      >
        <div className="w-8 h-8 rounded-lg bg-white border border-gray-100 flex items-center justify-center group-hover:bg-green-50 group-hover:border-green-100 transition-all">
          <ArrowLeft size={14} />
        </div>
        Back to Dashboard
      </button>

      {/* Identity Card */}
      <div className="bg-white p-10 rounded-[3rem] border border-gray-100 shadow-xl relative overflow-hidden group">
        <div className="absolute top-0 right-0 w-80 h-80 bg-green-50/50 rounded-full -mr-40 -mt-40 blur-3xl pointer-events-none group-hover:bg-green-100/50 transition-colors"></div>
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-orange-50/50 rounded-full -ml-32 -mb-32 blur-3xl pointer-events-none group-hover:bg-orange-100/50 transition-colors"></div>
        
        <div className="relative flex flex-col md:flex-row items-center gap-8">
          <div className="relative">
            <div className="w-40 h-40 rounded-[3.5rem] bg-gray-50 border-4 border-white shadow-2xl overflow-hidden">
              {user.photoUrl ? (
                <img src={user.photoUrl} alt={user.name} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-5xl font-black text-gray-300">
                  {user.name.charAt(0)}
                </div>
              )}
            </div>
            <div className="absolute -bottom-2 -right-2 w-12 h-12 bg-[#111827] rounded-2xl flex items-center justify-center text-white shadow-lg border-4 border-white">
              <ShieldCheck size={24} />
            </div>
          </div>

          <div className="flex-1 text-center md:text-left">
            <div className="flex flex-col md:flex-row md:items-center gap-4 mb-4">
              <h2 className="text-4xl font-black text-[#111827] tracking-tight truncate">{user.name}</h2>
              <span className={cn(
                "w-fit mx-auto md:mx-0 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-[0.2em] border",
                user.role === 'admin' ? "bg-amber-50 text-amber-600 border-amber-100" : "bg-green-50 text-green-600 border-green-100"
              )}>
                Authorized {user.role}
              </span>
            </div>
            
            <div className="flex flex-wrap items-center justify-center md:justify-start gap-4 text-[#6B7280] font-black text-[10px] uppercase tracking-widest">
              <span className="flex items-center gap-2 bg-gray-50 px-3 py-1.5 rounded-xl border border-gray-100">
                <Mail size={14} className="text-gray-400" />
                {user.email}
              </span>
              <span className="flex items-center gap-2 bg-gray-50 px-3 py-1.5 rounded-xl border border-gray-100">
                <Calendar size={14} className="text-gray-400" />
                Reg Date: {format(safeGetDate(user.createdAt), 'MMM dd, yyyy')}
              </span>
              <span className={cn(
                "px-3 py-1.5 rounded-xl border font-black",
                user.accountStatus === 'disabled' ? "bg-rose-50 text-rose-600 border-rose-100" : "bg-emerald-50 text-emerald-600 border-emerald-100"
              )}>
                Status: {user.accountStatus || 'active'}
              </span>
            </div>
          </div>
          
          <div className="flex flex-col items-center md:items-end gap-3">
             <div className="px-8 py-5 bg-[#111827] text-white rounded-[2rem] shadow-2xl relative overflow-hidden">
                <div className="absolute top-0 right-0 w-16 h-16 bg-white/5 rounded-full -mr-8 -mt-8"></div>
                <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1 text-left">Merit Balance</p>
                <div className="flex items-baseline gap-2">
                    <span className="text-4xl font-black tabular-nums">{user.points}</span>
                    <span className="text-xs font-black text-green-400">PTS</span>
                </div>
             </div>
             
             <button
               onClick={handleToggleStatus}
               className={cn(
                 "flex items-center gap-2 px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all shadow-lg",
                 user.accountStatus === 'disabled'
                  ? "bg-emerald-600 text-white hover:bg-emerald-700 shadow-emerald-200"
                  : "bg-rose-600 text-white hover:bg-rose-700 shadow-rose-200"
               )}
             >
               {user.accountStatus === 'disabled' ? <ShieldCheck size={16} /> : <Ban size={16} />}
               {user.accountStatus === 'disabled' ? 'Authorize Access' : 'Suspend Account'}
             </button>
          </div>
        </div>
      </div>

      {/* Professional Record Details */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white p-10 rounded-[3rem] border border-gray-100 shadow-xl space-y-10">
          <div>
            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-10 rounded-2xl bg-blue-50 flex items-center justify-center text-blue-600">
                 <Briefcase size={20} />
              </div>
              <h3 className="text-xl font-black text-[#111827] uppercase tracking-tight">Citizen Deployment Record</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-8">
              <div className="space-y-2 group">
                <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] ml-2 group-hover:text-blue-500 transition-colors">Authorized Full Name</p>
                <div className="flex items-center gap-4 bg-gray-50/50 p-4 rounded-2xl border-2 border-transparent group-hover:border-blue-100 group-hover:bg-white transition-all">
                  <UserIcon size={20} className="text-gray-300" />
                  <p className="font-extrabold text-[#111827]">{user.name}</p>
                </div>
              </div>

              <div className="space-y-2 group">
                <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] ml-2 group-hover:text-blue-500 transition-colors">Mobile Identification</p>
                <div className="flex items-center gap-4 bg-gray-50/50 p-4 rounded-2xl border-2 border-transparent group-hover:border-blue-100 group-hover:bg-white transition-all">
                  <Phone size={20} className="text-gray-300" />
                  <p className="font-extrabold text-[#111827]">{user.mobile || 'NOT PROVIDED'}</p>
                </div>
              </div>

              <div className="space-y-2 group">
                <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] ml-2 group-hover:text-blue-500 transition-colors">Municipal Ward</p>
                <div className="flex items-center gap-4 bg-gray-50/50 p-4 rounded-2xl border-2 border-transparent group-hover:border-blue-100 group-hover:bg-white transition-all">
                  <Hash size={20} className="text-gray-300" />
                  <p className="font-extrabold text-[#111827]">{user.wardNumber ? `Ward #${user.wardNumber}` : 'NOT ASSIGNED'}</p>
                </div>
              </div>

              <div className="space-y-2 group">
                <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] ml-2 group-hover:text-blue-500 transition-colors">Career / Profession</p>
                <div className="flex items-center gap-4 bg-gray-50/50 p-4 rounded-2xl border-2 border-transparent group-hover:border-blue-100 group-hover:bg-white transition-all">
                  <Briefcase size={20} className="text-gray-300" />
                  <p className="font-extrabold text-[#111827] uppercase">{user.profession || 'NOT UPDATED'}</p>
                </div>
              </div>

              <div className="space-y-2 group">
                <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] ml-2 group-hover:text-blue-500 transition-colors">Assigned City</p>
                <div className="flex items-center gap-4 bg-gray-50/50 p-4 rounded-2xl border-2 border-transparent group-hover:border-blue-100 group-hover:bg-white transition-all">
                  <Globe size={20} className="text-gray-300" />
                  <p className="font-extrabold text-[#111827] uppercase tracking-tight">{user.city || 'Raipur'}</p>
                </div>
              </div>
            </div>
            
            <div className="space-y-2 mt-8 group">
              <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] ml-2 group-hover:text-blue-500 transition-colors">Verified Residential Coordinates</p>
              <div className="flex items-start gap-4 bg-gray-50/50 p-5 rounded-3xl border-2 border-transparent group-hover:border-blue-100 group-hover:bg-white transition-all min-h-[100px]">
                <MapPin size={22} className="text-gray-300 mt-1 shrink-0" />
                <p className="font-extrabold text-[#111827] leading-relaxed uppercase text-sm">{user.address || 'RESIDENTIAL DATA NOT PROVIDED'}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white p-10 rounded-[3rem] border border-gray-100 shadow-xl space-y-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-2xl bg-orange-50 flex items-center justify-center text-orange-600">
               <TrendingUp size={20} />
            </div>
            <h3 className="text-xl font-black text-[#111827] uppercase tracking-tight">Civic Analytics</h3>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between p-6 bg-gray-50 rounded-3xl group hover:bg-[#111827] transition-all">
              <div>
                <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest group-hover:text-gray-500 transition-colors">Tasks Completed</p>
                <p className="text-2xl font-black text-[#111827] group-hover:text-white transition-colors tabular-nums">{user.tasksCompleted || 0}</p>
              </div>
              <div className="w-12 h-12 bg-white rounded-2xl shadow-sm flex items-center justify-center text-emerald-500">
                <CheckCircle2 size={24} />
              </div>
            </div>

            <div className="flex items-center justify-between p-6 bg-gray-50 rounded-3xl group hover:bg-[#111827] transition-all">
              <div>
                <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest group-hover:text-gray-500 transition-colors">Login Continuity</p>
                <p className="text-2xl font-black text-orange-600 transition-colors tabular-nums">{user.currentStreak || 0} <span className="text-[10px] uppercase">Days</span></p>
              </div>
              <div className="w-12 h-12 bg-white rounded-2xl shadow-sm flex items-center justify-center text-orange-500">
                <TrendingUp size={24} />
              </div>
            </div>

            <div className="flex items-center justify-between p-6 bg-gray-50 rounded-3xl group hover:bg-[#111827] transition-all">
              <div>
                <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest group-hover:text-gray-500 transition-colors">Civic Grievances</p>
                <p className="text-2xl font-black text-rose-600 transition-colors tabular-nums">{user.complaintsSubmitted || 0}</p>
              </div>
              <div className="w-12 h-12 bg-white rounded-2xl shadow-sm flex items-center justify-center text-rose-500">
                <ShieldAlert size={24} />
              </div>
            </div>

            <div className="flex items-center justify-between p-6 bg-gray-50 rounded-3xl group hover:bg-[#111827] transition-all">
              <div>
                <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest group-hover:text-gray-500 transition-colors">Citizen Maturity</p>
                <p className="text-sm font-black text-indigo-600 uppercase tracking-tighter group-hover:text-indigo-400 transition-colors">
                  {user.points >= 1000 ? 'Municipal Legend' : user.points >= 500 ? 'Civic Hero' : 'Active Citizen'}
                </p>
              </div>
              <div className="w-12 h-12 bg-white rounded-2xl shadow-sm flex items-center justify-center text-indigo-500">
                <Award size={24} />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Analytics Mini-Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-green-50 rounded-2xl flex items-center justify-center text-green-600">
              <CheckCircle2 size={24} />
            </div>
            <div>
              <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Tasks Executed</p>
              <p className="text-2xl font-black text-[#111827]">{completedCount}</p>
            </div>
          </div>
        </div>
        <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-amber-50 rounded-2xl flex items-center justify-center text-amber-600">
              <Clock size={24} />
            </div>
            <div>
              <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">In Progress</p>
              <p className="text-2xl font-black text-[#111827]">{pendingCount}</p>
            </div>
          </div>
        </div>
        <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-600">
              <TrendingUp size={24} />
            </div>
            <div>
              <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Success Rate</p>
              <p className="text-2xl font-black text-[#111827]">
                {tasks.length > 0 ? Math.round((completedCount / tasks.length) * 100) : 0}%
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Completed Tasks History Section */}
      <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-xl overflow-hidden">
        <div className="px-8 py-8 border-b border-gray-50 flex items-center justify-between bg-gray-50/30">
           <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-green-100 flex items-center justify-center text-green-600">
                <ShieldCheck size={20} />
              </div>
              <div>
                <h3 className="text-xl font-black text-[#111827] tracking-tight uppercase tracking-widest text-sm">Validated Accomplishments</h3>
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mt-0.5">Chronological record of verified missions</p>
              </div>
           </div>
        </div>

        {tasks.filter(t => t.status === 'completed' || t.status === 'approved').length === 0 ? (
          <div className="p-20 text-center space-y-4">
            <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto text-gray-200">
               <CheckCircle2 size={32} />
            </div>
            <p className="text-gray-400 font-bold">No validated accomplishments recorded for this citizen.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-gray-50 bg-gray-50/10">
                  <th className="px-8 py-6 text-[10px] font-black text-gray-400 uppercase tracking-widest">Validated Mission</th>
                  <th className="px-8 py-6 text-[10px] font-black text-gray-400 uppercase tracking-widest text-right">Completion Timestamp</th>
                  <th className="px-8 py-6 text-[10px] font-black text-gray-400 uppercase tracking-widest text-right">Merit Awarded</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {tasks
                  .filter((task) => task.status === 'completed' || task.status === 'approved')
                  .sort((a, b) => {
                    const dateA = safeGetDate(a.completedAt || a.createdAt).getTime();
                    const dateB = safeGetDate(b.completedAt || b.createdAt).getTime();
                    return dateB - dateA;
                  })
                  .map((task) => (
                    <tr key={(task as any)._id || task.id} className="hover:bg-green-50/30 transition-colors group">
                      <td className="px-8 py-6">
                        <div className="flex flex-col">
                          <span className="text-sm font-black text-gray-900 uppercase group-hover:text-green-600 transition-colors">{task.title}</span>
                          <div className="flex items-center gap-1.5 text-[10px] font-bold text-gray-400 mt-1 uppercase">
                             <MapPin size={12} />
                             {task.location}
                          </div>
                        </div>
                      </td>
                      <td className="px-8 py-6 text-right">
                        <div className="flex flex-col items-end">
                          <span className="text-sm font-black text-gray-700">
                            {task.completedAt ? format(safeGetDate(task.completedAt), 'MMM dd, yyyy') : 'VERIFIED'}
                          </span>
                          <span className="text-[10px] text-gray-400 font-bold uppercase tracking-tight">
                            {task.completedAt ? format(safeGetDate(task.completedAt), 'HH:mm') : ''}
                          </span>
                        </div>
                      </td>
                      <td className="px-8 py-6 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <div className="px-3 py-1 bg-green-100 rounded-full border border-green-200">
                            <span className="text-xs font-black text-green-700">+{task.pointsValue} PTS</span>
                          </div>
                        </div>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Full Deployment History */}
      <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-xl overflow-hidden">
        <div className="px-8 py-8 border-b border-gray-50 flex items-center justify-between">
           <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gray-50 flex items-center justify-center text-gray-400">
                <History size={20} />
              </div>
              <h3 className="text-xl font-black text-[#111827] tracking-tight uppercase tracking-widest text-sm">Full Deployment Logs</h3>
           </div>
        </div>

        {tasks.length === 0 ? (
          <div className="p-20 text-center space-y-4">
            <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto text-gray-200">
               <History size={32} />
            </div>
            <p className="text-gray-400 font-bold">No history records found for this citizen.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-gray-50">
                  <th className="px-8 py-6 text-[10px] font-black text-gray-400 uppercase tracking-widest">Location / Mission</th>
                  <th className="px-8 py-6 text-[10px] font-black text-gray-400 uppercase tracking-widest text-center">Status</th>
                  <th className="px-8 py-6 text-[10px] font-black text-gray-400 uppercase tracking-widest text-right">Merit Reward</th>
                  <th className="px-8 py-6 text-[10px] font-black text-gray-400 uppercase tracking-widest text-right">Completion Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {tasks.map((task) => (
                  <tr key={(task as any)._id || task.id} className="hover:bg-gray-50/50 transition-colors group">
                    <td className="px-8 py-6">
                      <div className="flex flex-col">
                        <span className="text-sm font-black text-gray-900 uppercase group-hover:text-green-600 transition-colors">{task.title}</span>
                        <div className="flex items-center gap-1.5 text-[10px] font-bold text-gray-400 mt-1 uppercase">
                           <MapPin size={12} />
                           {task.location}
                        </div>
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <div className="flex justify-center">
                        <span className={cn(
                          "px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest",
                          (task.status === 'completed' || task.status === 'approved')
                            ? "bg-green-100 text-green-700" 
                            : task.status === 'submitted' 
                              ? "bg-blue-100 text-blue-700"
                              : "bg-amber-100 text-amber-700"
                        )}>
                          {task.status}
                        </span>
                      </div>
                    </td>
                    <td className="px-8 py-6 text-right">
                      <span className="text-sm font-black text-gray-900">+{task.pointsValue} PTS</span>
                    </td>
                    <td className="px-8 py-6 text-right">
                      <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">
                        {task.completedAt ? format(safeGetDate(task.completedAt), 'MMM dd, yyyy') : 'PENDING'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Merit Redemptions History */}
      <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-xl overflow-hidden">
        <div className="px-8 py-8 border-b border-gray-50 flex items-center justify-between bg-indigo-50/10">
           <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-indigo-100 flex items-center justify-center text-indigo-600">
                <Trophy size={20} />
              </div>
              <div>
                <h3 className="text-xl font-black text-[#111827] tracking-tight uppercase tracking-widest text-sm">Merit Redemption Archive</h3>
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mt-0.5">Summary of citizen benefit utilization</p>
              </div>
           </div>
        </div>

        {redeems.length === 0 ? (
          <div className="p-20 text-center space-y-4">
            <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto text-gray-200">
               <Gift size={32} />
            </div>
            <p className="text-gray-400 font-bold">No merit point redemptions found in historical records.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-gray-50 bg-indigo-50/5">
                  <th className="px-8 py-6 text-[10px] font-black text-gray-400 uppercase tracking-widest">Reward Entity</th>
                  <th className="px-8 py-6 text-[10px] font-black text-gray-400 uppercase tracking-widest text-center">Benefit Status</th>
                  <th className="px-8 py-6 text-[10px] font-black text-gray-400 uppercase tracking-widest text-right">Merit Cost</th>
                  <th className="px-8 py-6 text-[10px] font-black text-gray-400 uppercase tracking-widest text-right">Redemption Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {redeems.map((redeem) => (
                  <tr key={(redeem as any)._id || redeem.id} className="hover:bg-indigo-50/30 transition-colors group">
                    <td className="px-8 py-6">
                      <div className="flex items-center gap-4">
                        <div className="w-8 h-8 rounded-lg bg-white shadow-sm flex items-center justify-center text-indigo-400">
                          <Gift size={16} />
                        </div>
                        <span className="text-sm font-black text-gray-900 uppercase">{redeem.rewardTitle}</span>
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <div className="flex justify-center">
                        <span className={cn(
                          "px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest border",
                          redeem.status === 'processed' ? "bg-green-50 text-green-700 border-green-100" : "bg-blue-50 text-blue-700 border-blue-100"
                        )}>
                          {redeem.status}
                        </span>
                      </div>
                    </td>
                    <td className="px-8 py-6 text-right font-black text-rose-600 tabular-nums">
                      -{redeem.pointsCost} PTS
                    </td>
                    <td className="px-8 py-6 text-right">
                      <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">
                        {format(safeGetDate(redeem.createdAt), 'MMM dd, yyyy')}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
