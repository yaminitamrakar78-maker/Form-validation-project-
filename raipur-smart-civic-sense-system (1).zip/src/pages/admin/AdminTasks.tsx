import React, { useState, useEffect } from 'react';
import { api } from '../../lib/api';
import { Task, UserProfile } from '../../types';
import { 
  Plus, 
  Search, 
  Filter, 
  MapPin, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  MoreVertical,
  ArrowUpDown,
  X,
  Loader2,
  ClipboardList,
  Edit2,
  Sparkles,
  ExternalLink,
  ShieldCheck,
  ShieldAlert,
  Trash2,
  Check,
  Settings,
  Zap,
  Target,
  History,
  User as UserIcon,
  Calendar
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn, safeGetDate } from '../../lib/utils';
import { format } from 'date-fns';
import { MapContainer, TileLayer, Marker, Popup, useMapEvents } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { useAuth } from '../../context/AuthContext';
import { toast } from 'sonner';

const markerIcon = 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png';
const markerShadow = 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png';

let DefaultIcon = L.icon({
  iconUrl: markerIcon,
  shadowUrl: markerShadow,
  iconSize: [25, 41],
  iconAnchor: [12, 41]
});
L.Marker.prototype.options.icon = DefaultIcon;

export const AdminTasks: React.FC = () => {
  const { profile: adminProfile } = useAuth();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [workers, setWorkers] = useState<Record<string, string>>({});
  const [workerEmails, setWorkerEmails] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'pending' | 'submitted' | 'approved' | 'rejected'>('all');
  const [search, setSearch] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [reviewTask, setReviewTask] = useState<Task | null>(null);
  const [isHistoryModalOpen, setIsHistoryModalOpen] = useState(false);
  const [historyTask, setHistoryTask] = useState<any | null>(null);
  const [taskLogs, setTaskLogs] = useState<any[]>([]);
  const [loadingLogs, setLoadingLogs] = useState(false);
  const [isActioning, setIsActioning] = useState(false);
  const [rejectionReason, setRejectionReason] = useState('');
  
  // Task form state
  const [taskForm, setTaskForm] = useState({
    title: '',
    description: '',
    location: '',
    latitude: 21.1702,
    longitude: 72.8311,
    pointsValue: 50,
    type: 'individual' as 'individual' | 'group',
    workerId: '',
    assignedUsers: [] as string[]
  });

  const [mode, setMode] = useState<'tasks' | 'habits' | 'settings'>('tasks');
  const [habitSubmissions, setHabitSubmissions] = useState<any[]>([]);

  // Settings state
  const [autoApprove, setAutoApprove] = useState(false);
  const [confidenceThreshold, setConfidenceThreshold] = useState(0.8);
  const [isSavingSettings, setIsSavingSettings] = useState(false);

  // Body scroll lock
  useEffect(() => {
    if (isModalOpen || reviewTask || isHistoryModalOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isModalOpen, reviewTask, isHistoryModalOpen]);

  const fetchSettings = async () => {
    try {
      const data = await api.admin.getSettings();
      setAutoApprove(data.autoApproveHabits || false);
      setConfidenceThreshold(data.aiConfidenceThreshold || 0.8);
    } catch (err) {
      console.error("Error fetching settings:", err);
    }
  };

  const logTaskAction = async (taskId: string, action: string, details?: string) => {
    if (!adminProfile) return;
    try {
      await api.admin.addLog({
        taskId,
        action,
        userName: adminProfile.name,
        details: details || ''
      });
    } catch (error) {
      console.error("Error logging task action:", error);
    }
  };

  const fetchTaskHistory = async (taskId: string) => {
    setLoadingLogs(true);
    try {
      const logs = await api.admin.getLogs(taskId);
      setTaskLogs(logs);
    } catch (error) {
      console.error("Error fetching task history:", error);
      toast.error("Failed to load task history");
    } finally {
      setLoadingLogs(false);
    }
  };

  const openHistoryModal = (item: any) => {
    setHistoryTask(item);
    setIsHistoryModalOpen(true);
    fetchTaskHistory(item._id || item.id);
  };

  const handleSaveSettings = async () => {
    setIsSavingSettings(true);
    try {
      await api.admin.updateSettings({
        autoApproveHabits: autoApprove,
        aiConfidenceThreshold: confidenceThreshold,
      });
      toast.success("System configuration updated successfully");
    } catch (error) {
      console.error("Settings error:", error);
      toast.error("Failed to update settings");
    } finally {
      setIsSavingSettings(false);
    }
  };

  const fetchWorkers = async () => {
    try {
      const users = await api.users.getAll();
      const workerMap: Record<string, string> = {};
      const emailMap: Record<string, string> = {};
      users.forEach((user: any) => {
        workerMap[user.id || user._id] = user.name || 'Citizen';
        emailMap[user.id || user._id] = user.email || '';
      });
      setWorkers(workerMap);
      setWorkerEmails(emailMap);
    } catch (err) {
      console.error("Error fetching workers:", err);
    }
  };

  const sendNotification = async (userId: string, title: string, message: string, type: 'assignment' | 'approval' | 'rejection', relatedId: string) => {
    try {
      await api.notifications.create({
        userId,
        title,
        message,
        type,
        relatedId
      });

      // Send email if worker email is available
      const workerEmail = workerEmails[userId];
      if (workerEmail) {
        await api.sendEmail({
          to: workerEmail,
          subject: `[Smart Civic] ${title}`,
          html: `
            <div style="font-family: sans-serif; max-width: 600px; margin: auto; border: 1px solid #eee; padding: 20px; border-radius: 10px;">
              <h2 style="color: #16a34a;">Smart Civic Notification</h2>
              <p>Hello,</p>
              <p><strong>${title}</strong></p>
              <p>${message}</p>
              <div style="margin-top: 20px; padding-top: 20px; border-top: 1px solid #eee; font-size: 12px; color: #666;">
                This is an automated notification from the Smart Civic Sense System.
              </div>
            </div>
          `
        });
      }
    } catch (error) {
      console.error("Error sending notification:", error);
    }
  };

  useEffect(() => {
    fetchWorkers();
    fetchSettings();
  }, []);

  const fetchAdminTasks = async () => {
    setLoading(true);
    try {
      if (mode === 'tasks') {
        const data = await api.tasks.getAll();
        setTasks(data);
      } else if (mode === 'habits') {
        const data = await api.habits.getAll();
        const formattedData = data.map((d: any) => {
          return { 
            id: d.id || d._id, 
            ...d,
            title: d.taskTitle,
            pointsValue: d.points,
            proofImageUrl: d.imageUrl,
            latitude: d.location?.lat,
            longitude: d.location?.lng
          };
        });
        setHabitSubmissions(formattedData);
      }
    } catch (err) {
      console.error("Fetch tasks failed:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (mode !== 'settings') {
      fetchAdminTasks();
    }
  }, [mode]);

  useEffect(() => {
    // Audit logic removed to resolve build error
  }, [reviewTask]);

  const handleApprove = async () => {
    if (!reviewTask) return;
    const taskId = (reviewTask as any)._id || reviewTask.id;
    setIsActioning(true);
    try {
      if (mode === 'tasks') {
        await api.tasks.approve(taskId);
      } else {
        await api.habits.approve(taskId);
      }

      await logTaskAction(taskId, 'approved', `Task approved by ${adminProfile?.name}`);

      toast.success("✅ Task approved and points awarded successfully");
      setReviewTask(null);
      fetchAdminTasks();
    } catch (error) {
      console.error("Approval failed:", error);
      toast.error("Failed to approve.");
    } finally {
      setIsActioning(false);
    }
  };

  const handleReject = async () => {
    if (!reviewTask || !rejectionReason) {
      toast.error("Please provide a reason.");
      return;
    }
    const taskId = (reviewTask as any)._id || reviewTask.id;
    setIsActioning(true);
    try {
      if (mode === 'tasks') {
        await api.tasks.reject(taskId, rejectionReason);
      } else {
        await api.habits.reject(taskId, rejectionReason);
      }

      await logTaskAction(taskId, 'rejected', `Reason: ${rejectionReason}`);

      toast.info("❌ Task rejected by admin");
      setReviewTask(null);
      fetchAdminTasks();
    } catch (error) {
      console.error("Rejection failed:", error);
      toast.error("Failed to reject.");
    } finally {
      setIsActioning(false);
    }
  };

  const handleDelete = async (item: any) => {
    const itemId = item._id || item.id;
    const isConfirmed = window.confirm(`Are you sure you want to permanently delete this ${mode === 'tasks' ? 'task' : 'submission'}? This action cannot be undone.`);
    if (!isConfirmed) return;

    const toastId = toast.loading("Deleting record...");
    try {
      if (mode === 'tasks') {
        await api.tasks.delete(itemId);
        await logTaskAction(itemId, 'deleted', `Task "${item.title}" deleted`);
      } else {
        await api.habits.delete(itemId);
      }
      toast.success("Record deleted successfully", { id: toastId });
      fetchAdminTasks();
    } catch (error) {
      console.error("Deletion failed:", error);
      toast.error("Failed to delete the record", { id: toastId });
    }
  };

  const handleSaveTask = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      if (editingTask) {
        await api.tasks.update(editingTask.id, taskForm);
        await logTaskAction(editingTask.id, 'updated', `Task details updated.`);
      } else {
        const newTask = await api.tasks.create(taskForm);
        await logTaskAction(newTask.id, 'created', `Initial deployment.`);
      }
      setIsModalOpen(false);
      setEditingTask(null);
      fetchAdminTasks();
      toast.success(editingTask ? "Task updated" : "Task created and assigned");
    } catch (error) {
      console.error("Error saving task:", error);
      toast.error("Failed to save task");
    } finally {
      setIsSubmitting(false);
    }
  };

  const openAddModal = () => {
    setEditingTask(null);
    setTaskForm({ 
      title: '', 
      description: '', 
      location: '', 
      latitude: 21.1702,
      longitude: 72.8311,
      pointsValue: 50, 
      type: 'individual', 
      workerId: '', 
      assignedUsers: [] 
    });
    setIsModalOpen(true);
  };

  const openEditModal = (task: Task) => {
    setEditingTask(task);
    setTaskForm({
      title: task.title,
      description: task.description,
      location: task.location,
      latitude: task.latitude || 21.1702,
      longitude: task.longitude || 72.8311,
      pointsValue: task.pointsValue,
      type: task.type || 'individual',
      workerId: task.workerId || '',
      assignedUsers: task.assignedUsers || []
    });
    setIsModalOpen(true);
  };

  const LocationPicker = () => {
    useMapEvents({
      click(e) {
        setTaskForm(prev => ({
          ...prev,
          latitude: e.latlng.lat,
          longitude: e.latlng.lng
        }));
      },
    });
    return taskForm.latitude && taskForm.longitude ? (
      <Marker position={[taskForm.latitude, taskForm.longitude]} />
    ) : null;
  };

  const ChangeView = ({ center }: { center: [number, number] }) => {
    const map = useMapEvents({});
    map.setView(center);
    return null;
  };

  const filteredTasks = tasks.filter(task => {
    const matchesFilter = filter === 'all' || task.status === filter;
    const matchesSearch = task.title.toLowerCase().includes(search.toLowerCase()) || 
                         task.location.toLowerCase().includes(search.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  return (
    <div className="space-y-8 pb-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-3xl font-black text-[#111827] tracking-tight">Task Repository</h2>
          <p className="text-[#6B7280] mt-1 font-medium">Manage and assign cleanliness goals across the city.</p>
        </div>
        <button 
          onClick={openAddModal}
          className="bg-green-600 text-white px-6 py-4 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-green-700 transition-all shadow-lg shadow-green-100 active:scale-95"
        >
          <Plus size={20} strokeWidth={3} />
          Deploy New Task
        </button>
      </div>
      {/* Mode Switcher */}
      <div className="flex items-center gap-4 bg-white p-2 rounded-3xl border border-gray-100 shadow-sm w-fit">
        <button 
          onClick={() => setMode('tasks')}
          className={cn(
            "px-8 py-3 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] transition-all",
            mode === 'tasks' ? "bg-[#111827] text-white shadow-xl" : "text-gray-400 hover:text-gray-600"
          )}
        >
          Municipal Tasks
        </button>
        <button 
          onClick={() => setMode('habits')}
          className={cn(
            "px-8 py-3 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] transition-all",
            mode === 'habits' ? "bg-[#111827] text-white shadow-xl" : "text-gray-400 hover:text-gray-600"
          )}
        >
          Daily Habit Submissions
        </button>
        <button 
          onClick={() => setMode('settings')}
          className={cn(
            "px-8 py-3 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] transition-all",
            mode === 'settings' ? "bg-[#111827] text-white shadow-xl" : "text-gray-400 hover:text-gray-600"
          )}
        >
          System Settings
        </button>
      </div>

      {mode === 'settings' ? (
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-[2.5rem] border border-gray-100 shadow-xl p-10 max-w-2xl"
        >
          <div className="flex items-center gap-4 mb-10">
            <div className="w-16 h-16 rounded-[1.5rem] bg-indigo-50 flex items-center justify-center text-indigo-600">
              <Settings size={32} />
            </div>
            <div>
              <h3 className="text-2xl font-black text-[#111827] tracking-tight">AI & Automation</h3>
              <p className="text-gray-400 text-sm font-medium">Configure auto-approval parameters for civic tasks.</p>
            </div>
          </div>

          <div className="space-y-8">
            <div className="flex items-center justify-between p-6 bg-gray-50 rounded-3xl border border-gray-100">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <Zap size={18} className="text-yellow-500" />
                  <h4 className="font-black text-[#111827] text-sm uppercase tracking-tight">Auto-Approve Submissions</h4>
                </div>
                <p className="text-xs text-gray-500 font-medium">Allow AI to instantly award points for high-confidence proofs.</p>
              </div>
              <button 
                onClick={() => setAutoApprove(!autoApprove)}
                className={cn(
                  "w-14 h-8 rounded-full transition-all relative flex items-center px-1",
                  autoApprove ? "bg-green-600" : "bg-gray-300"
                )}
              >
                <motion.div 
                  animate={{ x: autoApprove ? 24 : 0 }}
                  className="w-6 h-6 bg-white rounded-full shadow-md"
                />
              </button>
            </div>

            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <Target size={18} className="text-blue-500" />
                  <h4 className="font-black text-[#111827] text-sm uppercase tracking-tight">AI Confidence Threshold</h4>
                </div>
                <span className="font-black text-indigo-600 bg-indigo-50 px-3 py-1 rounded-lg text-sm">{Math.round(confidenceThreshold * 100)}%</span>
              </div>
              <input 
                type="range"
                min="0.5"
                max="0.99"
                step="0.01"
                value={confidenceThreshold}
                onChange={(e) => setConfidenceThreshold(parseFloat(e.target.value))}
                className="w-full h-2 bg-gray-100 rounded-lg appearance-none cursor-pointer accent-indigo-600"
              />
              <div className="flex justify-between text-[10px] font-black text-gray-400 uppercase tracking-widest px-1">
                <span>Medium (50%)</span>
                <span>Ultra High (99%)</span>
              </div>
              <p className="text-[10px] text-gray-400 italic">
                Higher threshold means fewer auto-approvals but lower risk of fraud. Recommended: 80%+.
              </p>
            </div>

            <button 
              onClick={handleSaveSettings}
              disabled={isSavingSettings}
              className="w-full bg-[#111827] text-white py-5 rounded-2xl font-black uppercase tracking-[0.2em] text-xs hover:bg-black transition-all flex items-center justify-center gap-3 shadow-xl disabled:opacity-50"
            >
              {isSavingSettings ? <Loader2 className="animate-spin" size={18} /> : <CheckCircle2 size={18} />}
              Save Configuration
            </button>
          </div>
        </motion.div>
      ) : (
      <>
      {/* Filters & Search */}
      <div className="bg-white p-4 rounded-3xl border border-gray-100 shadow-sm flex flex-col lg:flex-row items-center gap-4">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
          <input 
            type="text" 
            placeholder={mode === 'tasks' ? "Search tasks by title or location..." : "Search habits..."}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-12 pr-4 py-3 bg-gray-50 border-none rounded-2xl focus:ring-2 focus:ring-green-500 transition-all font-medium"
          />
        </div>
        <div className="flex items-center gap-2 p-1 bg-gray-50 rounded-2xl w-full lg:w-auto">
          {(['all', 'pending', 'submitted', 'approved', 'rejected'] as const).map((t) => (
            <button
              key={t}
              onClick={() => setFilter(t)}
              className={cn(
                "px-6 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition-all flex-1 lg:flex-none",
                filter === t ? "bg-white text-green-600 shadow-sm" : "text-gray-400 hover:text-gray-600"
              )}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* Table Container */}
      <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-xl overflow-hidden">
        {loading ? (
          <div className="p-20 flex flex-col items-center justify-center gap-4">
            <Loader2 className="animate-spin text-green-600" size={40} />
            <p className="text-gray-400 font-bold uppercase tracking-widest text-xs">Accessing Records...</p>
          </div>
        ) : (mode === 'tasks' ? filteredTasks : habitSubmissions.filter(h => filter === 'all' || h.status === filter)).length === 0 ? (
          <div className="p-20 text-center space-y-4">
            <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto">
              <ClipboardList size={32} className="text-gray-300" />
            </div>
            <p className="text-gray-500 font-bold">No {mode} found matching your criteria.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-gray-50">
                  <th className="px-8 py-6 text-[10px] font-black text-gray-400 uppercase tracking-widest">Details</th>
                  <th className="px-8 py-6 text-[10px] font-black text-gray-400 uppercase tracking-widest text-center">Status</th>
                  <th className="px-8 py-6 text-[10px] font-black text-gray-400 uppercase tracking-widest">Participant</th>
                  <th className="px-8 py-6 text-[10px] font-black text-gray-400 uppercase tracking-widest text-right">Points</th>
                  <th className="px-8 py-6 text-[10px] font-black text-gray-400 uppercase tracking-widest text-right">Date</th>
                  <th className="px-8 py-6 text-[10px] font-black text-gray-400 uppercase tracking-widest text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {(mode === 'tasks' ? filteredTasks : habitSubmissions.filter(h => filter === 'all' || h.status === filter)).map((item) => (
                  <tr key={(item as any)._id || item.id} className="hover:bg-gray-50/50 transition-colors group">
                    <td className="px-8 py-6">
                      <div className="flex flex-col">
                        <span className="text-sm font-black text-gray-900 group-hover:text-green-600 transition-colors uppercase">{item.title}</span>
                        <span className="text-xs text-gray-400 line-clamp-1 mt-1 font-medium">{item.description || item.address}</span>
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <div className="flex justify-center">
                        <span className={cn(
                          "px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-tighter",
                          item.status === 'approved' ? "bg-green-100 text-green-700" : 
                          item.status === 'submitted' ? "bg-blue-100 text-blue-700" :
                          item.status === 'rejected' ? "bg-rose-100 text-rose-700" :
                          "bg-amber-100 text-amber-700"
                        )}>
                          {item.status}
                        </span>
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <div className="flex items-center gap-3">
                         <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 text-[10px] font-bold">
                           {workers[item.workerId || item.userId]?.charAt(0) || 'U'}
                         </div>
                         <span className="text-xs font-bold text-gray-700">{workers[item.workerId || item.userId] || 'Unknown Citizen'}</span>
                      </div>
                    </td>
                    <td className="px-8 py-6 text-right">
                      <span className="text-sm font-black text-[#111827]">{item.pointsValue} PTS</span>
                    </td>
                    <td className="px-8 py-6 text-right whitespace-nowrap">
                      <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">
                        {format(safeGetDate(item.createdAt || item.timestamp), 'MMM dd')}
                      </span>
                    </td>
                    <td className="px-8 py-6 text-right whitespace-nowrap">
                      <div className="flex justify-end gap-2">
                        {(mode === 'habits' || item.status !== 'pending') ? (
                          <button 
                            onClick={() => setReviewTask(item)}
                            className={cn(
                              "p-2 rounded-lg transition-all flex items-center gap-1 text-[10px] font-black uppercase tracking-widest px-3 shadow-sm",
                              (item.status === 'submitted' || (mode === 'habits' && item.status === 'pending'))
                                ? "bg-blue-600 text-white hover:bg-blue-700" 
                                : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                            )}
                          >
                             {(item.status === 'submitted' || (mode === 'habits' && item.status === 'pending')) ? (
                               <>
                                 <Sparkles size={14} className="animate-pulse" />
                                 Review
                               </>
                             ) : 'View Detail'}
                          </button>
                        ) : null}
                        <button 
                           onClick={() => openHistoryModal(item)}
                           className="p-2 rounded-lg bg-indigo-50 text-indigo-600 hover:bg-indigo-100 transition-all"
                           title="Audit History"
                        >
                           <History size={16} />
                        </button>
                        {mode === 'tasks' && (
                          <button 
                            onClick={() => openEditModal(item)}
                            className="p-2 rounded-lg bg-gray-50 text-gray-400 hover:text-green-600 transition-all"
                          >
                            <Edit2 size={16} />
                          </button>
                        )}
                        <button 
                          onClick={() => handleDelete(item)}
                          className="p-2 rounded-lg bg-gray-50 text-gray-400 hover:text-rose-600 transition-all"
                          title="Delete Record"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
      </>
      )}

      {/* History Modal */}
      <AnimatePresence>
        {isHistoryModalOpen && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsHistoryModalOpen(false)}
              className="absolute inset-0 bg-[#111827]/80 backdrop-blur-md"
            />
            <motion.div 
              initial={{ scale: 0.95, opacity: 0, x: 50 }}
              animate={{ scale: 1, opacity: 1, x: 0 }}
              exit={{ scale: 0.95, opacity: 0, x: 50 }}
              className="bg-white rounded-[3rem] shadow-2xl w-full max-w-2xl overflow-hidden relative z-10 flex flex-col max-h-[90vh]"
            >
              <div className="p-10 border-b border-gray-50 flex justify-between items-center bg-gray-50/50">
                <div className="flex items-center gap-4">
                    <div className="w-14 h-14 rounded-2xl bg-indigo-600 flex items-center justify-center text-white shadow-lg shadow-indigo-100">
                        <History size={28} />
                    </div>
                    <div>
                        <h3 className="text-2xl font-black text-[#111827] tracking-tight uppercase">Audit Trail</h3>
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mt-0.5">Chronological record of task lifecycle</p>
                    </div>
                </div>
                <button 
                    onClick={() => setIsHistoryModalOpen(false)} 
                    className="w-12 h-12 rounded-2xl bg-white border border-gray-100 flex items-center justify-center text-gray-400 hover:text-rose-500 transition-all shadow-sm"
                >
                  <X size={24} />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-10 space-y-8 bg-white custom-scrollbar">
                {historyTask && (
                    <div className="mb-12 p-6 bg-indigo-50/30 border border-indigo-100 rounded-3xl">
                        <div className="flex justify-between items-start mb-4">
                            <h4 className="text-lg font-black text-[#111827] uppercase tracking-tight">{historyTask.title}</h4>
                            <span className={cn(
                                "px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-tighter",
                                historyTask.status === 'approved' ? "bg-green-100 text-green-700" : 
                                historyTask.status === 'submitted' ? "bg-blue-100 text-blue-700" :
                                historyTask.status === 'rejected' ? "bg-rose-100 text-rose-700" :
                                "bg-amber-100 text-amber-700"
                            )}>
                                {historyTask.status}
                            </span>
                        </div>
                        <div className="grid grid-cols-2 gap-6 text-[11px]">
                            <div className="flex items-center gap-2 text-gray-500 font-bold border-r border-gray-100 uppercase tracking-wide">
                                <UserIcon size={14} className="text-indigo-400" />
                                {workers[historyTask.workerId || historyTask.userId] || 'Citizen'}
                            </div>
                            <div className="flex items-center gap-2 text-gray-500 font-bold uppercase tracking-wide">
                                <Calendar size={14} className="text-indigo-400" />
                                Created: {format(safeGetDate(historyTask.createdAt || historyTask.timestamp), 'PPP p')}
                            </div>
                        </div>
                    </div>
                )}

                <div className="relative pl-10 border-l-2 border-dashed border-gray-100 space-y-12 pb-8">
                    {loadingLogs ? (
                        <div className="py-20 flex flex-col items-center gap-4">
                            <Loader2 className="animate-spin text-indigo-600" size={32} />
                            <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Reconstructing timeline...</p>
                        </div>
                    ) : taskLogs.length === 0 ? (
                        <div className="py-12 text-center">
                             <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4">
                                <History size={24} className="text-gray-200" />
                            </div>
                            <p className="text-sm font-bold text-gray-400 uppercase tracking-tight">No historical logs captured yet</p>
                            <p className="text-[10px] text-gray-400 mt-1 uppercase">Logs will appear as actions are performed on this task.</p>
                        </div>
                    ) : (
                        taskLogs.map((log, idx) => (
                            <div key={log.id} className="relative">
                                <div className={cn(
                                    "absolute -left-[51px] top-0 w-6 h-6 rounded-full border-4 border-white shadow-md z-10",
                                    log.action === 'created' ? "bg-green-500" :
                                    log.action === 'assigned' || log.action === 'reassigned' ? "bg-blue-500" :
                                    log.action === 'approved' ? "bg-green-600 shadow-green-100" :
                                    log.action === 'rejected' ? "bg-rose-500 shadow-rose-100" :
                                    "bg-indigo-500"
                                )} />
                                <div className="space-y-2">
                                    <div className="flex justify-between items-center">
                                        <h5 className="text-sm font-black text-[#111827] uppercase tracking-tight">{log.action}</h5>
                                        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                                            {format(safeGetDate(log.timestamp), 'MMM dd, HH:mm')}
                                        </span>
                                    </div>
                                    <div className="p-5 bg-gray-50 rounded-2xl border border-gray-100 shadow-sm">
                                        <p className="text-xs font-medium text-gray-600 leading-relaxed italic">"{log.details || 'Task operational state changed'}"</p>
                                        <div className="mt-3 flex items-center gap-2 pt-3 border-t border-gray-100">
                                            <div className="w-6 h-6 rounded-full bg-white border border-gray-100 flex items-center justify-center text-[9px] font-black text-indigo-600 uppercase">
                                                {log.userName?.charAt(0)}
                                            </div>
                                            <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Executed by: {log.userName}</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ))
                    )}
                </div>
              </div>

              <div className="p-8 bg-gray-50/50 border-t border-gray-50">
                <button 
                  onClick={() => setIsHistoryModalOpen(false)}
                  className="w-full py-4 bg-[#111827] text-white rounded-2xl font-black uppercase tracking-[0.2em] text-xs hover:bg-black transition-all shadow-xl shadow-gray-200"
                >
                  Close Audit Panel
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Add Task Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsModalOpen(false)}
              className="absolute inset-0 bg-[#111827]/80 backdrop-blur-md"
            />
            <motion.div 
              initial={{ scale: 0.95, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 20 }}
              className="bg-white rounded-[2rem] shadow-2xl w-full max-w-[700px] max-h-[90vh] overflow-hidden relative z-10 flex flex-col"
            >
              <div className="p-6 md:p-10 border-b border-gray-50 flex justify-between items-center bg-white sticky top-0 z-20">
                <div>
                  <h3 className="text-2xl md:text-3xl font-black text-[#111827] tracking-tight">{editingTask ? 'Edit Task' : 'Create Task'}</h3>
                  <p className="text-gray-400 font-bold uppercase tracking-widest text-[9px] md:text-[10px] mt-1">{editingTask ? 'Modify technical specifications' : 'Define new civic objectives'}</p>
                </div>
                <button onClick={() => setIsModalOpen(false)} className="w-10 h-10 md:w-12 md:h-12 rounded-2xl bg-gray-50 flex items-center justify-center text-gray-400 hover:text-rose-500 hover:bg-rose-50 transition-all">
                  <X size={24} />
                </button>
              </div>

              <div className="p-6 md:p-10 overflow-y-auto custom-scrollbar flex-1">
                <form onSubmit={handleSaveTask} className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="md:col-span-2 space-y-2">
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Task Title</label>
                    <input 
                      required
                      type="text" 
                      placeholder="e.g., Clean Gandhi Park Entrance"
                      value={taskForm.title}
                      onChange={(e) => setTaskForm({...taskForm, title: e.target.value})}
                      className="w-full bg-gray-50 border-2 border-transparent focus:border-green-500 focus:bg-white rounded-2xl p-4 md:p-5 text-gray-800 font-bold placeholder-gray-300 transition-all focus:ring-0 outline-none"
                    />
                  </div>

                  <div className="md:col-span-2 space-y-4">
                    <div className="flex justify-between items-center px-1">
                      <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Select Precise Location</label>
                      <div className="flex gap-4">
                         <div className="flex flex-col items-end">
                            <span className="text-[8px] font-black text-gray-300 uppercase">Lat</span>
                            <span className="text-[10px] font-mono font-bold text-green-600">{taskForm.latitude.toFixed(4)}</span>
                         </div>
                         <div className="flex flex-col items-end">
                            <span className="text-[8px] font-black text-gray-300 uppercase">Lng</span>
                            <span className="text-[10px] font-mono font-bold text-green-600">{taskForm.longitude.toFixed(4)}</span>
                         </div>
                      </div>
                    </div>
                    <div className="h-64 rounded-3xl overflow-hidden border-2 border-gray-50 shadow-inner relative group">
                      <MapContainer 
                        center={[taskForm.latitude, taskForm.longitude]} 
                        zoom={13} 
                        className="h-full w-full"
                      >
                        <TileLayer
                          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                        />
                        <LocationPicker />
                        <ChangeView center={[taskForm.latitude, taskForm.longitude]} />
                      </MapContainer>
                      <div className="absolute top-4 right-4 z-[400] bg-white/90 backdrop-blur-md px-3 py-1.5 rounded-xl border border-gray-100 shadow-sm pointer-events-none">
                        <p className="text-[9px] font-black text-gray-900 uppercase tracking-tight">Click map to set point</p>
                      </div>
                    </div>
                  </div>

                  <div className="md:col-span-2 space-y-2">
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Location Name / Address</label>
                    <input 
                      required
                      type="text" 
                      placeholder="e.g., Sector 10 / Main Gate"
                      value={taskForm.location}
                      onChange={(e) => setTaskForm({...taskForm, location: e.target.value})}
                      className="w-full bg-gray-50 border-2 border-transparent focus:border-green-500 focus:bg-white rounded-2xl p-4 md:p-5 text-gray-800 font-bold placeholder-gray-300 transition-all focus:ring-0 outline-none"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Task Type</label>
                    <select 
                      value={taskForm.type}
                      onChange={(e) => setTaskForm({...taskForm, type: e.target.value as 'individual' | 'group'})}
                      className="w-full bg-gray-50 border-2 border-transparent focus:border-green-500 focus:bg-white rounded-2xl p-4 md:p-5 text-gray-800 font-bold transition-all focus:ring-0 outline-none"
                    >
                      <option value="individual">Individual</option>
                      <option value="group">Group Task</option>
                    </select>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Points Reward</label>
                    <input 
                      required
                      type="number" 
                      value={taskForm.pointsValue}
                      onChange={(e) => setTaskForm({...taskForm, pointsValue: parseInt(e.target.value) || 0})}
                      className="w-full bg-gray-50 border-2 border-transparent focus:border-green-500 focus:bg-white rounded-2xl p-4 md:p-5 text-gray-800 font-bold placeholder-gray-300 transition-all focus:ring-0 outline-none"
                    />
                  </div>

                  <div className="md:col-span-2">
                    {taskForm.type === 'individual' ? (
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Assign Operator</label>
                        <select 
                          value={taskForm.workerId}
                          onChange={(e) => setTaskForm({...taskForm, workerId: e.target.value})}
                          className="w-full bg-gray-50 border-2 border-transparent focus:border-green-500 focus:bg-white rounded-2xl p-4 md:p-5 text-gray-800 font-bold transition-all focus:ring-0 outline-none"
                        >
                          <option value="">Public Task (Unassigned)</option>
                          {Object.entries(workers).map(([id, name]) => (
                            <option key={id} value={id}>{name}</option>
                          ))}
                        </select>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Assign Group Members (Multi-select)</label>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-40 overflow-y-auto p-4 bg-gray-50 rounded-2xl border-2 border-transparent">
                          {Object.entries(workers).map(([id, name]) => (
                            <label key={id} className="flex items-center gap-3 p-2 hover:bg-white rounded-xl transition-colors cursor-pointer">
                              <input 
                                type="checkbox"
                                checked={taskForm.assignedUsers.includes(id)}
                                onChange={(e) => {
                                  if (e.target.checked) {
                                    setTaskForm({...taskForm, assignedUsers: [...taskForm.assignedUsers, id]});
                                  } else {
                                    setTaskForm({...taskForm, assignedUsers: taskForm.assignedUsers.filter(uid => uid !== id)});
                                  }
                                }}
                                className="rounded border-gray-300 text-green-600 focus:ring-green-500"
                              />
                              <span className="text-xs font-bold text-gray-700">{name}</span>
                            </label>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="md:col-span-2 space-y-2">
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Description</label>
                    <textarea 
                      required
                      rows={3}
                      placeholder="Provide specific instructions for the worker..."
                      value={taskForm.description}
                      onChange={(e) => setTaskForm({...taskForm, description: e.target.value})}
                      className="w-full bg-gray-50 border-2 border-transparent focus:border-green-500 focus:bg-white rounded-2xl p-4 md:p-5 text-gray-800 font-bold placeholder-gray-300 transition-all focus:ring-0 outline-none resize-none"
                    />
                  </div>

                  <div className="md:col-span-2 pt-4 flex flex-col sm:flex-row gap-4">
                    <button
                      type="button"
                      onClick={() => setIsModalOpen(false)}
                      className="flex-1 font-black py-4 md:py-5 rounded-[1.5rem] bg-gray-50 text-gray-400 hover:bg-gray-100 transition-all uppercase text-xs"
                    >
                      ABORT
                    </button>
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="flex-[2] bg-[#111827] text-white font-black py-4 md:py-5 rounded-[1.5rem] flex items-center justify-center gap-3 hover:bg-black transition-all shadow-xl shadow-gray-200 uppercase text-xs"
                    >
                      {isSubmitting ? (
                        <Loader2 className="animate-spin" size={20} />
                      ) : (
                        <>
                          <CheckCircle2 size={20} />
                          {editingTask ? 'SAVE CHANGES' : 'DEPLOY TASK'}
                        </>
                      )}
                    </button>
                  </div>
                </form>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Review Verification Modal */}
      <AnimatePresence>
        {reviewTask && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setReviewTask(null)}
              className="absolute inset-0 bg-[#111827]/90 backdrop-blur-xl"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 30 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 30 }}
              className="bg-white rounded-[2rem] md:rounded-[3.5rem] shadow-2xl w-full max-w-[700px] max-h-[90vh] overflow-hidden relative z-10 flex flex-col"
            >
              <div className="p-6 md:p-10 scroll-py-10 overflow-y-auto custom-scrollbar">
                <div className="flex justify-between items-start mb-8 sticky top-0 bg-white z-10 pb-4">
                  <div>
                    <h3 className="text-xl md:text-3xl font-black text-[#111827] tracking-tight uppercase">Intelligence Audit</h3>
                    <p className="text-gray-400 font-bold uppercase tracking-widest text-[9px] md:text-[10px] mt-1">Cross-referencing telemetry and vision data</p>
                  </div>
                  <div className="flex items-center gap-2 md:gap-4">
                    <button 
                      onClick={() => openHistoryModal(reviewTask)}
                      className="w-10 h-10 md:w-12 md:h-12 rounded-2xl bg-indigo-50 flex items-center justify-center text-indigo-600 hover:bg-indigo-100 transition-all border border-indigo-100 shadow-sm"
                      title="View Audit Log"
                    >
                      <History size={20} />
                    </button>
                    <button onClick={() => setReviewTask(null)} className="w-10 h-10 md:w-12 md:h-12 rounded-2xl bg-gray-50 flex items-center justify-center text-gray-400 hover:text-rose-500 transition-all">
                      <X size={20} />
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-8">
                  <div className="space-y-6">
                    <div className="relative rounded-2xl md:rounded-[2rem] overflow-hidden border-4 border-gray-50 aspect-video md:aspect-square group shadow-md">
                      <img src={reviewTask.proofImageUrl} alt="Audit" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                      
                      <div className="absolute top-4 left-4">
                        <span className={cn(
                          "px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-2xl backdrop-blur-md flex items-center gap-2",
                          (reviewTask as any).verificationStatus === 'genuine' ? "bg-green-500/80 text-white" :
                          (reviewTask as any).verificationStatus === 'suspicious' ? "bg-amber-500/80 text-white" :
                          "bg-rose-500/80 text-white"
                        )}>
                          {(reviewTask as any).verificationStatus === 'genuine' ? <ShieldCheck size={14} /> : <ShieldAlert size={14} />}
                          {(reviewTask as any).verificationStatus || 'unverified'}
                        </span>
                      </div>
                    </div>

                    <div className="bg-gray-50 p-8 rounded-[2.5rem] space-y-6">
                        <div>
                          <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3">AI Vision Analysis Findings</h4>
                          <>
                            <p className="text-sm font-bold text-gray-700 leading-relaxed italic">"{(reviewTask as any).aiVerificationResult || 'Awaiting analysis...'}"</p>
                            <div className="flex flex-wrap gap-2 mt-4">
                              {(reviewTask as any).aiLabels?.map((label: any, idx: number) => (
                                <span key={idx} className="px-3 py-1 bg-white rounded-full text-[10px] font-black text-green-600 border border-green-50 uppercase tracking-wider shadow-sm">
                                  {label}
                                </span>
                              ))}
                            </div>
                          </>
                        </div>
                        
                        {reviewTask.workerNotes && (
                          <div className="pt-6 border-t border-gray-200/50">
                            <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Worker Testimony</h4>
                            <p className="text-xs font-bold text-gray-500 leading-relaxed">"{reviewTask.workerNotes}"</p>
                          </div>
                        )}
                    </div>
                  </div>

                  <div className="space-y-8">
                    <div className="space-y-4">
                        <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Risk Assessment Metrics</h4>
                        <div className="grid grid-cols-1 gap-3">
                              <div className={cn(
                                  "p-5 rounded-2xl flex flex-col border-2 transition-all relative overflow-hidden",
                                  reviewTask.aiConfidence && reviewTask.aiConfidence > 0.8 ? "bg-green-50 border-green-100" : "bg-amber-50 border-amber-100"
                              )}>
                                  <div className="flex items-center justify-between relative z-10">
                                    <div className="flex flex-col">
                                      <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Vision Accuracy</span>
                                      <span className="text-[9px] font-bold text-gray-500 mt-1 uppercase">Object pattern matching</span>
                                    </div>
                                    <span className="text-2xl font-black text-[#111827]">{Math.round((reviewTask.aiConfidence || 0) * 100)}%</span>
                                  </div>
                                  <div className="mt-3 w-full h-1.5 bg-gray-200/50 rounded-full overflow-hidden relative z-10">
                                    <motion.div 
                                      initial={{ width: 0 }}
                                      animate={{ width: `${(reviewTask.aiConfidence || 0) * 100}%` }}
                                      className={cn(
                                        "h-full rounded-full",
                                        reviewTask.aiConfidence && reviewTask.aiConfidence > 0.8 ? "bg-green-500" : "bg-amber-500"
                                      )}
                                    />
                                  </div>
                              </div>

                              <div className={cn(
                                  "p-5 rounded-2xl flex items-center justify-between border-2 transition-all",
                                  reviewTask.cleanlinessLevel === 'clean' ? "bg-green-50 border-green-100" : 
                                  reviewTask.cleanlinessLevel === 'moderate' ? "bg-amber-50 border-amber-100" : "bg-rose-50 border-rose-100"
                              )}>
                                  <div className="flex flex-col">
                                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Cleanliness Level</span>
                                    <span className="text-[9px] font-bold text-gray-500 mt-1 uppercase">AI environment detection</span>
                                  </div>
                                  <div className="flex items-center gap-3">
                                    {reviewTask.cleanlinessLevel === 'clean' && <ShieldCheck className="text-green-600" size={24} />}
                                    {reviewTask.cleanlinessLevel === 'moderate' && <AlertCircle className="text-amber-600" size={24} />}
                                    {reviewTask.cleanlinessLevel === 'dirty' && <ShieldAlert className="text-rose-600" size={24} />}
                                    <span className={cn(
                                      "text-xl font-black uppercase tracking-tight",
                                      reviewTask.cleanlinessLevel === 'clean' ? "text-green-600" : 
                                      reviewTask.cleanlinessLevel === 'moderate' ? "text-amber-600" : "text-rose-600"
                                    )}>
                                      {reviewTask.cleanlinessLevel || 'PENDING'}
                                    </span>
                                  </div>
                              </div>

                              <div className={cn(
                                  "p-5 rounded-2xl flex items-center justify-between border-2 transition-all",
                                  reviewTask.verificationStatus === 'duplicate' ? "bg-rose-50 border-rose-100" : "bg-green-50 border-green-100"
                              )}>
                                  <div className="flex flex-col">
                                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Duplicate Check</span>
                                    <span className="text-[9px] font-bold text-gray-500 mt-1 uppercase">Perceptual Hash Comparison</span>
                                  </div>
                                  <span className={cn("text-lg font-black", reviewTask.verificationStatus === 'duplicate' ? "text-rose-600" : "text-green-600")}>
                                      {reviewTask.verificationStatus === 'duplicate' ? 'FAILED' : 'PASSED'}
                                  </span>
                              </div>
                              <div className={cn(
                                  "p-5 rounded-2xl flex items-center justify-between border-2 transition-all",
                                  reviewTask.verificationStatus === 'fake' ? "bg-rose-50 border-rose-100" : "bg-green-50 border-green-100"
                              )}>
                                  <div className="flex flex-col">
                                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Genuineness Check</span>
                                    <span className="text-[9px] font-bold text-gray-500 mt-1 uppercase">Digital Fingerprint Auth</span>
                                  </div>
                                  <span className={cn("text-lg font-black", reviewTask.verificationStatus === 'fake' ? "text-rose-600" : "text-green-600")}>
                                      {reviewTask.verificationStatus === 'fake' ? 'SUSPICIOUS' : 'GENUINE'}
                                  </span>
                              </div>
                          </div>
                    </div>

                    <div className="space-y-4">
                        <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest flex justify-between items-center">
                          Geospatial Telemetry
                          <span className="text-blue-500 animate-pulse text-[8px] font-black uppercase tracking-[0.2em]">Live Signal</span>
                        </h4>
                        
                        {reviewTask.latitude && reviewTask.longitude && (
                          <div className="h-48 rounded-[2rem] overflow-hidden border-2 border-gray-100 shadow-md">
                            <MapContainer 
                              center={[reviewTask.latitude, reviewTask.longitude]} 
                              zoom={15} 
                              scrollWheelZoom={false}
                              className="h-full w-full"
                            >
                              <TileLayer
                                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                              />
                              <Marker position={[reviewTask.latitude, reviewTask.longitude]} />
                            </MapContainer>
                          </div>
                        )}

                        <div className="bg-[#111827] text-white p-6 rounded-[2rem] relative overflow-hidden group border border-gray-800 shadow-xl">
                            <div className="relative z-10">
                                <div className="flex items-center gap-2 mb-2">
                                    <MapPin size={14} className="text-green-400" />
                                    <span className="text-[10px] font-black uppercase tracking-widest text-gray-400">Verified Coordinate</span>
                                </div>
                                <p className="text-sm font-bold truncate pr-12">{reviewTask.address || 'Location data unavailable'}</p>
                                <div className="mt-4 flex gap-6">
                                    <div>
                                        <p className="text-[8px] font-black text-gray-600 uppercase mb-1">LAT</p>
                                        <p className="text-xs font-mono font-bold text-green-400">{reviewTask.latitude?.toFixed(6) || '--'}</p>
                                    </div>
                                    <div>
                                        <p className="text-[8px] font-black text-gray-600 uppercase mb-1">LNG</p>
                                        <p className="text-xs font-mono font-bold text-green-400">{reviewTask.longitude?.toFixed(6) || '--'}</p>
                                    </div>
                                </div>
                            </div>
                            <MapPin className="absolute -right-6 -bottom-6 w-32 h-32 text-white/5 rotate-12 transition-transform group-hover:scale-110" />
                        </div>
                        <div className="flex items-center gap-2 px-1">
                          <AlertCircle size={12} className="text-gray-400" />
                          <p className="text-[9px] font-bold text-gray-400 italic">Expected: {typeof reviewTask.location === 'string' ? reviewTask.location : (reviewTask.address || 'GPS Verified')} (Radius checks passed)</p>
                        </div>
                    </div>

                    <div className="pt-6 space-y-4 border-t border-gray-100">
                        {(reviewTask.status === 'submitted' || (mode === 'habits' && reviewTask.status === 'pending')) ? (
                          <>
                            <div className="space-y-2">
                               <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest ml-1">Admin Action Note (Required for Rejection)</label>
                               <textarea 
                                 value={rejectionReason}
                                 onChange={(e) => setRejectionReason(e.target.value)}
                                 placeholder="Reason for rejection or feedback for worker..."
                                 className="w-full bg-gray-50 border-2 border-transparent focus:border-rose-500 rounded-2xl p-4 text-xs font-bold transition-all outline-none resize-none min-h-[80px]"
                               />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                              <button 
                                  disabled={isActioning}
                                  onClick={handleReject}
                                  className="py-5 rounded-2xl bg-white text-rose-600 font-black text-[10px] uppercase tracking-widest hover:bg-rose-600 hover:text-white transition-all border-2 border-rose-100 disabled:opacity-30 shadow-sm"
                              >
                                  {isActioning ? <Loader2 className="animate-spin mx-auto" size={16} /> : 'Reject Submission'}
                              </button>
                              <button 
                                  disabled={isActioning}
                                  onClick={handleApprove}
                                  className="py-5 rounded-2xl bg-[#111827] text-white font-black text-[10px] uppercase tracking-widest hover:bg-black transition-all shadow-xl shadow-gray-200 flex items-center justify-center gap-2 group disabled:opacity-30"
                              >
                                  {isActioning ? <Loader2 className="animate-spin" size={16} /> : (
                                    <>
                                      <Check size={16} strokeWidth={3} className="text-green-400 group-hover:scale-125 transition-transform" />
                                      Approve & Reward
                                    </>
                                  )}
                              </button>
                            </div>
                          </>
                        ) : (
                          <div className={cn(
                            "p-6 rounded-[2rem] border-2 flex items-center justify-center gap-4",
                            reviewTask.status === 'approved' ? "bg-green-50 border-green-100 text-green-700" : "bg-rose-50 border-rose-100 text-rose-700"
                          )}>
                            {reviewTask.status === 'approved' ? <ShieldCheck size={32} /> : <ShieldAlert size={32} />}
                            <div className="flex flex-col">
                               <span className="text-xs font-black uppercase tracking-widest">Final Verdict Issued</span>
                               <span className="text-lg font-black uppercase">Mission {reviewTask.status}</span>
                               {reviewTask.rejectionReason && (
                                 <p className="text-[10px] font-bold mt-1 opacity-70 italic">"{reviewTask.rejectionReason}"</p>
                               )}
                            </div>
                          </div>
                        )}
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
