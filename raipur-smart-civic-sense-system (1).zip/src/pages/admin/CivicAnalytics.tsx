import React, { useState, useEffect } from 'react';
import { api } from '../../lib/api';
import { Task, RedeemRequest, DigitalPass } from '../../types';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell, 
  Legend 
} from 'recharts';
import { 
  AlertTriangle, 
  TrendingUp, 
  MapPin, 
  CheckCircle2, 
  ShieldCheck, 
  Zap, 
  Activity,
  BarChart3,
  Navigation,
  Loader2,
  ChevronRight,
  Plus,
  Ticket,
  Award
} from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '../../lib/utils';
import { MapContainer, TileLayer, Marker, Popup, Circle } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Fix for default leaflet marker icons
const iconUrl = 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png';
const shadowUrl = 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png';

let DefaultIcon = L.icon({
    iconUrl,
    shadowUrl,
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
});

L.Marker.prototype.options.icon = DefaultIcon;

const AnalyticsCard: React.FC<{ title: string; children: React.ReactNode; className?: string }> = ({ title, children, className }) => (
  <div className={cn("bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm relative overflow-hidden", className)}>
    <div className="flex items-center justify-between mb-8">
      <h3 className="text-xl font-bold text-[#111827] tracking-tight">{title}</h3>
      <div className="w-8 h-8 rounded-lg bg-gray-50 flex items-center justify-center">
        <Activity size={16} className="text-gray-400" />
      </div>
    </div>
    <div className="w-full h-[320px]">
      {children}
    </div>
  </div>
);

export const CivicAnalytics: React.FC = () => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [redeems, setRedeems] = useState<RedeemRequest[]>([]);
  const [passes, setPasses] = useState<DigitalPass[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [stats, setStats] = useState({
    clean: 0,
    moderate: 0,
    dirty: 0,
    total: 0,
    approvalRate: 0,
    activePasses: 0,
    usedPasses: 0,
    totalRedeemedPoints: 0
  });

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const [adminStats, fetchedTasks, fetchedRedeems] = await Promise.all([
          api.admin.getStats(),
          api.tasks.getAll(),
          api.redeem.getAll()
        ]);

        setStats({
          total: adminStats.tasks || 0,
          clean: adminStats.clean || 0,
          moderate: adminStats.moderate || 0,
          dirty: adminStats.dirty || 0,
          approvalRate: adminStats.approvalRate || 0,
          activePasses: adminStats.activePasses || 0,
          usedPasses: adminStats.usedPasses || 0,
          totalRedeemedPoints: adminStats.totalRedeemedPoints || 0
        });
        setTasks(fetchedTasks);
        setRedeems(fetchedRedeems);
        setError(null);
      } catch (err) {
        console.error("Analytics fetch failed:", err);
        setError("Failed to fetch analytical data.");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    // Removed old heavy calculations based on local full-collection states
  }, []);

  const pieData = [
    { name: 'Clean', value: stats.clean, color: '#10b981' },
    { name: 'Moderate', value: stats.moderate, color: '#f59e0b' },
    { name: 'Dirty', value: stats.dirty, color: '#ef4444' },
  ];

  const passStatsData = [
    { name: 'Active', value: stats.activePasses, color: '#6366f1' },
    { name: 'Used', value: stats.usedPasses, color: '#ec4899' },
    { name: 'Expired', value: (stats as any).expiredPasses || 0, color: '#94a3b8' },
  ];

  const rewardPopularityData = Array.from(
    redeems.reduce((acc, r) => {
      acc.set(r.rewardTitle, (acc.get(r.rewardTitle) || 0) + 1);
      return acc;
    }, new Map<string, number>())
  ).map(([name, count]) => ({ name, count }))
   .sort((a, b) => b.count - a.count)
   .slice(0, 5);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4">
        <Loader2 className="animate-spin text-green-600" size={40} />
        <p className="text-gray-400 font-medium font-mono text-sm animate-pulse">ANALYZING CITY PULSE...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4 p-8 bg-rose-50 rounded-[3rem] border border-rose-100">
        <AlertTriangle className="text-rose-500" size={48} />
        <h2 className="text-2xl font-black text-rose-900">Permission Error</h2>
        <p className="text-rose-700 text-center max-w-md">{error}</p>
        <button 
          onClick={() => window.location.reload()}
          className="mt-4 px-6 py-3 bg-rose-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-rose-600/20"
        >
          Retry Connection
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-10 pb-20">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 px-4">
        <div className="flex items-center gap-6">
          <div className="w-14 h-14 md:w-18 md:h-18 flex items-center justify-center bg-blue-600 rounded-full shadow-lg border-2 border-white text-white">
            <BarChart3 size={28} />
          </div>
          <div className="space-y-2">
            <h2 className="text-3xl md:text-5xl font-black text-[#111827] tracking-tight uppercase">Raipur Municipal Corporation</h2>
            <p className="text-orange-500 font-bold uppercase tracking-widest text-[10px] mt-1">Smart Civic Sense System</p>
          </div>
        </div>

        <div className="flex gap-4">
          <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm flex flex-col items-end">
            <span className="text-[8px] font-black text-gray-400 uppercase tracking-widest mb-1">Approval Efficiency</span>
            <span className="text-xl font-black text-green-600">{stats.approvalRate.toFixed(1)}%</span>
          </div>
        </div>
      </div>

      {/* Real-time Heatmap / Dirty Areas Detection */}
      <div className="bg-[#111827] rounded-[3rem] shadow-2xl p-8 overflow-hidden relative min-h-[600px] flex flex-col">
        <div className="relative z-10 flex flex-col md:flex-row justify-between gap-8 mb-8">
          <div className="space-y-1">
             <h3 className="text-2xl font-black text-white tracking-tight">Area Cleanliness Hotspots</h3>
             <p className="text-gray-400 text-sm">Real-time dirty area detection based on verified submissions.</p>
          </div>
          <div className="flex items-center gap-3">
             <div className="flex items-center gap-2 bg-white/5 px-4 py-2 rounded-xl border border-white/10">
                <div className="w-2 h-2 rounded-full bg-rose-500 animate-ping"></div>
                <span className="text-[10px] font-black uppercase tracking-widest text-white">4 Critical Zones</span>
             </div>
             <button className="bg-green-500 hover:bg-green-600 text-[#111827] px-6 py-2.5 rounded-xl font-black text-[10px] uppercase tracking-widest transition-all flex items-center gap-2">
                <Plus size={14} /> Assign Emergency Task
             </button>
          </div>
        </div>

        <div className="flex-1 rounded-[2rem] overflow-hidden border border-white/10 shadow-inner z-10">
          <MapContainer center={[19.0760, 72.8777]} zoom={13} style={{ height: '400px', width: '100%' }}>
            <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
            {tasks.map((task) => (
              task.latitude && task.longitude && (
                <React.Fragment key={(task as any)._id || task.id}>
                  <Marker position={[task.latitude, task.longitude]}>
                    <Popup>
                      <div className="p-2">
                        <p className="font-black text-sm uppercase mb-1">{task.title}</p>
                        <p className="text-[10px] text-gray-500">{task.address}</p>
                        <div className={cn(
                          "mt-2 px-2 py-1 rounded text-[8px] font-bold uppercase tracking-widest inline-block",
                          task.cleanlinessLevel === 'dirty' ? 'bg-rose-100 text-rose-600' : 
                          task.cleanlinessLevel === 'moderate' ? 'bg-amber-100 text-amber-600' : 
                          'bg-green-100 text-green-600'
                        )}>
                          {task.cleanlinessLevel || 'Unknown'}
                        </div>
                      </div>
                    </Popup>
                  </Marker>
                  <Circle 
                    center={[task.latitude, task.longitude]} 
                    radius={200}
                    pathOptions={{ 
                      color: task.cleanlinessLevel === 'dirty' ? '#ef4444' : task.cleanlinessLevel === 'moderate' ? '#f59e0b' : '#10b981',
                      fillColor: task.cleanlinessLevel === 'dirty' ? '#ef4444' : task.cleanlinessLevel === 'moderate' ? '#f59e0b' : '#10b981',
                      fillOpacity: 0.2
                    }}
                  />
                </React.Fragment>
              )
            ))}
          </MapContainer>
        </div>

        <div className="absolute -right-20 -bottom-20 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl"></div>
      </div>

      {/* Analytics Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <AnalyticsCard title="Reward Popularity Index">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={rewardPopularityData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis 
                dataKey="name" 
                axisLine={false} 
                tickLine={false} 
                tick={{ fontSize: 10, fontWeight: 700, fill: '#64748b' }}
              />
              <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fontWeight: 700, fill: '#64748b' }} />
              <Tooltip 
                cursor={{ fill: '#f8fafc' }}
                contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1)' }}
              />
              <Bar dataKey="count" fill="#6366f1" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </AnalyticsCard>

        <AnalyticsCard title="Digital Pass Lifecycle Status">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={passStatsData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={100}
                paddingAngle={5}
                dataKey="value"
                stroke="none"
              >
                {passStatsData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                 contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1)' }}
              />
              <Legend iconType="circle" wrapperStyle={{ fontSize: '10px', fontWeight: 'bold', paddingTop: '20px' }} />
            </PieChart>
          </ResponsiveContainer>
          <div className="absolute top-[50%] left-1/2 -translate-x-1/2 -translate-y-1/2 text-center pointer-events-none">
             <p className="text-2xl font-black text-[#111827]">{passes.length}</p>
             <p className="text-[8px] font-black text-gray-400 uppercase tracking-widest">Passes</p>
          </div>
        </AnalyticsCard>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <AnalyticsCard title="Cleanliness Intensity Distribution">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={pieData}
                cx="50%"
                cy="50%"
                innerRadius={80}
                outerRadius={100}
                paddingAngle={8}
                dataKey="value"
                stroke="none"
              >
                {pieData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                 contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1)' }}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="absolute top-[60%] left-1/2 -translate-x-1/2 -translate-y-1/2 text-center pointer-events-none">
             <p className="text-3xl font-black text-[#111827]">{stats.total}</p>
             <p className="text-[8px] font-black text-gray-400 uppercase tracking-widest">Total Audits</p>
          </div>
          <div className="mt-4 grid grid-cols-3 gap-2">
             {pieData.map(item => (
               <div key={item.name} className="bg-gray-50 p-3 rounded-xl border border-gray-100 flex flex-col items-center">
                  <div className="w-2 h-2 rounded-full mb-1" style={{ backgroundColor: item.color }}></div>
                  <span className="text-[8px] font-black text-gray-400 uppercase tracking-widest">{item.name}</span>
                  <span className="text-sm font-black text-[#111827]">{item.value}</span>
               </div>
             ))}
          </div>
        </AnalyticsCard>

        <AnalyticsCard title="AI Insights & Smart Recommendations">
          <div className="space-y-6">
            <div className="p-6 bg-blue-50 border border-blue-100 rounded-[2rem] relative overflow-hidden group">
               <div className="relative z-10">
                  <div className="flex items-center gap-2 text-blue-700 font-bold text-xs uppercase mb-3">
                    <Zap size={14} className="fill-current" />
                    Cleanliness Trend
                  </div>
                  <p className="text-blue-900 font-bold leading-relaxed mb-4">
                    AI Insight: Community complaints and garbage reports increased by 35% in Sector 4 this week.
                  </p>
                  <div className="text-[10px] font-black text-blue-500 uppercase tracking-widest">
                    Confidence Level: 92%
                  </div>
               </div>
               <Activity className="absolute -right-8 -bottom-8 text-blue-500/10 group-hover:scale-110 transition-transform" size={120} />
            </div>

            <div className="p-6 bg-green-50 border border-green-100 rounded-[2rem] relative overflow-hidden group">
               <div className="relative z-10">
                  <div className="flex items-center gap-2 text-green-700 font-bold text-xs uppercase mb-3">
                    <TrendingUp size={14} />
                    Resource Optimization
                  </div>
                  <p className="text-green-900 font-bold leading-relaxed mb-4">
                    Recommendation: Assign 3 additional workers to the railway market area based on peak activity.
                  </p>
                  <button className="bg-green-600 text-white px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest flex items-center gap-2">
                    Accept & Deploy <ChevronRight size={12} />
                  </button>
               </div>
               <TrendingUp size={120} className="absolute -right-8 -bottom-8 text-green-500/10 group-hover:scale-110 transition-transform" />
            </div>
          </div>
        </AnalyticsCard>
      </div>

      {/* Critical Action Status */}
      <div className="bg-white p-10 rounded-[3rem] border border-gray-100 shadow-sm">
        <div className="flex items-center justify-between mb-8">
           <h3 className="text-xl font-black text-[#111827] tracking-tight">Active Critical Zones</h3>
           <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Awaiting Intervention</span>
        </div>
        
        <div className="space-y-4">
           {tasks.filter(t => t.cleanlinessLevel === 'dirty').slice(0, 5).map(task => (
             <div key={(task as any)._id || task.id} className="flex items-center justify-between p-5 bg-gray-50 hover:bg-rose-50 transition-colors border border-gray-100 rounded-[2rem] group">
                <div className="flex items-center gap-4">
                   <div className="w-12 h-12 rounded-2xl bg-white border border-gray-100 flex items-center justify-center text-rose-500 shadow-sm group-hover:scale-110 transition-transform">
                      <AlertTriangle size={20} />
                   </div>
                   <div>
                      <h4 className="font-bold text-[#111827] underline decoration-rose-500/30">{task.title}</h4>
                      <p className="text-[10px] text-gray-500 font-medium">{task.address}</p>
                   </div>
                </div>
                <div className="flex items-center gap-4">
                   <div className="text-right hidden sm:block">
                      <p className="text-[8px] font-black text-gray-400 uppercase tracking-widest">Report Frequency</p>
                      <p className="text-xs font-bold text-[#111827]">High Activity</p>
                   </div>
                   <button className="bg-[#111827] text-white px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-rose-600 transition-colors">
                      Assign
                   </button>
                </div>
             </div>
           ))}
        </div>
      </div>
    </div>
  );
};
