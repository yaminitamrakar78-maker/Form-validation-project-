import React, { useState, useEffect } from 'react';
import { api } from '../../lib/api';
import { UserProfile } from '../../types';
import { 
  Users, 
  Search, 
  Filter, 
  MoreVertical, 
  Shield, 
  User, 
  Trash2, 
  ChevronRight,
  TrendingUp,
  Award,
  Loader2,
  AlertTriangle,
  Hash
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { cn } from '../../lib/utils';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner';

export const AdminUsers: React.FC = () => {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [wardFilter, setWardFilter] = useState('');
  const [roleFilter, setRoleFilter] = useState<'all' | 'admin' | 'worker'>('all');

  const [totalUsers, setTotalUsers] = useState(0);
  const [adminCount, setAdminCount] = useState(0);

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const fetchedUsers = await api.users.getAll();
      setUsers(fetchedUsers);
      
      setTotalUsers(fetchedUsers.length);
      setAdminCount(fetchedUsers.filter((u: any) => u.role === 'admin').length);
    } catch (error) {
      console.error("Error fetching users:", error);
      toast.error("Database sync failed.");
    } finally {
      setLoading(false);
    }
  };

  const handleToggleRole = async (user: UserProfile) => {
    const newRole = user.role === 'admin' ? 'worker' : 'admin';
    const confirmed = window.confirm(
      `CRITICAL ACTION: Change access level for ${user.name} to ${newRole.toUpperCase()}?\n\nThis will modify their system permissions immediately.`
    );
    
    if (!confirmed) return;

    try {
      await api.users.update(user.uid, { role: newRole });
      setUsers(prev => prev.map(u => u.uid === user.uid ? { ...u, role: newRole } : u));
      toast.success("Clearance Level Updated", {
        description: `${user.name} now has ${newRole} privileges.`
      });
      // Update admin count
      setAdminCount(prev => newRole === 'admin' ? prev + 1 : prev - 1);
    } catch (error) {
      console.error("Error updating role:", error);
      toast.error("Access Modification Failed");
    }
  };

  const filteredUsers = users.filter(user => {
    const matchesSearch = 
      user.name.toLowerCase().includes(search.toLowerCase()) || 
      user.email.toLowerCase().includes(search.toLowerCase()) ||
      (user.mobile && user.mobile.includes(search));
    
    const matchesRole = roleFilter === 'all' || user.role === roleFilter;
    const matchesWard = !wardFilter || (user.wardNumber && user.wardNumber.includes(wardFilter));
    
    return matchesSearch && matchesRole && matchesWard;
  });

  return (
    <div className="space-y-8 pb-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-3xl font-black text-[#111827] tracking-tight">Citizen Roster</h2>
          <p className="text-[#6B7280] mt-1 font-medium">Coordinate civil workers and administrative personnel.</p>
        </div>
      </div>

      {/* Analytics Mini-Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-600">
              <Users size={24} />
            </div>
            <div>
              <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest text-left">Total Users</p>
              <p className="text-2xl font-black text-[#111827]">{totalUsers}</p>
            </div>
          </div>
        </div>
        <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 bg-green-50 rounded-2xl flex items-center justify-center text-green-600">
              <Award size={24} />
            </div>
            <div>
              <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest text-left">Avg. Contribution</p>
              <p className="text-2xl font-black text-[#111827]">
                {totalUsers > 0 ? Math.round(users.reduce((acc, u) => acc + (u.points || 0), 0) / (users.length || 1)) : 0} PTS
              </p>
            </div>
          </div>
        </div>
        <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 bg-rose-50 rounded-2xl flex items-center justify-center text-rose-600">
              <Shield size={24} />
            </div>
            <div>
              <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest text-left">Internal Staff</p>
              <p className="text-2xl font-black text-[#111827]">{adminCount}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Search & Filters */}
      <div className="bg-white p-4 rounded-3xl border border-gray-100 shadow-sm flex flex-col lg:flex-row items-center gap-4">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
          <input 
            type="text" 
            placeholder="Search by name, email or mobile..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-12 pr-4 py-3 bg-gray-50 border-none rounded-2xl focus:ring-2 focus:ring-green-500 transition-all font-medium"
          />
        </div>
        <div className="relative w-full lg:w-48">
          <Hash className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
          <input 
            type="text" 
            placeholder="Ward No."
            value={wardFilter}
            onChange={(e) => setWardFilter(e.target.value)}
            className="w-full pl-11 pr-4 py-3 bg-gray-50 border-none rounded-2xl focus:ring-2 focus:ring-green-500 transition-all font-medium text-sm"
          />
        </div>
        <div className="flex items-center gap-2 p-1 bg-gray-50 rounded-2xl w-full lg:w-auto">
          {(['all', 'admin', 'worker'] as const).map((r) => (
            <button
              key={r}
              onClick={() => setRoleFilter(r)}
              className={cn(
                "px-6 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition-all flex-1 lg:flex-none",
                roleFilter === r ? "bg-white text-green-600 shadow-sm" : "text-gray-400 hover:text-gray-600"
              )}
            >
              {r}s
            </button>
          ))}
        </div>
      </div>

      {/* Users Table */}
      <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-xl overflow-hidden">
        {loading ? (
          <div className="p-20 flex flex-col items-center justify-center gap-4">
            <Loader2 className="animate-spin text-green-600" size={40} />
            <p className="text-gray-400 font-bold uppercase tracking-widest text-xs">Synchronizing Identity Vault...</p>
          </div>
        ) : filteredUsers.length === 0 ? (
          <div className="p-20 text-center space-y-4">
            <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto">
              <Users size={32} className="text-gray-300" />
            </div>
            <p className="text-gray-500 font-bold text-center">No citizens found matching your criteria.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-gray-50">
                  <th className="px-8 py-6 text-[10px] font-black text-gray-400 uppercase tracking-widest">Citizen Profile</th>
                  <th className="px-8 py-6 text-[10px] font-black text-gray-400 uppercase tracking-widest">Ward</th>
                  <th className="px-8 py-6 text-[10px] font-black text-gray-400 uppercase tracking-widest">Clearance Role</th>
                  <th className="px-8 py-6 text-[10px] font-black text-gray-400 uppercase tracking-widest text-right">Merit Points</th>
                  <th className="px-8 py-6 text-[10px] font-black text-gray-400 uppercase tracking-widest text-right">Operations</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {filteredUsers.map((user) => (
                  <tr key={user.uid} className="hover:bg-gray-50/50 transition-colors group">
                    <td className="px-8 py-6">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center text-gray-400 font-black relative overflow-hidden">
                          {user.photoUrl ? (
                            <img src={user.photoUrl} alt={user.name} className="w-full h-full object-cover" />
                          ) : (
                            user.name.charAt(0)
                          )}
                          <div className="absolute inset-0 bg-gradient-to-tr from-green-500/10 to-transparent"></div>
                        </div>
                        <div className="flex flex-col">
                          <span className="text-sm font-black text-gray-900 uppercase group-hover:text-green-600 transition-colors">{user.name}</span>
                          <span className="text-xs text-gray-400 font-medium">{user.email}</span>
                        </div>
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] font-black text-gray-400">#</span>
                        <span className="text-sm font-black text-gray-700">{user.wardNumber || 'N/A'}</span>
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <span className={cn(
                        "px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest",
                        user.role === 'admin' 
                          ? "bg-rose-100 text-rose-700 border border-rose-200" 
                          : "bg-blue-100 text-blue-700 border border-blue-200"
                      )}>
                        {user.role}
                      </span>
                    </td>
                    <td className="px-8 py-6 text-right">
                      <span className="text-lg font-black text-[#111827]">{user.points || 0}</span>
                    </td>
                    <td className="px-8 py-6 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-2">
                        <Link 
                          to={`/admin/users/${user.uid}`}
                          className="px-4 py-2 rounded-xl bg-gray-50 text-gray-500 hover:text-green-600 hover:bg-green-50 transition-all text-[10px] font-black uppercase tracking-widest flex items-center gap-2"
                        >
                          Identity Log
                          <ChevronRight size={14} />
                        </Link>
                        <button 
                          onClick={() => handleToggleRole(user)}
                          className="p-2 rounded-xl bg-gray-50 text-gray-400 hover:text-blue-600 hover:bg-blue-50 transition-all border border-transparent hover:border-blue-100"
                          title="Toggle Role"
                        >
                          <Shield size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
