import React, { useState, useEffect } from 'react';
import { api } from '../../lib/api';
import { RedeemRequest, UserProfile } from '../../types';
import { 
  Award, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Search, 
  User, 
  Ticket,
  Loader2,
  AlertCircle,
  Star,
  QrCode
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { format } from 'date-fns';
import { cn, safeGetDate } from '../../lib/utils';
import { toast } from 'sonner';

export const AdminRewards: React.FC = () => {
  const [requests, setRequests] = useState<RedeemRequest[]>([]);
  const [workers, setWorkers] = useState<Record<string, UserProfile>>({});
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'pending' | 'approved' | 'rejected'>('pending');
  const [processingId, setProcessingId] = useState<string | null>(null);

  useEffect(() => {
    fetchWorkers();
    fetchRequests();
  }, []);

  const fetchWorkers = async () => {
    try {
      const users = await api.users.getAll();
      const workerMap: Record<string, UserProfile> = {};
      users.forEach((u: any) => {
        workerMap[u.uid || u._id] = u;
      });
      setWorkers(workerMap);
    } catch (err) {
       console.error("Error fetching workers for rewards:", err);
    }
  };

  const fetchRequests = async () => {
    setLoading(true);
    try {
      const data = await api.redeem.getAll();
      setRequests(data);
    } catch (error: any) {
      console.error("Error fetching requests:", error);
      toast.error("Failed to load rewards bureau.");
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (request: RedeemRequest) => {
    const requestId = (request as any)._id || request.id;
    if (!requestId) {
      toast.error("Resource index missing.");
      return;
    }
    setProcessingId(requestId);
    try {
      await api.redeem.approve(requestId);
      toast.success("✅ Approved & Pass Generated Successfully");
      fetchRequests();
    } catch (error: any) {
      console.error("Approval Failed:", error);
      toast.error(error.message || "Approval Failed");
    } finally {
      setProcessingId(null);
    }
  };

  const handleReject = async (request: RedeemRequest) => {
    const requestId = (request as any)._id || request.id;
    if (!requestId) {
      toast.error("Resource index missing.");
      return;
    }
    setProcessingId(requestId);
    try {
      await api.redeem.reject(requestId);
      toast.info("Request Rejected");
      fetchRequests();
    } catch (error: any) {
      console.error("Reject Failed:", error);
      toast.error("Reject Failed");
    } finally {
      setProcessingId(null);
    }
  };

  const filteredRequests = requests.filter(r => r.status === filter);

  return (
    <div className="space-y-8 pb-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-3xl font-black text-[#111827] tracking-tight">Redemption Bureau</h2>
          <p className="text-[#6B7280] mt-1 font-medium">Review and fulfill merit-based reward claims.</p>
        </div>
      </div>

      {/* Status Filter */}
      <div className="flex items-center gap-2 p-1 bg-white rounded-2xl w-fit border border-gray-100 shadow-sm">
        {(['pending', 'approved', 'rejected'] as const).map((s) => (
          <button
            key={s}
            onClick={() => setFilter(s)}
            className={cn(
              "px-6 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition-all",
              filter === s ? "bg-[#111827] text-white shadow-lg" : "text-gray-400 hover:text-gray-600"
            )}
          >
            {s}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="p-20 flex flex-col items-center justify-center gap-4">
          <Loader2 className="animate-spin text-green-600" size={40} />
          <p className="text-gray-400 font-bold uppercase tracking-widest text-xs">Auditing Inventory claims...</p>
        </div>
      ) : filteredRequests.length === 0 ? (
        <div className="p-20 text-center space-y-4 bg-white rounded-[2.5rem] border border-gray-100 shadow-sm">
          <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto text-gray-200">
             <Ticket size={32} />
          </div>
          <p className="text-gray-400 font-bold uppercase tracking-widest text-xs">No entries in this sector</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {filteredRequests.map((request) => (
            <motion.div 
              layout
              key={(request as any)._id || request.id}
              className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm hover:shadow-md transition-all flex flex-col md:flex-row items-center gap-6"
            >
              <div className="w-16 h-16 rounded-2xl bg-gray-50 flex items-center justify-center text-gray-400">
                 {workers[request.userId]?.name.charAt(0) || 'C'}
              </div>
              
              <div className="flex-1 text-center md:text-left">
                <div className="flex flex-col md:flex-row md:items-center gap-2 mb-1">
                   <h3 className="text-lg font-black text-[#111827] uppercase tracking-tight">{request.rewardTitle}</h3>
                   <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest hidden md:inline">|</span>
                   <span className="text-[10px] font-bold text-[#111827] uppercase tracking-widest">{workers[request.userId]?.name || 'Unknown Citizen'}</span>
                </div>
                <div className="flex items-center justify-center md:justify-start gap-4 text-[10px] font-bold uppercase tracking-widest">
                   <span className="flex items-center gap-1.5 p-1 px-2 bg-green-50 text-green-700 rounded-lg">
                      <Ticket size={12} /> {request.points} PTS (REQUESTED)
                   </span>
                   <span className="flex items-center gap-1.5 p-1 px-2 bg-blue-50 text-blue-700 rounded-lg">
                      <Star size={12} /> {workers[request.userId]?.points || 0} PTS (CURRENT BALANCE)
                   </span>
                   <span className="flex items-center gap-1.5 text-gray-400">
                      <Clock size={12} /> {format(safeGetDate(request.createdAt), 'MMM dd, HH:mm')}
                   </span>
                </div>
              </div>

              {request.status === 'pending' && (
                <div className="flex items-center gap-3 w-full md:w-auto">
                  <button 
                    disabled={!!processingId}
                    onClick={() => handleReject(request)}
                    className="flex-1 md:w-auto md:px-6 md:h-12 rounded-xl bg-rose-50 text-rose-500 hover:bg-rose-100 transition-all flex items-center justify-center border border-rose-100 font-black text-[10px] gap-2 p-3"
                  >
                    {processingId === ((request as any)._id || request.id) ? <Loader2 className="animate-spin" /> : <XCircle size={18} />}
                    <span className="uppercase tracking-widest">Reject</span>
                  </button>
                  <button 
                    disabled={!!processingId}
                    onClick={() => handleApprove(request)}
                    className="flex-[2] md:w-auto md:px-8 md:h-12 rounded-xl bg-green-600 text-white hover:bg-green-700 transition-all flex items-center justify-center gap-2 font-black text-[10px] tracking-widest shadow-lg shadow-green-100 p-3"
                  >
                    {processingId === ((request as any)._id || request.id) ? <Loader2 className="animate-spin" /> : (
                      <>
                        <CheckCircle2 size={18} />
                        FULFILL CLAIM
                      </>
                    )}
                  </button>
                </div>
              )}

              {request.status !== 'pending' && (
                <div className={cn(
                  "px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest border",
                  request.status === 'approved' ? "bg-green-50 text-green-700 border-green-100" : "bg-rose-50 text-rose-700 border-rose-100"
                )}>
                  {request.status} ON {request.updatedAt ? format(safeGetDate(request.updatedAt), 'MMM dd') : 'N/A'}
                </div>
              )}
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
};
