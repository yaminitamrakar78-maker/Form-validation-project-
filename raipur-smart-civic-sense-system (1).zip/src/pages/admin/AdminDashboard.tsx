import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../../lib/api';
import { 
    Users, 
    ClipboardList, 
    Bell, 
    CheckCircle2, 
    Clock, 
    TrendingUp, 
    Loader2,
    PieChart as PieChartIcon,
    Award,
    ShieldCheck,
    MessageSquare,
    AlertCircle,
    Trophy,
    AlertTriangle,
    Sparkles,
    Zap
} from 'lucide-react';
import { 
    AreaChart, 
    Area, 
    XAxis, 
    YAxis, 
    CartesianGrid, 
    Tooltip, 
    ResponsiveContainer,
    Cell,
    PieChart,
    Pie,
    BarChart,
    Bar
} from 'recharts';

// Sub-component for individual chart cards to prevent full dashboard re-renders
const ChartCard: React.FC<{ title: string; children: React.ReactNode; className?: string }> = ({ title, children, className }) => (
  <div className={`bg-white p-6 md:p-8 rounded-[2.5rem] border border-gray-100 shadow-sm relative overflow-hidden ${className}`}>
    <div className="flex items-center justify-between mb-8">
      <h3 className="text-xl font-bold text-[#111827] tracking-tight">{title}</h3>
      <div className="w-8 h-8 rounded-lg bg-gray-50 flex items-center justify-center">
        <TrendingUp size={16} className="text-gray-400" />
      </div>
    </div>
    <div className="w-full h-[350px]">
      {children}
    </div>
  </div>
);

export const AdminDashboard: React.FC = () => {
  const [stats, setStats] = useState({
    users: 0,
    tasks: 0,
    notices: 0,
    completedTasks: 0,
    pendingTasks: 0,
    pendingRewards: 0,
    totalFeedback: 0,
    resolvedFeedback: 0,
    pendingFeedback: 0,
    activeUsers: 0,
    totalPointsRedeemed: 0,
    avgResolutionTime: 'N/A',
    mostAffectedWard: 'N/A',
    cleanlinessIndex: 0,
    clean: 0,
    moderate: 0,
    dirty: 0
  });

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchCounts = async () => {
      try {
        const data = await api.admin.getStats();
        setStats(prev => ({ ...prev, ...data }));
        setLoading(false);
      } catch (err: any) {
        console.error("Dashboard count fetch failed:", err);
        setError(err.message || "Unable to load performance metrics at this time.");
        setLoading(false);
      }
    };

    fetchCounts();
  }, []);

  const chartData = [
    { name: 'Mon', count: 4 },
    { name: 'Tue', count: 7 },
    { name: 'Wed', count: 5 },
    { name: 'Thu', count: 12 },
    { name: 'Fri', count: 9 },
    { name: 'Sat', count: 15 },
    { name: 'Sun', count: 10 },
  ];

  const pieData = [
    { name: 'Completed', value: stats.completedTasks, color: '#10B981' },
    { name: 'Pending', value: stats.pendingTasks, color: '#F59E0B' },
  ];

  const cards = [
    { label: 'Total Citizens', value: stats.users, icon: Users, color: 'text-blue-600', bg: 'bg-blue-50', border: 'border-blue-100', trend: 'Community Size' },
    { label: 'Active Citizens', value: stats.activeUsers, icon: Trophy, color: 'text-emerald-600', bg: 'bg-emerald-50', border: 'border-emerald-100', trend: 'Contributors' },
    { label: 'Redeemed Value', value: `${stats.totalPointsRedeemed} pts`, icon: Award, color: 'text-amber-600', bg: 'bg-amber-50', border: 'border-amber-100', trend: 'Total Incentives' },
    { label: 'Cleanliness Index', value: `${stats.cleanlinessIndex}%`, icon: Sparkles, color: 'text-sky-600', bg: 'bg-sky-50', border: 'border-sky-100', trend: 'City Health' },
  ];

  const smartMetrics = [
    { label: 'Total Complaints', value: stats.totalFeedback, icon: MessageSquare, sub: 'Total reported', color: 'bg-indigo-500' },
    { label: 'Resolved Cases', value: stats.resolvedFeedback, icon: CheckCircle2, sub: 'Closed issues', color: 'bg-green-500' },
    { label: 'Pending Action', value: stats.pendingFeedback, icon: Clock, sub: 'Awaiting review', color: 'bg-amber-500' },
    { label: 'Resolution Speed', value: stats.avgResolutionTime, icon: Zap, sub: 'Avg per task', color: 'bg-purple-500' },
    { label: 'Hotspot Ward', value: stats.mostAffectedWard, icon: AlertTriangle, sub: 'Needs attention', color: 'bg-rose-500' },
    { label: 'Resolved Ratio', value: stats.totalFeedback > 0 ? `${Math.round((stats.resolvedFeedback / stats.totalFeedback) * 100)}%` : '0%', icon: TrendingUp, sub: 'Efficiency', color: 'bg-cyan-500' },
  ];

  if (loading) {
    return (
      <div className="space-y-10 animate-pulse">
        <div className="flex flex-col md:flex-row justify-between gap-4">
          <div className="space-y-4">
            <div className="h-10 w-64 bg-gray-200 rounded-xl"></div>
            <div className="h-4 w-48 bg-gray-100 rounded-lg"></div>
          </div>
          <div className="h-10 w-40 bg-gray-100 rounded-xl"></div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[1,2,3,4].map(i => (
            <div key={i} className="bg-white p-6 rounded-3xl border border-gray-100 h-40 shadow-sm"></div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 bg-white rounded-[2.5rem] border border-gray-100 h-[450px] shadow-sm"></div>
          <div className="bg-[#111827] rounded-[2.5rem] h-[450px] shadow-sm"></div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4 p-8 bg-rose-50 rounded-[3rem] border border-rose-100">
        <AlertTriangle className="text-rose-500" size={48} />
        <h2 className="text-2xl font-black text-rose-900">Sync Error</h2>
        <p className="text-rose-700 text-center max-w-md">{error}</p>
        <button 
          onClick={() => window.location.reload()}
          className="mt-4 px-10 py-4 bg-rose-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-rose-600/20 active:scale-95 transition-all"
        >
          Re-authenticate Dashboard
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-10">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8 bg-white p-8 rounded-[3rem] border border-gray-100 shadow-sm overflow-hidden relative">
        <div className="absolute top-0 left-0 w-1 h-full bg-orange-500" />
        <div className="flex items-center gap-6 relative z-10">
          <div className="w-16 h-16 flex items-center justify-center bg-indigo-600 rounded-full shadow-lg border-2 border-white text-white hidden sm:flex">
            <ShieldCheck size={32} />
          </div>
          <div>
            <div className="flex items-center gap-3 mb-2">
              <span className="text-[10px] font-black text-orange-600 uppercase tracking-[0.2em] bg-orange-50 px-3 py-1 rounded-full border border-orange-100">Official Municipal Dashboard</span>
            </div>
            <h2 className="text-3xl font-black text-[#111827] tracking-tight uppercase">Raipur Municipal Corporation</h2>
            <p className="text-orange-500 mt-1 font-bold uppercase tracking-widest text-xs">Smart Civic Sense System</p>
          </div>
        </div>
        <div className="flex items-center gap-2 bg-green-50 px-6 py-3 rounded-2xl border border-green-100 relative z-10">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
            <span className="text-[10px] font-black text-green-700 uppercase tracking-[0.2em]">Live Monitoring Active</span>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {cards.map((card) => (
          <div key={card.label} className={`bg-white p-6 rounded-[2.5rem] border ${card.border} shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300 relative overflow-hidden group`}>
            <div className="flex justify-between items-start mb-4">
              <div className={`w-12 h-12 ${card.bg} rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform`}>
                <card.icon className={card.color} size={24} />
              </div>
              <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest">{card.trend}</span>
            </div>
            <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">{card.label}</p>
            <p className="text-3xl font-black text-[#111827] mt-1">{card.value}</p>
            <div className="absolute -right-4 -bottom-4 opacity-5 group-hover:opacity-10 transition-opacity">
              <card.icon size={100} />
            </div>
          </div>
        ))}
      </div>

      {/* Smart City Insights Section */}
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <div className="h-px flex-1 bg-gray-100" />
          <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.3em]">Operational Intelligence</h3>
          <div className="h-px flex-1 bg-gray-100" />
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {smartMetrics.map((metric) => (
            <div key={metric.label} className="bg-white p-5 rounded-[2rem] border border-gray-100 shadow-sm hover:border-indigo-100 transition-all text-center flex flex-col items-center">
              <div className={`w-10 h-10 ${metric.color} text-white rounded-xl flex items-center justify-center mb-3 shadow-lg shadow-gray-200`}>
                <metric.icon size={18} />
              </div>
              <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest leading-tight mb-1">{metric.label}</p>
              <p className="text-xl font-black text-[#111827]">{metric.value}</p>
              <p className="text-[8px] font-bold text-gray-400 uppercase mt-2 opacity-60">{metric.sub}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Cleanliness Analytics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-8 rounded-[2.5rem] border border-green-100 shadow-sm flex flex-col items-center justify-center text-center group hover:bg-green-50 transition-colors">
          <div className="w-16 h-16 bg-green-100 rounded-2xl flex items-center justify-center text-green-600 mb-4 group-hover:scale-110 transition-transform">
            <CheckCircle2 size={32} />
          </div>
          <span className="text-xs font-black text-gray-400 uppercase tracking-widest mb-1">Clean Zones</span>
          <span className="text-4xl font-black text-green-600">{stats.clean}</span>
        </div>
        <div className="bg-white p-8 rounded-[2.5rem] border border-amber-100 shadow-sm flex flex-col items-center justify-center text-center group hover:bg-amber-50 transition-colors">
          <div className="w-16 h-16 bg-amber-100 rounded-2xl flex items-center justify-center text-amber-600 mb-4 group-hover:scale-110 transition-transform">
            <TrendingUp size={32} />
          </div>
          <span className="text-xs font-black text-gray-400 uppercase tracking-widest mb-1">Moderate Zones</span>
          <span className="text-4xl font-black text-amber-600">{stats.moderate}</span>
        </div>
        <div className="bg-white p-8 rounded-[2.5rem] border border-rose-100 shadow-sm flex flex-col items-center justify-center text-center group hover:bg-rose-50 transition-colors">
          <div className="w-16 h-16 bg-rose-100 rounded-2xl flex items-center justify-center text-rose-600 mb-4 group-hover:scale-110 transition-transform">
            <AlertCircle size={32} />
          </div>
          <span className="text-xs font-black text-gray-400 uppercase tracking-widest mb-1">Dirty Zones</span>
          <span className="text-4xl font-black text-rose-600">{stats.dirty}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Growth Chart */}
        <div className="lg:col-span-2 bg-white p-6 md:p-8 rounded-[2.5rem] border border-gray-100 shadow-sm relative overflow-hidden flex flex-col justify-between" style={{ minHeight: '450px' }}>
          <div className="flex items-center justify-between mb-8">
              <div>
                <h3 className="text-xl font-bold text-[#111827] tracking-tight">Cleanup Velocity</h3>
                <p className="text-xs text-gray-400 font-medium">Daily task completion efficiency</p>
              </div>
              <div className="flex items-center gap-2">
                <div className="hidden sm:flex items-center gap-4 mr-4">
                   <div className="flex items-center gap-1.5">
                     <div className="w-2 h-2 rounded-full bg-green-500"></div>
                     <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Tasks</span>
                   </div>
                </div>
                <select className="bg-gray-50 border-none rounded-xl text-[10px] font-black uppercase tracking-widest text-gray-500 p-3 focus:ring-0 outline-none cursor-pointer">
                    <option>Last 7 Days</option>
                    <option>Last 30 Days</option>
                </select>
              </div>
          </div>
          
          <div className="flex-1 w-full h-[350px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorCount" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10B981" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#10B981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis 
                    dataKey="name" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fill: '#94a3b8', fontSize: 10, fontWeight: 700 }} 
                    dy={10}
                />
                <YAxis 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fill: '#94a3b8', fontSize: 10, fontWeight: 700 }} 
                />
                <Tooltip 
                    contentStyle={{ 
                        borderRadius: '16px', 
                        border: 'none', 
                        boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.05)',
                        padding: '12px 16px'
                    }}
                    itemStyle={{ fontSize: '12px', fontWeight: 'bold' }}
                />
                <Area 
                    type="monotone" 
                    dataKey="count" 
                    stroke="#10B981" 
                    strokeWidth={4} 
                    fillOpacity={1} 
                    fill="url(#colorCount)" 
                    animationDuration={1500}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Leaderboard Preview */}
        <LeaderboardPreview />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
         <ChartCard title="Task Distribution Breakdown">
            <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={80}
                    outerRadius={100}
                    paddingAngle={8}
                    dataKey="value"
                    stroke="none"
                >
                    {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                </Pie>
                <Tooltip 
                    contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1)' }}
                />
                </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-x-0 top-[60%] flex flex-col items-center justify-center pointer-events-none">
                <p className="text-4xl font-black text-[#111827] leading-none">{stats.tasks}</p>
                <p className="text-[10px] text-gray-500 uppercase tracking-widest font-black mt-2">Active</p>
            </div>
            <div className="mt-4 flex items-center justify-center gap-6">
                {pieData.map(item => (
                    <div key={item.name} className="flex items-center gap-2">
                        <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }}></div>
                        <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{item.name}</span>
                    </div>
                ))}
            </div>
         </ChartCard>
         
         <div className="bg-[#111827] p-8 md:p-12 rounded-[2.5rem] shadow-2xl text-white flex flex-col justify-between relative overflow-hidden">
            <div className="relative z-10">
               <div className="w-16 h-16 rounded-2xl bg-white/10 flex items-center justify-center text-green-400 mb-8 border border-white/10">
                  <Bell size={32} />
               </div>
               <h3 className="text-3xl font-black mb-4 tracking-tight">Public Feedback.</h3>
               <p className="text-gray-400 text-lg leading-relaxed mb-8">
                  There are {stats.totalFeedback} active complaints and suggestions from citizens that require attention.
               </p>
            </div>
            
            <button className="bg-white text-[#111827] px-8 py-4 rounded-xl font-black text-xs uppercase tracking-widest hover:bg-green-500 transition-colors relative z-10">
               Review Feedback
            </button>
            
            <div className="absolute -right-10 -bottom-10 opacity-10 pointer-events-none">
               <MessageSquare size={300} />
            </div>
         </div>
      </div>
    </div>
  );
};

const LeaderboardPreview: React.FC = () => {
  const [topUsers, setTopUsers] = useState<any[]>([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchTopUsers = async () => {
      try {
        const data = await api.users.getAll();
        setTopUsers(data.slice(0, 5));
      } catch (err) {
        console.error("Leaderboard preview fetch failed:", err);
      }
    };

    fetchTopUsers();
  }, []);

  return (
    <div className="bg-[#111827] p-8 rounded-[2.5rem] shadow-2xl text-white relative overflow-hidden flex flex-col h-full" style={{ minHeight: '450px' }}>
      <div className="relative z-10">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
             <div className="w-10 h-10 rounded-xl bg-green-500/10 flex items-center justify-center">
                <Trophy size={20} className="text-green-400" />
             </div>
             <h3 className="text-xl font-bold tracking-tight">Top Contributors</h3>
          </div>
        </div>

        <div className="space-y-4">
          {topUsers.map((user, i) => (
            <div key={user.id} className="flex items-center justify-between p-3 bg-white/5 rounded-2xl border border-white/5 group hover:bg-white/10 transition-all">
              <div className="flex items-center gap-3">
                <span className="text-xs font-black text-gray-500 w-4">{i + 1}</span>
                <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-[10px] font-black border border-white/10 overflow-hidden">
                  {user.photoUrl ? <img src={user.photoUrl} alt="" className="w-full h-full object-cover" /> : user.name?.[0]}
                </div>
                <span className="text-sm font-bold truncate max-w-[100px]">{user.name}</span>
              </div>
              <span className="text-lg font-black text-green-400">{user.points}</span>
            </div>
          ))}
        </div>
      </div>
      
      <button 
        onClick={() => navigate('/admin/leaderboard')}
        className="mt-8 relative z-10 w-full py-4 rounded-2xl bg-white/5 border border-white/10 text-[10px] font-black uppercase tracking-widest hover:bg-white hover:text-[#111827] transition-all"
      >
        View Full Leaderboard
      </button>

      <div className="absolute -right-20 -bottom-20 w-64 h-64 bg-green-500/5 rounded-full blur-3xl pointer-events-none"></div>
    </div>
  );
};
