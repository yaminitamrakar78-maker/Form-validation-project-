import React, { useState, useEffect } from 'react';
import { api } from '../lib/api';
import { UserProfile } from '../types';
import { 
  Trophy, 
  Medal, 
  Star, 
  TrendingUp, 
  ShieldCheck, 
  Zap, 
  Crown,
  Flame,
  ChevronRight,
  ClipboardCheck,
  Search,
  Filter,
  Loader2,
  ArrowRight,
  AlertTriangle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';

const getBadgeInfo = (points: number) => {
  if (points >= 5000) return { label: 'Top Civic Leader', color: 'bg-rose-100 text-rose-700', icon: Crown, border: 'border-rose-200' };
  if (points >= 2500) return { label: 'Cleanliness Champion', color: 'bg-yellow-100 text-yellow-700', icon: Trophy, border: 'border-yellow-200' };
  if (points >= 1000) return { label: 'Smart City Hero', color: 'bg-purple-100 text-purple-700', icon: ShieldCheck, border: 'border-purple-200' };
  if (points >= 500) return { label: 'Civic Contributor', color: 'bg-blue-100 text-blue-700', icon: Zap, border: 'border-blue-200' };
  return { label: 'Beginner Cleaner', color: 'bg-green-100 text-green-700', icon: Star, border: 'border-green-200' };
};

export const Leaderboard: React.FC = () => {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'all' | 'weekly' | 'monthly'>('all');

  useEffect(() => {
    const fetchUsers = async () => {
      setLoading(true);
      try {
        const usersData = await api.users.getAll();
        // Sort by points desc
        const sorted = usersData.sort((a: any, b: any) => (b.points || 0) - (a.points || 0));
        setUsers(sorted);
        setError(null);
      } catch (err) {
        console.error("Leaderboard fetch failed:", err);
        setError("Unable to sync leaderboard.");
      } finally {
        setLoading(false);
      }
    };

    fetchUsers();
  }, []);

  if (loading && users.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4">
        <Loader2 className="animate-spin text-green-600" size={40} />
        <p className="text-xs font-black text-gray-400 uppercase tracking-widest animate-pulse">Loading leaderboard...</p>
      </div>
    );
  }

  if (error && users.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4 text-center p-8 bg-rose-50 rounded-[3rem] border border-rose-100">
        <AlertTriangle className="text-rose-500" size={48} />
        <h2 className="text-2xl font-black text-rose-900">Permission Denied</h2>
        <p className="text-rose-700 max-w-sm">{error}</p>
        <button onClick={() => window.location.reload()} className="mt-4 px-8 py-4 bg-rose-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl">Retry Sync</button>
      </div>
    );
  }

  const topThree = users.slice(0, 3);
  const rest = users.slice(3);

  return (
    <div className="space-y-12 pb-20">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 px-4">
        <div className="flex items-center gap-6">
          <div className="w-14 h-14 md:w-18 md:h-18 flex items-center justify-center bg-green-600 rounded-full shadow-lg border-2 border-white text-white">
            <Trophy size={24} className="fill-current" />
          </div>
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-green-50 text-green-600 text-[10px] font-black uppercase tracking-widest border border-green-100">
              <Trophy size={12} className="fill-current" />
              Civic Merit System
            </div>
            <h2 className="text-3xl md:text-5xl font-black text-[#111827] tracking-tight uppercase">Raipur Municipal Corporation</h2>
            <p className="text-orange-500 font-bold uppercase tracking-widest text-[10px] mt-1">Smart Civic Sense System</p>
          </div>
        </div>

        <div className="flex items-center gap-2 p-1 bg-gray-100 rounded-2xl">
          {['all', 'weekly', 'monthly'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab as any)}
              className={cn(
                "px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all",
                activeTab === tab 
                  ? "bg-white text-[#111827] shadow-sm" 
                  : "text-gray-400 hover:text-gray-600"
              )}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* Top 3 Podium */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-end relative">
        <div className="absolute inset-0 bg-green-500/5 blur-[120px] rounded-full pointer-events-none"></div>
        
        {/* Silver - Rank 2 */}
        {topThree[1] && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="order-2 md:order-1 bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-xl flex flex-col items-center relative z-10"
          >
            <div className="absolute -top-4 left-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-gray-400 text-white flex items-center justify-center font-black text-sm border-2 border-white">2</div>
            <div className="w-20 h-20 rounded-full bg-gray-100 flex items-center justify-center text-gray-400 text-2xl font-black mb-4 overflow-hidden border-4 border-gray-50">
              {topThree[1].photoUrl ? <img src={topThree[1].photoUrl} alt="" /> : topThree[1].name[0]}
            </div>
            <h3 className="text-lg font-black text-[#111827] text-center">{topThree[1].name}</h3>
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-4">Silver Contributor</p>
            <div className="w-full flex items-center justify-between p-3 bg-gray-50 rounded-xl">
               <span className="text-xs font-black text-gray-500 uppercase tracking-widest">Points</span>
               <span className="text-xl font-black text-[#111827] tracking-tight">{topThree[1].points}</span>
            </div>
          </motion.div>
        )}

        {/* Gold - Rank 1 */}
        {topThree[0] && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="order-1 md:order-2 bg-[#111827] p-10 rounded-[3rem] shadow-2xl shadow-green-900/20 flex flex-col items-center relative z-20 md:scale-110 mb-8 md:mb-0"
          >
            <div className="absolute -top-6 left-1/2 -translate-x-1/2 w-12 h-12 rounded-full bg-green-500 text-[#111827] flex items-center justify-center font-black text-xl border-4 border-white shadow-xl">1</div>
            <div className="w-28 h-28 rounded-full bg-white/10 flex items-center justify-center text-white text-4xl font-black mb-6 overflow-hidden border-4 border-white/20">
              {topThree[0].photoUrl ? <img src={topThree[0].photoUrl} alt="" /> : topThree[0].name[0]}
            </div>
            <h3 className="text-2xl font-black text-white text-center leading-tight mb-2">{topThree[0].name}</h3>
            <div className={cn("px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-[0.2em] mb-6", getBadgeInfo(topThree[0].points).color)}>
               {getBadgeInfo(topThree[0].points).label}
            </div>
            <div className="w-full flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/10">
               <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">Master Score</span>
               <span className="text-3xl font-black text-green-400 tracking-tighter">{topThree[0].points}</span>
            </div>
          </motion.div>
        )}

        {/* Bronze - Rank 3 */}
        {topThree[2] && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="order-3 bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-xl flex flex-col items-center relative z-10"
          >
            <div className="absolute -top-4 left-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-amber-600 text-white flex items-center justify-center font-black text-sm border-2 border-white">3</div>
            <div className="w-20 h-20 rounded-full bg-gray-100 flex items-center justify-center text-gray-400 text-2xl font-black mb-4 overflow-hidden border-4 border-gray-50">
              {topThree[2].photoUrl ? <img src={topThree[2].photoUrl} alt="" /> : topThree[2].name[0]}
            </div>
            <h3 className="text-lg font-black text-[#111827] text-center">{topThree[2].name}</h3>
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-4">Bronze Contributor</p>
            <div className="w-full flex items-center justify-between p-3 bg-gray-50 rounded-xl">
               <span className="text-xs font-black text-gray-500 uppercase tracking-widest">Points</span>
               <span className="text-xl font-black text-[#111827] tracking-tight">{topThree[2].points}</span>
            </div>
          </motion.div>
        )}
      </div>

      {/* Leaderboard Table Section */}
      <div className="bg-white rounded-[3rem] border border-gray-100 shadow-sm overflow-hidden p-6 md:p-10">
         <div className="flex flex-col md:flex-row items-center justify-between gap-6 mb-10">
            <h2 className="text-2xl font-black text-[#111827] tracking-tight">Active Rankings</h2>
            <div className="relative w-full md:w-80">
               <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
               <input 
                 type="text" 
                 placeholder="Search contributors..." 
                 className="w-full pl-12 pr-4 py-4 bg-gray-50 border-none rounded-2xl text-sm font-bold focus:ring-2 focus:ring-green-500 transition-all outline-none"
               />
            </div>
         </div>

         <div className="space-y-4">
            {rest.length === 0 && !loading && (
               <div className="py-20 text-center">
                  <Trophy size={48} className="mx-auto text-gray-100 mb-4" />
                  <p className="text-gray-400 font-bold uppercase tracking-widest text-xs">No leaderboard data available.</p>
               </div>
            )}
            {rest.map((user, i) => {
              const badge = getBadgeInfo(user.points);
              return (
                <motion.div 
                  key={(user as any)._id || user.uid}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.05 }}
                  className="flex items-center justify-between p-5 md:px-8 bg-white border border-gray-50 rounded-[2rem] hover:bg-gray-50 transition-all group"
                >
                  <div className="flex items-center gap-6">
                    <span className="text-lg font-black text-gray-200 w-8 group-hover:text-gray-400 transition-colors">{i + 4}</span>
                    <div className="w-12 h-12 rounded-2xl bg-gray-100 flex items-center justify-center text-gray-400 font-black overflow-hidden border border-gray-100">
                      {user.photoUrl ? (
                        <img src={user.photoUrl} alt="" className="w-full h-full object-cover" />
                      ) : (
                        <span className="text-xl">{user.name[0]}</span>
                      )}
                    </div>
                    <div>
                       <h4 className="font-bold text-[#111827] leading-tight">{user.name}</h4>
                       <div className="flex items-center gap-2 mt-1">
                         <div className={cn("text-[8px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full inline-block", badge.color)}>
                           {badge.label}
                         </div>
                         {user.currentStreak > 0 && (
                           <div className="flex items-center gap-1 text-orange-500 text-[8px] font-black uppercase">
                             <Flame size={10} fill="currentColor" />
                             {user.currentStreak} Day Streak
                           </div>
                         )}
                       </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-10">
                    <div className="hidden sm:flex flex-col items-end">
                       <p className="text-[8px] font-black text-gray-300 uppercase tracking-widest mb-1">Impact Rating</p>
                       <div className="flex gap-1">
                          {[1,2,3,4,5].map(star => (
                            <Star key={star} size={8} className={cn("fill-green-500 text-green-500", star > 4 && "opacity-20")} />
                          ))}
                       </div>
                    </div>
                    <div className="text-right min-w-[80px]">
                       <p className="text-[8px] font-black text-gray-400 uppercase tracking-widest mb-1">Total Score</p>
                       <p className="text-xl font-black text-[#111827] tracking-tighter">{user.points}</p>
                    </div>
                  </div>
                </motion.div>
              );
            })}
            
            {loading && (
               <div className="flex flex-col items-center justify-center py-20 gap-4">
                  <Loader2 className="animate-spin text-green-600" size={40} />
                  <p className="text-xs font-black text-gray-400 uppercase tracking-widest animate-pulse">Updating rankings...</p>
               </div>
            )}
         </div>
      </div>

      {/* Rewards CTA */}
      <div className="bg-[#111827] p-10 md:p-16 rounded-[4rem] text-white overflow-hidden relative">
         <div className="relative z-10 max-w-xl">
           <h2 className="text-4xl font-black mb-6 tracking-tight leading-none">Turn your points into <br /> <span className="text-green-400 uppercase italic">Real Value.</span></h2>
           <p className="text-gray-400 text-lg mb-10 leading-relaxed">
             The leaderboard isn't just about prestige—it's your gateway to exclusive city rewards, utility vouchers, and civic badges.
           </p>
           <button className="bg-green-500 hover:bg-green-600 text-[#111827] px-10 py-5 rounded-2xl font-black text-xs uppercase tracking-widest transition-all shadow-xl shadow-green-500/20 active:scale-95 flex items-center gap-3">
             View Reward Store <ArrowRight size={18} />
           </button>
         </div>
         
         <div className="absolute right-0 top-0 bottom-0 w-1/2 opacity-10 pointer-events-none hidden lg:block">
            <TrendingUp size={600} className="-rotate-12 translate-x-20" />
         </div>
      </div>
    </div>
  );
};
