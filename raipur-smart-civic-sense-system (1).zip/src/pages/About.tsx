import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Info, 
  CheckCircle2, 
  MapPin, 
  ShieldCheck, 
  ArrowRight, 
  Gift, 
  Clock, 
  HelpCircle, 
  Shield, 
  Sprout, 
  Shirt, 
  Brush, 
  Recycle, 
  Trash2, 
  Droplets, 
  Zap, 
  Trees, 
  Ban,
  Camera,
  Search,
  AlertTriangle,
  X,
  Send,
  Loader2,
  MessageCircle,
  LayoutDashboard,
  Award
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn, safeGetDate } from '../lib/utils';
import { api } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import { toast } from 'sonner';
import { DEFAULT_DAILY_HABITS } from '@/constants';

const ICON_MAP: Record<string, React.ReactNode> = {
  Shield: <Shield className="text-blue-500" size={24} />,
  Sprout: <Sprout className="text-green-500" size={24} />,
  Shirt: <Shirt className="text-amber-500" size={24} />,
  Brush: <Brush className="text-orange-500" size={24} />,
  Recycle: <Recycle className="text-cyan-500" size={24} />,
  Trash2: <Trash2 className="text-rose-500" size={24} />,
  Droplets: <Droplets className="text-indigo-500" size={24} />,
  Zap: <Zap className="text-yellow-500" size={24} />,
  Trees: <Trees className="text-emerald-500" size={24} />,
  Ban: <Ban className="text-red-500" size={24} />,
};

const SectionHeader: React.FC<{ title: string; subtitle?: string; emoji?: string }> = ({ title, subtitle, emoji }) => (
  <div className="mb-8">
    <div className="flex items-center gap-3 mb-2">
      {emoji && <span className="text-2xl">{emoji}</span>}
      <h2 className="text-2xl md:text-3xl font-black text-[#111827] tracking-tight">{title}</h2>
    </div>
    {subtitle && <p className="text-gray-500 font-medium">{subtitle}</p>}
  </div>
);

const StepItem: React.FC<{ number: number; title: string; desc: string }> = ({ number, title, desc }) => (
  <div className="flex gap-6 items-start group">
    <div className="w-10 h-10 rounded-full bg-[#111827] text-white flex items-center justify-center font-black shrink-0 shadow-lg group-hover:scale-110 transition-transform">
      {number}
    </div>
    <div className="space-y-1">
      <h4 className="font-black text-[#111827] tracking-tight">{title}</h4>
      <p className="text-sm text-gray-500 leading-relaxed">{desc}</p>
    </div>
  </div>
);

export const About: React.FC = () => {
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({ subject: '', message: '', type: 'query' });
  const [completionStats, setCompletionStats] = useState({ count: 0, total: DEFAULT_DAILY_HABITS.length });

  const fetchStats = async () => {
    if (!(profile as any)?._id && !profile?.uid) return;
    
    const userId = (profile as any)?._id || profile?.uid;
    const today = new Date().toISOString().split('T')[0];
    const cacheKey = `about_completion_stats_${userId}_${today}`;
    const cached = sessionStorage.getItem(cacheKey);
    const cachedTime = sessionStorage.getItem(`${cacheKey}_time`);

    if (cached && cachedTime && (Date.now() - parseInt(cachedTime)) < 600000) {
      setCompletionStats(JSON.parse(cached));
      return;
    }

    try {
      const habits = await api.habits.getAll();
      let count = 0;
      habits.forEach((habit: any) => {
        const habitDate = new Date(habit.createdAt).toISOString().split('T')[0];
        if (habitDate === today) count++;
      });
      
      const newStats = { count, total: DEFAULT_DAILY_HABITS.length };
      setCompletionStats(newStats);
      sessionStorage.setItem(cacheKey, JSON.stringify(newStats));
      sessionStorage.setItem(`${cacheKey}_time`, Date.now().toString());
    } catch (error) {
      console.error("Error fetching about stats:", error);
    }
  };

  useEffect(() => {
    fetchStats();
  }, [(profile as any)?._id || profile?.uid]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;
    if (!formData.subject || !formData.message) {
      toast.error("Please fill in all fields");
      return;
    }

    setIsSubmitting(true);
    try {
      await api.feedback.submit({
        subject: formData.subject,
        message: formData.message
      });
      
      toast.success("Message Sent", { description: "An administrator will review your request shortly." });
      setIsModalOpen(false);
      setFormData({ subject: '', message: '', type: 'query' });
    } catch (error: any) {
       toast.error(error.message || "Feedback submission failed");
    } finally {
      setIsSubmitting(false);
    }
  };

  const progress = (completionStats.count / completionStats.total) * 100;

  return (
    <div className="max-w-6xl mx-auto space-y-16 pb-24 px-4 sm:px-6">
      {/* Hero Banner */}
      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative bg-[#111827] rounded-[3rem] overflow-hidden p-8 md:p-16 text-white"
      >
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-green-500/20 text-green-400 text-[10px] font-black uppercase tracking-widest mb-8 border border-green-500/20">
            <Zap size={14} className="fill-current" />
            Civic Revolution
          </div>
          <h1 className="text-4xl md:text-6xl font-black mb-6 tracking-tighter leading-none">
            Your Guide to a <br /> <span className="text-green-400 italic">Smarter City.</span>
          </h1>
          <p className="text-lg text-gray-400 leading-relaxed mb-10">
            Everything you need to know about the Smart Civic Sense System. Join thousands of citizens 
            making a real impact every single day.
          </p>
          <div className="flex flex-wrap gap-4">
            <button 
              onClick={() => navigate('/dashboard')}
              className="bg-green-500 hover:bg-green-600 text-[#111827] px-8 py-4 rounded-2xl font-black text-sm uppercase tracking-widest transition-all shadow-xl shadow-green-500/20 flex items-center gap-2 group"
            >
              <LayoutDashboard size={20} />
              Start Task
              <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
            </button>
            <button 
              onClick={() => setIsModalOpen(true)}
              className="bg-white/10 hover:bg-white/20 text-white px-8 py-4 rounded-2xl font-black text-sm uppercase tracking-widest transition-all border border-white/10 flex items-center gap-2"
            >
              <MessageCircle size={20} />
              Contact Support
            </button>
          </div>
        </div>
        
        {/* Progress Tracker (Bonus) */}
        <div className="absolute right-8 bottom-8 md:right-16 md:top-1/2 md:-translate-y-1/2 bg-white/5 backdrop-blur-xl border border-white/10 p-6 rounded-[2.5rem] w-full md:w-64">
           <div className="flex justify-between items-center mb-4">
             <span className="text-[10px] font-black uppercase tracking-widest text-gray-400">Daily Goal</span>
             <span className="text-xs font-black text-green-400">{Math.round(progress)}%</span>
           </div>
           <div className="h-3 bg-white/10 rounded-full overflow-hidden mb-4">
             <motion.div 
               initial={{ width: 0 }}
               animate={{ width: `${progress}%` }}
               className="h-full bg-green-500"
             />
           </div>
           <p className="text-[10px] font-medium text-gray-400 leading-tight">
             {completionStats.count} of {completionStats.total} tasks completed today.
           </p>
        </div>

        {/* Decoration */}
        <div className="absolute -right-20 -top-20 w-96 h-96 bg-green-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -left-20 -bottom-20 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
      </motion.div>

      {/* 1. About the Platform */}
      <section>
        <div className="bg-white rounded-[3rem] p-10 md:p-16 border border-gray-100 shadow-sm flex flex-col md:flex-row gap-12 items-center">
           <div className="w-24 h-24 md:w-32 md:h-32 rounded-[2.5rem] bg-indigo-50/50 flex items-center justify-center shrink-0 shadow-xl border-4 border-white overflow-hidden p-2">
             <ShieldCheck className="w-12 h-12 text-indigo-600" />
           </div>
           <div>
             <SectionHeader 
               emoji="🌍" 
               title="About Smart Civic Sense System" 
               subtitle="Building the foundation for cleaner communities"
             />
             <p className="text-gray-500 text-lg leading-relaxed max-w-2xl">
               This platform is designed to improve civic responsibility and cleanliness in society. 
               Users can complete daily and assigned tasks like cleaning areas, saving resources, 
               and contributing to the environment to earn reward points.
             </p>
           </div>
        </div>
      </section>

      {/* 2. What are Daily Tasks? */}
      <section className="space-y-12">
        <SectionHeader 
          emoji="✅"
          title="Daily Civic Tasks"
          subtitle="Simple activities that build good civic habits regularly."
        />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {DEFAULT_DAILY_HABITS.map((habit, i) => (
            <motion.div 
              key={habit.id}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              className="bg-white p-6 rounded-3xl border border-gray-100 hover:border-green-300 transition-colors shadow-sm text-center space-y-4"
            >
               <div className="w-12 h-12 rounded-2xl bg-gray-50 flex items-center justify-center mx-auto transition-colors group-hover:bg-green-50">
                 {ICON_MAP[habit.icon] || <Zap size={24} />}
               </div>
               <h4 className="font-bold text-sm text-[#111827] leading-tight px-2">{habit.title}</h4>
            </motion.div>
          ))}
        </div>
      </section>

      {/* 3. How to Perform Daily Task? */}
      <section className="bg-gray-50 rounded-[3rem] p-10 md:p-16 border border-gray-100">
         <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
           <div className="space-y-10">
             <SectionHeader 
               emoji="📸"
               title="How to Complete a Task"
               subtitle="Follow these simple steps to ensure your contribution is recorded."
             />
             <div className="space-y-8">
               <StepItem number={1} title="Go to Dashboard" desc="Login and navigate to your main control center." />
               <StepItem number={2} title="Select a Daily Task" desc="Choose any task from the Daily Civic Habits section." />
               <StepItem number={3} title="Click on the Task" desc="Open the submission modal for your chosen activity." />
               <StepItem number={4} title="Upload Proof" desc="Click the camera area to upload a real image as proof." />
               <StepItem number={5} title="Location Access" desc="Allow location access to verify where the task was done." />
               <StepItem number={6} title="Submit" desc="Click 'Submit for Review' to send your data to our team." />
             </div>
           </div>
           <div className="relative">
              <div className="aspect-[4/5] bg-white rounded-[4rem] shadow-2xl border-8 border-gray-100 overflow-hidden relative">
                 <div className="absolute inset-0 bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center p-12">
                    <div className="space-y-6 text-center">
                       <div className="w-20 h-20 rounded-full bg-[#111827] text-white flex items-center justify-center mx-auto shadow-2xl animate-bounce">
                          <Camera size={40} />
                       </div>
                       <p className="text-gray-400 font-black uppercase tracking-widest text-[10px]">Proof Visualization</p>
                    </div>
                 </div>
                 <div className="absolute bottom-10 left-10 right-10 bg-white p-6 rounded-3xl shadow-xl border border-gray-50">
                    <div className="flex items-center gap-4">
                       <div className="w-12 h-12 rounded-xl bg-green-500 flex items-center justify-center text-white">
                          <CheckCircle2 size={24} />
                       </div>
                       <div className="text-left">
                          <p className="font-black text-[#111827] leading-none mb-1">TASK VERIFIED</p>
                          <p className="text-[10px] text-gray-400 font-bold">+15 Points Awarded</p>
                       </div>
                    </div>
                 </div>
              </div>
              <div className="absolute -top-6 -right-6 w-24 h-24 bg-yellow-400 rounded-full blur-2xl opacity-20" />
              <div className="absolute -bottom-10 -left-10 w-32 h-32 bg-green-400 rounded-full blur-3xl opacity-20" />
           </div>
         </div>
      </section>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* 4. Verification Process */}
        <section className="bg-white p-10 rounded-[3rem] border border-gray-100 shadow-sm space-y-6">
          <SectionHeader 
            emoji="🔍"
            title="Verification & Approval"
          />
          <div className="space-y-4">
             <div className="p-4 bg-gray-50 rounded-2xl flex items-start gap-4">
                <Search className="text-blue-500 shrink-0" size={24} />
                <p className="text-sm text-gray-500 font-medium">Your task will be checked by AI and Admin</p>
             </div>
             <div className="p-4 bg-gray-50 rounded-2xl flex items-start gap-4">
                <AlertTriangle className="text-rose-500 shrink-0" size={24} />
                <p className="text-sm text-gray-500 font-medium">Duplicate or fake images will be rejected</p>
             </div>
             <div className="p-4 bg-gray-50 rounded-2xl flex items-start gap-4">
                <CheckCircle2 className="text-green-500 shrink-0" size={24} />
                <p className="text-sm text-gray-500 font-medium">Only genuine work will be approved</p>
             </div>
          </div>
        </section>

        {/* 5. Rewards System */}
        <section className="bg-[#111827] p-10 rounded-[3rem] text-white space-y-6">
          <SectionHeader 
            emoji="🎁"
            title="Earn Rewards"
          />
          <div className="space-y-4 text-gray-300">
             <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-yellow-500 border border-white/10 shrink-0">
                  <Zap size={20} />
                </div>
                <p className="text-sm font-medium">Each task gives points</p>
             </div>
             <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-green-500 border border-white/10 shrink-0">
                  <Award size={20} />
                </div>
                <p className="text-sm font-medium">Points added only after approval</p>
             </div>
             <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-blue-500 border border-white/10 shrink-0">
                  <Gift size={20} />
                </div>
                <p className="text-sm font-medium">Redeem from the Rewards section</p>
             </div>
          </div>
        </section>
      </div>

      {/* 6. Important Guidelines */}
      <section className="bg-rose-50 rounded-[3rem] p-10 md:p-16 border border-rose-100 text-center space-y-8">
         <SectionHeader 
           emoji="⚠️"
           title="Rules & Guidelines"
           subtitle="Maintaining integrity in our community"
         />
         <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              "Upload real and recent images",
              "Do not submit duplicate photos",
              "Location must be enabled",
              "Follow all safety rules"
            ].map((rule, i) => (
              <div key={i} className="bg-white p-6 rounded-2xl border border-rose-200 text-rose-700 font-bold text-sm shadow-sm group hover:bg-rose-700 hover:text-white transition-colors">
                {rule}
              </div>
            ))}
         </div>
      </section>

      {/* Contact Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="bg-white w-full max-w-xl rounded-[2.5rem] shadow-2xl overflow-hidden"
            >
              <div className="p-8 bg-[#111827] text-white flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-green-500/20 flex items-center justify-center text-green-400">
                    <MessageCircle size={20} />
                  </div>
                  <div>
                    <h3 className="text-xl font-black tracking-tight">Contact Admin</h3>
                    <p className="text-xs text-gray-400 font-medium tracking-widest uppercase">Support & Queries</p>
                  </div>
                </div>
                <button onClick={() => setIsModalOpen(false)} className="w-10 h-10 rounded-full hover:bg-white/10 flex items-center justify-center transition-colors">
                  <X size={20} />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="p-8 space-y-6">
                <div className="space-y-2">
                   <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 ml-1">Request Type</label>
                   <div className="grid grid-cols-3 gap-2">
                     {['query', 'issue', 'other'].map(t => (
                       <button
                         key={t}
                         type="button"
                         onClick={() => setFormData(prev => ({ ...prev, type: t }))}
                         className={cn(
                           "py-3 rounded-xl text-[10px] font-black uppercase tracking-tighter border transition-all",
                           formData.type === t 
                            ? "bg-green-600 text-white border-green-600" 
                            : "bg-gray-50 text-gray-400 border-gray-100 hover:bg-gray-100"
                         )}
                       >
                         {t}
                       </button>
                     ))}
                   </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 ml-1">Subject</label>
                  <input 
                    type="text"
                    placeholder="Briefly describe your query..."
                    value={formData.subject}
                    onChange={(e) => setFormData(prev => ({ ...prev, subject: e.target.value }))}
                    className="w-full px-6 py-4 bg-gray-50 border-2 border-transparent focus:border-green-500 focus:bg-white rounded-2xl font-bold transition-all outline-none"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 ml-1">Message Detail</label>
                  <textarea 
                    rows={4}
                    placeholder="Tell us more about how we can help..."
                    value={formData.message}
                    onChange={(e) => setFormData(prev => ({ ...prev, message: e.target.value }))}
                    className="w-full px-6 py-4 bg-gray-50 border-2 border-transparent focus:border-green-500 focus:bg-white rounded-2xl font-bold transition-all outline-none resize-none"
                  />
                </div>

                <button 
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-[#111827] text-white py-5 rounded-2xl font-black uppercase tracking-[0.2em] text-xs hover:bg-black transition-all flex items-center justify-center gap-3 shadow-xl active:scale-[0.98] disabled:opacity-50"
                >
                  {isSubmitting ? <Loader2 className="animate-spin" size={18} /> : <Send size={18} />}
                  Send Message
                </button>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
