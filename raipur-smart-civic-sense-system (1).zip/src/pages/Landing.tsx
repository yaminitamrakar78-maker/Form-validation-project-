import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ShieldCheck, Zap, Users, BarChart3, ChevronRight, Globe, Camera, Share2 } from 'lucide-react';
import { motion } from 'motion/react';
import raipurLogo from "@/assets/raipur-logo.png";
import { useAuth } from '../context/AuthContext';

export const Landing: React.FC = () => {
  const [logoError, setLogoError] = useState(false);
  const { user, profile } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (user && profile) {
      console.log(`[Landing] Authenticated user detected (${profile.role}), redirecting...`);
      if (profile.role === 'admin') {
        navigate('/admin/dashboard');
      } else {
        navigate('/user/dashboard');
      }
    }
  }, [user, profile, navigate]);
  return (
    <div className="min-h-screen bg-white">
      {/* Official Top Strip */}
      <div className="bg-[#111827] text-white py-2 px-6 flex justify-between items-center text-[10px] font-black uppercase tracking-[0.2em] relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-orange-500/10 via-transparent to-green-500/10" />
        <div className="relative z-10">Raipur Municipal Corporation | Smart City Initiative</div>
        <div className="relative z-10 hidden sm:block">Govt. of Chhattisgarh</div>
      </div>

      {/* Navbar */}
      <nav className="container mx-auto px-6 py-6 flex justify-between items-center border-b border-gray-50 relative z-10 bg-white/80 backdrop-blur-md sticky top-0">
        <div className="flex items-center gap-3">
          {!logoError ? (
            <img 
              src={raipurLogo} 
              alt="Raipur Municipal Corporation Logo" 
              className="w-10 h-10 object-contain rounded-full shadow-lg shadow-gray-100 border-2 border-white" 
              onError={() => setLogoError(true)}
            />
          ) : (
            <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center text-orange-600 font-bold text-xs shadow-lg shadow-gray-100 border-2 border-white">RMC</div>
          )}
          <div className="flex flex-col">
            <span className="text-sm md:text-base font-black text-[#111827] tracking-tight leading-tight">
              RAIPUR MUNICIPAL CORPORATION
            </span>
            <span className="text-[10px] md:text-xs font-bold text-orange-500 uppercase tracking-widest">Smart Civic Sense System</span>
          </div>
        </div>
        <div className="flex items-center gap-4 sm:gap-8">
            <Link to="/login" className="text-xs font-black text-gray-400 hover:text-[#111827] uppercase tracking-widest transition-colors">Login</Link>
            <Link to="/register" className="bg-[#111827] text-white px-6 py-2.5 rounded-full text-xs font-black uppercase tracking-widest hover:shadow-xl hover:shadow-gray-200 transition-all active:scale-95">Register</Link>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="container mx-auto px-6 pt-20 pb-24 text-center relative overflow-hidden">
        <motion.div
           initial={{ opacity: 0, y: 20 }}
           animate={{ opacity: 1, y: 0 }}
           transition={{ duration: 0.6 }}
        >
            <div className="flex items-center justify-center gap-2 mb-8">
              <span className="bg-orange-50 text-orange-700 px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-widest border border-orange-100">Cleanliness Mission</span>
              <span className="w-1.5 h-1.5 rounded-full bg-gray-300" />
              <span className="bg-green-50 text-green-700 px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-widest border border-green-100">Smart Monitoring</span>
            </div>

            <h1 className="text-5xl md:text-8xl font-black text-[#111827] leading-[1.05] tracking-tight mb-4">
              Building a <span className="text-orange-500">Swachh</span> & <span className="text-green-600">Smart</span> Raipur.
            </h1>
            <p className="text-lg font-bold text-gray-400 uppercase tracking-widest mb-10 max-w-2xl mx-auto">
              Citizen Participation & Cleanliness Monitoring Platform
            </p>
            <p className="text-xl text-[#6B7280] max-w-2xl mx-auto leading-relaxed mb-12 font-medium">
              Join the official initiative of Raipur Municipal Corporation to transform our city through AI-verified task completion and real rewards.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Link to="/register" className="w-full sm:w-auto bg-[#111827] text-white px-10 py-5 rounded-2xl text-[12px] font-black uppercase tracking-[0.2em] hover:bg-black transition-all flex items-center justify-center gap-3 group shadow-2xl shadow-gray-200">
                    Join Swachh Raipur
                    <ChevronRight className="group-hover:translate-x-1 transition-transform" />
                </Link>
                <button className="w-full sm:w-auto border-2 border-gray-100 text-[#111827] px-10 py-5 rounded-2xl text-[12px] font-black uppercase tracking-[0.2em] hover:bg-gray-50 transition-all">
                    Public Dashboard
                </button>
            </div>
        </motion.div>
      </section>

      {/* Compact Civic Banner */}
      <section className="container mx-auto px-6 mb-20">
        <div className="relative bg-[#111827] rounded-[2.5rem] overflow-hidden border border-white/10 shadow-2xl shadow-gray-200">
          <div className="absolute inset-0 bg-gradient-to-r from-green-500/10 via-transparent to-orange-500/10" />
          <div className="relative z-10 px-8 py-10 md:px-12 flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="flex flex-col md:flex-row items-center gap-6 text-center md:text-left">
              <div className="w-16 h-16 bg-white rounded-3xl flex items-center justify-center p-3 shadow-xl shrink-0 border border-gray-100">
                <ShieldCheck className="w-10 h-10 text-green-600" />
              </div>
              <div className="space-y-1">
                <div className="flex items-center justify-center md:justify-start gap-2 mb-1">
                  <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
                  <span className="text-green-400 text-[10px] font-black uppercase tracking-[0.3em]">Official Mission</span>
                </div>
                <h2 className="text-3xl md:text-4xl font-black text-white tracking-tighter uppercase leading-none">Swachh Raipur Mission</h2>
                <p className="text-gray-400 text-sm font-bold uppercase tracking-widest">Clean Raipur, Green Raipur</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="hidden lg:flex flex-col items-end border-r border-white/10 pr-6">
                <span className="text-gray-500 text-[10px] font-black uppercase tracking-widest">Sustainability Rank</span>
                <span className="text-white font-black text-xl">Top 10 Cities</span>
              </div>
              <div className="bg-white/5 backdrop-blur-md border border-white/10 px-6 py-3 rounded-2xl">
                <p className="text-gray-300 text-xs font-medium leading-relaxed max-w-[200px]">
                  Join the mission for a cleaner urban future.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Bar */}
      <section className="bg-gray-50 py-20 border-y border-gray-100">
          <div className="container mx-auto px-6">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-12 text-center">
                  <div>
                      <p className="text-4xl font-black text-[#111827]">12k+</p>
                      <p className="text-sm font-bold text-gray-400 uppercase tracking-widest mt-2">Tasks Done</p>
                  </div>
                  <div>
                      <p className="text-4xl font-black text-[#111827]">4.8k</p>
                      <p className="text-sm font-bold text-gray-400 uppercase tracking-widest mt-2">Active Users</p>
                  </div>
                  <div>
                      <p className="text-4xl font-black text-[#111827]">98%</p>
                      <p className="text-sm font-bold text-gray-400 uppercase tracking-widest mt-2">AI Precision</p>
                  </div>
                  <div>
                      <p className="text-4xl font-black text-[#111827]">15+</p>
                      <p className="text-sm font-bold text-gray-400 uppercase tracking-widest mt-2">Cities Covered</p>
                  </div>
              </div>
          </div>
      </section>

      {/* Features */}
      <section className="container mx-auto px-6 py-32">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
              <div className="space-y-6">
                  <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center shadow-lg shadow-blue-50">
                    <Camera size={32} />
                  </div>
                  <h3 className="text-2xl font-bold text-[#111827]">AI Verification</h3>
                  <p className="text-[#6B7280] leading-relaxed">
                      Using Google's Gemini AI to instantly verify cleanliness through image recognition. No manual oversight needed.
                  </p>
              </div>
              <div className="space-y-6">
                  <div className="w-16 h-16 bg-yellow-50 text-yellow-600 rounded-2xl flex items-center justify-center shadow-lg shadow-yellow-50">
                    <Zap size={32} />
                  </div>
                  <h3 className="text-2xl font-bold text-[#111827]">Instant Rewards</h3>
                  <p className="text-[#6B7280] leading-relaxed">
                      Earn points immediately after AI verification. Redeem them for bus passes, utility bill discounts, and more.
                  </p>
              </div>
              <div className="space-y-6">
                  <div className="w-16 h-16 bg-green-50 text-green-600 rounded-2xl flex items-center justify-center shadow-lg shadow-green-50">
                    <Globe size={32} />
                  </div>
                  <h3 className="text-2xl font-bold text-[#111827]">Community Impact</h3>
                  <p className="text-[#6B7280] leading-relaxed">
                      Watch your city improve in real-time. Join thousands of other civic-minded citizens in our leaderboard.
                  </p>
              </div>
          </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#111827] text-white py-24 mt-20 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-orange-500 via-white to-green-500 opacity-50" />
          <div className="container mx-auto px-6 grid grid-cols-1 md:grid-cols-4 gap-12 relative z-10">
              <div className="md:col-span-2">
                <div className="flex items-center gap-4 mb-6">
                    {!logoError ? (
                      <img 
                        src={raipurLogo} 
                        alt="Raipur Municipal Corporation Official Logo" 
                        className="h-12 w-12 object-contain rounded-full border border-white/20" 
                        onError={() => setLogoError(true)}
                      />
                    ) : (
                      <div className="h-12 w-12 bg-white/10 rounded-full flex items-center justify-center text-white font-bold text-xs border border-white/20">RMC</div>
                    )}
                    <div className="flex flex-col">
                      <span className="text-lg font-black tracking-tight text-white">RAIPUR MUNICIPAL CORPORATION</span>
                      <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest leading-none">Powered by Raipur Smart City Digital Team</span>
                    </div>
                </div>
                <p className="text-gray-400 max-w-sm text-sm font-medium leading-relaxed">
                    The official digital initiative by Raipur Municipal Corporation to promote hygiene and civic responsibility through incentivized citizen participation.
                </p>
              </div>
              <div>
                  <h4 className="font-black uppercase tracking-widest text-xs mb-8 text-gray-500">Resource Links</h4>
                  <ul className="space-y-4 text-gray-400 text-sm font-bold">
                      <li><Link to="/login" className="hover:text-white transition-colors">Citizen Portal</Link></li>
                      <li><Link to="/login" className="hover:text-white transition-colors">Admin Login</Link></li>
                      <li><a href="#" className="hover:text-white transition-colors">Privacy & Data Policy</a></li>
                  </ul>
              </div>
              <div>
                  <h4 className="font-black uppercase tracking-widest text-xs mb-8 text-gray-500">Contact Official</h4>
                  <ul className="space-y-4 text-gray-400 text-sm font-bold">
                      <li>raipur@smartcity.gov.in</li>
                      <li>1100 (Toll Free)</li>
                      <li>Nagar Nigam, Raipur (C.G.)</li>
                  </ul>
              </div>
          </div>
          <div className="container mx-auto px-6 pt-20 border-t border-white/5 mt-20 flex flex-col md:flex-row justify-between items-center gap-6 text-[10px] text-gray-500 font-bold uppercase tracking-widest">
              <span>© 2026 Raipur Smart Civic Sense System.</span>
              <div className="flex items-center gap-6">
                <a href="#" className="hover:text-white transition-colors">Terms of Use</a>
                <a href="#" className="hover:text-white transition-colors">Disclaimer</a>
                <span className="text-orange-500/50 underline underline-offset-4 decoration-white/10">Swachh Bharat Mission</span>
              </div>
          </div>
      </footer>
    </div>
  );
};
