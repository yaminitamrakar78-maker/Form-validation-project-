import React, { useState, useEffect } from 'react';
import { api } from '../../lib/api';
import { useAuth } from '../../context/AuthContext';
import { Task } from '../../types';
import { MapPin, Camera, CheckCircle, AlertCircle, Loader2, Sparkles, Clock, X } from 'lucide-react';
import { verifyCleanliness, AIVerificationResult } from '../../services/aiService';
import { motion, AnimatePresence } from 'motion/react';
import { cn, generatePerceptualHash, safeGetDate, compressImage } from '../../lib/utils';
import { MapContainer, TileLayer, Marker, useMapEvents } from 'react-leaflet';
import L from 'leaflet';
import { format } from 'date-fns';
import { toast } from 'sonner';

// Fix for default leaflet marker icons
import 'leaflet/dist/leaflet.css';

const markerIcon = 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png';
const markerShadow = 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png';

let DefaultIcon = L.icon({
  iconUrl: markerIcon,
  shadowUrl: markerShadow,
  iconSize: [25, 41],
  iconAnchor: [12, 41]
});
L.Marker.prototype.options.icon = DefaultIcon;

interface LocationPickerProps {
  location: { lat: number; lng: number };
  onChange: (lat: number, lng: number) => void;
}

const LocationPicker: React.FC<LocationPickerProps> = ({ location, onChange }) => {
  const MapEvents = () => {
    useMapEvents({
      click(e) {
        onChange(e.latlng.lat, e.latlng.lng);
      },
    });
    return null;
  };

  return (
    <div className="h-48 w-full rounded-2xl overflow-hidden border border-blue-100 shadow-inner">
      <MapContainer 
        center={[location.lat, location.lng]} 
        zoom={15} 
        scrollWheelZoom={false}
        className="h-full w-full"
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        <MapEvents />
        <Marker 
          position={[location.lat, location.lng]} 
          draggable={true}
          eventHandlers={{
            dragend: (e: any) => {
              const marker = e.target;
              const position = marker.getLatLng();
              onChange(position.lat, position.lng);
            },
          }}
        />
      </MapContainer>
    </div>
  );
};

export const UserTasks: React.FC = () => {
  const { profile } = useAuth();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'pending' | 'submitted' | 'approved' | 'rejected'>('pending');
  const [submitting, setSubmitting] = useState(false);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [proofImage, setProofImage] = useState<string | null>(null);
  const [location, setLocation] = useState<{ lat: number; lng: number; address: string } | null>(null);
  const [workerNotes, setWorkerNotes] = useState('');
  const [submissionStep, setSubmissionStep] = useState<string>('');

  const logTaskAction = async (taskId: string, action: string, details?: string) => {
    if (!profile) return;
    try {
      await api.admin.addLog({
        taskId,
        action,
        userId: profile.uid,
        userName: profile.name,
        details: details || ''
      });
    } catch (error) {
      console.error("Error logging task action:", error);
    }
  };

  useEffect(() => {
    fetchTasks();
  }, [profile, filter]);

  const fetchTasks = async () => {
    if (!profile) return;
    setLoading(true);
    try {
      const allTasks = await api.tasks.getAll();
      // Filter by status and workerId/assignedUsers
      const filtered = allTasks.filter((t: any) => {
        const isAssigned = t.workerId === profile.uid || (t.assignedUsers && t.assignedUsers.includes(profile.uid));
        return isAssigned && t.status === filter;
      });
      
      setTasks(filtered.sort((a: any, b: any) => safeGetDate(b.createdAt).getTime() - safeGetDate(a.createdAt).getTime()));
    } catch (error) {
      console.error("Error fetching tasks:", error);
      toast.error("Failed to fetch tasks");
    } finally {
      setLoading(false);
    }
  };

  const detectLocation = () => {
    return new Promise<{ lat: number; lng: number; address: string }>((resolve, reject) => {
      if (!navigator.geolocation) {
        reject("Geolocation not supported");
        return;
      }
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const { latitude, longitude } = position.coords;
          resolve({ 
            lat: latitude, 
            lng: longitude, 
            address: `GPS: ${latitude.toFixed(4)}, ${longitude.toFixed(4)}` 
          });
        },
        (error) => reject(error.message)
      );
    });
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast.error("Image too large", {
          description: "Please upload an image smaller than 5MB."
        });
        return;
      }
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64 = reader.result as string;
        const compressed = await compressImage(base64);
        setProofImage(compressed);
        
        try {
          const loc = await detectLocation();
          setLocation(loc);
          toast.success("Location Captured", {
            description: "Your GPS coordinates have been securely attached."
          });
        } catch (err) {
          console.error("Location detection failed", err);
          toast.warning("Manual Location Recommended", {
            description: "We couldn't automatically detect your location. Please check the map."
          });
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const submitTask = async () => {
    if (!selectedTask || !proofImage || !profile) return;
    setSubmitting(true);
    
    try {
      // 1. Perceptual Hashing
      setSubmissionStep('Generating security fingerprint...');
      const hash = await generatePerceptualHash(proofImage);

      // 2. AI Analysis
      setSubmissionStep('Running AI Content Audit...');
      let aiAnalysis: AIVerificationResult | null = null;
      try {
        aiAnalysis = await verifyCleanliness(proofImage);
        
        if (aiAnalysis.isFake) {
          toast.warning("Authenticity Warning", {
            description: "Our AI suspect this image may not be genuine. You can still submit, but it will be flagged for manual review.",
            duration: 6000
          });
        }
      } catch (aiErr) {
        console.error("AI Analysis failed:", aiErr);
      }

      // 3. API Submission
      setSubmissionStep('Synchronizing with Grid...');
      await api.tasks.update(selectedTask.id, {
        status: 'submitted',
        completedAt: new Date().toISOString(),
        proofImageUrl: proofImage,
        latitude: location?.lat || null,
        longitude: location?.lng || null,
        address: location?.address || 'Location unknown',
        imageHash: hash,
        workerNotes: workerNotes,
        aiAnalysis: aiAnalysis,
        verificationStatus: aiAnalysis?.isFake ? 'flagged' : 'pending_review',
        updatedAt: new Date().toISOString()
      });

      // Log the submission
      await logTaskAction(selectedTask.id, 'submitted', `Task submitted by ${profile.name} with proof image.`);

      // 4. Notification for Admin
      await api.notifications.create({
        userId: 'admin', 
        title: 'New Task Submission',
        message: `${profile.name} submitted proof for "${selectedTask.title}"`,
        type: 'info',
        relatedId: selectedTask.id
      });

      toast.success("Task Submitted Successfully!", {
        description: "Your work is now entering administrative review. Points will be awarded upon approval."
      });
      
      setSelectedTask(null);
      setProofImage(null);
      setLocation(null);
      setWorkerNotes('');
      setSubmissionStep('');
      fetchTasks();
    } catch (error) {
      console.error("Error submitting task:", error);
      toast.error("Submission Failed", {
        description: "An error occurred while publishing your task. Please try again."
      });
    } finally {
      setSubmitting(false);
      setSubmissionStep('');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-[#111827]">Assigned Tasks</h2>
          <p className="text-[#6B7280]">Complete these tasks to contribute to the city and earn reward points.</p>
        </div>
        <div className="flex bg-gray-100 p-1 rounded-xl w-fit">
          {(['pending', 'submitted', 'approved', 'rejected'] as const).map((s) => (
            <button
              key={s}
              onClick={() => setFilter(s)}
              className={cn(
                "px-4 py-2 rounded-lg text-xs font-bold transition-all uppercase tracking-tighter",
                filter === s ? "bg-white text-green-700 shadow-sm" : "text-gray-500 hover:text-gray-700"
              )}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-64">
          <Loader2 className="animate-spin text-green-600" size={32} />
        </div>
      ) : tasks.length === 0 ? (
        <div className="bg-white p-12 rounded-2xl border border-dashed border-gray-300 flex flex-col items-center justify-center text-center">
            <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mb-4">
                <CheckCircle className="text-gray-400" size={32} />
            </div>
            <h3 className="text-lg font-semibold text-[#111827]">
              {filter === 'pending' ? 'All clear!' : `No ${filter} tasks`}
            </h3>
            <p className="text-[#6B7280] max-w-sm uppercase text-[10px] font-black tracking-widest mt-2">
              {filter === 'pending' 
                ? "There are no pending tasks assigned to you right now." 
                : `You don't have any tasks in ${filter} status yet.`}
            </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {tasks.map((task) => (
            <motion.div 
              key={task.id} 
              layoutId={task.id}
              className="bg-white rounded-2xl border border-[#E5E7EB] shadow-sm overflow-hidden hover:shadow-md transition-all group"
            >
              <div className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div className="flex flex-col gap-2">
                    <div className={cn(
                      "px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider w-fit",
                      task.status === 'approved' ? "bg-green-100 text-green-700" : 
                      task.status === 'submitted' ? "bg-blue-100 text-blue-700" :
                      task.status === 'rejected' ? "bg-rose-100 text-rose-700" :
                      "bg-gray-100 text-gray-700"
                    )}>
                      {task.pointsValue} Points
                    </div>
                    <span className={cn(
                      "px-2 py-0.5 rounded-md text-[8px] font-black uppercase tracking-[0.2em] w-fit border",
                      task.type === 'group' ? "bg-purple-50 text-purple-600 border-purple-100" : "bg-blue-50 text-blue-600 border-blue-100"
                    )}>
                      {task.type || 'Individual'}
                    </span>
                  </div>
                  <span className="text-xs text-gray-400 flex items-center gap-1">
                    <Clock size={12} />
                    {task.status === 'pending' ? format(safeGetDate(task.createdAt), 'MMM dd') : format(safeGetDate(task.completedAt || task.createdAt), 'MMM dd')}
                  </span>
                </div>
                <h3 className="text-xl font-bold text-[#111827] mb-2 group-hover:text-green-600 transition-colors uppercase">{task.title}</h3>
                <div className="flex items-center text-[#6B7280] text-sm mb-4 gap-1">
                  <MapPin size={16} />
                  {task.location}
                </div>
                <p className="text-[#4B5563] text-sm mb-6 line-clamp-2">{task.description}</p>
                
                {task.status === 'pending' ? (
                  <button
                    onClick={() => setSelectedTask(task)}
                    className="w-full bg-[#111827] text-white font-semibold py-3 px-6 rounded-xl hover:bg-black transition-colors flex items-center justify-center gap-2"
                  >
                    <Camera size={18} />
                    Start Submission
                  </button>
                ) : (
                  <div className={cn(
                    "flex flex-col gap-2 p-4 rounded-xl text-sm font-bold",
                    task.status === 'approved' ? "bg-green-50 text-green-600" :
                    task.status === 'submitted' ? "bg-blue-50 text-blue-600" :
                    "bg-rose-50 text-rose-600"
                  )}>
                    <div className="flex items-center gap-2">
                      {task.status === 'approved' ? <CheckCircle size={18} /> : <Clock size={18} />}
                      {task.status === 'approved' ? 'Verification Passed: Reward Granted' : 
                       task.status === 'submitted' ? 'Sent for Administrative Review' : 
                       'Rejection Notice Issued'}
                    </div>
                    {task.rejectionReason && (
                      <p className="text-[10px] font-medium text-rose-500 italic mt-1 pl-6">
                        Reason: {task.rejectionReason}
                      </p>
                    )}
                  </div>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {/* Task Submission Modal */}
      <AnimatePresence>
        {selectedTask && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedTask(null)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 30 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 30 }}
              className="bg-white rounded-[3.5rem] shadow-2xl w-full max-w-5xl max-h-[90vh] overflow-y-auto relative z-10 custom-scrollbar"
            >
              <div className="p-6 md:p-8">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-2xl font-bold text-[#111827]">Submit Proof of Completion</h3>
                  <button onClick={() => setSelectedTask(null)} className="text-gray-400 hover:text-gray-600">
                    <X size={24} />
                  </button>
                </div>

                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-6">
                      <div className="bg-gray-50 p-6 rounded-3xl border border-gray-100 shadow-sm">
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Target Task</p>
                        <p className="font-bold text-[#111827] text-lg mb-2">{selectedTask.title}</p>
                        <div className="flex items-center gap-2 text-green-600 font-bold text-xs">
                          <Sparkles size={14} />
                          {selectedTask.pointsValue} Points Reward
                        </div>
                      </div>

                      <div className="space-y-2">
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-1">Note to Admin (Optional)</p>
                        <textarea 
                          value={workerNotes}
                          onChange={(e) => setWorkerNotes(e.target.value)}
                          placeholder="Detail the work performed or site conditions..."
                          className="w-full p-5 rounded-3xl border-2 border-gray-100 focus:border-green-500 bg-gray-50/30 transition-all text-sm min-h-[140px] outline-none font-medium"
                        />
                      </div>

                      {!proofImage ? (
                        <label className="border-2 border-dashed border-gray-200 rounded-[2.5rem] h-72 flex flex-col items-center justify-center cursor-pointer hover:bg-green-50 hover:border-green-400 transition-all group bg-gray-50/20">
                          <div className="w-16 h-16 bg-white shadow-md text-green-600 rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform border border-gray-100">
                            <Camera size={28} />
                          </div>
                          <p className="text-sm font-bold text-gray-700">Attach Clear Photo Evidence</p>
                          <p className="text-[10px] text-gray-400 mt-2 uppercase tracking-widest font-black">Supported: JPEG, PNG (max 5MB)</p>
                          <input type="file" className="hidden" accept="image/*" onChange={handleImageUpload} />
                        </label>
                      ) : (
                        <div className="relative rounded-[2.5rem] overflow-hidden aspect-square shadow-xl group border-8 border-white ring-1 ring-gray-100">
                          <img src={proofImage} alt="Proof" className="w-full h-full object-cover" />
                          <div className="absolute inset-0 bg-[#111827]/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-4">
                            <CheckCircle className="text-green-400" size={48} />
                            <p className="text-white font-black uppercase text-xs tracking-widest">Image Loaded</p>
                            <button 
                              onClick={() => setProofImage(null)}
                              className="bg-white/20 backdrop-blur-md text-white px-6 py-2 rounded-full hover:bg-rose-500 transition-all font-black uppercase text-[10px] tracking-widest mt-4"
                            >
                              Replace Image
                            </button>
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="space-y-6">
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Security & Telemetry</p>
                          {location && (
                            <span className="flex items-center gap-1.5 text-blue-600 animate-pulse">
                              <span className="w-1.5 h-1.5 bg-blue-600 rounded-full" />
                              <span className="text-[10px] font-black uppercase tracking-widest">Signal Locked</span>
                            </span>
                          )}
                        </div>
                        
                        {location ? (
                          <div className="space-y-4">
                            <LocationPicker 
                              location={{ lat: location.lat, lng: location.lng }}
                              onChange={(lat, lng) => setLocation({ 
                                ...location, 
                                lat, 
                                lng, 
                                address: `Adjusted: ${lat.toFixed(4)}, ${lng.toFixed(4)}` 
                              })}
                            />
                            <div className="p-5 bg-blue-50/50 rounded-3xl border-2 border-blue-100 flex items-start gap-4">
                              <div className="w-10 h-10 bg-white rounded-xl shadow-sm flex items-center justify-center text-blue-600 shrink-0">
                                <MapPin size={20} />
                              </div>
                              <div>
                                <p className="font-bold text-blue-900 text-xs uppercase tracking-tight mb-0.5">Detected GPS Coordinate</p>
                                <p className="text-[10px] text-blue-700/80 font-bold font-mono">{location.address}</p>
                                <p className="text-[9px] text-blue-400 font-medium mt-1 leading-relaxed">Location data is required for municipal verification.</p>
                              </div>
                            </div>
                            <div className="flex items-center gap-2 p-3 bg-green-50 border border-green-100 rounded-2xl">
                               <CheckCircle className="text-green-600" size={14} />
                               <span className="text-[10px] font-bold text-green-700">Location detected successfully</span>
                            </div>
                          </div>
                        ) : (
                          <div className="h-full min-h-[300px] rounded-[2.5rem] bg-gray-50 border-2 border-dashed border-gray-200 flex flex-col items-center justify-center text-center p-8">
                            <div className="w-16 h-16 bg-white rounded-3xl shadow-sm flex items-center justify-center text-gray-200 mb-6">
                              <MapPin size={32} />
                            </div>
                            <p className="text-sm font-bold text-gray-400 uppercase tracking-widest">Awaiting Geolocation</p>
                            <p className="text-[10px] text-gray-400 mt-3 max-w-[200px] leading-relaxed">Please upload a photo. The system will automatically attempt to capture your GPS coordinates.</p>
                          </div>
                        )}
                      </div>

                      <div className="p-6 bg-amber-50 rounded-3xl border-2 border-amber-100 mt-auto">
                        <div className="flex gap-4">
                           <AlertCircle className="text-amber-600 shrink-0" size={20} />
                           <div className="space-y-1">
                             <p className="text-[10px] font-black text-amber-900 uppercase tracking-widest">Submission Notice</p>
                             <p className="text-[10px] text-amber-700/80 font-bold leading-relaxed">
                               After submission, your work will be audited by municipal AI and administrators. Reward points are granted only after successful verification.
                             </p>
                           </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 pt-8">
                    <button
                      onClick={() => setSelectedTask(null)}
                      className="bg-gray-100 text-gray-500 font-black text-xs uppercase tracking-widest py-6 rounded-2xl hover:bg-gray-200 transition-all border-b-4 border-gray-200 active:border-b-0 active:translate-y-1"
                    >
                      Cancel Upload
                    </button>
                    <button
                      disabled={!proofImage || !location || submitting}
                      onClick={submitTask}
                      className={cn(
                        "font-black text-xs uppercase tracking-widest py-6 rounded-2xl transition-all shadow-xl flex items-center justify-center gap-3 relative overflow-hidden",
                        proofImage && location && !submitting
                          ? "bg-green-600 text-white hover:bg-green-700 shadow-green-200 border-b-4 border-green-800 active:border-b-0 active:translate-y-1" 
                          : "bg-gray-100 text-gray-300 cursor-not-allowed"
                      )}
                    >
                      {submitting ? (
                        <div className="flex flex-col items-center">
                          <div className="flex items-center gap-2">
                             <Loader2 className="animate-spin" size={18} />
                             <span>Processing...</span>
                          </div>
                          <span className="text-[8px] mt-1 opacity-70 animate-pulse">{submissionStep}</span>
                        </div>
                      ) : (
                        <>
                          <CheckCircle size={18} strokeWidth={3} />
                          Finalize & Submit
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
