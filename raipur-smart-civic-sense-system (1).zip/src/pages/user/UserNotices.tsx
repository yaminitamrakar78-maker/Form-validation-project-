import React, { useState, useEffect } from 'react';
import { api } from '../../lib/api';
import { Notice } from '../../types';
import { Bell, Clock, Calendar, ChevronRight } from 'lucide-react';
import { motion } from 'motion/react';
import { safeGetDate, cn } from '../../lib/utils';

export const UserNotices: React.FC = () => {
  const [notices, setNotices] = useState<Notice[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchNotices = async () => {
      try {
        const data = await api.notices.getAll();
        setNotices(data);
      } catch (error) {
        console.error("Error fetching notices:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchNotices();
  }, []);

  return (
    <div className="space-y-8 pb-20">
      <div className="flex items-center gap-6">
        <div className="w-16 h-16 flex items-center justify-center bg-blue-600 rounded-full shadow-lg border-2 border-white text-white">
          <Bell size={32} />
        </div>
        <div>
            <h2 className="text-3xl md:text-4xl font-black text-[#111827] tracking-tight uppercase">Raipur Municipal Corporation</h2>
            <p className="text-orange-500 font-bold uppercase tracking-widest text-[10px] mt-1">Smart Civic Sense System</p>
        </div>
      </div>

      <div className="space-y-4">
        {loading ? (
           <div className="space-y-4">
             {[1,2,3].map(i => (
               <div key={i} className="h-32 bg-gray-100 rounded-2xl animate-pulse" />
             ))}
           </div>
        ) : notices.length === 0 ? (
          <div className="text-center py-20 bg-white rounded-[2.5rem] border border-gray-100 shadow-sm">
            <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto text-gray-200 mb-4">
              <Bell size={32} />
            </div>
            <p className="text-gray-400 font-bold uppercase tracking-widest text-xs">No civic notices available.</p>
          </div>
        ) : (
          notices.map((notice, index) => (
            <motion.div
              key={notice.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-all group cursor-pointer"
            >
              <div className="flex items-start gap-6">
                <div className="hidden sm:flex flex-col items-center justify-center w-20 h-20 bg-gray-50 text-[#111827] rounded-3xl font-black border border-gray-100 shadow-sm shrink-0">
                  <span className="text-[10px] uppercase tracking-widest opacity-40">{safeGetDate(notice.issuedAt).toLocaleString('en-US', { month: 'short' })}</span>
                  <span className="text-2xl">{safeGetDate(notice.issuedAt).getDate()}</span>
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="flex items-center gap-2 sm:hidden">
                      <Calendar size={14} className="text-green-600" />
                      <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{safeGetDate(notice.issuedAt).toLocaleDateString()}</span>
                    </div>
                    {notice.category && (
                      <span className={cn(
                        "text-[8px] font-black px-2 py-1 rounded-md uppercase tracking-widest text-white shadow-sm",
                        notice.category === 'Urgent' ? "bg-orange-500" : 
                        notice.category === 'Update' ? "bg-blue-400" : "bg-green-500"
                      )}>
                        {notice.category}
                      </span>
                    )}
                  </div>
                  <h3 className="text-xl font-black text-[#111827] mb-2 uppercase tracking-tight group-hover:text-green-600 transition-colors">{notice.title}</h3>
                  <p className="text-[#4B5563] font-medium leading-relaxed">{notice.content}</p>
                </div>
                <div className="self-center">
                   <div className="w-10 h-10 rounded-full bg-gray-50 flex items-center justify-center text-gray-300 group-hover:text-green-500 group-hover:bg-green-50 transition-all">
                      <ChevronRight size={20} strokeWidth={3} />
                   </div>
                </div>
              </div>
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
};
