import React, { createContext, useContext, useEffect, useState } from 'react';
import { 
  onAuthStateChanged, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut as firebaseSignOut, 
  User, 
  sendPasswordResetEmail,
  GoogleAuthProvider,
  signInWithPopup
} from 'firebase/auth';
import { doc, getDoc, setDoc, serverTimestamp, getDocFromServer, enableNetwork } from 'firebase/firestore';
import { UserProfile } from '../types';
import { auth, db, useFallbackDb } from '../lib/firebase';

interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
  isOffline: boolean;
  login: (credentials: any) => Promise<void>;
  register: (userData: any) => Promise<void>;
  signInWithGoogle: () => Promise<void>;
  signOut: () => void;
  refreshProfile: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const ADMIN_EMAILS = ['yaminitamrakar78@gmail.com', 'patelsulochana46@gmail.com'];

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [isOffline, setIsOffline] = useState(false);

  // Check connectivity periodically
  useEffect(() => {
    const checkStatus = () => {
      setIsOffline(!window.navigator.onLine);
    };
    window.addEventListener('online', checkStatus);
    window.addEventListener('offline', checkStatus);
    checkStatus();
    return () => {
      window.removeEventListener('online', checkStatus);
      window.removeEventListener('offline', checkStatus);
    };
  }, []);

  const fetchProfile = async (uid: string) => {
    try {
      console.log(`[Auth] Fetching profile for: ${uid}`);
      const docRef = doc(db, 'users', uid);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        const data = docSnap.data();
        console.log(`[Auth] Profile found:`, data);
        setProfile({ id: docSnap.id, ...data } as any);
        return { id: docSnap.id, ...data } as UserProfile;
      } else {
        console.warn(`[Auth] No profile found for UID: ${uid}`);
        setProfile(null);
        return null;
      }
    } catch (err: any) {
      if (err.message?.includes('offline') || err.code === 'unavailable') {
        console.warn("[Auth] Profile fetch failure (offline):", err.message || err);
      } else {
        console.error("[Auth] Profile fetch failure:", err);
      }
      setProfile(null);
      return null;
    }
  };

  const ensureUserProfile = async (user: User) => {
    let retries = 3;
    let lastError: any = null;

    while (retries > 0) {
      try {
        console.log(`[Auth] Ensuring profile for UID: ${user.uid} (Attempts left: ${retries})`);
        
        // Explicitly try to enable network before critical calls if we suspect flakiness
        try {
          await enableNetwork(db);
        } catch (enErr) {
          console.warn("[Auth] Failed to explicitly enable network:", enErr);
        }

        let docRef = doc(db, 'users', user.uid);
        
        let docSnap;
        try {
          docSnap = await getDoc(docRef);
        } catch (getDocErr: any) {
          console.warn("[Auth] getDoc failed or reported offline:", getDocErr.message || getDocErr);
          if (getDocErr.code === 'not-found' || getDocErr.code === 'unavailable' || getDocErr.message?.includes('offline')) {
            console.warn("[Auth] Attempting transparent fallback to (default) database due to offline/not-found status...");
            useFallbackDb();
            // Re-resolve reference using the updated active db from our proxy
            docRef = doc(db, 'users', user.uid);
            try {
              docSnap = await getDoc(docRef);
            } catch (fallbackErr: any) {
              console.warn("[Auth] getDoc failed on fallback database as well:", fallbackErr.message);
              throw fallbackErr;
            }
          } else {
            throw getDocErr;
          }
        }

        const isAdmin = ADMIN_EMAILS.includes(user.email || '');
        
        if (!docSnap.exists()) {
          console.log(`[Auth] User profile missing. Creating for ${user.email} (IsAdmin: ${isAdmin})`);
          const profileData = {
            uid: user.uid,
            name: user.displayName || user.email?.split('@')[0] || 'Municipal User',
            email: user.email,
            mobile: '',
            role: isAdmin ? 'admin' : 'worker',
            points: 0,
            createdAt: serverTimestamp(),
            accountStatus: 'active',
            currentStreak: 0,
            longestStreak: 0,
            tasksCompleted: 0,
            complaintsSubmitted: 0
          };
          await setDoc(docRef, profileData);
          setProfile({ id: user.uid, ...profileData } as any);
          try {
            localStorage.setItem(`user_profile_${user.uid}`, JSON.stringify({ id: user.uid, ...profileData }));
          } catch (le) {
            console.warn("[Auth] LocalStorage cache write failed", le);
          }
          return { id: user.uid, ...profileData };
        }

        const existingProfile = { id: docSnap.id, ...docSnap.data() } as any;
        setProfile(existingProfile);
        try {
          localStorage.setItem(`user_profile_${user.uid}`, JSON.stringify(existingProfile));
        } catch (le) {
          console.warn("[Auth] LocalStorage cache write failed", le);
        }

        // Migrations/Fixes for legacy profiles
        const needsUpdate = 
          (existingProfile.role === 'worker' && isAdmin) || 
          existingProfile.points === undefined ||
          existingProfile.accountStatus === undefined;

        if (needsUpdate) {
          console.log(`[Auth] Patching/Migrating profile for user: ${user.email}`);
          const updates: any = {};
          if (existingProfile.role === 'worker' && isAdmin) updates.role = 'admin';
          if (existingProfile.points === undefined) updates.points = 0;
          if (existingProfile.accountStatus === undefined) updates.accountStatus = 'active';
          
          await setDoc(docRef, updates, { merge: true });
          const finalProfile = { ...existingProfile, ...updates };
          setProfile(finalProfile);
          try {
            localStorage.setItem(`user_profile_${user.uid}`, JSON.stringify(finalProfile));
          } catch (le) {}
          return finalProfile;
        }

        return existingProfile;
      } catch (err: any) {
        lastError = err;
        const isOffline = err.message?.includes('offline') || err.code === 'unavailable';
        if (isOffline) {
          console.warn(`[Auth] Network reported offline during ensureUserProfile. Aborting retries and utilizing local resilient fallback.`);
          break;
        } else {
          console.error(`[Auth] Attempt failed for ensureUserProfile (${retries} left):`, err.message);
          retries--;
          if (retries > 0) {
            await new Promise(resolve => setTimeout(resolve, 1000));
            continue;
          }
        }
      }
    }

    if (lastError && (lastError.message?.includes('offline') || lastError.code === 'unavailable')) {
      console.warn("[Auth] Handled network/offline state during ensureUserProfile. Local fallback profile initiated.");
    } else {
      console.error("[Auth] Error in ensureUserProfile after retries:", lastError);
    }
    
    // Offline resilience fallback
    console.warn("[Auth] Firestore completely offline. Initiating offline resilient fallback...");
    try {
      const cached = localStorage.getItem(`user_profile_${user.uid}`);
      if (cached) {
        const parsed = JSON.parse(cached);
        console.log("[Auth] Successfully loaded cached user profile from offline localStorage:", parsed);
        setProfile(parsed);
        return parsed;
      }
    } catch (lcErr) {
      console.error("[Auth] Failed to read from local storage:", lcErr);
    }

    const isAdmin = ADMIN_EMAILS.includes(user.email || '');
    const synthesizedProfile: UserProfile = {
      uid: user.uid,
      id: user.uid,
      name: user.displayName || user.email?.split('@')[0] || 'Municipal User',
      email: user.email || '',
      mobile: '',
      role: isAdmin ? 'admin' : 'worker',
      points: 0,
      accountStatus: 'active',
      currentStreak: 0,
      longestStreak: 0,
      tasksCompleted: 0,
      complaintsSubmitted: 0
    } as any;

    console.log("[Auth] Synthesized fallback profile:", synthesizedProfile);
    setProfile(synthesizedProfile);
    try {
      localStorage.setItem(`user_profile_${user.uid}`, JSON.stringify(synthesizedProfile));
    } catch (lsErr) {
      console.warn("[Auth] Failed to save offline profile to localStorage:", lsErr);
    }

    return synthesizedProfile;
  };

  useEffect(() => {
    // Prevent multiple auth subscriptions
    let isSubscribed = true;
    console.log("[Auth] Effect triggered. Initializing onAuthStateChanged");

    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (!isSubscribed) return;

      try {
        console.log(`[Auth] State changed: ${user ? user.email : 'Logged out'}`);
        setCurrentUser(user);
        
        if (user) {
          console.log("[Auth] User detected, fetching profile...");
          await ensureUserProfile(user);
        } else {
          setProfile(null);
        }
      } catch (error: any) {
        if (error.code === 'auth/network-request-failed') {
          console.error("[Auth] Network error during state change. Check connection.");
        } else {
          console.error("[Auth] Unexpected error in auth listener:", error);
        }
      } finally {
        if (isSubscribed) {
          setLoading(false);
          console.log("[Auth] Loading finished.");
        }
      }
    }, (error) => {
      console.error("[Auth] onAuthStateChanged Error:", error);
      if (isSubscribed) setLoading(false);
    });

    return () => {
      console.log("[Auth] Cleaning up auth subscription");
      isSubscribed = false;
      unsubscribe();
    };
  }, []);

  const handleRedirect = (userProfile: any, userEmail?: string | null) => {
    const isAdminEmail = ADMIN_EMAILS.includes(userEmail || '');
    const isAdminRole = userProfile?.role === 'admin';
    
    console.log(`[Auth] Redirecting. IsAdminEmail: ${isAdminEmail}, IsAdminRole: ${isAdminRole}`);
    
    if (isAdminEmail || isAdminRole) {
      window.location.href = '/admin/dashboard';
    } else {
      window.location.href = '/user/dashboard';
    }
  };

  const login = async (credentials: any) => {
    try {
      const { email, password } = credentials;
      console.log(`[Auth] Attempting login for ${email}`);
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;
      
      const userProfile = await ensureUserProfile(user);
      handleRedirect(userProfile, user.email);
    } catch (err: any) {
      console.error("[Auth] Login Error Details:", err);
      let errorMessage = "Invalid email or password.";
      
      if (err.code === 'auth/network-request-failed') {
        errorMessage = "Network request failed. Please check your internet connection and ensure your browser isn't blocking Firebase (check AdBlockers).";
      } else if (err.code === 'auth/invalid-credential' || err.message.includes('auth/invalid-credential')) {
        errorMessage = "Invalid credentials. If you haven't registered in our new system yet, please click 'Create Account' below.";
      } else if (err.code === 'auth/user-disabled') {
        errorMessage = "This account has been disabled.";
      } else if (err.code === 'auth/too-many-requests') {
        errorMessage = "Too many failed attempts. Please try again later.";
      } else if (err.code === 'auth/configuration-not-found') {
        errorMessage = "Firebase Authentication is not configured correctly in the console.";
      }
      
      throw new Error(errorMessage);
    }
  };

  const signInWithGoogle = async () => {
    try {
      console.log("[Auth] Initiating Google Sign-In");
      const provider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, provider);
      const user = result.user;
      
      const userProfile = await ensureUserProfile(user);
      handleRedirect(userProfile, user.email);
    } catch (err: any) {
      console.error("[Auth] Google Sign-In Error:", err);
      let msg = err.message || "Google Sign-In failed.";
      if (err.code === 'auth/network-request-failed') {
        msg = "Network failure during Google Sign-In. Check your connection or authorized domains in Firebase Console.";
      } else if (err.code === 'auth/popup-closed-by-user') {
        msg = "Sign-in popup was closed before completion.";
      } else if (err.code === 'auth/unauthorized-domain') {
        msg = "This domain is not authorized for Firebase Authentication. Please add it to the 'Authorized Domains' list in Firebase Console.";
      }
      throw new Error(msg);
    }
  };

  const register = async (userData: any) => {
    try {
      const { email, password, name, role, mobile } = userData;
      console.log(`[Auth] Registering user: ${email}`);
      const isAdminByEmail = ADMIN_EMAILS.includes(email);
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;

      const profileData = {
        uid: user.uid,
        name: name,
        email: email,
        mobile: mobile || '',
        role: isAdminByEmail ? 'admin' : (role || 'worker'),
        points: 0,
        createdAt: serverTimestamp(),
        accountStatus: 'active',
        currentStreak: 0,
        longestStreak: 0,
        tasksCompleted: 0,
        complaintsSubmitted: 0
      };

      await setDoc(doc(db, 'users', user.uid), profileData);
      setProfile({ id: user.uid, ...profileData } as any);
      
      handleRedirect(profileData, email);
    } catch (err: any) {
      let errorMessage = err.message || "Failed to register. Please check your connection.";
      if (err.code === 'auth/network-request-failed') {
        errorMessage = "Network request failed during registration. Please check your connection.";
      } else if (err.code === 'auth/email-already-in-use') {
        errorMessage = "This email is already registered. Try logging in instead.";
      } else if (err.code === 'auth/weak-password') {
        errorMessage = "Password is too weak. Please use at least 6 characters.";
      }
      console.error("[Auth] Registration Error:", err);
      throw new Error(errorMessage);
    }
  };

  const signOut = async () => {
    try {
      console.log("[Auth] Signing out...");
      await firebaseSignOut(auth);
      window.location.href = '/login';
    } catch (err) {
      console.error("[Auth] Sign out error:", err);
    }
  };

  const refreshProfile = async () => {
    if (auth.currentUser) {
      await fetchProfile(auth.currentUser.uid);
    }
  };

  const resetPassword = async (email: string) => {
    try {
      await sendPasswordResetEmail(auth, email);
    } catch (err: any) {
      const errorMessage = err.message || "Failed to send reset email.";
      console.error("[Auth] Reset Password Error:", err);
      throw new Error(errorMessage);
    }
  };

  return (
    <AuthContext.Provider value={{ 
      user: currentUser, 
      profile, 
      loading, 
      isOffline,
      login, 
      register, 
      signInWithGoogle,
      signOut, 
      refreshProfile,
      resetPassword
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
