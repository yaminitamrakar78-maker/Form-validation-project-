import { 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  setDoc, 
  updateDoc, 
  deleteDoc, 
  query, 
  where, 
  orderBy, 
  limit, 
  serverTimestamp,
  Timestamp,
  increment,
  addDoc
} from 'firebase/firestore';
import { db, OperationType, handleFirestoreError } from '../lib/firebase';
import { UserProfile, Task, Notice, Reward, Feedback, RedeemRequest, DigitalPass, Notification, HabitSubmission } from '../types';

export const firebaseService = {
  users: {
    getProfile: async (uid: string) => {
      try {
        const docRef = doc(db, 'users', uid);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          return { id: docSnap.id, ...docSnap.data() } as unknown as UserProfile;
        }
        return null;
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, `users/${uid}`);
      }
    },
    createProfile: async (profile: Partial<UserProfile>) => {
      try {
        const uid = profile.uid;
        if (!uid) throw new Error('UID is required to create profile');
        const docRef = doc(db, 'users', uid);
        const data = {
          ...profile,
          points: profile.points || 0,
          role: profile.role || 'worker',
          accountStatus: 'active',
          currentStreak: 0,
          longestStreak: 0,
          tasksCompleted: 0,
          complaintsSubmitted: 0,
          createdAt: serverTimestamp(),
        };
        await setDoc(docRef, data);
        return { id: uid, ...data } as unknown as UserProfile;
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, 'users');
      }
    },
    updateProfile: async (uid: string, data: Partial<UserProfile>) => {
      try {
        const docRef = doc(db, 'users', uid);
        await updateDoc(docRef, { ...data, updatedAt: serverTimestamp() });
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `users/${uid}`);
      }
    },
    getAll: async () => {
      try {
        const q = query(collection(db, 'users'), orderBy('points', 'desc'));
        const querySnapshot = await getDocs(q);
        return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as unknown as UserProfile[];
      } catch (error) {
        handleFirestoreError(error, OperationType.LIST, 'users');
      }
    }
  },
  tasks: {
    getAll: async (workerId?: string) => {
      try {
        let q = query(collection(db, 'tasks'), orderBy('createdAt', 'desc'));
        if (workerId) {
          q = query(collection(db, 'tasks'), where('workerId', '==', workerId), orderBy('createdAt', 'desc'));
        }
        const querySnapshot = await getDocs(q);
        return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as Task[];
      } catch (error) {
        handleFirestoreError(error, OperationType.LIST, 'tasks');
      }
    },
    create: async (task: Partial<Task>) => {
      try {
        const docRef = await addDoc(collection(db, 'tasks'), {
          ...task,
          status: task.status || 'pending',
          createdAt: serverTimestamp(),
        });
        return { id: docRef.id, ...task } as Task;
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, 'tasks');
      }
    },
    update: async (id: string, data: Partial<Task>) => {
      try {
        const docRef = doc(db, 'tasks', id);
        await updateDoc(docRef, { ...data, updatedAt: serverTimestamp() });
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `tasks/${id}`);
      }
    },
    delete: async (id: string) => {
      try {
        await deleteDoc(doc(db, 'tasks', id));
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, `tasks/${id}`);
      }
    }
  },
  notices: {
    getAll: async () => {
      try {
        const q = query(collection(db, 'notices'), orderBy('issuedAt', 'desc'));
        const querySnapshot = await getDocs(q);
        return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as Notice[];
      } catch (error) {
        handleFirestoreError(error, OperationType.LIST, 'notices');
      }
    },
    create: async (notice: Partial<Notice>) => {
      try {
        await addDoc(collection(db, 'notices'), {
          ...notice,
          issuedAt: serverTimestamp(),
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, 'notices');
      }
    },
    delete: async (id: string) => {
      try {
        await deleteDoc(doc(db, 'notices', id));
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, `notices/${id}`);
      }
    }
  },
  habits: {
    getAll: async (userId?: string) => {
      try {
        let q = query(collection(db, 'habitSubmissions'), orderBy('createdAt', 'desc'));
        if (userId) {
          q = query(collection(db, 'habitSubmissions'), where('userId', '==', userId), orderBy('createdAt', 'desc'));
        }
        const querySnapshot = await getDocs(q);
        return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as HabitSubmission[];
      } catch (error) {
        handleFirestoreError(error, OperationType.LIST, 'habitSubmissions');
      }
    },
    submit: async (payload: Partial<HabitSubmission>) => {
      try {
        const docRef = await addDoc(collection(db, 'habitSubmissions'), {
          ...payload,
          status: 'pending',
          createdAt: serverTimestamp(),
        });
        return { id: docRef.id, ...payload } as HabitSubmission;
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, 'habitSubmissions');
      }
    },
    update: async (id: string, data: Partial<HabitSubmission>) => {
      try {
        const docRef = doc(db, 'habitSubmissions', id);
        await updateDoc(docRef, data);
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `habitSubmissions/${id}`);
      }
    }
  },
  feedback: {
    submit: async (payload: Partial<Feedback>) => {
      try {
        await addDoc(collection(db, 'feedback'), {
          ...payload,
          status: 'pending',
          createdAt: serverTimestamp(),
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, 'feedback');
      }
    },
    getAll: async () => {
      try {
        const q = query(collection(db, 'feedback'), orderBy('createdAt', 'desc'));
        const querySnapshot = await getDocs(q);
        return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as Feedback[];
      } catch (error) {
        handleFirestoreError(error, OperationType.LIST, 'feedback');
      }
    }
  },
  redeem: {
    getAll: async (userId?: string) => {
      try {
        let q = query(collection(db, 'redeemRequests'), orderBy('createdAt', 'desc'));
        if (userId) {
          q = query(collection(db, 'redeemRequests'), where('userId', '==', userId), orderBy('createdAt', 'desc'));
        }
        const querySnapshot = await getDocs(q);
        return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as RedeemRequest[];
      } catch (error) {
        handleFirestoreError(error, OperationType.LIST, 'redeemRequests');
      }
    },
    create: async (payload: Partial<RedeemRequest>) => {
      try {
        const docRef = await addDoc(collection(db, 'redeemRequests'), {
          ...payload,
          status: 'pending',
          createdAt: serverTimestamp(),
        });
        return { id: docRef.id, ...payload } as RedeemRequest;
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, 'redeemRequests');
      }
    },
    update: async (id: string, data: Partial<RedeemRequest>) => {
      try {
        const docRef = doc(db, 'redeemRequests', id);
        await updateDoc(docRef, data);
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `redeemRequests/${id}`);
      }
    }
  },
  passes: {
    getAll: async (userId?: string) => {
      try {
        let q = query(collection(db, 'digitalPasses'), orderBy('issuedAt', 'desc'));
        if (userId) {
          q = query(collection(db, 'digitalPasses'), where('userId', '==', userId), orderBy('issuedAt', 'desc'));
        }
        const querySnapshot = await getDocs(q);
        return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as unknown as DigitalPass[];
      } catch (error) {
        handleFirestoreError(error, OperationType.LIST, 'digitalPasses');
      }
    },
    getById: async (id: string) => {
      try {
        const docRef = doc(db, 'digitalPasses', id);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          return { id: docSnap.id, ...docSnap.data() } as unknown as DigitalPass;
        }
        return null;
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, `digitalPasses/${id}`);
      }
    },
    use: async (id: string) => {
      try {
        const docRef = doc(db, 'digitalPasses', id);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const current = docSnap.data();
          const newCount = (current.usedCount || 0) + 1;
          const status = newCount >= (current.usageLimit || 1) ? 'used' : 'active';
          await updateDoc(docRef, {
            usedCount: newCount,
            status,
            updatedAt: serverTimestamp()
          });
          return { id, ...current, usedCount: newCount, status } as unknown as DigitalPass;
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `digitalPasses/${id}`);
      }
    },
    create: async (payload: Partial<DigitalPass>) => {
      try {
        const docRef = await addDoc(collection(db, 'digitalPasses'), {
          ...payload,
          status: 'active',
          usedCount: 0,
          issuedAt: serverTimestamp(),
        });
        return { id: docRef.id, ...payload, status: 'active', usedCount: 0 } as unknown as DigitalPass;
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, 'digitalPasses');
      }
    }
  },
  notifications: {
    getAll: async (userId: string) => {
      try {
        const q = query(collection(db, 'notifications'), where('userId', '==', userId), orderBy('createdAt', 'desc'));
        const querySnapshot = await getDocs(q);
        return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as Notification[];
      } catch (error) {
        handleFirestoreError(error, OperationType.LIST, 'notifications');
      }
    },
    markRead: async (id: string) => {
      try {
        await updateDoc(doc(db, 'notifications', id), { read: true });
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `notifications/${id}`);
      }
    },
    create: async (payload: Partial<Notification>) => {
      try {
        await addDoc(collection(db, 'notifications'), {
          ...payload,
          read: false,
          createdAt: serverTimestamp(),
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, 'notifications');
      }
    }
  },
  rewards: {
    getAll: async () => {
      try {
        const querySnapshot = await getDocs(collection(db, 'rewards'));
        return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as unknown as Reward[];
      } catch (error) {
        handleFirestoreError(error, OperationType.LIST, 'rewards');
      }
    },
    create: async (payload: Partial<Reward>) => {
      try {
        const docRef = await addDoc(collection(db, 'rewards'), {
          ...payload,
          createdAt: serverTimestamp(),
        });
        return { id: docRef.id, ...payload } as Reward;
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, 'rewards');
      }
    },
    delete: async (id: string) => {
      try {
        await deleteDoc(doc(db, 'rewards', id));
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, `rewards/${id}`);
      }
    }
  },
  logs: {
    getByTaskId: async (taskId: string) => {
      try {
        const q = query(collection(db, 'taskLogs'), where('taskId', '==', taskId), orderBy('timestamp', 'desc'));
        const querySnapshot = await getDocs(q);
        return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      } catch (error) {
        handleFirestoreError(error, OperationType.LIST, 'taskLogs');
      }
    },
    create: async (payload: any) => {
      try {
        await addDoc(collection(db, 'taskLogs'), {
          ...payload,
          timestamp: serverTimestamp(),
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, 'taskLogs');
      }
    }
  },
  admin: {
    getStats: async () => {
      try {
        const usersSnap = await getDocs(collection(db, 'users'));
        const tasksSnap = await getDocs(collection(db, 'tasks'));
        const feedbackSnap = await getDocs(collection(db, 'feedback'));
        const passesSnap = await getDocs(collection(db, 'digitalPasses'));
        
        const tasks = tasksSnap.docs.map(d => d.data());
        
        return {
          totalUsers: usersSnap.size,
          totalTasks: tasksSnap.size,
          pendingTasks: tasks.filter(t => t.status === 'pending').length,
          receivedFeedback: feedbackSnap.size,
          tasks: tasksSnap.size, // for chart or duplicate expected key
          clean: tasks.filter(t => t.cleanlinessLevel === 'clean').length,
          moderate: tasks.filter(t => t.cleanlinessLevel === 'moderate').length,
          dirty: tasks.filter(t => t.cleanlinessLevel === 'dirty').length,
          approvalRate: tasksSnap.size > 0 ? (tasks.filter(t => t.status === 'approved').length / tasksSnap.size) * 100 : 0,
          activePasses: passesSnap.docs.filter(p => p.data().status === 'active').length,
          usedPasses: passesSnap.docs.filter(p => p.data().status === 'used').length,
          totalRedeemedPoints: 0, // aggregate if needed
        };
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, 'admin/stats');
      }
    }
  }
};
