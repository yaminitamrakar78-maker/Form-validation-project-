import { api } from '../lib/api';

/**
 * Updates a user's daily streak based on task completion.
 */
export const updateUserStreak = async (_userId: string) => {
  try {
    return await api.users.updateStreak();
  } catch (err) {
    console.error("Streak update failed:", err);
    return null;
  }
};

/**
 * Resets streak if user missed a day.
 */
export const checkAndResetStreak = async (_userId: string) => {
  try {
    const response = await api.users.checkStreak();
    return response.reset;
  } catch (err) {
    console.error("Streak check failed:", err);
    return false;
  }
};
