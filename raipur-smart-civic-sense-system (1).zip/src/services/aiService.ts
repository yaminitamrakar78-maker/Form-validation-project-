import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY as string });

export interface AIVerificationResult {
  isClean: boolean;
  confidence: number;
  message: string;
  labels: string[];
  isFake: boolean;
  fakeReason?: string;
  cleanlinessLevel: 'clean' | 'moderate' | 'dirty';
}

export async function verifyCleanliness(base64Image: string): Promise<AIVerificationResult> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [
        {
          parts: [
            { text: `Analyze this image for civic cleanliness and hygiene tasks as part of the "Smart Civic Sense System". 
            
            Target Activities/Objects:
            - Garbage & Litter: Piles of trash, scattered plastic, organic waste.
            - Public Sanitation: Road sweeping, drain cleaning, community cleaning.
            - Maintenance: Public toilets, parks, street furniture cleanliness.

            Evaluation Criteria:
            1. Task Authenticity: Is this a real photo taken on-site (Genuineness Check)?
            2. Fraud Detection: Detect if this is a screenshot, a photo of a digital screen, a stock image from the web, or a digitally manipulated image.
            3. Progress: Is the area clean? Rate the cleanliness level.

            Return a RAW JSON object with:
            - 'isClean' (boolean): true if the area looks maintained and the civic task appears fulfilled.
            - 'confidence' (number 0-1): your certainty in the analysis.
            - 'message' (string): detail what you see related to cleanliness (be specific like "Clear evidence of road sweeping" or "Significant plastic litter detected").
            - 'labels' (string array): 3-5 tags (e.g., "Road Sweeping", "Waste Management", "Public Park").
            - 'isFake' (boolean): true if the image is likely a screenshot, stock photo, or non-genuine.
            - 'fakeReason' (string): detailed technical reason if 'isFake' is true (e.g., "Moiré patterns typical of photographing a computer screen detected").
            - 'cleanlinessLevel' (string): 'clean' | 'moderate' | 'dirty'.
            ` },
            { inlineData: { mimeType: "image/jpeg", data: base64Image.split(',')[1] } }
          ]
        }
      ],
      config: {
        responseMimeType: "application/json"
      }
    });

    const result = JSON.parse(response.text);
    return {
      isClean: result.isClean,
      confidence: result.confidence,
      message: result.message,
      labels: result.labels || [],
      isFake: result.isFake || false,
      fakeReason: result.fakeReason,
      cleanlinessLevel: result.cleanlinessLevel || 'clean'
    };
  } catch (error) {
    console.error("AI Verification failed", error);
    throw new Error("AI verification service is currently unavailable.");
  }
}
