import React, { useState, useEffect } from 'react';
import { api } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import { DEFAULT_DAILY_HABITS } from '../constants';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Shield, Sprout, Shirt, Brush, Recycle, 
  Trash2, Droplets, Zap, Trees, Ban, 
  CheckCircle2, Sparkles, Trophy, X, Camera, MapPin, Loader2
} from 'lucide-react';
import { cn, compressImage } from '../lib/utils';
import { verifyCleanliness } from '../services/aiService';
import { toast } from 'sonner';
import { format } from 'date-fns';

const ICON_MAP: Record<string, React.ReactNode> = {
  Shield: <Shield size={20} />,
  Sprout: <Sprout size={20} />,
  Shirt: <Shirt size={20} />,
  Brush: <Brush size={20} />,
  Recycle: <Recycle size={20} />,
  Trash2: <Trash2 size={20} />,
  Droplets: <Droplets size={20} />,
  Zap: <Zap size={20} />,
  Trees: <Trees size={20} />,
  Ban: <Ban size={20} />,
};

interface SubmitModalProps {
  habit: typeof DEFAULT_DAILY_HABITS[0];
  onClose: () => void;
  onSuccess: () => void;
}

const SubmissionModal: React.FC<SubmitModalProps> = ({ habit, onClose, onSuccess }) => {
  const { user } = useAuth();
  const [file, setFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [location, setLocation] = useState<{lat: number, lng: number} | null>(null);
  const [fetchingLocation, setFetchingLocation] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  useEffect(() => {
    handleGetLocation();
  }, []);

  const handleGetLocation = () => {
    setFetchingLocation(true);
    if (!navigator.geolocation) {
      toast.error("Geolocation is not supported");
      setFetchingLocation(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        setLocation({
          lat: position.coords.latitude,
          lng: position.coords.longitude
        });
        setFetchingLocation(false);
      },
      (error) => {
        console.error("Location error:", error);
        toast.error("Geolocation failed. Location is required for verification.");
        setFetchingLocation(false);
      }
    );
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      toast.error("Image too large. Please use an image under 5MB.");
      return;
    }

    setFile(file);
    const reader = new FileReader();
    reader.onloadend = () => {
      setImagePreview(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async () => {
    if (submitting || verifying || showSuccess) return;
    if (!user) return;
    
    if (!file || !location) {
      toast.error("Please upload image and allow location access");
      return;
    }

    setSubmitting(true);
    try {
      // 1. Upload Image
      const { url: imageUrl } = await api.upload(file);

      // 2. Fetch System Settings
      const config = await api.admin.getSettings();

      let initialStatus = "pending";
      let aiResult = null;

      // 3. AI Verification if enabled
      if (config.autoApproveHabits && imagePreview) {
        setVerifying(true);
        try {
          const result = await verifyCleanliness(imagePreview);
          aiResult = result;
          if (!result.isFake && result.confidence >= config.aiConfidenceThreshold) {
            initialStatus = "approved";
          }
        } catch (err) {
          console.error("AI verify failed:", err);
        } finally {
          setVerifying(false);
        }
      }

      await api.habits.submit({
        taskTitle: habit.title,
        points: habit.points,
        imageUrl,
        location,
        status: initialStatus,
        type: "daily"
      });

      // If auto-approved, the backend would ideally handle points, but for now I'll just show success
      // In my server.ts, POST /habits doesn't automatically award points yet unless I use the /habits/:id/approve endpoint.
      // I can either have the backend do it in POST /habits if status is approved, or call the approve endpoint here if initialStatus is approved.
      // I'll call the approve endpoint if it's auto-approved.
      // Wait, I need the ID.

      setShowSuccess(true);
      setTimeout(() => {
        onSuccess();
      }, 2500);

    } catch (error: any) {
      console.error("Error:", error);
      toast.error(error.message || 'Submission failed');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-white w-full max-w-lg rounded-3xl overflow-hidden shadow-2xl"
      >
        <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-green-100 text-green-600 flex items-center justify-center">
              {ICON_MAP[habit.icon]}
            </div>
            <div>
              <h3 className="font-black text-gray-800 uppercase tracking-tight">{habit.title}</h3>
              <p className="text-[10px] font-black text-yellow-600 uppercase tracking-widest leading-none">Award: {habit.points} Points</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-gray-200 rounded-full transition-colors">
            <X size={20} className="text-gray-400" />
          </button>
        </div>

        <div className="p-8 space-y-6">
          <AnimatePresence mode="wait">
            {showSuccess ? (
              <motion.div 
                key="success"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex flex-col items-center justify-center py-12 text-center"
              >
                <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center text-green-600 mb-6 shadow-inner">
                  <CheckCircle2 size={48} className="animate-bounce" />
                </div>
                <h3 className="text-2xl font-black text-[#111827] uppercase tracking-tight mb-2">Success!</h3>
                <p className="text-gray-500 font-bold max-w-[240px] leading-relaxed">
                  Task submitted successfully for admin verification.
                </p>
                <div className="mt-8 flex items-center gap-2 px-4 py-2 bg-green-50 rounded-xl border border-green-100">
                  <Sparkles size={14} className="text-green-600" />
                  <span className="text-[10px] font-black text-green-700 uppercase tracking-widest">Rewards Pending</span>
                </div>
              </motion.div>
            ) : (
              <motion.div key="form" className="space-y-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Photo Proof</label>
                  <div 
                    onClick={() => !submitting && !verifying && fileInputRef.current?.click()}
                    className={cn(
                      "w-full aspect-video rounded-2xl border-2 border-dashed flex flex-col items-center justify-center cursor-pointer transition-all overflow-hidden relative group",
                      imagePreview ? "border-green-500" : "border-gray-200 hover:border-green-300 hover:bg-green-50"
                    )}
                  >
                    {imagePreview ? (
                      <>
                        <img src={imagePreview} alt="Preview" className="w-full h-full object-cover" />
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                          <span className="text-white text-xs font-bold flex items-center gap-2">
                            <Camera size={16} /> Retake
                          </span>
                        </div>
                      </>
                    ) : (
                      <div className="text-center p-6">
                        <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4 text-gray-400 group-hover:text-green-500 transition-colors">
                          <Camera size={32} />
                        </div>
                        <p className="text-sm font-bold text-gray-600">Open Camera / Picker</p>
                        <p className="text-[10px] text-gray-400 mt-1 uppercase tracking-widest font-black">Proof required for rewards</p>
                      </div>
                    )}
                  </div>
                  <input 
                    type="file" 
                    ref={fileInputRef}
                    onChange={handleFileChange}
                    accept="image/*"
                    capture="environment"
                    className="hidden"
                  />
                </div>

                <div className="bg-gray-50 p-4 rounded-2xl flex items-center justify-between border border-gray-100">
                  <div className="flex items-center gap-3">
                    <div className={cn(
                      "w-10 h-10 rounded-xl flex items-center justify-center",
                      location ? "bg-green-100 text-green-600" : "bg-blue-100 text-blue-600"
                    )}>
                      {fetchingLocation ? <Loader2 size={20} className="animate-spin" /> : <MapPin size={20} />}
                    </div>
                    <div>
                      <p className="text-xs font-black text-gray-800 uppercase tracking-tight">
                        {fetchingLocation ? "Detecting Location..." : location ? "📍 Location Captured" : "Location Required"}
                      </p>
                      <p className="text-[10px] font-bold text-gray-400">
                        {location ? `${location.lat.toFixed(6)}, ${location.lng.toFixed(6)}` : "Please enable GPS access"}
                      </p>
                    </div>
                  </div>
                  {!location && !fetchingLocation && (
                    <button 
                      onClick={handleGetLocation}
                      className="text-[10px] font-black text-blue-600 uppercase tracking-widest hover:underline"
                    >
                      Retry
                    </button>
                  )}
                </div>

                <button
                  disabled={submitting || verifying || !file || !location}
                  onClick={handleSubmit}
                  className={cn(
                    "w-full py-5 rounded-2xl flex items-center justify-center gap-3 transition-all shadow-xl",
                    (submitting || verifying || !file || !location)
                      ? "bg-gray-100 text-gray-400 cursor-not-allowed" 
                      : "bg-[#111827] text-white hover:bg-green-600 active:scale-95"
                  )}
                >
                  {submitting || verifying ? (
                    <>
                      <Loader2 size={20} className="animate-spin" />
                      <span className="font-black uppercase tracking-widest">
                        {verifying ? "AI Processing..." : "Submitting..."}
                      </span>
                    </>
                  ) : (
                    <>
                      <Sparkles size={20} />
                      <span className="font-black uppercase tracking-widest">Submit for Review</span>
                    </>
                  )}
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
};

export const DailyHabitSection: React.FC = () => {
  const { user } = useAuth();
  const [submissions, setSubmissions] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [selectedHabit, setSelectedHabit] = useState<typeof DEFAULT_DAILY_HABITS[0] | null>(null);

  const today = format(new Date(), 'yyyy-MM-dd');

  const fetchDailySubmissions = async () => {
    if (!user) return;

    try {
      const allSubmissions = await api.habits.getAll(user.uid);
      const statusMap: Record<string, string> = {};
      
      allSubmissions.forEach((sub: any) => {
        const subDate = format(new Date(sub.createdAt), 'yyyy-MM-dd');
        if (subDate === today && sub.type === 'daily') {
          // In MERN, we don't have the same composite ID, but we can match by title or habit ID if we stored it.
          // Since we submission by title in SubmissionModal, we match by title here.
          const habit = DEFAULT_DAILY_HABITS.find(h => h.title === sub.taskTitle);
          if (habit) {
            statusMap[habit.id] = sub.status;
          }
        }
      });
      
      setSubmissions(statusMap);
    } catch (err: any) {
      console.error("Fetch habits failed:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDailySubmissions();
  }, [user, today]);

  const handleSuccess = () => {
    setSelectedHabit(null);
    fetchDailySubmissions();
  };

  const completedCount = Object.keys(submissions).length;
  const progress = (completedCount / DEFAULT_DAILY_HABITS.length) * 100;

  if (loading) return <div className="h-48 flex items-center justify-center text-xs font-black uppercase tracking-widest text-gray-300">Syncing Habits...</div>;

  return (
    <>
      <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="p-6 bg-gradient-to-br from-green-500 to-emerald-600 text-white">
          <div className="flex justify-between items-center mb-4">
            <div>
              <h2 className="text-xl font-black tracking-tight">Daily Civic Habits</h2>
              <p className="text-green-50 text-sm font-medium">Complete tasks to earn community rewards</p>
            </div>
            <div className="bg-white/20 p-3 rounded-2xl backdrop-blur-md">
              <Trophy size={24} />
            </div>
          </div>
          
          <div className="bg-white/10 rounded-2xl p-4 backdrop-blur-md">
            <div className="flex justify-between text-xs font-black uppercase tracking-widest mb-2">
              <span>Goal Progress</span>
              <span>{Math.round(progress)}%</span>
            </div>
            <div className="h-2 bg-black/10 rounded-full overflow-hidden">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                className="h-full bg-white shadow-[0_0_10px_rgba(255,255,255,0.5)]"
              />
            </div>
          </div>
        </div>

        <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
          {DEFAULT_DAILY_HABITS.map((habit) => {
            const status = submissions[habit.id];
            const isDone = !!status;

            return (
              <motion.button
                key={habit.id}
                whileHover={!isDone ? { scale: 1.02, y: -2 } : {}}
                whileTap={!isDone ? { scale: 0.98 } : {}}
                onClick={() => setSelectedHabit(habit)}
                disabled={isDone}
                className={cn(
                  "flex items-center gap-4 p-4 rounded-2xl border transition-all text-left group",
                  isDone 
                    ? "bg-green-50 border-green-100 opacity-75 cursor-default" 
                    : "bg-white border-gray-100 hover:border-green-200 hover:shadow-md cursor-pointer"
                )}
              >
                <div className={cn(
                  "w-12 h-12 rounded-xl flex items-center justify-center transition-colors",
                  isDone 
                    ? "bg-green-500 text-white" 
                    : "bg-gray-50 text-gray-500 group-hover:bg-green-100 group-hover:text-green-600"
                )}>
                  {isDone ? <CheckCircle2 size={24} /> : ICON_MAP[habit.icon]}
                </div>
                
                <div className="flex-1">
                  <p className={cn(
                    "font-bold text-sm leading-tight mb-1",
                    isDone ? "text-green-800 line-through" : "text-gray-800"
                  )}>
                    {habit.title}
                  </p>
                  <div className="flex items-center gap-2">
                    <span className={cn(
                      "text-[10px] font-black uppercase tracking-widest",
                      isDone ? "text-green-600" : "text-yellow-600"
                    )}>
                      +{habit.points} Points
                    </span>
                    {status && (
                      <span className="text-[10px] text-green-500 font-bold italic">• {status.toUpperCase()}</span>
                    )}
                  </div>
                </div>

                {!isDone && (
                  <div className="w-6 h-6 rounded-full border-2 border-gray-200 group-hover:border-green-500 transition-colors flex items-center justify-center">
                    <div className="w-2 h-2 rounded-full bg-green-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                )}
              </motion.button>
            );
          })}
        </div>
      </div>

      <AnimatePresence>
        {selectedHabit && (
          <SubmissionModal 
            habit={selectedHabit} 
            onClose={() => setSelectedHabit(null)} 
            onSuccess={handleSuccess}
          />
        )}
      </AnimatePresence>
    </>
  );
};

