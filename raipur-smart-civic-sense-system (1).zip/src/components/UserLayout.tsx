import React, { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { LayoutDashboard, ClipboardList, Bell, Gift, MessageSquare, LogOut, User as UserIcon, Info, Trophy, ShieldCheck, Ticket } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';
import { NotificationCenter } from './NotificationCenter';
import { toast } from 'sonner';
import raipurLogo from "@/assets/raipur-logo.png";

export const UserLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [logoError, setLogoError] = useState(false);
  const { profile, signOut } = useAuth();
  const navigate = useNavigate();
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  const navItems = [
    { to: '/user/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
    { to: '/user/tasks', icon: ClipboardList, label: 'My Tasks' },
    { to: '/user/notices', icon: Bell, label: 'Notices' },
    { to: '/user/rewards', icon: Gift, label: 'Rewards' },
    { to: '/user/passes', icon: Ticket, label: 'My Passes' },
    { to: '/user/feedback', icon: MessageSquare, label: 'Feedback' },
    { to: '/user/leaderboard', icon: Trophy, label: 'Leaderboard' },
    { to: '/user/profile', icon: UserIcon, label: 'My Profile' },
    { to: '/user/about', icon: Info, label: 'About & Help' },
  ];

  const handleSignOut = async () => {
    try {
      await signOut();
      toast.success("Logged out successfully");
      navigate('/login');
    } catch (error) {
      toast.error("Failed to logout");
    }
  };

  return (
    <div className="min-h-screen bg-[#F8F9FA] flex flex-col">
      {/* Official Top Strip */}
      <div className="bg-[#0f172a] text-white py-1.5 px-6 flex justify-between items-center text-[9px] font-black uppercase tracking-[0.2em] border-b border-white/5 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-orange-500/10 via-transparent to-green-500/10" />
        <div className="relative z-10">Raipur Municipal Corporation | Smart City Digital Portal</div>
        <div className="relative z-10 hidden sm:block">Official Personnel Access</div>
      </div>

      <div className="flex flex-col md:flex-row flex-1">
        {/* Logout Confirmation Dialog */}
      <AnimatePresence>
        {showLogoutConfirm && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white rounded-[2rem] w-full max-w-md overflow-hidden shadow-2xl"
            >
              <div className="p-8 text-center">
                <div className="w-16 h-16 rounded-2xl bg-rose-50 flex items-center justify-center text-rose-500 mx-auto mb-6">
                  <LogOut size={32} />
                </div>
                <h3 className="text-2xl font-black text-[#111827] mb-2 tracking-tight">Sign Out</h3>
                <p className="text-gray-500 font-medium mb-8">Are you sure you want to end your session? You will need to log in again to access your tasks.</p>
                
                <div className="flex gap-4">
                  <button
                    onClick={() => setShowLogoutConfirm(false)}
                    className="flex-1 px-6 py-4 rounded-xl border border-gray-100 font-bold text-gray-500 hover:bg-gray-50 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSignOut}
                    className="flex-1 px-6 py-4 rounded-xl bg-gradient-to-r from-rose-500 to-rose-600 text-white font-black uppercase tracking-widest text-[10px] shadow-lg shadow-rose-500/20 hover:shadow-rose-500/30 transition-all active:scale-95"
                  >
                    Confirm Logout
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Sidebar for Desktop */}
      <aside className="hidden md:flex flex-col w-64 bg-[#0f172a] text-white h-full sticky top-0 border-r border-white/5">
        <div className="p-6 border-b border-white/5">
          <div className="flex items-center gap-3">
            {!logoError ? (
              <img 
                src={raipurLogo} 
                alt="Raipur Municipal Corporation Logo" 
                className="w-10 h-10 object-contain rounded-full shadow-lg border-2 border-white/10 p-0.5 bg-white" 
                onError={() => setLogoError(true)}
              />
            ) : (
              <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center text-orange-600 font-bold text-[10px] shadow-lg border-2 border-white/10">RMC</div>
            )}
            <div className="flex flex-col">
              <span className="text-sm font-black text-white leading-tight uppercase tracking-tight">Raipur Municipal Corporation</span>
              <span className="text-[10px] font-bold text-orange-400 uppercase tracking-widest mt-1">Smart Civic Sense System</span>
            </div>
          </div>
        </div>
        <nav className="flex-1 px-4 py-8 space-y-2">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                cn(
                  "flex items-center gap-3 px-4 py-3.5 rounded-xl transition-all duration-200 group",
                  isActive 
                    ? "bg-green-500 text-white font-bold shadow-lg shadow-green-500/20" 
                    : "text-gray-400 hover:text-white hover:bg-white/5"
                )
              }
            >
              {({ isActive }) => (
                <>
                  <item.icon size={20} className={cn("transition-colors", isActive ? "text-white" : "group-hover:text-green-400")} />
                  {item.label}
                </>
              )}
            </NavLink>
          ))}
        </nav>
        <div className="p-4 mt-auto">
          <div className="flex items-center gap-3 px-4 py-4 rounded-2xl bg-white/5 border border-white/5">
            <div className="w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center text-green-400 overflow-hidden shrink-0">
               {profile?.photoUrl ? (
                 <img src={profile.photoUrl} alt={profile.name} className="w-full h-full object-cover" />
               ) : (
                 <UserIcon size={20} />
               )}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold text-white truncate">{profile?.name || 'Citizen'}</p>
              <p className="text-[10px] text-gray-500 truncate uppercase font-black tracking-widest">{profile?.role || 'User'}</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Mobile Navbar */}
      <div className="md:hidden bg-[#111827] text-white p-4 sticky top-0 z-50">
        <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              {!logoError ? (
                <img 
                  src={raipurLogo} 
                  alt="Raipur Municipal Corporation Logo" 
                  className="w-10 h-10 object-contain rounded-full bg-white p-0.5" 
                  onError={() => setLogoError(true)}
                />
              ) : (
                <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center text-orange-600 font-bold text-[10px]">RMC</div>
              )}
              <div className="flex flex-col">
                <span className="text-xs font-black text-white leading-tight uppercase tracking-tighter">Raipur Municipal Corp</span>
                <span className="text-[8px] font-bold text-orange-400 uppercase tracking-widest mt-0.5">Smart Civic Sense</span>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <NotificationCenter />
              <button 
                onClick={() => setShowLogoutConfirm(true)}
                className="w-10 h-10 rounded-xl bg-rose-500/10 flex items-center justify-center text-rose-500 active:scale-95 transition-all"
              >
                <LogOut size={20} />
              </button>
            </div>
        </div>
        <div className="flex items-center justify-around mt-4 pt-2 border-t border-white/5 overflow-x-auto no-scrollbar gap-4">
            {navItems.map((item) => (
                <NavLink
                    key={item.to}
                    to={item.to}
                    className={({ isActive }) =>
                        cn(
                            "flex flex-col items-center gap-1 min-w-[60px]",
                            isActive ? "text-green-400 font-bold" : "text-gray-500"
                        )
                    }
                >
                    <item.icon size={20} />
                    <span className="text-[10px] font-black uppercase tracking-widest">{item.label}</span>
                </NavLink>
            ))}
        </div>
      </div>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col min-h-screen">
        <header className="h-20 bg-white border-b border-[#E5E7EB] sticky top-0 z-40 hidden md:flex items-center justify-between px-8">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center text-blue-500">
                <ShieldCheck size={20} />
              </div>
              <div className="flex flex-col">
                  <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest leading-none mb-1">Authenticated User</span>
                  <span className="text-sm font-black text-[#111827]">{profile?.name}</span>
              </div>
            </div>
            
            <div className="flex items-center gap-6">
              <NotificationCenter />
              <div className="h-8 w-[1px] bg-gray-100"></div>
              <button
                onClick={() => setShowLogoutConfirm(true)}
                className="flex items-center gap-3 px-5 py-2.5 rounded-xl bg-rose-50 text-rose-600 font-bold text-xs hover:bg-rose-100 transition-all active:scale-95 group"
              >
                <LogOut size={16} className="group-hover:rotate-12 transition-transform" />
                Sign Out
              </button>
            </div>
        </header>

        <div className="flex-1 p-4 md:p-8 overflow-y-auto">
          <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            {children}
          </motion.div>
        </div>
      </div>
    </main>
    </div>
    </div>
  );
};
