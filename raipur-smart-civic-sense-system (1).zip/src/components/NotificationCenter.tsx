import React, { useState, useEffect } from 'react';
import { api } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import { Notification } from '../types';
import { Bell, BellOff, Check, Trash2, X, AlertCircle, Info, Sparkles, Clock } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';
import { format } from 'date-fns';

export const NotificationCenter: React.FC = () => {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);

  const fetchNotifications = async () => {
    if (!user) return;

    try {
      const data = await api.notifications.getAll();
      setNotifications(data);
      setUnreadCount(data.filter((n: any) => !n.read).length);
    } catch (error) {
      console.error("Error fetching notifications:", error);
    }
  };

  useEffect(() => {
    fetchNotifications();
    // Poll for notifications every 30 seconds
    const interval = setInterval(fetchNotifications, 30000);
    return () => clearInterval(interval);
  }, [user]);

  const markAsRead = async (notificationId: string) => {
    try {
      await api.notifications.markRead(notificationId);
      setNotifications(prev => prev.map(n => 
        ((n as any)._id === notificationId || n.id === notificationId) ? { ...n, read: true } : n
      ));
      setUnreadCount(prev => Math.max(0, prev - 1));
    } catch (error) {
      console.error("Error marking as read:", error);
    }
  };

  const markAllAsRead = async () => {
    try {
      const unread = notifications.filter(n => !n.read);
      await Promise.all(unread.map(n => api.notifications.markRead((n as any)._id || n.id)));
      setNotifications(prev => prev.map(n => ({ ...n, read: true })));
      setUnreadCount(0);
    } catch (error) {
      console.error("Error marking all as read:", error);
    }
  };

  const clearAll = async () => {
    try {
      await Promise.all(notifications.map(n => api.notifications.delete((n as any)._id || n.id)));
      setNotifications([]);
      setUnreadCount(0);
      setIsOpen(false);
    } catch (error) {
      console.error("Error clearing notifications:", error);
    }
  };

  const getIcon = (type: Notification['type']) => {
    switch (type) {
      case 'assignment': return <Clock className="text-blue-500" size={16} />;
      case 'approval':
      case 'reward': return <Sparkles className="text-green-500" size={16} />;
      case 'rejection': return <AlertCircle className="text-rose-500" size={16} />;
      default: return <Info className="text-gray-500" size={16} />;
    }
  };

  return (
    <div className="relative">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="relative p-2 rounded-xl text-gray-400 hover:text-green-600 hover:bg-green-50 transition-all active:scale-95"
      >
        <Bell size={20} />
        {unreadCount > 0 && (
          <span className="absolute top-1.5 right-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-rose-500 text-[10px] font-black text-white ring-2 ring-white animate-soft-bounce">
            {unreadCount}
          </span>
        )}
      </button>

      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpen(false)}
              className="fixed inset-0 z-40 bg-black/5"
            />
            <motion.div
              initial={{ opacity: 0, y: 10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 10, scale: 0.95 }}
              className="absolute right-0 mt-4 w-80 md:w-96 bg-white rounded-3xl shadow-2xl shadow-gray-200 border border-gray-100 z-50 overflow-hidden"
            >
              <div className="p-6 border-b border-gray-50 flex items-center justify-between bg-gray-50/50">
                <div>
                    <h3 className="text-sm font-black text-gray-900 uppercase tracking-widest">Notification Flow</h3>
                    <p className="text-[10px] font-bold text-gray-400 uppercase mt-0.5">Municipal updates & Alerts</p>
                </div>
                <div className="flex gap-2">
                    {unreadCount > 0 && (
                        <button 
                            onClick={markAllAsRead}
                            className="p-1.5 rounded-lg text-gray-400 hover:text-green-600 hover:bg-green-50 transition-all group"
                            title="Mark all as read"
                        >
                            <Check size={16} />
                        </button>
                    )}
                    <button 
                        onClick={clearAll}
                        className="p-1.5 rounded-lg text-gray-400 hover:text-rose-600 hover:bg-rose-50 transition-all group"
                        title="Clear all"
                    >
                        <Trash2 size={16} />
                    </button>
                </div>
              </div>

              <div className="max-h-[400px] overflow-y-auto no-scrollbar py-2">
                {notifications.length === 0 ? (
                  <div className="p-12 text-center flex flex-col items-center gap-3">
                    <div className="w-12 h-12 bg-gray-50 rounded-2xl flex items-center justify-center text-gray-300">
                        <BellOff size={24} />
                    </div>
                    <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Comm line clear</p>
                  </div>
                ) : (
                  notifications.map((n) => (
                    <div 
                      key={(n as any)._id || n.id}
                      onClick={() => !n.read && markAsRead((n as any)._id || n.id)}
                      className={cn(
                        "px-6 py-4 flex gap-4 transition-all cursor-pointer border-l-4",
                        n.read ? "border-transparent opacity-60" : "border-green-500 bg-green-50/10"
                      )}
                    >
                      <div className="mt-1">
                        <div className="w-8 h-8 rounded-xl bg-white border border-gray-100 shadow-sm flex items-center justify-center">
                            {getIcon(n.type)}
                        </div>
                      </div>
                      <div className="flex-1 space-y-1">
                        <p className="text-xs font-black text-gray-900 group-hover:text-green-600 transition-colors uppercase leading-tight">{n.title}</p>
                        <p className="text-[11px] font-medium text-gray-500 leading-relaxed">{n.message}</p>
                        <p className="text-[9px] font-bold text-gray-400 uppercase tracking-tighter mt-2">{format(new Date(n.createdAt), 'MMM dd, HH:mm')}</p>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {notifications.length > 0 && (
                <div className="p-4 bg-gray-50/50 border-t border-gray-50">
                    <button 
                        onClick={() => setIsOpen(false)}
                        className="w-full py-2.5 rounded-xl bg-white border border-gray-200 text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] hover:bg-gray-100 transition-all"
                    >
                        Close Portal
                    </button>
                </div>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
};
