import React, { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Users, 
  ClipboardCheck, 
  BellRing, 
  MessageSquare, 
  LogOut, 
  ShieldCheck,
  Award,
  Info,
  Trophy,
  Activity,
  AlertTriangle,
  X
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';
import { AdminNotificationCenter } from './AdminNotificationCenter';
import { toast } from 'sonner';
import raipurLogo from "@/assets/raipur-logo.png";

export const AdminLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [logoError, setLogoError] = useState(false);
  const { profile, signOut } = useAuth();
  const navigate = useNavigate();
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navItems = [
    { to: '/admin/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
    { to: '/admin/users', icon: Users, label: 'User Management' },
    { to: '/admin/tasks', icon: ClipboardCheck, label: 'Task Management' },
    { to: '/admin/notices', icon: BellRing, label: 'Notices' },
    { to: '/admin/rewards', icon: Award, label: 'Redeem Requests' },
    { to: '/admin/scanner', icon: ShieldCheck, label: 'Pass Verification' },
    { to: '/admin/feedback', icon: MessageSquare, label: 'Feedback' },
    { to: '/admin/analytics', icon: Activity, label: 'Civic Analytics' },
    { to: '/admin/leaderboard', icon: Trophy, label: 'Leaderboard' },
    { to: '/admin/about', icon: Info, label: 'About & Help' },
  ];

  const handleSignOut = async () => {
    try {
      await signOut();
      toast.success("Logged out successfully");
      navigate('/login');
    } catch (error) {
      toast.error("Failed to logout");
    }
  };

  return (
    <div className="min-h-screen bg-[#F9FAFB] flex flex-col">
      {/* Official Top Strip */}
      <div className="bg-[#111827] text-white py-1.5 px-6 flex justify-between items-center text-[9px] font-black uppercase tracking-[0.2em] border-b border-white/5 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-orange-500/10 via-transparent to-green-500/10" />
        <div className="relative z-10">Raipur Municipal Corporation | Smart City Administrative Portal</div>
        <div className="relative z-10 hidden sm:block">Swachh Raipur Mission Control</div>
      </div>

      <div className="flex flex-col md:flex-row flex-1">
        {/* Logout Confirmation Dialog */}
      <AnimatePresence>
        {showLogoutConfirm && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white rounded-[2rem] w-full max-w-md overflow-hidden shadow-2xl"
            >
              <div className="p-8 text-center">
                <div className="w-16 h-16 rounded-2xl bg-rose-50 flex items-center justify-center text-rose-500 mx-auto mb-6">
                  <LogOut size={32} />
                </div>
                <h3 className="text-2xl font-black text-[#111827] mb-2 tracking-tight">Confirm Logout</h3>
                <p className="text-gray-500 font-medium mb-8">Are you sure you want to exit the administrative session? All unsaved changes will be lost.</p>
                
                <div className="flex gap-4">
                  <button
                    onClick={() => setShowLogoutConfirm(false)}
                    className="flex-1 px-6 py-4 rounded-xl border border-gray-100 font-bold text-gray-500 hover:bg-gray-50 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSignOut}
                    className="flex-1 px-6 py-4 rounded-xl bg-gradient-to-r from-rose-500 to-rose-600 text-white font-black uppercase tracking-widest text-[10px] shadow-lg shadow-rose-500/20 hover:shadow-rose-500/30 transition-all active:scale-95"
                  >
                    Yes, Logout
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMobileMenuOpen(false)}
              className="fixed inset-0 bg-[#111827]/80 backdrop-blur-md z-[60] md:hidden"
            />
            <motion.div 
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed left-0 top-0 bottom-0 w-[80%] bg-[#111827] z-[70] md:hidden flex flex-col border-r border-white/5"
            >
              <div className="p-8 border-b border-white/5 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <img src={raipurLogo} alt="" className="w-10 h-10 bg-white p-1 rounded-xl" />
                  <span className="text-sm font-black text-white uppercase tracking-tighter">RMC Panel</span>
                </div>
                <button 
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-gray-400"
                >
                  <X size={20} />
                </button>
              </div>
              <nav className="flex-1 px-4 py-8 space-y-1 overflow-y-auto">
                {navItems.map((item) => (
                  <NavLink
                    key={item.to}
                    to={item.to}
                    onClick={() => setIsMobileMenuOpen(false)}
                    className={({ isActive }) =>
                      cn(
                        "flex items-center gap-4 px-6 py-4 rounded-2xl transition-all duration-200",
                        isActive 
                          ? "bg-green-500 text-white font-bold shadow-lg" 
                          : "text-gray-400 hover:text-white"
                      )
                    }
                  >
                    <item.icon size={20} />
                    {item.label}
                  </NavLink>
                ))}
              </nav>
              <div className="p-6 border-t border-white/5">
                 <button
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    setShowLogoutConfirm(true);
                  }}
                  className="w-full flex items-center gap-4 px-6 py-4 rounded-2xl text-rose-400 font-bold"
                 >
                   <LogOut size={20} />
                   Terminte Session
                 </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Sidebar for Desktop */}
      <aside className="hidden md:flex flex-col w-72 bg-[#111827] text-white h-full sticky top-0 border-r border-white/5">
        <div className="p-8 border-b border-white/5">
          <div className="flex items-center gap-4">
            {!logoError ? (
              <img 
                src={raipurLogo} 
                alt="Raipur Municipal Corporation Logo" 
                className="w-12 h-12 object-contain rounded-full shadow-lg border-2 border-white/10 p-0.5 bg-white" 
                onError={() => setLogoError(true)}
              />
            ) : (
              <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center text-orange-600 font-bold text-xs shadow-lg border-2 border-white/10">RMC</div>
            )}
            <div className="flex flex-col">
              <span className="text-sm md:text-base font-black text-white leading-tight uppercase tracking-tight">Raipur Municipal Corporation</span>
              <span className="text-[10px] font-bold text-orange-400 uppercase tracking-widest leading-none mt-1">Smart Civic Sense System</span>
            </div>
          </div>
        </div>

        <nav className="flex-1 px-4 py-4 space-y-1">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                cn(
                  "flex items-center gap-3 px-4 py-3.5 rounded-xl transition-all duration-200 group",
                  isActive 
                    ? "bg-green-500 text-white font-bold shadow-lg shadow-green-500/10" 
                    : "text-gray-400 hover:text-white hover:bg-white/5"
                )
              }
            >
              {({ isActive }) => (
                <>
                  <item.icon size={20} className={cn("transition-colors", isActive ? "text-white" : "group-hover:text-green-400")} />
                  {item.label}
                </>
              )}
            </NavLink>
          ))}
        </nav>

        <div className="p-6 mt-auto">
          <div className="flex items-center gap-4 px-4 py-4 mb-4 rounded-2xl bg-white/5 border border-white/5">
            <div className="w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center text-green-400 overflow-hidden">
               {profile?.photoUrl ? (
                 <img src={profile.photoUrl} alt={profile.name} className="w-full h-full object-cover" />
               ) : (
                 <ShieldCheck size={20} />
               )}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold text-white truncate">{profile?.name}</p>
              <p className="text-[10px] text-gray-500 uppercase tracking-widest font-black">Super Admin</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Mobile Header */}
      <div className="md:hidden bg-[#111827] text-white p-5 sticky top-0 z-50 shadow-lg">
        <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
                <button 
                  onClick={() => setIsMobileMenuOpen(true)}
                  className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-gray-400"
                >
                  <Activity size={20} />
                </button>
                {!logoError ? (
                  <img 
                    src={raipurLogo} 
                    alt="Raipur Municipal Corporation Logo" 
                    className="w-8 h-8 object-contain rounded-full bg-white p-0.5" 
                    onError={() => setLogoError(true)}
                  />
                ) : (
                  <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center text-orange-600 font-bold text-[8px]">RMC</div>
                )}
                <div className="flex flex-col">
                  <span className="text-[10px] font-black text-white leading-tight uppercase tracking-tighter">Raipur Municipal Corp</span>
                </div>
            </div>
            <div className="flex items-center gap-3">
              <AdminNotificationCenter />
              <button 
                onClick={() => setShowLogoutConfirm(true)}
                className="w-10 h-10 rounded-xl bg-rose-500/10 flex items-center justify-center text-rose-500 active:scale-95 transition-all"
              >
                <LogOut size={20} />
              </button>
            </div>
        </div>
      </div>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col min-h-screen">
        <header className="h-24 bg-white border-b border-gray-100 sticky top-0 z-40 hidden md:flex items-center justify-between px-10">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-gray-50 flex items-center justify-center text-gray-400 border border-gray-100">
                <ShieldCheck size={24} />
              </div>
              <div className="flex flex-col">
                  <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest leading-none mb-1">Administrative Sector</span>
                  <span className="text-base font-black text-[#111827]">{profile?.name}</span>
              </div>
            </div>

            <div className="flex items-center gap-6">
              <AdminNotificationCenter />
              <div className="h-10 w-[1px] bg-gray-100"></div>
              <button
                onClick={() => setShowLogoutConfirm(true)}
                className="flex items-center gap-3 px-6 py-3 rounded-2xl bg-gradient-to-r from-rose-500 to-rose-600 text-white font-black uppercase tracking-widest text-[10px] shadow-lg shadow-rose-500/20 hover:shadow-rose-500/30 transition-all hover:-translate-y-0.5 active:translate-y-0 group"
              >
                <LogOut size={16} className="group-hover:rotate-12 transition-transform" />
                Sign Out System
              </button>
            </div>
        </header>

        <div className="flex-1 p-6 md:p-10 overflow-y-auto">
          <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, ease: "easeOut" }}
          >
            {children}
          </motion.div>
        </div>
      </div>
    </main>
    </div>
    </div>
  );
};
