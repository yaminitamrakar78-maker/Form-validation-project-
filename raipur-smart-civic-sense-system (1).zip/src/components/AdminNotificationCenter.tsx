import React, { useState, useEffect } from 'react';
import { api } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import { Bell, BellOff, Check, Trash2, Clock, MapPin, Gift, AlertTriangle, ShieldCheck, Ticket } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn, safeGetDate } from '../lib/utils';
import { format } from 'date-fns';
import { useNavigate } from 'react-router-dom';

interface AdminNotification {
  id: string;
  type: 'redeem_request' | 'system_alert';
  title: string;
  message: string;
  userId: string;
  userName: string;
  rewardTitle?: string;
  rewardType?: string;
  points?: number;
  requestId: string;
  isRead: boolean;
  createdAt: any;
}

export const AdminNotificationCenter: React.FC = () => {
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState<AdminNotification[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);

  const fetchNotifications = async () => {
    if (!profile || profile.role !== 'admin') return;

    try {
      const data = await api.notifications.getAll();
      // Filter for admin-specific notifications if needed, 
      // or show all since the backend already filters based on role.
      setNotifications(data.map((n: any) => ({ ...n, id: n._id || n.id, isRead: n.read })));
      setUnreadCount(data.filter((n: any) => !n.read).length);
    } catch (error) {
      console.error("Error fetching notifications:", error);
    }
  };

  useEffect(() => {
    fetchNotifications();
  }, [profile]);

  const markAsRead = async (notificationId: string) => {
    try {
      await api.notifications.markRead(notificationId);
      setNotifications(prev => prev.map(n => n.id === notificationId ? { ...n, isRead: true } : n));
      setUnreadCount(prev => Math.max(0, prev - 1));
    } catch (error) {
      console.error("Error marking as read:", error);
    }
  };

  const markAllAsRead = async () => {
    try {
      const unread = notifications.filter(n => !n.isRead);
      await Promise.all(unread.map(n => api.notifications.markRead(n.id)));
      setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
      setUnreadCount(0);
    } catch (error) {
      console.error("Error marking all as read:", error);
    }
  };

  const clearAll = async () => {
    try {
      await Promise.all(notifications.map(n => api.notifications.delete(n.id)));
      setNotifications([]);
      setUnreadCount(0);
      setIsOpen(false);
    } catch (error) {
      console.error("Error clearing notifications:", error);
    }
  };

  const handleNotificationClick = (notification: AdminNotification) => {
    if (!notification.isRead) {
      markAsRead(notification.id);
    }
    
    if (notification.type === 'redeem_request') {
      navigate('/admin/rewards');
    }
    
    setIsOpen(false);
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'redeem_request': return <Gift className="text-amber-500" size={16} />;
      case 'system_alert': return <AlertTriangle className="text-rose-500" size={16} />;
      default: return <ShieldCheck className="text-green-500" size={16} />;
    }
  };

  return (
    <div className="relative">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className={cn(
            "relative p-3 rounded-2xl transition-all duration-300 group",
            isOpen ? "bg-green-500 text-white shadow-lg shadow-green-500/20" : "bg-white border border-gray-100 text-gray-400 hover:text-green-600 hover:bg-green-50 shadow-sm"
        )}
      >
        <Bell size={20} className={cn("transition-transform", unreadCount > 0 && !isOpen && "animate-wiggle")} />
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-rose-500 text-[9px] font-black text-white ring-4 ring-[#F9FAFB] animate-pulse">
            {unreadCount}
          </span>
        )}
      </button>

      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpen(false)}
              className="fixed inset-0 z-40 bg-black/10 backdrop-blur-[2px]"
            />
            <motion.div
              initial={{ opacity: 0, y: 15, scale: 0.95, filter: 'blur(10px)' }}
              animate={{ opacity: 1, y: 0, scale: 1, filter: 'blur(0px)' }}
              exit={{ opacity: 0, y: 15, scale: 0.95, filter: 'blur(10px)' }}
              className="absolute right-0 mt-4 w-96 bg-white rounded-[2.5rem] shadow-2xl shadow-gray-300/50 border border-gray-100 z-50 overflow-hidden"
            >
              <div className="p-8 border-b border-gray-50 flex items-center justify-between bg-gray-50/50">
                <div>
                    <h3 className="text-base font-black text-[#111827] uppercase tracking-tight">Municipal Command Center</h3>
                    <p className="text-[10px] font-bold text-gray-400 uppercase mt-0.5 tracking-wider">Operational Intelligence & Alerts</p>
                </div>
                <div className="flex gap-2">
                    {unreadCount > 0 && (
                        <button 
                            onClick={markAllAsRead}
                            className="w-10 h-10 rounded-xl bg-white border border-gray-100 flex items-center justify-center text-gray-400 hover:text-green-600 shadow-sm transition-all active:scale-95"
                            title="Acknowledge All"
                        >
                            <Check size={18} strokeWidth={3} />
                        </button>
                    )}
                    <button 
                        onClick={clearAll}
                        className="w-10 h-10 rounded-xl bg-white border border-gray-100 flex items-center justify-center text-gray-400 hover:text-rose-600 shadow-sm transition-all active:scale-95"
                        title="Purge Archives"
                    >
                        <Trash2 size={18} strokeWidth={3} />
                    </button>
                </div>
              </div>

              <div className="max-h-[500px] overflow-y-auto custom-scrollbar">
                {notifications.length === 0 ? (
                  <div className="p-20 text-center flex flex-col items-center gap-4">
                    <div className="w-20 h-20 bg-gray-50 rounded-3xl flex items-center justify-center text-gray-200">
                        <ShieldCheck size={48} strokeWidth={1} />
                    </div>
                    <div>
                        <p className="text-sm font-black text-gray-900 uppercase">Sector Secure</p>
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mt-1">No pending administrative alerts</p>
                    </div>
                  </div>
                ) : (
                  notifications.map((n) => (
                    <div 
                      key={n.id}
                      onClick={() => handleNotificationClick(n)}
                      className={cn(
                        "p-8 flex gap-6 transition-all cursor-pointer group border-b border-gray-50",
                        n.isRead ? "bg-white opacity-60" : "bg-green-50/20 hover:bg-green-50/40"
                      )}
                    >
                      <div className="mt-1 shrink-0">
                        <div className={cn(
                            "w-12 h-12 rounded-2xl flex items-center justify-center shadow-inner relative",
                            !n.isRead ? "bg-white ring-2 ring-green-100" : "bg-gray-50"
                        )}>
                            {getIcon(n.type)}
                            {!n.isRead && (
                                <span className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full border-2 border-white" />
                            )}
                        </div>
                      </div>
                      <div className="flex-1 space-y-2">
                        <div className="flex justify-between items-start">
                             <p className="text-xs font-black text-[#111827] uppercase tracking-tight leading-tight group-hover:text-green-600 transition-colors">
                                {n.title}
                             </p>
                             <div className="flex items-center gap-1 text-[8px] font-black text-gray-400 uppercase tracking-tighter">
                                <Clock size={10} />
                                {format(safeGetDate(n.createdAt), 'HH:mm')}
                             </div>
                        </div>
                        <p className="text-[11px] font-medium text-gray-500 leading-relaxed">{n.message}</p>
                        
                        {n.type === 'redeem_request' && (
                            <div className="flex items-center gap-3 mt-2">
                                <div className="flex items-center gap-1.5 px-2 py-1 bg-white border border-gray-100 rounded-lg text-[9px] font-black text-amber-600 uppercase">
                                    <Ticket size={10} /> {n.rewardType}
                                </div>
                                <div className="text-[9px] font-bold text-gray-400 uppercase">-{n.points} Points</div>
                            </div>
                        )}

                        <p className="text-[9px] font-black text-indigo-400 uppercase tracking-[0.2em] pt-1">
                            {format(safeGetDate(n.createdAt), 'MMM dd, yyyy')}
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {notifications.length > 0 && (
                <div className="p-6 bg-gray-50/50 border-t border-gray-50">
                    <button 
                        onClick={() => setIsOpen(false)}
                        className="w-full py-4 rounded-2xl bg-[#111827] text-[10px] font-black text-white uppercase tracking-[0.2em] hover:bg-black transition-all shadow-xl shadow-gray-200"
                    >
                        Secure Interface
                    </button>
                </div>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
};
