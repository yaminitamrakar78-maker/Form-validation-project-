export type UserRole = 'admin' | 'worker' | 'field_officer';

export interface UserProfile {
  id: string;
  uid: string;
  name: string;
  email: string;
  role: UserRole;
  createdAt: any;
  points: number;
  mobile?: string;
  photoUrl?: string;
  address?: string;
  city?: string;
  wardNumber?: string;
  accountStatus?: 'active' | 'disabled';
  currentStreak?: number;
  longestStreak?: number;
  lastTaskDate?: any;
  tasksCompleted?: number;
  complaintsSubmitted?: number;
  profession?: string;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  location: string;
  type: 'individual' | 'group';
  status: 'pending' | 'submitted' | 'approved' | 'rejected';
  workerId?: string; // For individual tasks
  assignedUsers?: string[]; // For group tasks
  proofImageUrl?: string;
  pointsValue: number;
  createdAt: any;
  completedAt?: any;
  latitude?: number;
  longitude?: number;
  address?: string;
  verificationStatus?: 'genuine' | 'suspicious' | 'duplicate' | 'fake';
  imageHash?: string;
  workerNotes?: string;
  adminActionAt?: any;
  rejectionReason?: string;
  updatedAt?: any;
  aiVerificationResult?: string;
  cleanlinessLevel?: 'clean' | 'moderate' | 'dirty';
  aiLabels?: string[];
  aiConfidence?: number;
  fakeProbability?: number;
}

export interface Habit {
  id: string;
  title: string;
  points: number;
  icon: string;
}

export interface HabitCompletion {
  id: string;
  userId: string;
  habitId: string;
  date: string; // YYYY-MM-DD
  points: number;
  timestamp: string;
  proofImageUrl?: string;
  location?: {
    latitude: number;
    longitude: number;
  };
  status?: 'pending' | 'submitted' | 'approved' | 'rejected';
}

export interface Notice {
  id: string;
  title: string;
  content: string;
  issuedAt: string;
  authorId: string;
  category?: 'Urgent' | 'Update' | 'Event';
}

export interface HabitSubmission {
  id: string;
  userId: string;
  userName: string;
  taskTitle: string;
  points: number;
  imageUrl: string;
  location: {
    lat: number;
    lng: number;
  };
  status: 'pending' | 'approved' | 'rejected';
  createdAt: any;
  type: 'daily-task';
  imageHash?: string;
  adminActionAt?: any;
  rejectionReason?: string;
}

export interface Reward {
  id: string;
  title: string;
  description: string;
  points: number;
  type: 'bus' | 'parking' | 'movie' | 'event';
  imageUrl?: string;
  validityDays?: number;
  stock?: number;
}

export interface Feedback {
  id: string;
  userId: string;
  message: string;
  createdAt: string;
  subject?: string;
  status?: 'pending' | 'resolved';
  resolvedAt?: string;
}

export interface RedeemRequest {
  id: string;
  userId: string;
  rewardId: string;
  rewardTitle: string;
  rewardType: 'bus' | 'parking' | 'movie' | 'event';
  points: number;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
  updatedAt?: string;
}

export interface DigitalPass {
  id: string;
  passId: string;
  userId: string;
  userName: string;
  rewardTitle: string;
  rewardType: 'bus' | 'parking' | 'movie' | 'event';
  issuedAt: string;
  validFrom: string;
  validTill: string;
  usageLimit: number;
  usedCount: number;
  status: 'active' | 'used' | 'expired';
  qrHash: string;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'assignment' | 'approval' | 'rejection' | 'system' | 'reward';
  read: boolean;
  createdAt: string;
  relatedId?: string; // e.g. taskId
}
