import React, { lazy, Suspense } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth, ADMIN_EMAILS } from './context/AuthContext';
import { Landing } from './pages/Landing';
import { Login } from './pages/Login';
import { Register } from './pages/Register';
import { UserLayout } from './components/UserLayout';
import { AdminLayout } from './components/AdminLayout';
import { Loader2 } from 'lucide-react';
import { Toaster } from 'sonner';
import { motion } from 'motion/react';

// Lazy Load Pages
const UserDashboard = lazy(() => import('./pages/user/UserDashboard').then(m => ({ default: m.UserDashboard })));
const UserTasks = lazy(() => import('./pages/user/UserTasks').then(m => ({ default: m.UserTasks })));
const UserNotices = lazy(() => import('./pages/user/UserNotices').then(m => ({ default: m.UserNotices })));
const UserRewards = lazy(() => import('./pages/user/UserRewards').then(m => ({ default: m.UserRewards })));
const UserPasses = lazy(() => import('./pages/user/UserPasses').then(m => ({ default: m.UserPasses })));
const UserFeedback = lazy(() => import('./pages/user/UserFeedback').then(m => ({ default: m.UserFeedback })));
const UserProfile = lazy(() => import('./pages/worker/Profile').then(m => ({ default: m.Profile })));

const AdminDashboard = lazy(() => import('./pages/admin/AdminDashboard').then(m => ({ default: m.AdminDashboard })));
const AdminTasks = lazy(() => import('./pages/admin/AdminTasks').then(m => ({ default: m.AdminTasks })));
const AdminUsers = lazy(() => import('./pages/admin/AdminUsers').then(m => ({ default: m.AdminUsers })));
const UserDetail = lazy(() => import('./pages/admin/UserDetail').then(m => ({ default: m.UserDetail })));
const AdminNotices = lazy(() => import('./pages/admin/AdminNotices').then(m => ({ default: m.AdminNotices })));
const AdminRewards = lazy(() => import('./pages/admin/AdminRewards').then(m => ({ default: m.AdminRewards })));
const AdminFeedback = lazy(() => import('./pages/admin/AdminFeedback').then(m => ({ default: m.AdminFeedback })));
const CivicAnalytics = lazy(() => import('./pages/admin/CivicAnalytics').then(m => ({ default: m.CivicAnalytics })));
const PassScanner = lazy(() => import('./pages/admin/PassScanner').then(m => ({ default: m.PassScanner })));

const Leaderboard = lazy(() => import('./pages/Leaderboard').then(m => ({ default: m.Leaderboard })));
const About = lazy(() => import('./pages/About').then(m => ({ default: m.About })));

const LoadingFallback: React.FC = () => (
  <div className="min-h-[400px] w-full flex flex-col items-center justify-center gap-6 bg-white/80 backdrop-blur-xl rounded-[3rem] border border-gray-100 shadow-2xl">
    <motion.div 
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      className="relative"
    >
      <Loader2 className="animate-spin text-green-500" size={40} strokeWidth={3} />
      <div className="absolute inset-0 blur-xl bg-green-400/20 animate-pulse" />
    </motion.div>
    <div className="text-center">
      <p className="text-[10px] font-black text-[#111827] uppercase tracking-[0.3em]">Smart Civic Node</p>
      <p className="text-[8px] font-bold text-gray-400 uppercase tracking-widest mt-2 animate-pulse transition-all">Official System Initializing...</p>
    </div>
  </div>
);

// Use the ADMIN_EMAIL exported from AuthContext

const ProtectedRoute: React.FC<{ children: React.ReactNode; allowedRole?: string }> = ({ children, allowedRole }) => {
  const { user, profile, loading } = useAuth();

  // Show splash screen while auth or profile is loading
  if (loading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 bg-[radial-gradient(circle_at_center,rgba(0,0,0,0.02)_0%,transparent_100%)]">
        <motion.div
           initial={{ opacity: 0, scale: 1.1 }}
           animate={{ opacity: 1, scale: 1 }}
           className="flex flex-col items-center gap-8"
        >
          <div className="relative">
            <Loader2 className="animate-spin text-green-600" size={48} />
          </div>
          <div className="text-center">
              <h1 className="text-xl font-black text-[#111827] uppercase tracking-tighter mb-2">Raipur Municipal Corporation</h1>
              <div className="flex items-center justify-center gap-3">
                 <div className="w-2 h-2 rounded-full bg-green-500 animate-bounce" />
                 <span className="text-[10px] font-black text-[#111827] uppercase tracking-[0.3em]">Official Personnel Access</span>
              </div>
          </div>
        </motion.div>
      </div>
    );
  }

  if (!user) {
    console.log("[ProtectedRoute] No user session, redirecting to login");
    return <Navigate to="/login" replace />;
  }

  // If user is logged in but profile is still missing after loading finished
  if (user && !profile) {
    console.warn("[ProtectedRoute] User detected but no profile found mapping to UID:", user.uid);
    // You might want to auto-create a profile here or redirect to a "Profile Not Found" page
    // For now, let's treat them as a standard worker if allowedRole is not admin
    if (allowedRole === 'admin' && !ADMIN_EMAILS.includes(user.email || '')) {
       return <Navigate to="/login" replace />;
    }
  }

  // Strict Admin Email Check
  const isStrictAdmin = ADMIN_EMAILS.includes(user.email || '');
  const isRoleAdmin = profile?.role === 'admin';

  if (allowedRole === 'admin') {
    if (!isStrictAdmin && !isRoleAdmin) {
      console.warn(`[ProtectedRoute] Unauthorized admin access attempt by ${user.email}`);
      return <Navigate to="/user/dashboard" replace />;
    }
  }

  // General Role Check
  if (allowedRole && profile?.role !== allowedRole && allowedRole !== 'admin') {
    console.warn(`[ProtectedRoute] Role mismatch. Required: ${allowedRole}, Found: ${profile?.role}`);
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
};

function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      
      {/* User Routes */}
      <Route path="/user/*" element={
        <ProtectedRoute>
          <UserLayout>
            <Suspense fallback={<LoadingFallback />}>
              <Routes>
                <Route path="dashboard" element={<UserDashboard />} />
                <Route path="tasks" element={<UserTasks />} />
                <Route path="notices" element={<UserNotices />} />
                <Route path="rewards" element={<UserRewards />} />
                <Route path="passes" element={<UserPasses />} />
                <Route path="feedback" element={<UserFeedback />} />
                <Route path="profile" element={<UserProfile />} />
                <Route path="leaderboard" element={<Leaderboard />} />
                <Route path="about" element={<About />} />
                <Route path="*" element={<Navigate to="dashboard" />} />
              </Routes>
            </Suspense>
          </UserLayout>
        </ProtectedRoute>
      } />

      {/* Admin Routes */}
      <Route path="/admin/*" element={
        <ProtectedRoute allowedRole="admin">
          <AdminLayout>
            <Suspense fallback={<LoadingFallback />}>
              <Routes>
                <Route path="dashboard" element={<AdminDashboard />} />
                <Route path="tasks" element={<AdminTasks />} />
                <Route path="users" element={<AdminUsers />} />
                <Route path="users/:userId" element={<UserDetail />} />
                <Route path="notices" element={<AdminNotices />} />
                <Route path="rewards" element={<AdminRewards />} />
                <Route path="feedback" element={<AdminFeedback />} />
                <Route path="analytics" element={<CivicAnalytics />} />
                <Route path="scanner" element={<PassScanner />} />
                <Route path="leaderboard" element={<Leaderboard />} />
                <Route path="about" element={<About />} />
                <Route path="*" element={<Navigate to="dashboard" />} />
              </Routes>
            </Suspense>
          </AdminLayout>
        </ProtectedRoute>
      } />

      <Route path="*" element={<Navigate to="/" />} />
    </Routes>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <Toaster position="top-center" richColors />
      <Router>
        <AppRoutes />
      </Router>
    </AuthProvider>
  );
}
