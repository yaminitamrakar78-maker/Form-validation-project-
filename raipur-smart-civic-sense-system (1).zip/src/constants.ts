export const DEFAULT_DAILY_HABITS = [
  { id: 'helmet', title: 'Wear helmet while riding', points: 5, icon: 'Shield' },
  { id: 'compost', title: 'Do home composting', points: 10, icon: 'Sprout' },
  { id: 'clothes', title: 'Donate old clothes', points: 10, icon: 'Shirt' },
  { id: 'clean', title: 'Clean nearby area', points: 15, icon: 'Brush' },
  { id: 'plastic', title: 'Reuse plastic items', points: 5, icon: 'Recycle' },
  { id: 'garbage', title: 'Dispose garbage properly', points: 5, icon: 'Trash2' },
  { id: 'water', title: 'Save water in daily use', points: 5, icon: 'Droplets' },
  { id: 'electricity', title: 'Save electricity', points: 5, icon: 'Zap' },
  { id: 'tree', title: 'Plant or care for trees', points: 15, icon: 'Trees' },
  { id: 'litter', title: 'Avoid littering in public', points: 10, icon: 'Ban' },
];

export const REWARDS = [
  { 
    id: 'bus_pass_1', 
    title: '1-Day Free Bus Pass', 
    points: 100, 
    type: 'bus', 
    description: 'Travel anywhere in the city for free for 1 day.',
    usageLimit: 1,
    validDurationDays: 30
  },
  { 
    id: 'parking_2', 
    title: '2-Hour Free Parking', 
    points: 50, 
    type: 'parking', 
    description: 'Free parking at any municipal parking lot.',
    usageLimit: 1,
    validDurationDays: 15
  },
  { 
    id: 'movie_disc', 
    title: 'Movie Ticket (50% Off)', 
    points: 200, 
    type: 'movie', 
    description: 'Get 50% discount on movie tickets at CineCentral.',
    usageLimit: 1,
    validDurationDays: 60
  },
  { 
    id: 'event_entry', 
    title: 'Community Music Fest Entry', 
    points: 300, 
    type: 'event', 
    description: 'VIP entry to the annual Community Music Festival.',
    usageLimit: 1,
    validDurationDays: 90
  }
];
