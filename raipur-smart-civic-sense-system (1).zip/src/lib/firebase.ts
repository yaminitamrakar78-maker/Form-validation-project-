import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth, setPersistence, browserLocalPersistence } from 'firebase/auth';
import { 
  getFirestore, 
  doc, 
  getDocFromServer, 
  initializeFirestore, 
  enableMultiTabIndexedDbPersistence,
  CACHE_SIZE_UNLIMITED
} from 'firebase/firestore';
import firebaseConfigJson from '../../firebase-applet-config.json';

// Function to sanitize config values that might have been accidentally pasted with prefixes or quotes
const sanitize = (val: any) => {
  if (typeof val !== 'string') return val;
  let cleaned = val.trim();
  
  // Strip common prefixes
  const prefixes = ['VITE_FIREBASE_API_KEY=', 'VITE_FIREBASE_AUTH_DOMAIN=', 'VITE_FIREBASE_PROJECT_ID=', 
                    'VITE_FIREBASE_STORAGE_BUCKET=', 'VITE_FIREBASE_MESSAGING_SENDER_ID=', 
                    'VITE_FIREBASE_APP_ID=', 'VITE_FIREBASE_MEASUREMENT_ID=', 'VITE_FIREBASE_DATABASE_ID=',
                    'apiKey=', 'apiKey: ', 'authDomain: ', 'projectId: ', 'appId: '];
  
  for (const prefix of prefixes) {
    if (cleaned.startsWith(prefix)) {
      cleaned = cleaned.substring(prefix.length).trim();
    }
  }

  // Handle generalized suffix/prefix with = or : if still present
  if (cleaned.includes('=') && (cleaned.startsWith('VITE_') || cleaned.startsWith('FIREBASE_'))) {
    cleaned = cleaned.split('=')[1] || cleaned;
  } else if (cleaned.includes(':') && !cleaned.includes('://')) { // Avoid breaking URLs
    cleaned = cleaned.split(':')[1] || cleaned;
  }

  // Strip quotes if present
  cleaned = cleaned.replace(/^["'](.+)["']$/, '$1').trim();
  
  return cleaned;
};

// Use environment variables if available (Vite preference), otherwise fallback to config JSON
const firebaseConfig = {
  apiKey: sanitize(import.meta.env.VITE_FIREBASE_API_KEY || firebaseConfigJson.apiKey),
  authDomain: sanitize(import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || firebaseConfigJson.authDomain),
  projectId: sanitize(import.meta.env.VITE_FIREBASE_PROJECT_ID || firebaseConfigJson.projectId),
  storageBucket: sanitize(import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || firebaseConfigJson.storageBucket),
  messagingSenderId: sanitize(import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || firebaseConfigJson.messagingSenderId),
  appId: sanitize(import.meta.env.VITE_FIREBASE_APP_ID || firebaseConfigJson.appId),
  measurementId: sanitize(import.meta.env.VITE_FIREBASE_MEASUREMENT_ID || firebaseConfigJson.measurementId),
  firestoreDatabaseId: sanitize(import.meta.env.VITE_FIREBASE_DATABASE_ID || firebaseConfigJson.firestoreDatabaseId)
};

// Validate config completeness
const requiredFields = ['apiKey', 'authDomain', 'projectId', 'appId'];
const missingFields = requiredFields.filter(field => !firebaseConfig[field as keyof typeof firebaseConfig]);

if (missingFields.length > 0) {
  console.error("[Firebase] Missing required configuration fields:", missingFields.join(', '));
  console.warn("[Firebase] Network requests for Auth will likely fail if parameters are incomplete.");
}

// Initialize Firebase only once
let app;
try {
  const existingApps = getApps();
  if (existingApps.length === 0) {
    console.log("[Firebase] Initializing fresh app instance for project:", firebaseConfig.projectId);
    app = initializeApp(firebaseConfig);
  } else {
    console.log("[Firebase] Reusing existing app instance.");
    app = existingApps[0];
  }
} catch (err: any) {
  console.error("[Firebase] Initialization error:", err.message);
  app = getApp(); // Final attempt to get reference
}

// Initialize Firestore with settings optimized for potentially restricted environments (like iframes/corporate networks)
const firestoreSettings = {
  experimentalForceLongPolling: true, // Bypass WebSocket blocks
  cacheSizeBytes: CACHE_SIZE_UNLIMITED
};

const databaseId = firebaseConfig.firestoreDatabaseId || '(default)';
console.log(`[Firebase] Attempting to initialize Firestore databases: Project=${firebaseConfig.projectId}, Database=${databaseId}`);

let primaryDb: any;
try {
  primaryDb = initializeFirestore(app, firestoreSettings, databaseId);
  console.log(`[Firebase] Primary Firestore initialized with database: ${databaseId}`);
} catch (err: any) {
  console.error(`[Firebase] Failed to initialize primary Firestore with database '${databaseId}':`, err.message);
  primaryDb = getFirestore(app);
}

let fallbackDb: any;
if (databaseId !== '(default)') {
  try {
    fallbackDb = initializeFirestore(app, firestoreSettings, '(default)');
    console.log("[Firebase] Fallback Firestore initialized with (default) database.");
  } catch (err: any) {
    console.error("[Firebase] Failed to initialize fallback Firestore: ", err.message);
    fallbackDb = primaryDb;
  }
} else {
  fallbackDb = primaryDb;
}

let activeDb = primaryDb;

export const useFallbackDb = () => {
  if (activeDb !== fallbackDb) {
    activeDb = fallbackDb;
    console.log("[Firebase] Switched active Firestore instance to (default) database fallback.");
  }
};

const dbInstance = new Proxy(primaryDb, {
  get(target, prop, receiver) {
    const val = Reflect.get(activeDb, prop);
    if (typeof val === 'function') {
      return val.bind(activeDb);
    }
    return val;
  },
  set(target, prop, value, receiver) {
    return Reflect.set(activeDb, prop, value);
  },
  getPrototypeOf(target) {
    return Reflect.getPrototypeOf(activeDb);
  },
  has(target, prop) {
    return Reflect.has(activeDb, prop);
  }
});

const db = dbInstance;

// Add a helper to check if the Project ID looks suspicious (shared system project vs private project)
if (firebaseConfig.projectId === 'gen-lang-client-0403467424') {
  console.warn("[Firebase] Warning: You are using a system-default Project ID. If permissions fail, ensure you have set up a private Firebase project in Settings.");
}

// Enable persistence only if explicitly requested, as it can cause "offline" errors in strict environments
// if (typeof window !== 'undefined') {
//   enableMultiTabIndexedDbPersistence(db).catch((err) => {
//     if (err.code === 'failed-precondition') {
//       console.warn("[Firestore] Multiple tabs open, persistence can only be enabled in one tab at a time.");
//     } else if (err.code === 'unimplemented') {
//       console.warn("[Firestore] The current browser doesn't support persistence.");
//     } else {
//       console.error("[Firestore] Persistence error:", err.message);
//     }
//   });
// }

// Perform a low-level reachability check
const checkFirestoreReachability = async () => {
  const url = `https://firestore.googleapis.com/google.firestore.v1.Firestore/Listen/channel?key=${firebaseConfig.apiKey}`;
  try {
    const res = await fetch(url, { mode: 'no-cors' });
    console.log("[Firebase] Firestore connectivity check: Domain is reachable via fetch.");
  } catch (err) {
    console.warn("[Firebase] Firestore connectivity check: FAILED. firestore.googleapis.com might be blocked.", err);
  }
};
checkFirestoreReachability();

export { db };
export const auth = getAuth(app);

// Use browser persistence to remember users across sessions
setPersistence(auth, browserLocalPersistence)
  .then(() => console.log("[Firebase] Auth persistence set to 'local' successfully."))
  .catch((err) => console.warn("[Firebase] Auth persistence error (tolerated offline/sandbox):", err.message));

// Blocker detection: check if common Firebase Auth scripts are actually reachable
const checkReachability = async () => {
  try {
    const authEndpoint = `https://www.googleapis.com/identitytoolkit/v3/relyingparty/getPublicKeys?key=${firebaseConfig.apiKey}`;
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000);
    
    await fetch(authEndpoint, { mode: 'no-cors', signal: controller.signal });
    clearTimeout(timeoutId);
    console.log("[Firebase] Network check: Identity Toolkit reachable.");
  } catch (err) {
    console.warn("[Firebase] Network check FAILED: Identity Toolkit unreachable. This often means an AdBlocker, VPN, or Firewall is blocking Firebase domains.");
  }
};
checkReachability();

console.log("[Firebase] Services initialized. Project:", firebaseConfig.projectId);

async function testConnection() {
  try {
    const databaseId = firebaseConfig.firestoreDatabaseId || '(default)';
    console.log(`[Firebase] Starting connectivity test... (DB: ${databaseId})`);
    
    // Attempt to read the specific connection test document allowed in rules
    const testDocRef = doc(db, 'test', 'connection');
    await getDocFromServer(testDocRef);
    
    console.log('[Firebase] Connectivity handshake reached server successfully.');
  } catch (error: any) {
    const databaseId = firebaseConfig.firestoreDatabaseId || '(default)';
    console.group('[Firebase] Connectivity Handshake Failed');
    console.log('Error Code:', error.code);
    console.log('Error Message:', error.message);
    console.log('Database ID:', databaseId);
    console.log('Project ID:', firebaseConfig.projectId);
    
    if (error.name === 'AbortError' || error.code === 'deadline-exceeded') {
       console.warn("Handshake timed out. The client might be on a slow network or Firestore is still cold-starting.");
    } else if (error.code === 'failed-precondition') {
       console.warn("Multi-tab issue or offline persistence detected.");
    } else if (error.message?.includes('offline') || error.code === 'unavailable') {
      console.warn("CRITICAL: The client appears to be truly offline or the connection is blocked by a firewall/proxy.");
      console.info("TIP: Check if an AdBlocker or corporate firewall is blocking *.googleapis.com or *.firebaseapp.com");
      if (databaseId !== '(default)') {
        console.warn("[Firebase] Switching transparent DB Proxy to (default) database fallback.");
        useFallbackDb();
      }
    } else if (error.code === 'permission-denied') {
      console.log("Handshake reached server, but access was denied (This confirms network is UP, rules just blocked it).");
    } else if (error.code === 'not-found') {
      console.warn(`WARNING: The database '${databaseId}' was not found. If this is a project-specific database, ensure it has been created in the Firebase console.`);
      if (databaseId !== '(default)') {
        console.warn("[Firebase] Switching transparent DB Proxy to (default) database fallback.");
        useFallbackDb();
      }
    } else {
      console.warn("Unexpected connection error:", error.message);
    }
    console.groupEnd();
  }
}

// Run connection test in background
testConnection().catch(() => {});

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}
