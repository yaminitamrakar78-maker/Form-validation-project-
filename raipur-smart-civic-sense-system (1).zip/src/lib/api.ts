import { firebaseService } from '../services/firebaseService';
import { auth } from './firebase';

export const api = {
  auth: {
    login: async () => {
      console.warn("Direct api.auth.login called. Use AuthContext instead.");
    },
    register: async () => {
      console.warn("Direct api.auth.register called. Use AuthContext instead.");
    },
    me: async () => {
      console.warn("Direct api.auth.me called. Use profile from AuthContext.");
    },
  },
  users: {
    getAll: async () => firebaseService.users.getAll(),
    getById: async (id: string) => firebaseService.users.getProfile(id),
    updateProfile: async (payload: any) => {
      const uid = auth.currentUser?.uid;
      if (!uid) throw new Error("Not authenticated");
      return firebaseService.users.updateProfile(uid, payload);
    },
    update: async (id: string, payload: any) => firebaseService.users.updateProfile(id, payload),
    getWorkerStats: async () => {
      const user = auth.currentUser;
      if (!user) return { completed: 0, pending: 0, rank: 0, activePasses: 0 };
      
      try {
        // Fetch core data (tasks and passes)
        const [tasks, passes] = await Promise.all([
          firebaseService.tasks.getAll(user.uid),
          firebaseService.passes.getAll(user.uid)
        ]);

        let rank: string | number = '--';
        try {
          // Attempt to get users for ranking - separate call so it doesn't block core stats
          const allUsers = await firebaseService.users.getAll();
          if (allUsers && allUsers.length > 0) {
            const sorted = [...allUsers].sort((a, b) => (b.points || 0) - (a.points || 0));
            const foundRank = sorted.findIndex(u => u.uid === user.uid) + 1;
            if (foundRank > 0) rank = foundRank;
          }
        } catch (rankErr) {
          console.warn("[API] Ranking calculation skipped:", rankErr);
        }

        const completed = (tasks || []).filter((t: any) => t.status === 'approved').length;
        const pending = (tasks || []).filter((t: any) => t.status === 'submitted' || t.status === 'pending').length;
        const activePasses = (passes || []).filter((p: any) => p.status === 'active').length;

        return { 
          completed, 
          pending, 
          rank, 
          activePasses 
        };
      } catch (err) {
        console.error("[API] Stats fetch failed:", err);
        return { completed: 0, pending: 0, rank: '--', activePasses: 0 };
      }
    },
    checkStreak: async () => { return { streak: 0, reset: false }; },
    updateStreak: async () => { return { streak: 0 }; },
  },
  tasks: {
    getAll: async (workerId?: string) => firebaseService.tasks.getAll(workerId),
    getByUser: async (userId: string) => firebaseService.tasks.getAll(userId),
    create: async (payload: any) => firebaseService.tasks.create(payload),
    update: async (id: string, payload: any) => firebaseService.tasks.update(id, payload),
    delete: async (id: string) => firebaseService.tasks.delete(id),
    approve: async (id: string) => firebaseService.tasks.update(id, { status: 'approved' }),
    reject: async (id: string, reason: string) => firebaseService.tasks.update(id, { status: 'rejected', rejectionReason: reason }),
  },
  admin: {
    getStats: async () => firebaseService.admin.getStats(),
    getSettings: async () => {
       return {
         autoApproveHabits: false,
         aiConfidenceThreshold: 0.8,
         cityCenter: { lat: 21.2514, lng: 81.6296 }
       };
    },
    updateSettings: async (payload: any) => { return {}; },
    getLogs: async (taskId: string) => firebaseService.logs.getByTaskId(taskId),
    addLog: async (payload: any) => firebaseService.logs.create(payload),
    getFeedback: async () => firebaseService.feedback.getAll(),
    deleteFeedback: async (id: string) => { /* implement delete in feedback service if needed */ },
  },
  habits: {
    getAll: async (userId?: string) => firebaseService.habits.getAll(userId),
    submit: async (payload: any) => {
      const user = auth.currentUser;
      if (!user) throw new Error("Not authenticated");
      return firebaseService.habits.submit({
        ...payload,
        userId: user.uid,
        userName: user.displayName || 'User',
      });
    },
    update: async (id: string, payload: any) => firebaseService.habits.update(id, payload),
    approve: async (id: string) => firebaseService.habits.update(id, { status: 'approved' }),
    reject: async (id: string, reason: string) => firebaseService.habits.update(id, { status: 'rejected', rejectionReason: reason }),
    delete: async (id: string) => { /* implement delete in habits service */ },
  },
  notifications: {
    getAll: async () => {
       const uid = auth.currentUser?.uid;
       if (!uid) return [];
       return firebaseService.notifications.getAll(uid);
    },
    create: async (payload: any) => firebaseService.notifications.create(payload),
    markRead: async (id: string) => firebaseService.notifications.markRead(id),
    delete: async (id: string) => { /* implement delete in notifications */ },
  },
  notices: {
    getAll: async () => firebaseService.notices.getAll(),
    create: async (payload: any) => firebaseService.notices.create(payload),
    delete: async (id: string) => firebaseService.notices.delete(id),
  },
  passes: {
    getAll: async () => {
      const uid = auth.currentUser?.uid;
      return firebaseService.passes.getAll(uid);
    },
    getById: async (id: string) => firebaseService.passes.getById(id),
    create: async (payload: any) => firebaseService.passes.create(payload),
    use: async (id: string) => firebaseService.passes.use(id),
  },
  redeem: {
    getAll: async (userId?: string) => firebaseService.redeem.getAll(userId),
    create: async (payload: any) => {
      const uid = auth.currentUser?.uid;
      if (!uid) throw new Error("Not authenticated");
      return firebaseService.redeem.create({ ...payload, userId: uid });
    },
    approve: async (id: string) => firebaseService.redeem.update(id, { status: 'approved' }),
    reject: async (id: string) => firebaseService.redeem.update(id, { status: 'rejected' }),
  },
  rewards: {
    getAll: async () => firebaseService.rewards.getAll(),
    create: async (payload: any) => firebaseService.rewards.create(payload),
    delete: async (id: string) => firebaseService.rewards.delete(id),
  },
  feedback: {
    submit: async (payload: any) => {
      const uid = auth.currentUser?.uid;
      if (!uid) throw new Error("Not authenticated");
      return firebaseService.feedback.submit({ ...payload, userId: uid });
    },
  },
  sendEmail: async (payload: any) => { return { success: true }; },
  health: async () => {
    try {
      // Use direct relative URL to be robust in sandboxed iframes (where origin can be "null")
      const response = await fetch('/api/health');
      if (!response.ok) throw new Error(`Backend unhealthy: ${response.status}`);
      return await response.json();
    } catch (err) {
      console.error("[API] Backend health check failed:", err);
      return { status: 'error', details: err instanceof Error ? err.message : String(err) };
    }
  },
  upload: async (file: File): Promise<{ url: string }> => {
    try {
      const formData = new FormData();
      formData.append('image', file);
      const response = await fetch('/api/upload', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}` // Placeholder for token if used
        },
        body: formData
      });
      if (!response.ok) throw new Error('Upload failed');
      return await response.json();
    } catch (err) {
      console.error("[API] Upload failed:", err);
      return { url: URL.createObjectURL(file) }; // Fallback
    }
  },
};

