import { ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export const generatePerceptualHash = (base64: string): Promise<string> => {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        resolve('');
        return;
      }
      const width = 9;
      const height = 8;
      canvas.width = width;
      canvas.height = height;
      ctx.drawImage(img, 0, 0, width, height);
      const imageData = ctx.getImageData(0, 0, width, height);
      const pixels = imageData.data;
      const gray: number[] = [];
      for (let i = 0; i < pixels.length; i += 4) {
        gray.push((pixels[i] + pixels[i + 1] + pixels[i + 2]) / 3);
      }
      let hash = '';
      for (let row = 0; row < height; row++) {
        for (let col = 0; col < width - 1; col++) {
          const left = gray[row * width + col];
          const right = gray[row * width + col + 1];
          hash += left > right ? '1' : '0';
        }
      }
      let hexHash = '';
      for (let i = 0; i < hash.length; i += 4) {
        hexHash += parseInt(hash.substring(i, i + 4), 2).toString(16);
      }
      resolve(hexHash);
    };
    img.src = base64;
  });
};

export const compressImage = (base64: string, maxWidth: number = 800, quality: number = 0.7): Promise<string> => {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      let width = img.width;
      let height = img.height;

      if (width > maxWidth) {
        height = Math.round((height * maxWidth) / width);
        width = maxWidth;
      }

      canvas.width = width;
      canvas.height = height;

      const ctx = canvas.getContext('2d');
      if (!ctx) {
        resolve(base64);
        return;
      }

      ctx.drawImage(img, 0, 0, width, height);
      resolve(canvas.toDataURL('image/jpeg', quality));
    };
    img.onerror = () => resolve(base64);
    img.src = base64;
  });
};

export function safeGetDate(dateVal: any): Date {
  if (!dateVal) return new Date();
  if (typeof dateVal === 'string') return new Date(dateVal);
  if (dateVal && typeof dateVal.toDate === 'function') return dateVal.toDate();
  if (dateVal && dateVal.seconds) return new Date(dateVal.seconds * 1000);
  return new Date(dateVal);
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errString = String(error);
  console.error(`API Error [${operationType}] at ${path}:`, errString);
  throw new Error(errString);
}
