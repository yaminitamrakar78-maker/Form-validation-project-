import * as dotenv from "dotenv";
dotenv.config();

import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import Razorpay from "razorpay";
import multer from "multer";
import { ObjectId } from "mongodb";
import { connectToDb, getDb } from "./server/db";
import { cloudinary, uploadBufferToCloudinary } from "./server/cloudinary";
import { sendBookingConfirmationEmail, sendCustomerStatusUpdateEmail, sendAdminNewBookingNotificationEmail } from "./server/email";


const isProduction = process.env.NODE_ENV === "production";
const PORT = 3000;

// Setup Multer memory storage
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 100 * 1024 * 1024, // 100MB limit for video uploads
  }
});

// Utility to convert id to ObjectId or string
function parseId(id: string) {
  if (ObjectId.isValid(id) && id.length === 24) {
    return new ObjectId(id);
  }
  return id;
}

function getPublicIdFromUrl(url: string): string | null {
  if (!url || !url.includes("cloudinary.com")) return null;
  try {
    const parts = url.split("/upload/");
    if (parts.length < 2) return null;
    const pathAndFilename = parts[1];
    const finalParts = pathAndFilename.split("/");
    const hasVersionDir = finalParts[0].startsWith("v") && !isNaN(Number(finalParts[0].slice(1)));
    const publicIdWithFormat = hasVersionDir ? finalParts.slice(1).join("/") : finalParts.join("/");
    const lastDotIdx = publicIdWithFormat.lastIndexOf(".");
    if (lastDotIdx !== -1) {
      return publicIdWithFormat.substring(0, lastDotIdx);
    }
    return publicIdWithFormat;
  } catch (e) {
    console.error("Error extracting publicId from url:", url, e);
    return null;
  }
}

async function deleteFromCloudinary(url?: string, publicId?: string, mediaType?: string) {
  const targetId = publicId || (url ? getPublicIdFromUrl(url) : null);
  if (!targetId || targetId === "placeholder_id") return;

  const resourceType = mediaType === 'video' ? 'video' : 'image';
  try {
    console.log(`Attempting to delete asset from Cloudinary: publicId=${targetId}, type=${resourceType}`);
    const result = await cloudinary.uploader.destroy(targetId, { resource_type: resourceType });
    console.log("Cloudinary destroy result:", result);
  } catch (err) {
    console.error("Cloudinary asset deletion failed:", err);
  }
}

async function startServer() {
  const app = express();
  app.use(express.json());

  // Connect to MongoDB
  try {
    await connectToDb();
  } catch (error) {
    console.error("Failed to connect to MongoDB on startup:", error);
  }

  // Razorpay initialization
  const razorpay = new Razorpay({
    key_id: process.env.RAZORPAY_KEY_ID || "rzp_test_placeholder",
    key_secret: process.env.RAZORPAY_KEY_SECRET || "placeholder_secret",
  });

  // ==========================================
  // API Routes
  // ==========================================

  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Razorpay Order Creation
  app.post("/api/create-order", async (req, res) => {
    try {
      const { amount, currency = "INR", receipt } = req.body;
      const options = {
        amount: Math.round(amount * 100), // amount in smallest currency unit
        currency,
        receipt,
      };

      const keyId = process.env.RAZORPAY_KEY_ID || "";
      const isPlaceholder = !keyId || keyId === "rzp_test_placeholder" || keyId.trim() === "";

      if (isPlaceholder) {
        console.warn("[PAYMENT SENDER] Razorpay credentials are empty/placeholder. Proceeding with standard sandbox simulated order.");
        return res.json({
          id: `order_simulated_${Math.random().toString(36).substring(2, 11)}`,
          amount: Math.round(amount * 100),
          currency,
          receipt,
          status: "created",
          isSimulated: true
        });
      }

      try {
        const order = await razorpay.orders.create(options);
        res.json({
          ...order,
          isSimulated: false
        });
      } catch (innerError: any) {
        console.warn("[PAYMENT SENDER] Razorpay service rejected creation (invalid keys or network error). Falling back to automatic Studio Sandbox mode:", innerError.message || innerError);
        res.json({
          id: `order_simulated_${Math.random().toString(36).substring(2, 11)}`,
          amount: Math.round(amount * 100),
          currency,
          receipt,
          status: "created",
          isSimulated: true
        });
      }
    } catch (error) {
      console.error("Razorpay order creation crash:", error);
      res.status(500).json({ error: "Failed to create order" });
    }
  });

  // ------------------------------------------
  // Public Data Endpoints
  // ------------------------------------------

  // Get active services
  app.get("/api/public/services", async (req, res) => {
    try {
      const dbInstance = await getDb();
      const includeDeleted = req.query.includeDeleted === "true";
      const filter = includeDeleted ? {} : { isDeleted: { $ne: true } };
      const services = await dbInstance.collection("services").find(filter).toArray();
      
      const mapped = await Promise.all(services.map(async (s) => {
        // Find the latest admin-uploaded media for this service category from the gallery
        const latestGallery = await dbInstance
          .collection("gallery")
          .findOne({ category: s.category }, { sort: { createdAt: -1 } as any });
          
        return {
          id: s.id || s._id.toString(),
          ...s,
          _id: s._id.toString(),
          image: latestGallery ? latestGallery.mediaUrl : (s.image || ""),
          mediaType: latestGallery ? latestGallery.mediaType : null
        };
      }));
      
      res.json(mapped);
    } catch (error) {
      console.error("Error fetching services:", error);
      res.status(500).json({ error: "Failed to fetch services" });
    }
  });

  // Get gallery items
  app.get("/api/public/gallery", async (req, res) => {
    try {
      const dbInstance = await getDb();
      const includeDeleted = req.query.includeDeleted === "true";
      const filter = includeDeleted ? {} : { isDeleted: { $ne: true } };

      const gallery = await dbInstance
        .collection("gallery")
        .find(filter)
        .sort({ createdAt: -1 })
        .toArray();
      const mapped = gallery.map(item => ({
        id: item._id.toString(),
        ...item,
        _id: item._id.toString()
      }));
      res.json(mapped);
    } catch (error) {
      console.error("Error fetching gallery:", error);
      res.status(500).json({ error: "Failed to fetch gallery" });
    }
  });

  // Get hero media list
  app.get("/api/public/hero-media", async (req, res) => {
    try {
      const dbInstance = await getDb();
      const list = await dbInstance
        .collection("heroMedia")
        .find({})
        .sort({ uploadedAt: -1 })
        .toArray();
      const mapped = list.map(item => ({
        id: item._id.toString(),
        ...item,
        _id: item._id.toString()
      }));
      res.json(mapped);
    } catch (error) {
      console.error("Error fetching hero media:", error);
      res.status(500).json({ error: "Failed to fetch hero media" });
    }
  });

  // Get contact & general settings
  app.get("/api/public/settings", async (req, res) => {
    try {
      const dbInstance = await getDb();
      const settings = await dbInstance.collection("settings").findOne({ _id: "admin" as any });
      res.json(settings || {
        contactNumber: "+91 91310 51376",
        adminEmail: "kalavantdeepak1712@gmail.com",
        instagramUrl: "#",
        facebookUrl: "#",
        twitterUrl: "#"
      });
    } catch (error) {
      console.error("Error fetching settings:", error);
      res.status(500).json({ error: "Failed to fetch settings" });
    }
  });

  // Get occupied and manually blocked dates
  app.get("/api/public/occupied-dates", async (req, res) => {
    try {
      const dbInstance = await getDb();
      const blocked = await dbInstance.collection("blocked_dates").find({}).toArray();
      const activeBookings = await dbInstance.collection("bookings")
        .find({ status: { $in: ["accepted", "in_progress", "completed"] } })
        .toArray();

      const blockedList = blocked.map(b => ({
        date: b.date,
        reason: b.reason,
        type: "blocked",
        timing: b.timeSlot || "all_day"
      }));

      const bookingsList = activeBookings.map(b => ({
        date: b.date,
        reason: "Confirmed Event Painting Schedule",
        type: "booking",
        timing: b.timing
      }));

      res.json([...blockedList, ...bookingsList]);
    } catch (err) {
      console.error("Error compiling occupied dates:", err);
      res.status(500).json({ error: "Failed to load occupied dates" });
    }
  });

  // ------------------------------------------
  // Cloudinary Media Upload Handler
  // ------------------------------------------
  app.post("/api/media/upload", upload.single("file"), async (req, res, next) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file provided" });
      }
      const folder = (req.query.folder as string) || "general";
      const resourceType = req.file.mimetype.startsWith("video/") ? "video" : "image";

      console.log(`[Media Upload] Uploading to folder: ${folder}, resourceType: ${resourceType}, size: ${req.file.size} bytes`);
      const cloudinaryRes = await uploadBufferToCloudinary(
        req.file.buffer,
        folder,
        resourceType
      );

      res.json({
        url: cloudinaryRes.secure_url,
        public_id: cloudinaryRes.public_id,
        duration: cloudinaryRes.duration
      });
    } catch (error: any) {
      console.error("Server upload error:", error);
      res.status(500).json({ error: error.message || "Upload failed to Cloudinary" });
    }
  });

  // ------------------------------------------
  // User Profile Sync Endpoint
  // ------------------------------------------
  app.post("/api/users/sync", async (req, res) => {
    try {
      const { uid, email, displayName, photoURL } = req.body;
      if (!uid) {
        return res.status(400).json({ error: "User UID is required" });
      }

      const dbInstance = await getDb();
      const usersCol = dbInstance.collection("users");

      let existing: any = await usersCol.findOne({ uid });

      if (!existing) {
        // Automatic Role Mapping for designated admin emails
        const isAdminEmail = email === "yaminitamrakar78@gmail.com" || email === "kalavantdeepak1712@gmail.com";
        const newProfile = {
          uid,
          email: email || "",
          displayName: displayName || "User",
          photoURL: photoURL || "",
          role: isAdminEmail ? "admin" : "user",
          createdAt: new Date().toISOString()
        };

        await usersCol.insertOne(newProfile);
        existing = newProfile;
      } else {
        // Ensure email and display info are synced
        const updateFields: any = {};
        if (email && existing.email !== email) updateFields.email = email;
        if (displayName && existing.displayName !== displayName) updateFields.displayName = displayName;
        if (photoURL && existing.photoURL !== photoURL) updateFields.photoURL = photoURL;
        
        // Double check admin email status just in case
        const isAdminEmail = email === "yaminitamrakar78@gmail.com" || email === "kalavantdeepak1712@gmail.com";
        const targetRole = isAdminEmail ? "admin" : existing.role || "user";
        if (existing.role !== targetRole) updateFields.role = targetRole;

        if (Object.keys(updateFields).length > 0) {
          await usersCol.updateOne({ uid }, { $set: updateFields });
          existing = { ...existing, ...updateFields };
        }
      }

      res.json(existing);
    } catch (error) {
      console.error("Error syncing user profile:", error);
      res.status(500).json({ error: "Failed to sync user profile" });
    }
  });

  // ------------------------------------------
  // Bookings Methods
  // ------------------------------------------

  // Get user specific bookings
  app.get("/api/bookings/user/:uid", async (req, res) => {
    try {
      const { uid } = req.params;
      const dbInstance = await getDb();
      const userBookings = await dbInstance
        .collection("bookings")
        .find({ userId: uid })
        .sort({ createdAt: -1 })
        .toArray();

      const mapped = userBookings.map(b => ({
        id: b._id.toString(),
        ...b,
        _id: b._id.toString()
      }));
      res.json(mapped);
    } catch (error) {
      console.error("Error fetching user bookings:", error);
      res.status(500).json({ error: "Failed to fetch bookings" });
    }
  });

  // Client reschedule request
  app.post("/api/bookings/:id/reschedule-request", async (req, res) => {
    try {
      const { id } = req.params;
      const { rescheduleDate, rescheduleTiming, note } = req.body;
      const dbInstance = await getDb();
      
      const updateResult = await dbInstance.collection("bookings").updateOne(
        { _id: parseId(id) as any },
        {
          $set: {
            rescheduleRequested: true,
            rescheduleDate,
            rescheduleTiming,
          },
          $push: {
            communicationLog: {
              sender: "customer" as const,
              text: `Requested schedule adjustment to ${rescheduleDate} (${rescheduleTiming}). Note: ${note || "None"}`,
              timestamp: new Date().toISOString()
            } as any
          }
        } as any
      );
      
      if (updateResult.matchedCount === 0) {
        return res.status(404).json({ error: "Booking not found" });
      }
      
      res.json({ success: true });
    } catch (err) {
      console.error("Error writing reschedule request:", err);
      res.status(500).json({ error: "Failed to log reschedule request" });
    }
  });

  // Create booking
  app.post("/api/bookings/create", async (req, res) => {
    try {
      const bookingDoc = req.body;
      const dbInstance = await getDb();
      const createdAt = bookingDoc.createdAt || new Date().toISOString();
      const status = bookingDoc.status || 'pending';

      const initialHistoryItem = {
        status,
        timestamp: createdAt,
        note: "Booking submitted. Awaiting studio availability verification."
      };

      const initialCommLog = {
        sender: "admin" as const,
        text: "Thank you for reserving a bespoke masterpiece. Our studio is reviewing your requirements.",
        timestamp: createdAt
      };

      const result = await dbInstance.collection("bookings").insertOne({
        ...bookingDoc,
        status,
        statusHistory: [initialHistoryItem],
        communicationLog: [initialCommLog],
        createdAt
      });

      const emailPayload = {
        id: result.insertedId.toString(),
        userEmail: bookingDoc.userEmail,
        userName: bookingDoc.userName,
        userPhone: bookingDoc.phone || bookingDoc.userPhone || "",
        date: bookingDoc.date,
        timing: bookingDoc.timing,
        location: bookingDoc.location,
        requirements: bookingDoc.requirements,
        artCategory: bookingDoc.artCategory,
        amount: bookingDoc.amount || 0,
        createdAt
      };

      // Trigger professional email confirmation upon booking
      try {
        await sendBookingConfirmationEmail(emailPayload);
      } catch (emailError) {
        console.error("Error sending booking confirmation email:", emailError);
      }

      // Trigger admin notification immediately!
      try {
        await sendAdminNewBookingNotificationEmail(emailPayload);
      } catch (adminEmailError) {
        console.error("Error alerting administrator:", adminEmailError);
      }

      res.json({
        id: result.insertedId.toString(),
        ...bookingDoc,
        status,
        statusHistory: [initialHistoryItem],
        communicationLog: [initialCommLog],
        createdAt
      });
    } catch (error) {
      console.error("Error creating booking:", error);
      res.status(500).json({ error: "Failed to record booking" });
    }
  });

  // ------------------------------------------
  // Admin Endpoints
  // ------------------------------------------

  // Get all bookings
  app.get("/api/admin/bookings", async (req, res) => {
    try {
      const dbInstance = await getDb();
      const all = await dbInstance
        .collection("bookings")
        .find({})
        .sort({ createdAt: -1 })
        .toArray();
      const mapped = all.map(b => ({
        id: b._id.toString(),
        ...b,
        _id: b._id.toString()
      }));
      res.json(mapped);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch bookings" });
    }
  });

  // Update booking status
  app.post("/api/admin/bookings/:id/status", async (req, res) => {
    try {
      const { id } = req.params;
      const { status, note } = req.body;
      const dbInstance = await getDb();
      
      const currentBooking = await dbInstance.collection("bookings").findOne({ _id: parseId(id) as any });
      if (!currentBooking) {
        return res.status(404).json({ error: "Booking not found" });
      }

      const timestamp = new Date().toISOString();
      const noteText = note || `Status updated to ${status.toUpperCase()}`;
      
      const historyItem = {
        status,
        timestamp,
        note: noteText
      };

      const commLogItem = {
        sender: "admin" as const,
        text: `Studio updated booking status to ${status.toUpperCase()}.${note ? ` Note: ${note}` : ""}`,
        timestamp
      };

      await dbInstance.collection("bookings").updateOne(
        { _id: parseId(id) as any },
        {
          $set: { status },
          $push: {
            statusHistory: historyItem as any,
            communicationLog: commLogItem as any
          }
        } as any
      );

      // Trigger automatic email update to customer
      try {
        const mailData = {
          id: currentBooking._id.toString(),
          userEmail: currentBooking.userEmail,
          userName: currentBooking.userName || "Valued Client",
          userPhone: currentBooking.phone || currentBooking.userPhone || "",
          date: currentBooking.date,
          timing: currentBooking.timing,
          location: currentBooking.location,
          requirements: currentBooking.requirements,
          artCategory: currentBooking.artCategory,
          amount: currentBooking.amount || 0,
          createdAt: currentBooking.createdAt || timestamp,
          status: status
        };
        await sendCustomerStatusUpdateEmail(mailData, note);
      } catch (embErr) {
        console.error("Booking status notification failed to send:", embErr);
      }

      res.json({ success: true, status, historyItem });
    } catch (error) {
      console.error("Error updating status:", error);
      res.status(500).json({ error: "Failed to update booking status" });
    }
  });



  // Get manually blocked dates
  app.get("/api/public/blocked-dates", async (req, res) => {
    try {
      const dbInstance = await getDb();
      const dates = await dbInstance.collection("blocked_dates").find({}).toArray();
      res.json(dates);
    } catch (err) {
      console.error("Error loading blocked dates:", err);
      res.status(500).json({ error: "Failed to loaded blocked dates" });
    }
  });

  // Block a date manually
  app.post("/api/admin/blocked-dates", async (req, res) => {
    try {
      const { date, reason, timeSlot } = req.body;
      if (!date) return res.status(400).json({ error: "Date is required" });
      
      const dbInstance = await getDb();
      const doc = {
        date,
        reason: reason || "Private / Corporate Booking",
        timeSlot: timeSlot || "all_day",
        createdAt: new Date().toISOString()
      };
      
      const result = await dbInstance.collection("blocked_dates").insertOne(doc);
      res.json({ success: true, id: result.insertedId, ...doc });
    } catch (err) {
      console.error("Error creating manual block:", err);
      res.status(500).json({ error: "Failed to block date" });
    }
  });

  // Delete manual date block
  app.delete("/api/admin/blocked-dates/:date", async (req, res) => {
    try {
      const { date } = req.params;
      const dbInstance = await getDb();
      await dbInstance.collection("blocked_dates").deleteMany({ date });
      res.json({ success: true });
    } catch (err) {
      console.error("Error removing block:", err);
      res.status(500).json({ error: "Failed to delete block" });
    }
  });

  // Reschedule booking date & time
  app.put("/api/admin/bookings/:id/reschedule", async (req, res) => {
    try {
      const { id } = req.params;
      const { date, timing, note } = req.body;
      const dbInstance = await getDb();
      
      const currentBooking = await dbInstance.collection("bookings").findOne({ _id: parseId(id) as any });
      if (!currentBooking) return res.status(404).json({ error: "Booking not found" });

      const timestamp = new Date().toISOString();
      const oldDate = currentBooking.date;
      const oldTiming = currentBooking.timing;

      const progressItem = {
        status: currentBooking.status,
        timestamp,
        note: `Rescheduled from ${oldDate} (${oldTiming}) to ${date} (${timing}).${note ? ` Reason: ${note}` : ""}`
      };

      const sysMessage = {
        sender: "admin" as const,
        text: `Schedule adjusted to ${date} @ ${timing} by the atelier.`,
        timestamp
      };

      await dbInstance.collection("bookings").updateOne(
        { _id: parseId(id) as any },
        {
          $set: { date, timing, rescheduleRequested: false },
          $push: {
            statusHistory: progressItem as any,
            communicationLog: sysMessage as any
          }
        } as any
      );

      // Notify customer immediately
      try {
        const mailData = {
          id: currentBooking._id.toString(),
          userEmail: currentBooking.userEmail,
          userName: currentBooking.userName || "Valued Client",
          userPhone: currentBooking.phone || currentBooking.userPhone || "",
          date,
          timing,
          location: currentBooking.location,
          requirements: currentBooking.requirements,
          artCategory: currentBooking.artCategory,
          amount: currentBooking.amount || 0,
          createdAt: currentBooking.createdAt || timestamp,
          status: currentBooking.status
        };
        await sendCustomerStatusUpdateEmail(mailData, `Notice: Your commission schedule window has been updated by Deepak to ${date} (${timing}). ${note || ""}`);
      } catch (sndErr) {
        console.error("Reschedule notification failure:", sndErr);
      }

      res.json({ success: true, date, timing });
    } catch (err) {
      console.error("Reschedule failure:", err);
      res.status(500).json({ error: "Failed to reschedule booking" });
    }
  });

  // Save admin notes to booking
  app.put("/api/admin/bookings/:id/notes", async (req, res) => {
    try {
      const { id } = req.params;
      const { adminNotes } = req.body;
      const dbInstance = await getDb();
      
      const currentBooking = await dbInstance.collection("bookings").findOne({ _id: parseId(id) as any });
      if (!currentBooking) {
        return res.status(404).json({ error: "Booking not found" });
      }

      const timestamp = new Date().toISOString();
      const historyItem = {
        status: currentBooking.status,
        timestamp,
        note: `Artist recorded a private log: "${adminNotes}"`
      };

      await dbInstance.collection("bookings").updateOne(
        { _id: parseId(id) as any },
        { 
          $set: { adminNotes },
          $push: { statusHistory: historyItem as any }
        } as any
      );
      res.json({ success: true, adminNotes, historyItem });
    } catch (err) {
      console.error("Failed to post notes:", err);
      res.status(500).json({ error: "Failed to update admin notes" });
    }
  });

  // Add communication message
  app.post("/api/admin/bookings/:id/communication", async (req, res) => {
    try {
      const { id } = req.params;
      const { text, sender } = req.body;
      if (!text) return res.status(400).json({ error: "Content is required" });
      
      const dbInstance = await getDb();
      const message = {
        sender: sender || "admin",
        text,
        timestamp: new Date().toISOString()
      };
      
      await dbInstance.collection("bookings").updateOne(
        { _id: parseId(id) as any },
        { $push: { communicationLog: message as any } } as any
      );
      res.json({ success: true, message });
    } catch (err) {
      console.error("Error saving message:", err);
      res.status(500).json({ error: "Failed to write communication log" });
    }
  });

  // Admin: Get all users
  app.get("/api/admin/users", async (req, res) => {
    try {
      const dbInstance = await getDb();
      const all = await dbInstance
        .collection("users")
        .find({})
        .sort({ createdAt: -1 })
        .toArray();
      const mapped = all.map(u => ({
        id: u._id.toString(),
        ...u,
        _id: u._id.toString()
      }));
      res.json(mapped);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch users" });
    }
  });

  // Save Settings
  app.post("/api/admin/settings", async (req, res) => {
    try {
      const settingsData = req.body;
      const dbInstance = await getDb();
      await dbInstance
        .collection("settings")
        .updateOne(
          { _id: "admin" as any },
          { $set: settingsData },
          { upsert: true }
        );
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to update settings" });
    }
  });

  // Add Service
  app.post("/api/admin/services", async (req, res) => {
    try {
      const service = req.body;
      const dbInstance = await getDb();
      const result = await dbInstance.collection("services").insertOne({
        ...service,
        id: service.id || service.title.toLowerCase().replace(/\s+/g, "-")
      });
      res.json({ id: result.insertedId.toString(), ...service });
    } catch (error) {
      res.status(500).json({ error: "Failed to add service" });
    }
  });

  // Update Service Details (Dynamic Pricing Management)
  app.post("/api/admin/services/update", async (req, res) => {
    try {
      const { id, price, premiumPrice, duration, deliveryTime, materials, discountOffer, category, description, title, image, mediaType } = req.body;
      const dbInstance = await getDb();
      
      const updateData: any = {};
      if (price !== undefined) updateData.price = Number(price);
      if (premiumPrice !== undefined) updateData.premiumPrice = premiumPrice ? Number(premiumPrice) : null;
      if (duration !== undefined) updateData.duration = duration;
      if (deliveryTime !== undefined) updateData.deliveryTime = deliveryTime;
      if (materials !== undefined) updateData.materials = materials;
      if (discountOffer !== undefined) updateData.discountOffer = discountOffer ? Number(discountOffer) : null;
      if (category !== undefined) updateData.category = category;
      if (description !== undefined) updateData.description = description;
      if (title !== undefined) updateData.title = title;
      if (image !== undefined) updateData.image = image;
      if (mediaType !== undefined) updateData.mediaType = mediaType;

      const query = {
        $or: [
          { _id: parseId(id) as any },
          { id: id }
        ]
      };

      const existing = await dbInstance.collection("services").findOne(query);
      if (existing) {
        await dbInstance.collection("services").updateOne(
          { _id: existing._id },
          { $set: updateData }
        );
      } else {
        await dbInstance.collection("services").updateOne(
          { id: id },
          { $set: updateData },
          { upsert: true }
        );
      }
      res.json({ success: true, id, updated: updateData });
    } catch (error) {
      console.error("Error updating service details dynamically:", error);
      res.status(500).json({ error: "Failed to update service details dynamically" });
    }
  });

  // Delete Service (Soft Delete by default, Permanent if specified)
  app.delete("/api/admin/services/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const { permanent } = req.query;
      const dbInstance = await getDb();
      const query = {
        $or: [
          { _id: parseId(id) as any },
          { id: id }
        ]
      };

      const service = await dbInstance.collection("services").findOne(query);
      if (!service) {
        return res.status(404).json({ error: "Service not found" });
      }

      if (permanent === "true") {
        await deleteFromCloudinary(service.image, service.publicId, "image");
        await dbInstance.collection("services").deleteOne({ _id: service._id });
        res.json({ success: true, permanent: true });
      } else {
        // Soft delete
        await dbInstance.collection("services").updateOne(
          { _id: service._id },
          { $set: { isDeleted: true, deletedAt: new Date().toISOString() } }
        );
        res.json({ success: true, soft: true });
      }
    } catch (error) {
      console.error("Failed to delete service:", error);
      res.status(500).json({ error: "Failed to delete service" });
    }
  });

  // Restore Trashed Service
  app.post("/api/admin/services/:id/restore", async (req, res) => {
    try {
      const { id } = req.params;
      const dbInstance = await getDb();
      const query = {
        $or: [
          { _id: parseId(id) as any },
          { id: id }
        ]
      };

      const service = await dbInstance.collection("services").findOne(query);
      if (!service) {
        return res.status(404).json({ error: "Service not found" });
      }

      await dbInstance.collection("services").updateOne(
        { _id: service._id },
        { $unset: { isDeleted: "", deletedAt: "" } }
      );
      res.json({ success: true });
    } catch (error) {
      console.error("Failed to restore service:", error);
      res.status(500).json({ error: "Failed to restore service" });
    }
  });

  // Add Gallery Item
  app.post("/api/admin/gallery", async (req, res) => {
    try {
      const item = req.body;
      const dbInstance = await getDb();
      const result = await dbInstance.collection("gallery").insertOne({
        ...item,
        createdAt: item.createdAt || new Date().toISOString()
      });
      res.json({ id: result.insertedId.toString(), ...item });
    } catch (error) {
      res.status(500).json({ error: "Failed to publish item" });
    }
  });

  // Update Gallery Item
  app.put("/api/admin/gallery/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const { title, description, category } = req.body;
      const dbInstance = await getDb();

      const updateData: any = {};
      if (title !== undefined) updateData.title = title;
      if (description !== undefined) updateData.description = description;
      if (category !== undefined) updateData.category = category;

      await dbInstance
        .collection("gallery")
        .updateOne({ _id: parseId(id) as any }, { $set: updateData });
      res.json({ success: true });
    } catch (error) {
      console.error("Error updating gallery item:", error);
      res.status(500).json({ error: "Failed to update gallery item" });
    }
  });

  // Delete Gallery Item (Support Trash Basket / Soft Delete and Permanent Delete)
  app.delete("/api/admin/gallery/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const { permanent } = req.query;
      const dbInstance = await getDb();
      const query = {
        $or: [
          { _id: parseId(id) as any },
          { id: id }
        ]
      };

      const item = await dbInstance
        .collection("gallery")
        .findOne(query);

      if (!item) {
        return res.status(404).json({ error: "Gallery item not found" });
      }

      if (permanent === "true") {
        await deleteFromCloudinary(item.mediaUrl, item.publicId, item.mediaType);
        await dbInstance
          .collection("gallery")
          .deleteOne({ _id: item._id });
        res.json({ success: true, permanent: true });
      } else {
        // Soft delete/Move to Trash
        await dbInstance.collection("gallery").updateOne(
          { _id: item._id },
          { $set: { isDeleted: true, deletedAt: new Date().toISOString() } }
        );
        res.json({ success: true, soft: true });
      }
    } catch (error) {
      console.error("Failed deleting gallery item:", error);
      res.status(500).json({ error: "Failed to delete gallery item" });
    }
  });

  // Restore Gallery Item from Trash
  app.post("/api/admin/gallery/:id/restore", async (req, res) => {
    try {
      const { id } = req.params;
      const dbInstance = await getDb();
      const query = {
        $or: [
          { _id: parseId(id) as any },
          { id: id }
        ]
      };

      const item = await dbInstance
        .collection("gallery")
        .findOne(query);

      if (!item) {
        return res.status(404).json({ error: "Gallery item not found" });
      }

      await dbInstance.collection("gallery").updateOne(
        { _id: item._id },
        { $set: { isDeleted: false, deletedAt: null } }
      );
      res.json({ success: true });
    } catch (error) {
      console.error("Failed to restore gallery item:", error);
      res.status(500).json({ error: "Failed to restore gallery item" });
    }
  });

  // Add Hero Media
  app.post("/api/admin/hero-media", async (req, res) => {
    try {
      const media = req.body;
      const dbInstance = await getDb();
      const result = await dbInstance.collection("heroMedia").insertOne({
        ...media,
        uploadedAt: media.uploadedAt || new Date().toISOString(),
        isFeatured: false
      });
      res.json({ id: result.insertedId.toString(), ...media });
    } catch (error) {
      res.status(500).json({ error: "Failed to save hero media" });
    }
  });

  // Delete Hero Media
  app.delete("/api/admin/hero-media/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const dbInstance = await getDb();
      const media = await dbInstance
        .collection("heroMedia")
        .findOne({ _id: parseId(id) as any });

      if (media) {
        await deleteFromCloudinary(media.mediaUrl, media.publicId, media.mediaType);
      }

      await dbInstance
        .collection("heroMedia")
        .deleteOne({ _id: parseId(id) as any });
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete hero media" });
    }
  });

  // Toggle/Set Featured Hero Media
  app.post("/api/admin/hero-media/:id/feature", async (req, res) => {
    try {
      const { id } = req.params;
      const { isFeatured } = req.body;
      const dbInstance = await getDb();
      
      // If we are featuring this item, clear featured status from all other heroMedia docs
      if (isFeatured) {
        await dbInstance
          .collection("heroMedia")
          .updateMany({}, { $set: { isFeatured: false } });
      }

      await dbInstance
        .collection("heroMedia")
        .updateOne({ _id: parseId(id) as any }, { $set: { isFeatured } });
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to set featured status" });
    }
  });

  // Update Hero Media Settings
  app.put("/api/admin/hero-media/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const { title, description, category, videoStartTime, videoEndTime, videoVolume, videoSpeed } = req.body;
      const dbInstance = await getDb();
      
      const updateData: any = {};
      if (title !== undefined) updateData.title = title;
      if (description !== undefined) updateData.description = description;
      if (category !== undefined) updateData.category = category;
      if (videoStartTime !== undefined) updateData.videoStartTime = Number(videoStartTime) || 0;
      if (videoEndTime !== undefined) updateData.videoEndTime = videoEndTime === null ? null : (Number(videoEndTime) || null);
      if (videoVolume !== undefined) updateData.videoVolume = Number(videoVolume) ?? 0;
      if (videoSpeed !== undefined) updateData.videoSpeed = Number(videoSpeed) || 1.0;

      await dbInstance
        .collection("heroMedia")
        .updateOne({ _id: parseId(id) as any }, { $set: updateData });
      res.json({ success: true });
    } catch (error) {
      console.error("Error updating hero media settings:", error);
      res.status(500).json({ error: "Failed to update hero media settings" });
    }
  });

  // Unmatched API Route Handler to prevent HTML fallthrough for bad API endpoints
  app.all("/api/*", (req, res, next) => {
    res.status(404).json({ error: `API route not found: ${req.method} ${req.path}` });
  });

  // Global custom error handler to guarantee JSON formatting on failures
  app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
    console.error("EXPRESS GLOBAL ERROR:", err);
    res.status(err.status || 500).json({
      error: err.message || "An internal server error occurred",
      stack: process.env.NODE_ENV !== "production" ? err.stack : undefined
    });
  });

  // ==========================================
  // Vite Middleware & SPA Fallback
  // ==========================================

  // Vite middleware for development
  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }



  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
