import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../../context/AuthContext';
import { X, Mail, Lock, User, LogIn, UserPlus, Loader2, Sparkles, AlertCircle } from 'lucide-react';
import toast from 'react-hot-toast';

export default function AuthModal() {
  const { 
    isAuthModalOpen, 
    authModalView, 
    closeAuthModal, 
    setAuthModalView, 
    signInWithGoogle, 
    signInWithEmail, 
    signUpWithEmail,
    isSigningIn 
  } = useAuth();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isAuthModalOpen) return null;

  const validateEmail = (email: string) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    // Basic Validation
    if (!email) {
      setErrorMsg('Email address is required');
      return;
    }
    if (!validateEmail(email)) {
      setErrorMsg('Please enter a valid email address');
      return;
    }
    if (!password) {
      setErrorMsg('Password is required');
      return;
    }
    if (password.length < 6) {
      setErrorMsg('Password must be at least 6 characters long');
      return;
    }

    if (authModalView === 'signup') {
      if (!name.trim()) {
        setErrorMsg('Please enter your full name');
        return;
      }
      if (password !== confirmPassword) {
        setErrorMsg('Passwords do not match');
        return;
      }
    }

    setLoading(true);
    try {
      if (authModalView === 'signin') {
        await signInWithEmail(email, password);
      } else {
        await signUpWithEmail(email, password, name.trim());
      }
      // Reset state on successful submit
      setEmail('');
      setPassword('');
      setConfirmPassword('');
      setName('');
    } catch (err: any) {
      console.error(err);
      let errMsg = 'Authentication failed. Please check your inputs.';
      if (err.code === 'auth/email-already-in-use') {
        errMsg = 'This email is already in use.';
      } else if (err.code === 'auth/wrong-password') {
        errMsg = 'Incorrect email or password.';
      } else if (err.code === 'auth/user-not-found') {
        errMsg = 'No account associated with this email.';
      } else if (err.message) {
        errMsg = err.message;
      }
      setErrorMsg(errMsg);
      toast.error(errMsg);
    } finally {
      setLoading(false);
    }
  };

  const handleToggle = (view: 'signin' | 'signup') => {
    setErrorMsg(null);
    setAuthModalView(view);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
        {/* Cinematic Blurred Backdrop Overlay */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={closeAuthModal}
          className="absolute inset-0 bg-black/80 backdrop-blur-md cursor-pointer"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          transition={{ type: 'spring', damping: 25, stiffness: 350 }}
          className="relative w-full max-w-md bg-zinc-950/90 backdrop-blur-2xl border border-amber-500/20 rounded-[2.5rem] overflow-hidden shadow-[0_0_50px_rgba(245,158,11,0.15)] p-8 md:p-10 text-center"
          id="auth-modal-container"
        >
          {/* Top Elegant Line */}
          <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-transparent via-amber-500/50 to-transparent" />

          {/* Close Button */}
          <button
            onClick={closeAuthModal}
            className="absolute top-6 right-6 p-2 rounded-full border border-white/5 hover:border-amber-500/30 text-gray-400 hover:text-amber-500 hover:bg-amber-500/10 transition-all cursor-pointer"
            id="auth-modal-close"
          >
            <X className="h-4 w-4" />
          </button>

          {/* Header */}
          <div className="mb-8 mt-4">
            <div className="mx-auto w-12 h-12 bg-amber-500/10 rounded-full border border-amber-500/20 flex items-center justify-center mb-4">
              <Sparkles className="h-5 w-5 text-amber-500 animate-pulse" />
            </div>
            <h2 className="text-3xl font-bold font-serif bg-gradient-to-r from-amber-200 via-amber-400 to-amber-200 bg-clip-text text-transparent tracking-wide">
              {authModalView === 'signin' ? 'Welcome Back' : 'Join DPartic Flow'}
            </h2>
            <p className="text-gray-400 text-xs tracking-wider mt-1.5 uppercase font-mono">
              {authModalView === 'signin' ? 'Bespoke Art & Professional Artistry' : 'Unlock Priority Bookings & Custom Art'}
            </p>
          </div>

          {/* Switch Tab */}
          <div className="flex bg-black/60 rounded-full p-1 border border-white/5 mb-6 max-w-[280px] mx-auto">
            <button
              onClick={() => handleToggle('signin')}
              className={`flex-1 py-2 text-[10px] uppercase tracking-widest font-bold rounded-full transition-all ${
                authModalView === 'signin'
                  ? 'bg-gradient-to-r from-amber-600 to-amber-500 text-black shadow-lg shadow-amber-500/10'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              Sign In
            </button>
            <button
              onClick={() => handleToggle('signup')}
              className={`flex-1 py-2 text-[10px] uppercase tracking-widest font-bold rounded-full transition-all ${
                authModalView === 'signup'
                  ? 'bg-gradient-to-r from-amber-600 to-amber-500 text-black shadow-lg shadow-amber-500/10'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              Sign Up
            </button>
          </div>

          {/* Error Message */}
          {errorMsg && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-start gap-2 bg-red-500/10 border border-red-500/20 text-red-500 rounded-2xl p-4 text-xs text-left mb-6"
            >
              <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </motion.div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {authModalView === 'signup' && (
              <div className="space-y-1.5 text-left">
                <label className="text-[10px] uppercase tracking-widest text-gray-500 font-mono ml-2">Full Name</label>
                <div className="relative">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Enter your full name"
                    disabled={loading || isSigningIn}
                    className="w-full bg-black/50 border border-white/5 disabled:opacity-50 hover:border-white/10 rounded-2xl py-3.5 pl-12 pr-4 text-sm text-white focus:outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/10 transition-all font-sans"
                  />
                </div>
              </div>
            )}

            <div className="space-y-1.5 text-left">
              <label className="text-[10px] uppercase tracking-widest text-gray-500 font-mono ml-2">Email Address</label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  disabled={loading || isSigningIn}
                  className="w-full bg-black/50 border border-white/5 disabled:opacity-50 hover:border-white/10 rounded-2xl py-3.5 pl-12 pr-4 text-sm text-white focus:outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/10 transition-all font-sans"
                />
              </div>
            </div>

            <div className="space-y-1.5 text-left">
              <label className="text-[10px] uppercase tracking-widest text-gray-500 font-mono ml-2">Password</label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  disabled={loading || isSigningIn}
                  className="w-full bg-black/50 border border-white/5 disabled:opacity-50 hover:border-white/10 rounded-2xl py-3.5 pl-12 pr-4 text-sm text-white focus:outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/10 transition-all font-sans"
                />
              </div>
            </div>

            {authModalView === 'signup' && (
              <div className="space-y-1.5 text-left">
                <label className="text-[10px] uppercase tracking-widest text-gray-500 font-mono ml-2">Confirm Password</label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <input
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="••••••••"
                    disabled={loading || isSigningIn}
                    className="w-full bg-black/50 border border-white/5 disabled:opacity-50 hover:border-white/10 rounded-2xl py-3.5 pl-12 pr-4 text-sm text-white focus:outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/10 transition-all font-sans"
                  />
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={loading || isSigningIn}
              className="w-full mt-6 py-4 bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 disabled:opacity-50 disabled:hover:scale-100 text-black font-extrabold text-[11px] tracking-widest uppercase rounded-2xl transition-all transform hover:scale-[1.02] flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-amber-500/10"
              id="auth-modal-submit"
            >
              {loading ? (
                <Loader2 className="h-4 w-4 animate-spin text-black" />
              ) : authModalView === 'signin' ? (
                <>
                  <LogIn className="h-4 w-4 text-black" />
                  <span>SIGN IN</span>
                </>
              ) : (
                <>
                  <UserPlus className="h-4 w-4 text-black" />
                  <span>SIGN UP</span>
                </>
              )}
            </button>
          </form>

          {/* Divider */}
          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t border-white/5" />
            </div>
            <div className="relative flex justify-center text-[10px] uppercase tracking-widest font-mono">
              <span className="bg-zinc-950 px-4 text-gray-500">Or continue with</span>
            </div>
          </div>

          {/* Google Access Button */}
          <button
            onClick={signInWithGoogle}
            disabled={loading || isSigningIn}
            className="w-full py-4 bg-white/5 hover:bg-white/10 disabled:opacity-50 disabled:hover:bg-white/5 disabled:hover:scale-100 border border-white/5 rounded-2xl transition-all text-xs text-white flex items-center justify-center gap-3 font-semibold uppercase tracking-widest transform hover:scale-[1.02] cursor-pointer"
            id="auth-modal-google"
          >
            {isSigningIn ? (
              <Loader2 className="h-4 w-4 animate-spin text-amber-500" />
            ) : (
              <svg className="h-4 w-4 shrink-0" viewBox="0 0 24 24">
                <path
                  fill="currentColor"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="currentColor"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="currentColor"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l3.66-2.85z"
                />
                <path
                  fill="currentColor"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.85c.87-2.6 3.3-4.53 6.16-4.53z"
                />
              </svg>
            )}
            <span>Google Workspace</span>
          </button>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
