import { useState, useEffect } from 'react';
import { Facebook, Instagram, Twitter, Mail, Phone, MapPin, Palette } from 'lucide-react';
import { Link } from 'react-router-dom';
import { AppSettings } from '../../types';

export default function Footer() {
  const [settings, setSettings] = useState<AppSettings>({
    contactNumber: '+91 91310 51376',
    adminEmail: 'kalavantdeepak1712@gmail.com',
    instagramUrl: 'https://www.instagram.com/dpartic_flow',
    facebookUrl: '#',
    twitterUrl: '#'
  });

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const res = await fetch('/api/public/settings');
        if (res.ok && res.headers.get('content-type')?.includes('application/json')) {
          const data = await res.json();
          setSettings(data);
        }
      } catch (error) {
        console.error("Error loading settings for footer:", error);
      }
    };
    fetchSettings();
  }, []);

  return (
    <footer className="bg-black border-t border-amber-500/20 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="space-y-6">
            <Link to="/" className="flex items-center space-x-2">
              <Palette className="h-8 w-8 text-amber-500" />
              <span className="text-2xl font-serif font-bold text-amber-500 tracking-[0.2em]">
                DPARTIC FLOW
              </span>
            </Link>
            <p className="text-gray-400 text-sm leading-relaxed">
              Curating cinematic artistic experiences for your most precious moments. Premium live art services for weddings, corporate events, and luxury parties.
            </p>
            <div className="flex space-x-4">
              <a href={`https://wa.me/919131051376`} target="_blank" rel="noopener noreferrer" className="p-2 bg-green-500/10 rounded-full text-green-500 hover:bg-green-500 hover:text-black transition-all">
                <svg className="h-5 w-5 fill-current" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L0 24l6.335-1.662c1.72.94 3.659 1.437 5.634 1.437h.005c6.558 0 11.897-5.335 11.9-11.894a11.83 11.83 0 00-3.484-8.43z"/>
                </svg>
              </a>
              <a href={settings.instagramUrl} target="_blank" rel="noopener noreferrer" className="p-2 bg-amber-500/10 rounded-full text-amber-500 hover:bg-amber-500 hover:text-black transition-all">
                <Instagram className="h-5 w-5" />
              </a>
              <a href={settings.facebookUrl} target="_blank" rel="noopener noreferrer" className="p-2 bg-amber-500/10 rounded-full text-amber-500 hover:bg-amber-500 hover:text-black transition-all">
                <Facebook className="h-5 w-5" />
              </a>
              <a href={settings.twitterUrl} target="_blank" rel="noopener noreferrer" className="p-2 bg-amber-500/10 rounded-full text-amber-500 hover:bg-amber-500 hover:text-black transition-all">
                <Twitter className="h-5 w-5" />
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-amber-500 font-bold uppercase tracking-widest mb-6">Quick Links</h3>
            <ul className="space-y-4">
              <li><Link to="/services" className="text-gray-400 hover:text-amber-500 transition-colors uppercase tracking-widest text-xs">Services</Link></li>
              <li><Link to="/gallery" className="text-gray-400 hover:text-amber-500 transition-colors uppercase tracking-widest text-xs">Gallery</Link></li>
              <li><Link to="/booking" className="text-gray-400 hover:text-amber-500 transition-colors uppercase tracking-widest text-xs">Book An Artist</Link></li>
              <li><Link to="/dashboard" className="text-gray-400 hover:text-amber-500 transition-colors uppercase tracking-widest text-xs">My Account</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-amber-500 font-bold uppercase tracking-widest mb-6">Art Categories</h3>
            <ul className="space-y-4">
              <li className="text-gray-400 uppercase tracking-widest text-xs">Live Sketches</li>
              <li className="text-gray-400 uppercase tracking-widest text-xs">Magical Portraits</li>
              <li className="text-gray-400 uppercase tracking-widest text-xs">Temp Tattoos</li>
              <li className="text-gray-400 uppercase tracking-widest text-xs">Pottery Art</li>
            </ul>
          </div>

          <div>
            <h3 className="text-amber-500 font-bold uppercase tracking-widest mb-6">Contact Us</h3>
            <ul className="space-y-4">
              <li className="flex items-start space-x-3 text-gray-400">
                <Mail className="h-5 w-5 text-amber-500 mt-1" />
                <span className="text-sm">{settings.adminEmail}</span>
              </li>
              <li className="flex items-start space-x-3 text-gray-400">
                <Phone className="h-5 w-5 text-amber-500 mt-1" />
                <span className="text-sm">{settings.contactNumber}</span>
              </li>
              <li className="flex items-start space-x-3 text-gray-400">
                <MapPin className="h-5 w-5 text-amber-500 mt-1" />
                <span className="text-sm">Abhanpur, Raipur, Chhattisgarh</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-amber-500/10 pt-8 flex flex-col md:flex-row justify-between items-center text-xs text-gray-500 uppercase tracking-[0.2em]">
          <p>© 2026 DPartic Flow. Elevating Every Occasion.</p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <a href="#" className="hover:text-amber-500">Privacy Policy</a>
            <a href="#" className="hover:text-amber-500">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
