import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { motion } from 'motion/react';
import { Menu, X, LogIn, LogOut, User, LayoutDashboard, Palette, Instagram } from 'lucide-react';
import { useState } from 'react';
import { cn } from '../../lib/utils';

export default function Navbar() {
  const { user, profile, signInWithGoogle, logout, isAdmin, isSigningIn, openAuthModal } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Services', path: '/services' },
    { name: 'Gallery', path: '/gallery' },
    { name: 'Book Now', path: '/booking' },
    { name: 'Contact', path: '/contact' },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <>
      <div className="fixed top-0 left-0 right-0 z-[60] bg-amber-500 text-black py-1 px-4 text-center text-[9px] font-bold uppercase tracking-[0.3em]">
        <div className="max-w-7xl mx-auto flex justify-center md:justify-between items-center">
          <div className="hidden md:flex items-center space-x-4">
            <span className="flex items-center gap-1"><Palette className="h-3 w-3" /> Professional Artistry for Events</span>
          </div>
            <div className="flex items-center space-x-6">
            <a href="https://www.instagram.com/dpartic_flow" target="_blank" rel="noopener noreferrer" className="hover:opacity-70 transition-opacity">
              <Instagram className="h-3 w-3" />
            </a>
            <a href="tel:9131051376" className="flex items-center gap-1 hover:opacity-70 transition-opacity">
              Contact: +91 91310 51376
            </a>
            <a href="https://wa.me/919131051376" target="_blank" rel="noopener noreferrer" className="hidden sm:flex items-center gap-1 hover:opacity-70 transition-opacity">
              WhatsApp Support
            </a>
          </div>
        </div>
      </div>
      <nav className="fixed top-6 left-0 right-0 z-50 bg-black/40 backdrop-blur-md border-b border-amber-500/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <Link to="/" className="flex items-center space-x-2">
            <Palette className="h-8 w-8 text-amber-500" />
            <span className="text-2xl font-serif font-bold text-amber-500 tracking-[0.2em]">
              DPARTIC FLOW
            </span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => {
              if (link.name === 'Book Now' && !user) {
                return (
                  <button
                    key={link.path}
                    onClick={() => openAuthModal('signin')}
                    className="text-[11px] font-medium transition-all hover:text-amber-500 uppercase tracking-[0.2em] text-beige-100 opacity-70 hover:opacity-100 cursor-pointer text-left bg-transparent border-none p-0 outline-none focus:outline-none"
                  >
                    {link.name}
                  </button>
                );
              }
              return (
                <Link
                  key={link.path}
                  to={link.path}
                  className={cn(
                    "text-[11px] font-medium transition-all hover:text-amber-500 uppercase tracking-[0.2em]",
                    isActive(link.path) ? "text-amber-500 border-b border-amber-500/50 pb-1" : "text-beige-100 opacity-70 hover:opacity-100"
                  )}
                >
                  {link.name}
                </Link>
              );
            })}

            {user ? (
              <div className="flex items-center space-x-4">
                <Link
                  to="/dashboard"
                  className={cn(
                    "p-2 rounded-full transition-colors",
                    isActive('/dashboard') ? "bg-amber-500/20 text-amber-500" : "hover:bg-amber-500/10 text-beige-100"
                  )}
                >
                  <User className="h-5 w-5" />
                </Link>
                {isAdmin && (
                  <Link
                    to="/admin"
                    className={cn(
                      "flex items-center space-x-2 px-4 py-2 rounded-xl transition-all border font-bold text-[10px] tracking-widest",
                      isActive('/admin') 
                        ? "bg-amber-500 text-black border-amber-500 shadow-lg shadow-amber-500/20" 
                        : "border-amber-500/30 text-amber-500 hover:bg-amber-500/10 hover:border-amber-500"
                    )}
                  >
                    <LayoutDashboard className="h-4 w-4" />
                    <span>ADMIN PANEL</span>
                  </Link>
                )}
                <button
                  onClick={logout}
                  className="flex items-center space-x-1 text-sm font-medium text-beige-100 hover:text-red-400 transition-colors uppercase tracking-widest"
                >
                  <LogOut className="h-4 w-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => openAuthModal('signin')}
                className="flex items-center space-x-2 px-6 py-2 bg-amber-500 text-black font-bold rounded-full hover:bg-amber-400 transition-all transform hover:scale-105"
              >
                <LogIn className="h-4 w-4" />
                <span>SIGN IN</span>
              </button>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-beige-100 p-2 focus:outline-none"
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Nav */}
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="md:hidden bg-black/95 backdrop-blur-xl border-b border-amber-500/20 pb-6 px-4 space-y-4"
        >
          {navLinks.map((link) => {
            if (link.name === 'Book Now' && !user) {
              return (
                <button
                  key={link.path}
                  onClick={() => {
                    setIsOpen(false);
                    openAuthModal('signin');
                  }}
                  className="block w-full text-left py-3 text-lg font-medium tracking-widest text-beige-100 uppercase bg-transparent p-0 border-none outline-none"
                >
                  {link.name}
                </button>
              );
            }
            return (
              <Link
                key={link.path}
                to={link.path}
                onClick={() => setIsOpen(false)}
                className={cn(
                  "block py-3 text-lg font-medium tracking-widest",
                  isActive(link.path) ? "text-amber-500" : "text-beige-100"
                )}
              >
                {link.name}
              </Link>
            );
          })}
          <div className="pt-4 border-t border-amber-500/10 space-y-4">
            {user ? (
              <>
                <Link
                  to="/dashboard"
                  onClick={() => setIsOpen(false)}
                  className="flex items-center space-x-2 text-beige-100 tracking-widest"
                >
                  <User className="h-5 w-5" />
                  <span>DASHBOARD</span>
                </Link>
                {isAdmin && (
                  <Link
                    to="/admin"
                    onClick={() => setIsOpen(false)}
                    className="flex items-center space-x-2 text-beige-100 tracking-widest"
                  >
                    <LayoutDashboard className="h-5 w-5" />
                    <span>ADMIN PANEL</span>
                  </Link>
                )}
                <button
                  onClick={() => {
                    logout();
                    setIsOpen(false);
                  }}
                  className="flex items-center space-x-2 text-red-400 tracking-widest"
                >
                  <LogOut className="h-5 w-5" />
                  <span>LOGOUT</span>
                </button>
              </>
            ) : (
              <button
                onClick={() => {
                  setIsOpen(false);
                  openAuthModal('signin');
                }}
                className="w-full flex items-center justify-center space-x-2 px-6 py-3 bg-amber-500 text-black font-bold rounded-full"
              >
                <LogIn className="h-5 w-5" />
                <span>SIGN IN</span>
              </button>
            )}
          </div>
        </motion.div>
      )}
    </nav>
  </>
);
}
