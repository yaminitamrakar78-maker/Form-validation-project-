export type UserRole = 'user' | 'admin';

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL: string;
  role: UserRole;
  createdAt: any;
}

export interface AppSettings {
  contactNumber: string;
  adminEmail: string;
  instagramUrl: string;
  facebookUrl: string;
  twitterUrl: string;
}

export interface StatusHistoryItem {
  status: string;
  timestamp: string;
  note?: string;
}

export interface CustomerMessage {
  sender: 'admin' | 'customer';
  text: string;
  timestamp: string;
}

export interface BlockedDate {
  id?: string;
  _id?: string;
  date: string;
  reason: string;
  timeSlot?: string; // Optional: specific time slot, or 'all_day'
  createdAt: string;
}

export interface Booking {
  id: string;
  userId: string;
  userEmail?: string;
  userName?: string;
  artCategory: string;
  date: string;
  timing: string;
  location: string;
  phone: string;
  whatsapp?: string;
  requirements: string;
  referenceImages: string[];
  paymentStatus: 'pending' | 'paid' | 'failed';
  amount: number;
  status: 'pending' | 'accepted' | 'in_progress' | 'completed' | 'cancelled';
  createdAt: string;
  statusHistory?: StatusHistoryItem[];
  adminNotes?: string;
  communicationLog?: CustomerMessage[];
  rescheduleRequested?: boolean;
  rescheduleDate?: string;
  rescheduleTiming?: string;
  whatsappAlertSent?: boolean;
  reminderSent?: boolean;
}

export interface GalleryItem {
  id: string;
  title: string;
  description: string;
  category: string;
  mediaUrl: string;
  mediaType: 'image' | 'video';
  createdAt: any;
}

export interface ArtService {
  id: string;
  title: string;
  description: string;
  price: number;
  image: string;
  category: string;
  isActive: boolean;
  mediaType?: 'image' | 'video' | null;
  premiumPrice?: number;
  duration?: string;
  deliveryTime?: string;
  materials?: string;
  sizePricingJSON?: string; // Stored as a JSON string of sizing array or records
  customOptionsJSON?: string; // Stored as a JSON string of custom toggle options
  discountOffer?: number;   // discount scale
}

export interface HeroMedia {
  id: string;
  title: string;
  description?: string;
  category?: string;
  mediaUrl: string;
  mediaType: 'image' | 'video';
  uploadedAt: any;
  isFeatured: boolean;
  videoStartTime?: number;
  videoEndTime?: number;
  videoVolume?: number;
  videoSpeed?: number;
}
