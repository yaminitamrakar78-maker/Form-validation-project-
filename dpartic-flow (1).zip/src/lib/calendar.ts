export function generateIcsContent(booking: {
  id: string;
  artCategory: string;
  date: string;
  timing: string;
  location: string;
  requirements?: string;
}): string {
  // Parsing date from YYYY-MM-DD
  const dateParts = booking.date.split('-'); // e.g., ['2026', '05', '27']
  let year = dateParts[0] || '2026';
  let month = dateParts[1] || '01';
  let day = dateParts[2] || '01';

  // Default start hour and end hour range
  let startHour = '09';
  let startMinute = '00';
  let endHour = '18';
  let endMinute = '00';

  const timingLower = booking.timing.toLowerCase();
  
  // Try to parse booking.timing (e.g. "6 PM - 10 PM" or "18:00")
  const hourMatch = timingLower.match(/(\d+)\s*(pm|am|:(\d+))?/);
  if (hourMatch) {
    let rawHour = parseInt(hourMatch[1], 10);
    const isPm = timingLower.includes('pm') || (rawHour < 12 && (timingLower.includes('evening') || timingLower.includes('night')));
    const isAm = timingLower.includes('am') || (rawHour < 12 && timingLower.includes('morning'));
    
    if (isPm && rawHour < 12) {
      rawHour += 12;
    } else if (isAm && rawHour === 12) {
      rawHour = 0;
    }
    
    startHour = rawHour.toString().padStart(2, '0');
    if (hourMatch[3]) {
      startMinute = hourMatch[3].padStart(2, '0');
    }
    
    // Default end hour to +3 hours after start hour
    let endHr = (rawHour + 3) % 24;
    endHour = endHr.toString().padStart(2, '0');
    endMinute = startMinute;
  }

  const dtStamp = new Date().toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
  const dtStart = `${year}${month}${day}T${startHour}${startMinute}00`;
  const dtEnd = `${year}${month}${day}T${endHour}${endMinute}00`;

  const title = `DPartic Flow Art - ${booking.artCategory}`;
  const description = `Live Art booking with Deepak Prajapati.\n\nType: ${booking.artCategory}\nTiming: ${booking.timing}\nLocation: ${booking.location}\nRequirements: ${booking.requirements || 'N/A'}\n\nThank you for choosing high-end fine art.`;

  // Escape special characters for ICS format
  const escapedDesc = description.replace(/\\/g, '\\\\').replace(/,/g, '\\,').replace(/;/g, '\\;').replace(/\n/g, '\\n');
  const escapedLocation = booking.location.replace(/\\/g, '\\\\').replace(/,/g, '\\,').replace(/;/g, '\\;');

  return [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//DPartic Flow//Art Booking//EN',
    'CALSCALE:GREGORIAN',
    'METHOD:PUBLISH',
    'BEGIN:VEVENT',
    `UID:booking-${booking.id}@dparticflow.com`,
    `DTSTAMP:${dtStamp}`,
    `DTSTART:${dtStart}`,
    `DTEND:${dtEnd}`,
    `SUMMARY:${title}`,
    `DESCRIPTION:${escapedDesc}`,
    `LOCATION:${escapedLocation}`,
    'STATUS:CONFIRMED',
    'BEGIN:VALARM',
    'TRIGGER:-PT24H',
    'ACTION:DISPLAY',
    'DESCRIPTION:Reminder: Your Live Art Event with DPartic Flow is tomorrow!',
    'END:VALARM',
    'END:VEVENT',
    'END:VCALENDAR'
  ].join('\r\n');
}

export function downloadIcsFile(booking: {
  id: string;
  artCategory: string;
  date: string;
  timing: string;
  location: string;
  requirements?: string;
}) {
  const content = generateIcsContent(booking);
  const blob = new Blob([content], { type: 'text/calendar;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `dpartic-flow-booking-${booking.id}.ics`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function getGoogleCalendarUrl(booking: {
  id: string;
  artCategory: string;
  date: string;
  timing: string;
  location: string;
  requirements?: string;
}): string {
  const dateParts = booking.date.split('-');
  let year = dateParts[0] || '2026';
  let month = dateParts[1] || '01';
  let day = dateParts[2] || '01';

  let startHour = '09';
  let endHour = '12';

  const timingLower = booking.timing.toLowerCase();
  const hourMatch = timingLower.match(/(\d+)\s*(pm|am|:(\d+))?/);
  if (hourMatch) {
    let rawHour = parseInt(hourMatch[1], 10);
    const isPm = timingLower.includes('pm') || (rawHour < 12 && (timingLower.includes('evening') || timingLower.includes('night')));
    if (isPm && rawHour < 12) rawHour += 12;
    startHour = rawHour.toString().padStart(2, '0');
    let endHr = (rawHour + 3) % 24;
    endHour = endHr.toString().padStart(2, '0');
  }

  const dtStart = `${year}${month}${day}T${startHour}0000`;
  const dtEnd = `${year}${month}${day}T${endHour}0000`;

  const text = encodeURIComponent(`DPartic Flow Art - ${booking.artCategory}`);
  const dates = `${dtStart}/${dtEnd}`;
  const details = encodeURIComponent(`Live Art booking with Deepak Prajapati.\nTiming: ${booking.timing}\nRequirements: ${booking.requirements || 'N/A'}`);
  const location = encodeURIComponent(booking.location);

  return `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${text}&dates=${dates}&details=${details}&location=${location}`;
}
