import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../context/AuthContext';
import { ArtService } from '../types';
import { Calendar, Clock, MapPin, Phone, MessageSquare, Image, Loader2, CheckCircle, CreditCard, Sparkles, X, Receipt } from 'lucide-react';
import { useDropzone } from 'react-dropzone';
import { cn, formatCurrency } from '../lib/utils';
import toast from 'react-hot-toast';
import { ART_SERVICES } from '../constants';

declare global {
  interface Window {
    Razorpay: any;
  }
}

const handleImageError = (e: React.SyntheticEvent<HTMLImageElement, Event>) => {
  e.currentTarget.src = "https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?q=80&w=1000";
};

export default function Booking() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { user, profile, signInWithGoogle, isSigningIn, openAuthModal } = useAuth();
  
  const [services, setServices] = useState<ArtService[]>(ART_SERVICES);
  const [selectedService, setSelectedService] = useState<ArtService | null>(ART_SERVICES[0]);
  const [customPrice, setCustomPrice] = useState<number | null>(null);
  const [loadingServices, setLoadingServices] = useState(true);
  const [occupiedDates, setOccupiedDates] = useState<any[]>([]);
  const [dateConflict, setDateConflict] = useState<any | null>(null);

  const [formData, setFormData] = useState({
    artCategory: ART_SERVICES[0]?.id || '',
    date: '',
    timing: '',
    location: '',
    phone: '',
    whatsapp: '',
    requirements: '',
  });

  const [files, setFiles] = useState<File[]>([]);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [bookingDetails, setBookingDetails] = useState<any | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchServices = async () => {
      try {
        // Fetch occupied/blocked slots
        try {
          const occRes = await fetch('/api/public/occupied-dates');
          if (occRes.ok && occRes.headers.get('content-type')?.includes('application/json')) {
            const occData = await occRes.json();
            setOccupiedDates(occData);
          }
        } catch (occErr) {
          console.error("Error loading empty spaces:", occErr);
        }

        const res = await fetch('/api/public/services');
        let finalServices = ART_SERVICES;
        if (res.ok && res.headers.get('content-type')?.includes('application/json')) {
          const data = await res.json() as ArtService[];
          if (data && data.length > 0) {
            finalServices = data;
            setServices(data);
          }
        }
        
        const initialId = searchParams.get('service');
        const found = finalServices.find(s => s.id === initialId) || finalServices[0];
        setSelectedService(found);
        
        const qPrice = searchParams.get('price');
        const qSpecs = searchParams.get('specs');
        if (qPrice) {
          setCustomPrice(Number(qPrice));
        } else if (found) {
          setCustomPrice(found.price);
        }

        if (found) {
          setFormData(prev => ({ 
            ...prev, 
            artCategory: found.id,
            requirements: qSpecs ? decodeURIComponent(qSpecs) : prev.requirements
          }));
        }
      } catch (err) {
        console.error("Error loaded services Booking:", err);
        // Fallback already initialized in finalServices
        const initialId = searchParams.get('service');
        const found = ART_SERVICES.find(s => s.id === initialId) || ART_SERVICES[0];
        setSelectedService(found);
        
        const qPrice = searchParams.get('price');
        const qSpecs = searchParams.get('specs');
        if (qPrice) {
          setCustomPrice(Number(qPrice));
        } else if (found) {
          setCustomPrice(found.price);
        }

        if (found) {
          setFormData(prev => ({ 
            ...prev, 
            artCategory: found.id,
            requirements: qSpecs ? decodeURIComponent(qSpecs) : prev.requirements
          }));
        }
      } finally {
        setLoadingServices(false);
      }
    };
    fetchServices();
  }, [searchParams]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    accept: { 'image/*': [] },
    multiple: true,
    onDrop: (acceptedFiles: File[]) => setFiles(prev => [...prev, ...acceptedFiles])
  } as any);

  const handleDateChange = (val: string) => {
    // Check conflicts
    const conflict = occupiedDates.find(d => d.date === val);
    if (conflict) {
      setDateConflict(conflict);
      toast(`Atelier Availability Notice: ${val} is currently unavailable (${conflict.reason}). Please select another date to secure Deepak.`, {
        icon: "⚜️",
        duration: 5000
      });
    } else {
      setDateConflict(null);
    }
    setFormData(prev => ({ ...prev, date: val }));
  };

  const loadRazorpay = () => {
    return new Promise((resolve) => {
      const script = document.createElement("script");
      script.src = "https://checkout.razorpay.com/v1/checkout.js";
      script.onload = () => resolve(true);
      script.onerror = () => resolve(false);
      document.body.appendChild(script);
    });
  };

  const handleBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      openAuthModal('signin');
      return;
    }
    if (!selectedService) return;
    if (dateConflict) {
      toast.error("Selected date is unavailable. Please pick an alternative open calendar date.", { icon: "❌" });
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const res = await loadRazorpay();
      if (!res) throw new Error("Razorpay SDK failed to load.");

      const imageUrls: string[] = [];
      if (files.length > 0) {
        for (let i = 0; i < files.length; i++) {
          const file = files[i];
          toast.loading(`Uploading reference ${i + 1}/${files.length}...`, { id: 'upload' });
          
          const formDataObj = new FormData();
          formDataObj.append('file', file);
          
          const uploadRes = await fetch(`/api/media/upload?folder=bookings`, {
            method: 'POST',
            body: formDataObj,
          });
          
          if (!uploadRes.ok) throw new Error(`Failed to upload reference image ${file.name}`);
          let uploadData: any = {};
          if (uploadRes.headers.get('content-type')?.includes('application/json')) {
            uploadData = await uploadRes.json();
          } else {
            throw new Error(`Invalid response format from upload: ${await uploadRes.text()}`);
          }
          imageUrls.push(uploadData.url);
        }
        toast.success('All references uploaded 🎨', { id: 'upload' });
      }

      const orderRes = await fetch('/api/create-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: customPrice || selectedService.price,
          receipt: `booking_${Date.now()}`,
        }),
      });
      if (!orderRes.ok) {
        throw new Error("Failed to create booking order payment session. Please check key configuration.");
      }
      let order: any = {};
      if (orderRes.headers.get('content-type')?.includes('application/json')) {
        order = await orderRes.json();
      } else {
        throw new Error(`Invalid response format from order creation: ${await orderRes.text()}`);
      }

      const options = {
        key: (import.meta as any).env.VITE_RAZORPAY_KEY_ID || "rzp_test_placeholder",
        amount: order.amount,
        currency: order.currency,
        name: "DPartic Flow",
        description: `Booking for ${selectedService.title}`,
        order_id: order.id,
        handler: async (response: any) => {
          toast.success('Payment completed successfully');
          const bookingPromise = async () => {
            const bookingDoc = {
              userId: user.uid,
              userEmail: user.email,
              userName: profile?.displayName || user.displayName,
              ...formData,
              artCategory: selectedService.title,
              referenceImages: imageUrls,
              paymentStatus: 'paid',
              razorpayPaymentId: response.razorpay_payment_id,
              razorpayOrderId: response.razorpay_order_id,
              amount: customPrice || selectedService.price,
              status: 'pending',
              createdAt: new Date().toISOString(),
              serviceImage: selectedService.image,
            };
            const saveRes = await fetch('/api/bookings/create', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(bookingDoc)
            });
            if (!saveRes.ok) throw new Error("Failed to save booking details to database");
            let savedData: any = {};
            if (saveRes.headers.get('content-type')?.includes('application/json')) {
              savedData = await saveRes.json();
            } else {
              throw new Error("Unable to read server response in JSON format");
            }
            setBookingDetails({ ...bookingDoc, id: savedData.id });
            setSuccess(true);
          };
          toast.promise(bookingPromise(), {
            loading: 'Submitting booking...',
            success: 'Booking request submitted ✨',
            error: 'Failed to submit booking',
          });
        },
        modal: {
          ondismiss: () => {
            toast.error('Payment cancelled');
          }
        },
        prefill: {
          name: profile?.displayName || user.displayName || "",
          email: user.email || "",
          contact: formData.phone || "",
        },
        theme: { color: "#f59e0b" },
      };

      if (order.isSimulated) {
        toast("Atelier Sandbox checkout activated due to placeholder key configuration.", { icon: "💳" });
        setTimeout(() => {
          options.handler({
            razorpay_payment_id: `pay_simulated_${Math.random().toString(36).substring(2, 11)}`,
            razorpay_order_id: order.id
          });
        }, 1000);
        return;
      }

      if (typeof (window as any).Razorpay === "undefined") {
        console.warn("Razorpay SDK not loaded in window. Falling back to sandbox checkout simulation.");
        toast("Simulating secure checkout via Atelier Studio Sandbox...", { icon: "🎨" });
        setTimeout(() => {
          options.handler({
            razorpay_payment_id: `pay_simulated_${Math.random().toString(36).substring(2, 11)}`,
            razorpay_order_id: order.id
          });
        }, 1000);
        return;
      }

      const paymentObject = new (window as any).Razorpay(options);
      paymentObject.open();
    } catch (err: any) {
      toast.error(err.message || "An unexpected error occurred.");
      if (err.message && err.message.startsWith('{')) {
        setError("Database error. Please contact support.");
      } else {
        setError(err.message || "An unexpected error occurred.");
      }
    } finally {
      setLoading(false);
    }
  };

  if (loadingServices) return <div className="min-h-screen bg-black flex items-center justify-center"><Loader2 className="h-10 w-10 text-amber-500 animate-spin" /></div>;

  // Success state is now handled natively via an elegant custom modal overlay at the bottom of the root wrapper

  return (
    <div className="min-h-screen bg-black pt-32 pb-20 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          <div>
            <span className="text-amber-500 text-xs font-bold uppercase tracking-[0.4em] mb-4 block">Reservation</span>
            <h1 className="text-4xl md:text-6xl font-serif italic font-bold text-beige-100 mb-8 tracking-tighter leading-tight">
              BOOK YOUR <br /> <span className="text-amber-500 italic">ARTIST</span>
            </h1>
            
            {selectedService && (
              <div className="bg-zinc-900/50 border border-amber-500/10 rounded-3xl p-8 mb-8 backdrop-blur-sm">
                <div className="flex items-center space-x-6 mb-8">
                  <img src={selectedService.image || undefined} onError={handleImageError} className="w-24 h-24 rounded-2xl object-cover" alt="Art" />
                  <div>
                    <h3 className="text-xl font-bold text-white">{selectedService.title}</h3>
                    <span className="text-amber-500 font-bold">{formatCurrency(customPrice || selectedService.price)}</span>
                  </div>
                </div>
                <p className="text-gray-400 text-sm mb-6">{selectedService.description}</p>
              </div>
            )}
            
            <div className="p-8 bg-amber-500/5 rounded-3xl border border-amber-500/10">
              <h4 className="text-amber-500 font-bold uppercase tracking-widest text-xs mb-4">Masterpiece Quality</h4>
              <p className="text-gray-400 text-xs leading-relaxed mb-4">
                Connect directly with the artist to customize your experience. Your security is our priority, and all transitions are encrypted.
              </p>
              <div className="pt-4 border-t border-amber-500/10 flex items-center justify-between">
                <span className="text-[10px] text-gray-500 uppercase tracking-widest">Need help booking?</span>
                <a href="https://wa.me/919131051376" target="_blank" rel="noopener noreferrer" className="text-amber-500 text-[10px] font-bold uppercase tracking-widest hover:underline">Chat with us</a>
              </div>
            </div>
          </div>

          <div className="bg-zinc-900/40 border border-white/5 rounded-[2rem] p-8 md:p-12 backdrop-blur-xl">
            {!user ? (
               <div className="text-center py-20 flex flex-col items-center justify-center">
                <span className="text-[10px] uppercase tracking-[0.3em] text-amber-500 font-bold mb-3 font-mono">Bespoke Experiences</span>
                <h3 className="text-3xl font-bold text-white mb-4 font-serif">Authenticate to Continue</h3>
                <p className="text-gray-400 text-xs max-w-sm leading-relaxed mb-8">
                  Sign in or create an account to customize your luxury event live paintings, view active bookings, and stream high-definition canvas replays.
                </p>
                <button 
                  onClick={() => openAuthModal('signin')} 
                  className="px-10 py-4 bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-black font-extrabold rounded-full uppercase tracking-widest transition-all transform hover:scale-105 shadow-lg shadow-amber-500/20"
                >
                  Sign In / Sign Up
                </button>
              </div>
            ) : (
              <form onSubmit={handleBooking} className="space-y-6">
                <div className="space-y-2">
                  <label className="text-[10px] uppercase tracking-widest text-gray-500 ml-2">Select Artwork</label>
                  <select 
                    className="w-full bg-black/50 border border-white/10 rounded-2xl py-4 px-4 text-white focus:outline-none focus:border-amber-500 appearance-none"
                    value={formData.artCategory}
                    onChange={e => {
                      setFormData({...formData, artCategory: e.target.value});
                      const s = services.find(si => si.id === e.target.value) || null;
                      setSelectedService(s);
                      if (s) {
                        setCustomPrice(s.price);
                      }
                    }}
                  >
                    {services.map(s => <option key={s.id} value={s.id}>{s.title}</option>)}
                  </select>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-[10px] uppercase tracking-widest text-gray-500 ml-2">Event Date</label>
                    <input type="date" required className={cn("w-full bg-black/50 border rounded-2xl py-4 px-4 text-white focus:outline-none transition-colors", dateConflict ? "border-red-500 focus:border-red-500" : "border-white/10 focus:border-amber-500")} value={formData.date} onChange={e => handleDateChange(e.target.value)} />
                    {dateConflict && (
                      <p className="text-[10px] text-red-400 mt-1 ml-2 font-mono uppercase tracking-wider">
                        ⚠️ Busy: Conflict with "{dateConflict.reason}"
                      </p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] uppercase tracking-widest text-gray-500 ml-2">Timing</label>
                    <input type="text" required placeholder="e.g. 6 PM - 10 PM" className="w-full bg-black/50 border border-white/10 rounded-2xl py-4 px-4 text-white focus:outline-none focus:border-amber-500 transition-colors" onChange={e => setFormData({...formData, timing: e.target.value})} />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] uppercase tracking-widest text-gray-500 ml-2">Location</label>
                  <input type="text" required placeholder="Venue, City" className="w-full bg-black/50 border border-white/10 rounded-2xl py-4 px-4 text-white focus:outline-none focus:border-amber-500 transition-colors" onChange={e => setFormData({...formData, location: e.target.value})} />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-[10px] uppercase tracking-widest text-gray-500 ml-2">Phone Number (Calling)</label>
                    <input type="tel" required placeholder="+91 XXXXX XXXXX" className="w-full bg-black/50 border border-white/10 rounded-2xl py-4 px-4 text-white focus:outline-none focus:border-amber-500 transition-colors" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] uppercase tracking-widest text-gray-500 ml-2">WhatsApp Number (Alerts)</label>
                    <input type="tel" required placeholder="+91 XXXXX XXXXX" className="w-full bg-black/50 border border-white/10 rounded-2xl py-4 px-4 text-white focus:outline-none focus:border-amber-500 transition-colors" value={formData.whatsapp} onChange={e => setFormData({...formData, whatsapp: e.target.value})} />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] uppercase tracking-widest text-gray-500 ml-2">Vision & Requirements</label>
                  <textarea placeholder="Describe your creative vision..." className="w-full bg-black/50 border border-white/10 rounded-2xl py-4 px-4 text-white focus:outline-none focus:border-amber-500 transition-colors min-h-[100px]" onChange={e => setFormData({...formData, requirements: e.target.value})} />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] uppercase tracking-widest text-gray-500 ml-2">References</label>
                  <div {...getRootProps()} className={cn("border-2 border-dashed rounded-2xl p-6 text-center transition-all", isDragActive ? "border-amber-500 bg-amber-500/5" : "border-white/10")}>
                    <input {...getInputProps()} />
                    <p className="text-[10px] text-gray-400 uppercase tracking-widest">Drop Moodboard/References</p>
                  </div>
                </div>

                {error && <p className="text-red-400 text-xs italic">{error}</p>}

                <button type="submit" disabled={loading || !selectedService} className="w-full py-5 bg-amber-500 text-white font-serif font-bold italic rounded-2xl tracking-widest hover:bg-amber-400 transition-all flex items-center justify-center space-x-3 text-lg">
                  {loading ? <Loader2 className="h-6 w-6 animate-spin" /> : <span>Secure & Proceed ({formatCurrency(customPrice || selectedService?.price || 0)})</span>}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>

      {/* Confirmation Modal with Booking Details */}
      <AnimatePresence>
        {success && bookingDetails && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md overflow-y-auto"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="max-w-xl w-full bg-zinc-950 border border-amber-500/30 rounded-[2.5rem] p-6 md:p-10 shadow-2xl shadow-amber-500/10 relative my-8"
            >
              {/* Close Button */}
              <button 
                onClick={() => {
                  setSuccess(false);
                  setBookingDetails(null);
                  setFiles([]);
                  setFormData({
                    artCategory: selectedService?.id || '',
                    date: '',
                    timing: '',
                    location: '',
                    phone: '',
                    whatsapp: '',
                    requirements: '',
                  });
                }}
                className="absolute top-6 right-6 p-2 bg-white/5 rounded-full text-gray-400 hover:text-white hover:bg-white/10 transition-colors"
                id="close-booking-modal-btn"
              >
                <X className="h-5 w-5" />
              </button>

              {/* Header */}
              <div className="flex flex-col items-center text-center pb-6 border-b border-white/10 mb-6">
                <div className="w-16 h-16 bg-amber-500/20 rounded-full flex items-center justify-center mb-4 relative">
                  <CheckCircle className="h-8 w-8 text-amber-500 absolute" />
                  <motion.div 
                    animate={{ rotate: 360 }}
                    transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
                    className="absolute inset-0 border-2 border-dashed border-amber-500/40 rounded-full"
                  />
                </div>
                <h2 className="text-2xl md:text-3xl font-serif italic font-bold text-white tracking-tight mb-1">
                  BOOKING CONFIRMED!
                </h2>
                <p className="text-gray-400 text-xs font-light">
                  Your payment was received. Here are your booking details:
                </p>
              </div>

              {/* Receipt Details */}
              <div className="space-y-4 mb-6 text-left">
                {/* Service Item Banner */}
                <div className="flex items-center space-x-4 bg-zinc-900/60 p-4 rounded-2xl border border-white/5">
                  {!!bookingDetails.serviceImage && (
                    <img src={bookingDetails.serviceImage || undefined} onError={handleImageError} className="w-14 h-14 rounded-xl object-cover border border-white/10" alt="Service" />
                  )}
                  <div className="flex-1 min-w-0">
                    <span className="text-[9px] uppercase tracking-wider text-amber-500 font-bold block">Art Category</span>
                    <h3 className="text-sm font-bold text-white truncate">{bookingDetails.artCategory}</h3>
                  </div>
                  <div className="text-right">
                    <span className="text-[9px] uppercase tracking-wider text-gray-500 block">Amount Paid</span>
                    <span className="text-amber-500 font-bold text-sm md:text-base">{formatCurrency(bookingDetails.amount)}</span>
                  </div>
                </div>

                {/* Info Grid */}
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="bg-zinc-900/40 p-3 rounded-2xl border border-white/5 space-y-1">
                    <div className="flex items-center text-gray-500 space-x-1.5">
                      <Calendar className="h-3.5 w-3.5 text-amber-500/70" />
                      <span className="text-[10px] uppercase tracking-wider font-semibold">Date</span>
                    </div>
                    <p className="text-white font-medium pl-5">{bookingDetails.date}</p>
                  </div>

                  <div className="bg-zinc-900/40 p-3 rounded-2xl border border-white/5 space-y-1">
                    <div className="flex items-center text-gray-500 space-x-1.5">
                      <Clock className="h-3.5 w-3.5 text-amber-500/70" />
                      <span className="text-[10px] uppercase tracking-wider font-semibold">Timing</span>
                    </div>
                    <p className="text-white font-medium pl-5">{bookingDetails.timing}</p>
                  </div>

                  <div className="bg-zinc-900/40 p-3 rounded-2xl border border-white/5 space-y-1 col-span-2">
                    <div className="flex items-center text-gray-500 space-x-1.5">
                      <MapPin className="h-3.5 w-3.5 text-amber-500/70" />
                      <span className="text-[10px] uppercase tracking-wider font-semibold">Location</span>
                    </div>
                    <p className="text-white font-medium pl-5 truncate">{bookingDetails.location}</p>
                  </div>

                  <div className="bg-zinc-900/40 p-3 rounded-2xl border border-white/5 space-y-1 col-span-2">
                    <div className="flex items-center text-gray-500 space-x-1.5">
                      <Phone className="h-3.5 w-3.5 text-amber-500/70" />
                      <span className="text-[10px] uppercase tracking-wider font-semibold">Phone</span>
                    </div>
                    <p className="text-white font-medium pl-5">{bookingDetails.phone}</p>
                  </div>
                </div>

                {/* Requirements & References */}
                {(bookingDetails.requirements || (bookingDetails.referenceImages && bookingDetails.referenceImages.length > 0)) && (
                  <div className="bg-zinc-900/30 p-4 rounded-2xl border border-white/5 space-y-3 text-xs">
                    {bookingDetails.requirements && (
                      <div className="space-y-1">
                        <div className="flex items-center text-gray-500 space-x-1.5">
                          <MessageSquare className="h-3.5 w-3.5 text-amber-500/70" />
                          <span className="text-[10px] uppercase tracking-wider font-semibold">Creative Vision</span>
                        </div>
                        <p className="text-gray-300 italic pl-5 leading-relaxed bg-black/20 p-2.5 rounded-xl border border-white/5">
                          "{bookingDetails.requirements}"
                        </p>
                      </div>
                    )}

                    {bookingDetails.referenceImages && bookingDetails.referenceImages.length > 0 && (
                      <div className="space-y-2">
                        <div className="flex items-center text-gray-500 space-x-1.5">
                          <Image className="h-3.5 w-3.5 text-amber-500/70" />
                          <span className="text-[10px] uppercase tracking-wider font-semibold">
                            Reference Images ({bookingDetails.referenceImages.length})
                          </span>
                        </div>
                        <div className="flex flex-wrap gap-2 pl-5">
                          {bookingDetails.referenceImages.slice(0, 4).map((url: string, idx: number) => (
                            <img 
                              key={idx} 
                              src={url || undefined} 
                              onError={handleImageError}
                              className="w-10 h-10 rounded-lg object-cover border border-white/10 hover:border-amber-500/50 transition-colors cursor-pointer" 
                              alt={`Reference ${idx + 1}`} 
                              onClick={() => window.open(url, '_blank')}
                            />
                          ))}
                          {bookingDetails.referenceImages.length > 4 && (
                            <div className="w-10 h-10 rounded-lg bg-zinc-800 flex items-center justify-center text-gray-400 text-xs border border-white/10">
                              +{bookingDetails.referenceImages.length - 4}
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Footer Meta */}
                <div className="flex items-center justify-between text-[10px] text-gray-500 font-mono pt-2 px-1">
                  <span>PAYMENT ID:</span>
                  <span className="text-gray-300 select-all hover:text-amber-500 transition-colors">
                    {bookingDetails.razorpayPaymentId || "n/a"}
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <button
                  onClick={() => {
                    setSuccess(false);
                    setBookingDetails(null);
                    setFiles([]);
                    setFormData({
                      artCategory: selectedService?.id || '',
                      date: '',
                      timing: '',
                      location: '',
                      phone: '',
                      requirements: '',
                    });
                  }}
                  className="w-full py-4 bg-zinc-900 border border-white/10 text-white font-semibold rounded-2xl uppercase tracking-widest text-[10px] hover:bg-zinc-800 transition-all text-center font-mono"
                  id="book-another-btn"
                >
                  Book Another
                </button>
                <button
                  onClick={() => {
                    setSuccess(false);
                    setBookingDetails(null);
                    navigate('/dashboard');
                  }}
                  className="w-full py-4 bg-amber-500 text-black font-semibold rounded-2xl uppercase tracking-widest text-[10px] hover:bg-amber-400 transition-all text-center font-mono"
                  id="dashboard-btn"
                >
                  Go to Dashboard
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
