import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Mail, Phone, MapPin, MessageSquare, Send, Globe, Instagram, Facebook, Twitter } from 'lucide-react';
import toast from 'react-hot-toast';

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Use high-end toast notifications instead of standard blocking alerts
    toast.success("Thank you for reaching out! Deepak Prajapati has received your message and will contact you shortly over Phone / Email. ✨");
    setFormData({ name: '', email: '', subject: '', message: '' });
  };

  return (
    <div className="min-h-screen bg-black pt-40 pb-20 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <motion.span 
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-amber-500 text-xs font-bold uppercase tracking-[0.4em] mb-4 block"
          >
            Get In Touch
          </motion.span>
          <motion.h1 
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-5xl md:text-7xl font-serif font-bold text-beige-100 tracking-tighter"
          >
            CONTACT <span className="text-amber-500 italic">CONCIERGE</span>
          </motion.h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          <motion.div 
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="space-y-12"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="p-8 bg-zinc-900/40 border border-white/5 rounded-3xl backdrop-blur-xl">
                <Mail className="h-8 w-8 text-amber-500 mb-6" />
                <h3 className="text-white font-bold mb-2">Email Us</h3>
                <p className="text-gray-400 text-sm mb-4">For bookings and inquiries</p>
                <a href="mailto:kalavantdeepak1712@gmail.com" className="text-amber-500 text-sm font-bold truncate block">kalavantdeepak1712@gmail.com</a>
              </div>
              <div className="p-8 bg-zinc-900/40 border border-white/5 rounded-3xl backdrop-blur-xl">
                <Phone className="h-8 w-8 text-amber-500 mb-6" />
                <h3 className="text-white font-bold mb-2">Call Us</h3>
                <p className="text-gray-400 text-sm mb-4">Available 10 AM - 8 PM</p>
                <a href="tel:9131051376" className="text-amber-500 text-sm font-bold">+91 91310 51376</a>
              </div>
            </div>

            <div className="p-8 bg-zinc-900/40 border border-white/5 rounded-3xl backdrop-blur-xl">
              <MapPin className="h-8 w-8 text-amber-500 mb-6" />
              <h3 className="text-white font-bold mb-2">Studio Location</h3>
              <p className="text-gray-400 text-sm">Abhanpur, Raipur, Chhattisgarh</p>
            </div>

            <div className="flex space-x-6 pt-4">
              <a href="https://wa.me/9131051376" target="_blank" rel="noopener noreferrer" className="p-4 bg-amber-500/10 rounded-full text-amber-500 hover:bg-amber-500 hover:text-black transition-all">
                <MessageSquare className="h-6 w-6" />
              </a>
              <a href="https://www.instagram.com/dpartic_flow" target="_blank" rel="noopener noreferrer" className="p-4 bg-amber-500/10 rounded-full text-amber-500 hover:bg-amber-500 hover:text-black transition-all">
                <Instagram className="h-6 w-6" />
              </a>
              <a href="#" className="p-4 bg-amber-500/10 rounded-full text-amber-500 hover:bg-amber-500 hover:text-black transition-all">
                <Twitter className="h-6 w-6" />
              </a>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="bg-zinc-900/40 border border-white/5 rounded-[2.5rem] p-8 md:p-12 backdrop-blur-xl"
          >
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] uppercase tracking-widest text-gray-500 ml-2">Name</label>
                  <input 
                    type="text" 
                    required 
                    className="w-full bg-black/50 border border-white/10 rounded-2xl py-4 px-4 text-white focus:outline-none focus:border-amber-500 transition-colors"
                    value={formData.name}
                    onChange={e => setFormData({...formData, name: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] uppercase tracking-widest text-gray-500 ml-2">Email</label>
                  <input 
                    type="email" 
                    required 
                    className="w-full bg-black/50 border border-white/10 rounded-2xl py-4 px-4 text-white focus:outline-none focus:border-amber-500 transition-colors"
                    value={formData.email}
                    onChange={e => setFormData({...formData, email: e.target.value})}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] uppercase tracking-widest text-gray-500 ml-2">Subject</label>
                <input 
                  type="text" 
                  required 
                  className="w-full bg-black/50 border border-white/10 rounded-2xl py-4 px-4 text-white focus:outline-none focus:border-amber-500 transition-colors"
                  value={formData.subject}
                  onChange={e => setFormData({...formData, subject: e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] uppercase tracking-widest text-gray-500 ml-2">Message</label>
                <textarea 
                  required 
                  className="w-full bg-black/50 border border-white/10 rounded-2xl py-4 px-4 text-white focus:outline-none focus:border-amber-500 transition-colors min-h-[150px]"
                  value={formData.message}
                  onChange={e => setFormData({...formData, message: e.target.value})}
                ></textarea>
              </div>
              <button 
                type="submit" 
                className="w-full py-5 bg-amber-500 text-black font-bold rounded-2xl uppercase tracking-[0.2em] flex items-center justify-center space-x-3 hover:bg-amber-400 transition-all"
              >
                <Send className="h-5 w-5" />
                <span>Send Message</span>
              </button>
            </form>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
