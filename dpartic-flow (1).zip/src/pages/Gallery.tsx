import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { GalleryItem } from '../types';
import { X, Maximize2, Play, Image as ImageIcon, ZoomIn, ZoomOut, RotateCcw, ChevronLeft, ChevronRight, Sparkles, Search } from 'lucide-react';
import { cn } from '../lib/utils';

const handleImageError = (e: React.SyntheticEvent<HTMLImageElement, Event>) => {
  e.currentTarget.src = "https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?q=80&w=1000";
};

// Premium high-res fallback gallery items representing Deepak's creations
const DEFAULT_GALLERY_ITEMS: GalleryItem[] = [
  {
    id: 'gallery-1',
    title: 'Eternal Wedding Vows Live Painting',
    category: 'Wedding Art',
    mediaUrl: 'https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&w=800&q=80',
    mediaType: 'image',
    description: 'Hand-painted live acrylic on premium Belgian linen capturing the royal exchange of vows.',
    createdAt: ''
  },
  {
    id: 'gallery-2',
    title: 'Sunkissed Heritage Couple Sketch',
    category: 'Live Sketches',
    mediaUrl: 'https://images.unsplash.com/photo-1512486130939-2c4f79935e4f?auto=format&fit=crop&w=800&q=80',
    mediaType: 'image',
    description: 'Elegant live minimal pencil portrait catching the subtle gleam of joy.',
    createdAt: ''
  },
  {
    id: 'gallery-3',
    title: 'The Golden Mandap Horizon',
    category: 'Wedding Art',
    mediaUrl: 'https://images.unsplash.com/photo-1549417229-aa67d3263c09?auto=format&fit=crop&w=800&q=80',
    mediaType: 'image',
    description: 'Bespoke live landscape of the floral altar during high-end seaside sunset vows.',
    createdAt: ''
  },
  {
    id: 'gallery-4',
    title: 'Cinematic Metal Dust Portrait Reveal',
    category: 'Couple Portraits',
    mediaUrl: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=800&q=80',
    mediaType: 'image',
    description: 'Interactive gold & brass glitter-dust portrait revealing the couple. Perfect event entertainment.',
    createdAt: ''
  },
  {
    id: 'gallery-5',
    title: 'Guests Premium Charcoal Sketches',
    category: 'Live Sketches',
    mediaUrl: 'https://images.unsplash.com/photo-1513364776144-60967b0f800f?auto=format&fit=crop&w=800&q=80',
    mediaType: 'image',
    description: 'Guests premium charcoal sketch souvenirs produced live in under five minutes.',
    createdAt: ''
  },
  {
    id: 'gallery-6',
    title: 'Royal Mandap oil canvas close up',
    category: 'Wedding Art',
    mediaUrl: 'https://images.unsplash.com/photo-1518156677180-95a2893f3e9f?auto=format&fit=crop&w=800&q=80',
    mediaType: 'image',
    description: 'Immaculate structural painting captures sacred flame of pheras.',
    createdAt: ''
  },
  {
    id: 'gallery-7',
    title: 'Delicate Portrait Gift Painting',
    category: 'Couple Portraits',
    mediaUrl: 'https://images.unsplash.com/photo-1460661419201-fd4cecdf8a8b?auto=format&fit=crop&w=800&q=80',
    mediaType: 'image',
    description: 'Hand-delivered acrylic portrait customized with metal gilded elements.',
    createdAt: ''
  },
  {
    id: 'gallery-8',
    title: 'Fine Linens and Altar Shadows',
    category: 'Custom Gifts',
    mediaUrl: 'https://images.unsplash.com/photo-1515934751635-c81c6bc9a2d8?auto=format&fit=crop&w=800&q=80',
    mediaType: 'image',
    description: 'Bespoke study of live shadows cast under Indian luxury event candle flares.',
    createdAt: ''
  },
  {
    id: 'gallery-9',
    title: 'Miniature Ceramic Sovereign Altar',
    category: 'Clay Art',
    mediaUrl: 'https://images.unsplash.com/photo-1576016770956-debb63d900ad?auto=format&fit=crop&w=800&q=80',
    mediaType: 'image',
    description: 'Exclusive hand-molded clay structures of spiritual mandirs decorated with heavy pure metallic gold gilding.',
    createdAt: ''
  },
  {
    id: 'gallery-10',
    title: 'Royal Custom Bridal Portrait Gift',
    category: 'Custom Gifts',
    mediaUrl: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=800&q=80',
    mediaType: 'image',
    description: 'Bespoke anniversary portrait commission gifted on heavy wood blocks.',
    createdAt: ''
  }
];

export default function Gallery() {
  const [items, setItems] = useState<GalleryItem[]>(DEFAULT_GALLERY_ITEMS);
  const [loading, setLoading] = useState(true);
  const [selectedMedia, setSelectedMedia] = useState<GalleryItem | null>(null);
  const [activeFilter, setActiveFilter] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [zoom, setZoom] = useState(1);
  const [isFillMode, setIsFillMode] = useState(false);
  const [sliderPosition, setSliderPosition] = useState(50);

  const categories = [
    'All', 
    'Wedding Art', 
    'Live Sketches', 
    'Couple Portraits',
    'Custom Gifts',
    'Clay Art'
  ];

  useEffect(() => {
    const fetchGallery = async () => {
      try {
        const res = await fetch('/api/public/gallery');
        if (res.ok && res.headers.get('content-type')?.includes('application/json')) {
          const data = await res.json();
          if (data && data.length > 0) {
            setItems(data);
          } else {
            setItems(DEFAULT_GALLERY_ITEMS);
          }
        } else {
          setItems(DEFAULT_GALLERY_ITEMS);
        }
      } catch (error) {
        console.error("Error fetching gallery:", error);
        setItems(DEFAULT_GALLERY_ITEMS);
      } finally {
        setLoading(false);
      }
    };
    fetchGallery();
  }, []);

  // Reset zoom & fill toggle on media change
  useEffect(() => {
    setZoom(1);
    setIsFillMode(false);
  }, [selectedMedia]);

  const filteredItems = items.filter(item => {
    const matchesCategory = activeFilter === 'All' || item.category === activeFilter;
    const matchesSearch = searchQuery.trim() === '' || 
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
      item.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (item.description && item.description.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  const currentIndex = selectedMedia 
    ? filteredItems.findIndex(i => i.id === selectedMedia.id)
    : -1;

  const handlePrev = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (currentIndex > 0) {
      setSelectedMedia(filteredItems[currentIndex - 1]);
    } else {
      setSelectedMedia(filteredItems[filteredItems.length - 1]);
    }
  };

  const handleNext = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (currentIndex < filteredItems.length - 1) {
      setSelectedMedia(filteredItems[currentIndex + 1]);
    } else {
      setSelectedMedia(filteredItems[0]);
    }
  };

  const handleZoomIn = (e: React.MouseEvent) => {
    e.stopPropagation();
    setZoom(prev => Math.min(prev + 0.25, 3));
  };

  const handleZoomOut = (e: React.MouseEvent) => {
    e.stopPropagation();
    setZoom(prev => Math.max(prev - 0.25, 0.5));
  };

  const handleZoomReset = (e: React.MouseEvent) => {
    e.stopPropagation();
    setZoom(1);
  };

  const toggleFillMode = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsFillMode(prev => !prev);
  };

  return (
    <div className="min-h-screen bg-black pt-36 pb-24 px-4 relative">
      {/* Decorative luxury mesh backdrop */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.01)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.01)_1px,transparent_1px)] bg-[size:50px_50px] pointer-events-none" />
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-amber-500/[0.02] rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Gallery Header */}
        <div className="text-center mb-16 max-w-3xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-4"
          >
            <span className="text-amber-500 text-[10px] uppercase font-mono tracking-[0.4em] mb-3 block">
              Curated Masterpieces
            </span>
            <h1 className="text-4xl md:text-6xl font-serif font-extrabold text-white tracking-tight leading-none text-balance">
              The Fine Art <span className="text-amber-500 italic font-normal">Exhibitions</span>
            </h1>
            
            {/* Elegant handwritten accent */}
            <div className="py-2">
              <span className="font-script text-3xl sm:text-4xl text-amber-500/80 transform block -rotate-1 select-none">
                Gilded memories captured by Deepak’s hands
              </span>
            </div>

            <p className="text-xs sm:text-sm text-zinc-400 font-light leading-relaxed max-w-xl mx-auto text-balance">
              Every canvas represents continuous live creation. Filter through categories to witness original wedding paintings, custom gold-leaf reveals, and rapid high-society sketches.
            </p>
          </motion.div>

          {/* Luxury Rounded Categories Strip */}
          <div className="flex flex-wrap justify-center gap-2 mt-10 max-w-5xl mx-auto pb-4 overflow-x-auto scrollbar-none">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => {
                  setActiveFilter(cat);
                }}
                className={cn(
                  "px-4.5 py-2.5 rounded-full text-[9px] font-bold uppercase tracking-widest border transition-all cursor-pointer whitespace-nowrap",
                  activeFilter === cat 
                    ? "bg-amber-500 border-amber-500 text-black shadow-lg shadow-amber-500/10" 
                    : "border-white/5 bg-zinc-900/30 text-zinc-400 hover:border-amber-500/40 hover:text-white"
                )}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Luxury Artistic Search Input */}
          <div className="mt-8 max-w-md mx-auto relative group">
            <div className="absolute inset-y-0 left-5 flex items-center pointer-events-none text-zinc-500 group-focus-within:text-amber-500 transition-colors">
              <Search className="h-4 w-4" />
            </div>
            <input
              type="text"
              placeholder="Search masterpieces by title or category..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-16 py-3 bg-zinc-950/80 border border-white/5 rounded-full text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500/50 focus:ring-1 focus:ring-amber-500/20 transition-all font-light uppercase tracking-widest text-center"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute inset-y-0 right-4 flex items-center text-zinc-500 hover:text-amber-500 transition-colors cursor-pointer text-[9px] uppercase font-mono tracking-widest px-2"
              >
                Clear
              </button>
            )}
          </div>
        </div>

        {/* Before / After Transformation Sandbox (Goal: Section 6 Upgrade) */}
        <div className="mb-20 bg-zinc-950/60 p-6 md:p-10 rounded-[2.5rem] border border-white/5 relative overflow-hidden text-left">
          <div className="absolute top-4 right-10 text-amber-500/10 text-6xl font-serif pointer-events-none select-none">Atelier</div>
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-4 space-y-4">
              <span className="text-amber-500 text-[10px] uppercase font-mono tracking-[0.3em] block">
                Dynamic Metamorphosis
              </span>
              <h2 className="text-2xl md:text-3.5xl font-serif font-bold text-white leading-tight">
                Before / After <br />
                <span className="text-amber-500 italic">Event Canvas Glow</span>
              </h2>
              <p className="text-xs text-zinc-400 font-light leading-relaxed">
                Interact with the golden slider tool to reveal how a pristine, blank primed Belgian linen is dynamically transformed into an immortal luxury oil heirloom during a single live wedding event.
              </p>
              
              {/* Little stats box for process */}
              <div className="grid grid-cols-2 gap-4 pt-4 border-t border-white/5">
                <div>
                  <span className="text-[10px] text-zinc-500 uppercase tracking-widest font-mono block">Zero Hour</span>
                  <span className="text-white text-xs font-serif font-bold">Raw Prime Linen</span>
                </div>
                <div>
                  <span className="text-[10px] text-zinc-550 text-zinc-500 uppercase tracking-widest font-mono block">Hour Five</span>
                  <span className="text-amber-500 text-xs font-serif font-bold">Gilded Heirloom</span>
                </div>
              </div>
            </div>

            <div className="lg:col-span-8 flex flex-col items-center w-full">
              {/* Interactive Draggable Split-Screener */}
              <div className="relative w-full aspect-[16/9] rounded-[2rem] overflow-hidden border border-white/10 select-none shadow-[0_20px_50px_rgba(0,0,0,0.8)]">
                {/* BEFORE IMAGE (Full Backing) */}
                <div className="absolute inset-0 w-full h-full bg-black">
                  <img 
                    src="https://images.unsplash.com/photo-1579783928621-7a13d66a6211?auto=format&fit=crop&w=1200&q=80" 
                    className="w-full h-full object-cover brightness-60 select-none pointer-events-none" 
                    alt="Before: Pristine Primed wood layout" 
                  />
                  <div className="absolute top-4 left-4 bg-black/85 backdrop-blur-md px-3 py-1 rounded-full border border-white/10 text-[8px] font-mono uppercase tracking-widest text-zinc-400">
                    Before: Blank Easel
                  </div>
                </div>

                {/* AFTER IMAGE (Clipped Container Overlay) */}
                <div 
                  className="absolute inset-y-0 left-0 right-0 overflow-hidden transition-all bg-black"
                  style={{ width: `${sliderPosition}%` }}
                >
                  <div className="absolute inset-0 w-full h-full" style={{ width: '100%' }}>
                    <img 
                      src="https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&w=1200&q=80" 
                      className="w-full h-full object-cover select-none pointer-events-none" 
                      alt="After: Gilded Golden Acrylic" 
                    />
                    <div className="absolute top-4 left-4 bg-amber-500 text-black px-3 py-1 rounded-full text-[8px] font-mono uppercase tracking-widest font-extrabold shadow-md">
                      ✦ After: Finished Heirloom
                    </div>
                  </div>
                </div>

                {/* DRAGGABLE BAR LINE */}
                <div 
                  className="absolute inset-y-0 w-0.5 bg-amber-400 z-10 pointer-events-none flex items-center justify-center"
                  style={{ left: `${sliderPosition}%` }}
                >
                  <div className="w-8 h-8 rounded-full bg-amber-500 border-2 border-black flex items-center justify-center text-black font-serif text-sm font-bold shadow-lg shadow-amber-500/30 transform -translate-x-[45%] pointer-events-none select-none">
                    ✦
                  </div>
                </div>

                {/* FULL SURFACE INPUT SLIDER RANGE OVERLAY */}
                <input 
                  type="range" 
                  min="0" 
                  max="100" 
                  value={sliderPosition} 
                  onChange={(e) => setSliderPosition(Number(e.target.value))}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-ew-resize z-20"
                />
              </div>
              <div className="w-full flex justify-between items-center text-[9px] font-mono text-zinc-500 tracking-widest mt-3 px-4">
                <span>← SWIPE LEFT FOR BLANK CANVAS</span>
                <span className="text-amber-550">DRAG THE CENTER HANDLE</span>
                <span>SWIPE RIGHT FOR GILDED MASTERPIECE →</span>
              </div>
            </div>
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center py-32">
            <div className="flex flex-col items-center gap-4">
              <div className="w-10 h-10 border-2 border-amber-500/10 border-t-amber-500 rounded-full animate-spin" />
              <span className="text-[10px] text-zinc-500 uppercase tracking-widest font-mono">Curating Canvas...</span>
            </div>
          </div>
        ) : filteredItems.length === 0 ? (
          <div className="text-center py-32 border border-white/5 bg-zinc-900/10 rounded-[2.5rem] max-w-xl mx-auto">
            <ImageIcon className="h-10 w-10 text-zinc-700 mx-auto mb-4" />
            <h3 className="text-sm font-serif font-bold text-zinc-400 uppercase tracking-widest">Exhibition is currently idle</h3>
            <p className="text-xs text-zinc-600 mt-2 p-4">Our studio is preparing more magnificent canvases. Select other collections above to view.</p>
          </div>
        ) : (
          /* Curated Responsive Grid Portfolio Showcase with Cinematic Spacing */
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {filteredItems.map((item, index) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.04, duration: 0.5 }}
                className="relative group border border-white/5 bg-zinc-950/60 rounded-[1.8rem] overflow-hidden cursor-pointer flex flex-col justify-between hover:border-amber-500/30 transition-all duration-300 hover:shadow-[0_12px_30px_rgba(197,160,89,0.05)]"
                onClick={() => setSelectedMedia(item)}
              >
                {/* Visual Artwork Box - 100% contained, beautiful presentation */}
                <div className="relative overflow-hidden flex items-center justify-center bg-black h-72 w-full shrink-0">
                  {/* Blurry Backdrop Glow */}
                  <img src={item.mediaUrl || undefined} onError={handleImageError} className="absolute inset-0 w-full h-full object-cover blur-2xl opacity-15 scale-110 pointer-events-none select-none" alt="" />
                  
                  {item.mediaType === 'video' ? (
                    <div className="relative w-full h-full flex items-center justify-center z-10 p-1">
                      <video src={item.mediaUrl || undefined} className="max-w-full max-h-full object-contain rounded-xl" muted playsInline loop autoPlay />
                      <div className="absolute inset-0 flex items-center justify-center bg-black/30 group-hover:bg-black/50 transition-colors z-20">
                        <Play className="h-8 w-8 text-amber-500 fill-amber-500" />
                      </div>
                    </div>
                  ) : (
                    <img 
                      src={item.mediaUrl || undefined} 
                      onError={handleImageError}
                      alt={item.title} 
                      className="max-w-full max-h-full object-contain relative z-10 transition-transform duration-700 ease-out group-hover:scale-103 p-1.5 rounded-2xl" 
                    />
                  )}
                  
                  {/* Glowing card border indicator */}
                  <div className="absolute inset-0 border border-amber-500/0 group-hover:border-amber-500/10 rounded-[1.8rem] transition-colors pointer-events-none z-30" />
                  
                  {/* Custom hover metadata slides up */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/35 to-transparent opacity-0 group-hover:opacity-100 transition-opacity p-5 flex flex-col justify-end z-20">
                    <Maximize2 className="h-5 w-5 text-amber-400 absolute top-4 right-4" />
                    <span className="text-amber-500 text-[8px] uppercase font-mono tracking-widest font-bold mb-1">
                      {item.category}
                    </span>
                    <h4 className="text-white font-serif font-bold tracking-tight text-xs sm:text-sm line-clamp-2">
                      {item.title}
                    </h4>
                  </div>
                </div>

                {/* Constant aesthetic footer detailing artwork specifications */}
                <div className="p-4.5 bg-zinc-950 border-t border-white/[0.02] flex-grow flex flex-col justify-between">
                  <div className="flex items-center justify-between">
                    <span className="text-[8px] uppercase tracking-widest font-mono text-zinc-500">
                      {item.category}
                    </span>
                    <span className="text-[10px] text-amber-500">✦</span>
                  </div>
                  <h4 className="text-white font-serif font-bold italic text-xs truncate mt-1">
                    {item.title}
                  </h4>
                  {item.description && (
                    <p className="text-zinc-500 text-[9px] line-clamp-1 mt-0.5 tracking-wide">
                      {item.description}
                    </p>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {/* Exhibition Interactive Lightbox */}
        <AnimatePresence>
          {selectedMedia && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[100] bg-black/98 backdrop-blur-2xl flex items-center justify-center p-2 md:p-12 select-none"
              onClick={() => setSelectedMedia(null)}
            >
              {/* Back ambient blurred glow */}
              <div className="absolute inset-0 pointer-events-none z-0">
                <img 
                  src={selectedMedia.mediaUrl || undefined} 
                  onError={handleImageError}
                  className="w-full h-full object-cover opacity-20 blur-3xl scale-125" 
                  alt="" 
                />
              </div>

              {/* Close Button */}
              <button 
                className="absolute top-6 right-6 text-white p-3 hover:bg-white/10 rounded-full transition-colors z-50 cursor-pointer"
                onClick={() => setSelectedMedia(null)}
                title="Close Lightbox"
              >
                <X className="h-6 w-6" />
              </button>

              {/* Left Slide Arrow */}
              {filteredItems.length > 1 && (
                <button
                  type="button"
                  onClick={handlePrev}
                  className="absolute left-4 top-1/2 -translate-y-1/2 text-white/70 hover:text-amber-500 bg-black/50 hover:bg-black/90 p-3 rounded-full border border-white/10 transition-colors z-50 cursor-pointer"
                  title="Previous Masterpiece"
                >
                  <ChevronLeft className="h-6 w-6" />
                </button>
              )}

              {/* Right Slide Arrow */}
              {filteredItems.length > 1 && (
                <button
                  type="button"
                  onClick={handleNext}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-white/70 hover:text-amber-500 bg-black/50 hover:bg-black/90 p-3 rounded-full border border-white/10 transition-colors z-50 cursor-pointer"
                  title="Next Masterpiece"
                >
                  <ChevronRight className="h-6 w-6" />
                </button>
              )}

              {/* Central Lightbox Wrapper */}
              <div 
                className="relative max-w-5xl w-full h-[85vh] flex flex-col items-center justify-between z-10" 
                onClick={e => e.stopPropagation()}
              >
                {/* Floating cinematic overlay tool bar */}
                <div className="flex items-center gap-4 bg-black/80 backdrop-blur-md px-5 py-2.5 rounded-full border border-white/10 z-30 mb-2">
                  <span className="text-[10px] text-zinc-500 font-mono">Magnification: {Math.round(zoom * 100)}%</span>
                  <div className="w-[1px] h-4 bg-white/10" />
                  <button onClick={handleZoomOut} className="text-white hover:text-amber-500 p-1 cursor-pointer" title="Zoom Out">
                    <ZoomOut className="h-4 w-4" />
                  </button>
                  <button onClick={handleZoomIn} className="text-white hover:text-amber-500 p-1 cursor-pointer" title="Zoom In">
                    <ZoomIn className="h-4 w-4" />
                  </button>
                  <button onClick={handleZoomReset} className="text-white hover:text-amber-500 p-1 cursor-pointer" title="Reset 1x">
                    <RotateCcw className="h-4 w-4" />
                  </button>
                  {selectedMedia.mediaType !== 'video' && (
                    <>
                      <div className="w-[1px] h-4 bg-white/10" />
                      <button onClick={toggleFillMode} className={cn("text-xs font-bold uppercase select-none cursor-pointer", isFillMode ? "text-amber-500" : "text-white/70 hover:text-white")} title="Toggle fit mode">
                        {isFillMode ? 'Fit' : 'Fill'}
                      </button>
                    </>
                  )}
                </div>

                {/* Media Container Box */}
                <div className="relative w-full flex-grow flex items-center justify-center overflow-auto rounded-xl bg-black/85 border border-white/5 p-4">
                  {selectedMedia.mediaType === 'video' ? (
                    <video 
                      src={selectedMedia.mediaUrl || null} 
                      controls 
                      autoPlay 
                      style={{ transform: `scale(${zoom})`, transition: 'transform 0.1s ease-out' }}
                      className="max-w-full max-h-[60vh] rounded-lg shadow-2xl object-contain mx-auto" 
                    />
                  ) : (
                    <img 
                      src={selectedMedia.mediaUrl || undefined} 
                      onError={handleImageError}
                      style={{ transform: `scale(${zoom})`, transition: 'transform 0.1s ease-out' }}
                      className={cn(
                        "rounded-lg shadow-2xl mx-auto transition-all",
                        isFillMode ? "w-full h-full object-cover" : "max-w-full max-h-[60vh] object-contain"
                      )} 
                      alt={selectedMedia.title} 
                    />
                  )}
                </div>

                {/* Media Title & Description Overlay */}
                <div className="text-center w-full max-w-2xl px-6 pt-4 mt-2">
                  <span className="text-amber-500 font-bold uppercase tracking-[0.25em] text-[10px] sm:text-xs mb-1.5 block">{selectedMedia.category}</span>
                  <h2 className="text-xl sm:text-2xl font-bold text-white mb-2 tracking-tight">{selectedMedia.title}</h2>
                  <p className="text-zinc-400 text-xs sm:text-sm font-light leading-relaxed truncate-2-lines">{selectedMedia.description}</p>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
