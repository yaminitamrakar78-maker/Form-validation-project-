import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { Booking, GalleryItem, UserProfile, ArtService, AppSettings, HeroMedia, BlockedDate, CustomerMessage, StatusHistoryItem } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { 
  LayoutDashboard, 
  Package, 
  Image as ImageIcon, 
  Users, 
  Upload, 
  Trash2, 
  Check, 
  X, 
  TrendingUp, 
  DollarSign, 
  Calendar,
  Loader2,
  ExternalLink,
  Edit,
  Settings as SettingsIcon,
  Palette,
  Phone,
  Mail,
  Instagram,
  Facebook,
  Twitter,
  Sparkles,
  Sliders,
  AlertTriangle,
  History,
  MessageSquare,
  Send,
  CalendarDays,
  ShieldCheck,
  Search,
  Filter,
  Eye,
  Plus,
  ArrowLeft,
  ArrowRight,
  ClipboardList
} from 'lucide-react';
import { cn, formatCurrency } from '../lib/utils';
import { useDropzone } from 'react-dropzone';
import toast from 'react-hot-toast';

export default function Admin() {
  const { isAdmin, loading: authLoading } = useAuth();
  const [activeTab, setActiveTab] = useState('overview');
  
  // Database datasets
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [gallery, setGallery] = useState<GalleryItem[]>([]);
  const [deletedGallery, setDeletedGallery] = useState<GalleryItem[]>([]);
  const [services, setServices] = useState<ArtService[]>([]);
  const [deletedServices, setDeletedServices] = useState<ArtService[]>([]);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [heroMedia, setHeroMedia] = useState<HeroMedia[]>([]);
  const [blockedDates, setBlockedDates] = useState<BlockedDate[]>([]);
  
  // Gallery deletion modal state
  const [deleteModal, setDeleteModal] = useState<{
    isOpen: boolean;
    itemId: string;
    itemTitle: string;
    itemType: 'gallery' | 'gallery-permanent';
  }>({
    isOpen: false,
    itemId: '',
    itemTitle: '',
    itemType: 'gallery'
  });
  const [isDeleting, setIsDeleting] = useState(false);
  const [settings, setSettings] = useState<AppSettings>({
    contactNumber: '+91 91310 51376',
    adminEmail: 'kalavantdeepak1712@gmail.com',
    instagramUrl: '#',
    facebookUrl: '#',
    twitterUrl: '#'
  });
  
  const [loading, setLoading] = useState(true);

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [bookingsSubTab, setBookingsSubTab] = useState<'registry' | 'analytics'>('registry');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [startDateFilter, setStartDateFilter] = useState('');
  const [endDateFilter, setEndDateFilter] = useState('');
  const [analyticsTimeframe, setAnalyticsTimeframe] = useState<'weekly' | 'monthly' | 'yearly' | 'custom'>('monthly');
  const [analyticsCategoryFilter, setAnalyticsCategoryFilter] = useState('all');

  // Interactive Calendar Coordinates
  const [currentMonth, setCurrentMonth] = useState(new Date().getMonth());
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
  const [inspectedDate, setInspectedDate] = useState<string | null>(null);

  // Manual Block date form
  const [blockDateStr, setBlockDateStr] = useState('');
  const [blockReason, setBlockReason] = useState('');
  const [blockTimeSlot, setBlockTimeSlot] = useState('all_day');

  // Reschedule Trigger state
  const [rescheduleBookingId, setRescheduleBookingId] = useState<string | null>(null);
  const [admReschDate, setAdmReschDate] = useState('');
  const [admReschTiming, setAdmReschTiming] = useState('');
  const [admReschNote, setAdmReschNote] = useState('');

  // Dialogue & Notes stream
  const [selectedBookingDetails, setSelectedBookingDetails] = useState<Booking | null>(null);
  const [admPrivateNote, setAdmPrivateNote] = useState('');
  const [admChatText, setAdmChatText] = useState('');
  const [statusActionNote, setStatusActionNote] = useState('');

  // Page-level dynamic progress reporter
  const [uploadProgress, setUploadProgress] = useState(0);



  // Hero Media Upload State
  const [heroUploadData, setHeroUploadData] = useState({
    title: '',
    mediaType: 'image' as 'image' | 'video',
    videoStartTime: 0,
    videoEndTime: '' as string | number,
    videoVolume: 0.0,
    videoSpeed: 1.0
  });
  const [heroUploadFile, setHeroUploadFile] = useState<File | null>(null);
  const [heroUploading, setHeroUploading] = useState(false);

  // Dynamic edits states
  const [itemTitles, setItemTitles] = useState<Record<string, string>>({});
  const [itemDescriptions, setItemDescriptions] = useState<Record<string, string>>({});
  const [itemCategories, setItemCategories] = useState<Record<string, string>>({});

  const [galleryTitles, setGalleryTitles] = useState<Record<string, string>>({});
  const [galleryDescriptions, setGalleryDescriptions] = useState<Record<string, string>>({});
  const [galleryCategories, setGalleryCategories] = useState<Record<string, string>>({});

  const [videoSettings, setVideoSettings] = useState<Record<string, {
    videoStartTime: number;
    videoEndTime: string | number;
    videoVolume: number;
    videoSpeed: number;
  }>>({});

  // Gallery Upload State
  const [uploadData, setUploadData] = useState({
    title: '',
    description: '',
    category: 'Wedding Paintings',
    mediaType: 'image' as 'image' | 'video'
  });
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);

  // Service Form State
  const [serviceData, setServiceData] = useState({
    title: '',
    description: '',
    price: 0,
    premiumPrice: 0,
    duration: '4-6 Hours Live Painting + Studio Detailing',
    materials: 'Premium Belgian Linen Canvas & Professional Golden High-Light Acrylics/Oils',
    deliveryTime: 'Same Night Unveiling + Safe Transport Packing',
    discountOffer: 0,
    category: 'Wedding Paintings',
    image: '',
    mediaType: 'image' as 'image' | 'video'
  });
  const [serviceFile, setServiceFile] = useState<File | null>(null);
  const [serviceUploading, setServiceUploading] = useState(false);

  // Dropzones
  const { getRootProps: getGalleryRootProps, getInputProps: getGalleryInputProps } = useDropzone({
    maxFiles: 1, 
    multiple: false, 
    onDrop: (acceptedFiles: File[]) => setUploadFile(acceptedFiles[0])
  } as any);

  const { getRootProps: getServiceRootProps, getInputProps: getServiceInputProps } = useDropzone({
    maxFiles: 1, 
    multiple: false, 
    onDrop: (acceptedFiles: File[]) => setServiceFile(acceptedFiles[0])
  } as any);

  const { getRootProps: getHeroRootProps, getInputProps: getHeroInputProps } = useDropzone({
    maxFiles: 1, 
    multiple: false, 
    onDrop: (acceptedFiles: File[]) => setHeroUploadFile(acceptedFiles[0])
  } as any);


  const refreshData = async () => {
    try {
      const bRes = await fetch('/api/admin/bookings');
      if (bRes.ok && bRes.headers.get('content-type')?.includes('application/json')) {
        const bData = await bRes.json();
        setBookings(bData);
      }

      const gRes = await fetch('/api/public/gallery?includeDeleted=true');
      if (gRes.ok && gRes.headers.get('content-type')?.includes('application/json')) {
        const gData = await gRes.json();
        setGallery(gData.filter((item: any) => !item.isDeleted));
        setDeletedGallery(gData.filter((item: any) => item.isDeleted));
      }

      const sRes = await fetch('/api/public/services?includeDeleted=true');
      if (sRes.ok && sRes.headers.get('content-type')?.includes('application/json')) {
        const sData = await sRes.json();
        setServices(sData.filter((s: any) => !s.isDeleted));
        setDeletedServices(sData.filter((s: any) => s.isDeleted));
      }

      const uRes = await fetch('/api/admin/users');
      if (uRes.ok && uRes.headers.get('content-type')?.includes('application/json')) {
        const uData = await uRes.json();
        setUsers(uData);
      }

      const hRes = await fetch('/api/public/hero-media');
      if (hRes.ok && hRes.headers.get('content-type')?.includes('application/json')) {
        const hData = await hRes.json();
        setHeroMedia(hData);
      }

      const settingsRes = await fetch('/api/public/settings');
      if (settingsRes.ok && settingsRes.headers.get('content-type')?.includes('application/json')) {
        const settingsData = await settingsRes.json();
        setSettings(settingsData);
      }

      const blockedRes = await fetch('/api/public/blocked-dates');
      if (blockedRes.ok && blockedRes.headers.get('content-type')?.includes('application/json')) {
        const blockedData = await blockedRes.json();
        setBlockedDates(blockedData);
      }
    } catch (err) {
      console.error("Failed fetching admin bundle:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isAdmin) {
      refreshData();
    }
  }, [isAdmin]);

  // Download filtered bookings as CSV
  const handleDownloadCSV = () => {
    const headers = [
      "Booking ID",
      "Customer Name",
      "Email",
      "Phone Number",
      "WhatsApp",
      "Event Date",
      "Timing",
      "Service Selected",
      "Retainer Amount",
      "Booking Status",
      "Booking Creation Date",
      "Location",
      "Private Notes",
      "Vision Requirements"
    ];

    const escapeCSV = (value: any) => {
      if (value === undefined || value === null) return "";
      const str = String(value);
      if (str.includes(",") || str.includes("\"") || str.includes("\n") || str.includes("\r")) {
        return `"${str.replace(/"/g, '""')}"`;
      }
      return str;
    };

    const rows = filteredBookings.map(b => [
      b.id || "",
      b.userName || "",
      b.userEmail || "",
      b.phone || "",
      b.whatsapp || b.phone || "",
      b.date || "",
      b.timing || "",
      b.artCategory || "",
      b.amount || "",
      b.status || "",
      b.createdAt ? new Date(b.createdAt).toISOString() : "",
      b.location || "",
      b.adminNotes || "",
      b.requirements || ""
    ]);

    const csvContent = [
      headers.join(","),
      ...rows.map(r => r.map(escapeCSV).join(","))
    ].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    
    const dateObj = new Date();
    const months = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
    const monthName = months[dateObj.getMonth()];
    const yearNum = dateObj.getFullYear();
    const filename = `bookings-${monthName}-${yearNum}.csv`;

    link.setAttribute("href", url);
    link.setAttribute("download", filename);
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success(`Exported ${filteredBookings.length} records to ${filename}`);
  };

  // Handle Updates
  const handleUpdateStatus = async (id: string, status: string, customNote?: string) => {
    try {
      const note = customNote || statusActionNote || `Status changed to ${status.toUpperCase()}`;
      const res = await fetch(`/api/admin/bookings/${id}/status`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, note })
      });
      if (!res.ok) throw new Error("Status failed to save.");
      toast.success(`Booking is now ${status.toUpperCase()}! Client notified via email.`);
      setStatusActionNote('');
      refreshData();
      if (selectedBookingDetails && selectedBookingDetails.id === id) {
        const timestamp = new Date().toISOString();
        const historyItem = { status, timestamp, note };
        const commLogItem = {
          sender: "admin" as const,
          text: `Studio updated booking status to ${status.toUpperCase()}.${note ? ` Note: ${note}` : ""}`,
          timestamp
        };
        const updated = { 
          ...selectedBookingDetails, 
          status,
          statusHistory: [...(selectedBookingDetails.statusHistory || []), historyItem],
          communicationLog: [...(selectedBookingDetails.communicationLog || []), commLogItem]
        } as Booking;
        setSelectedBookingDetails(updated);
      }
    } catch (err) {
      console.error(err);
      toast.error('Failed to change booking status.');
    }
  };

  const handleAdminReschedule = async (id: string) => {
    if (!admReschDate || !admReschTiming) {
      toast.error("Date & Timing proposed are required.");
      return;
    }
    try {
      const res = await fetch(`/api/admin/bookings/${id}/reschedule`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          date: admReschDate,
          timing: admReschTiming,
          note: admReschNote
        })
      });
      if (!res.ok) throw new Error("Reschedule failed.");
      toast.success("Schedule modified & client notified! ✨");
      setRescheduleBookingId(null);
      setAdmReschDate('');
      setAdmReschTiming('');
      setAdmReschNote('');
      refreshData();
      if (selectedBookingDetails && selectedBookingDetails.id === id) {
        setSelectedBookingDetails({ ...selectedBookingDetails, date: admReschDate, timing: admReschTiming } as Booking);
      }
    } catch (err) {
      console.error(err);
      toast.error("Failed to complete reschedule operation.");
    }
  };



  const handleSaveAdminPrivateNotes = async (id: string) => {
    try {
      const res = await fetch(`/api/admin/bookings/${id}/notes`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ adminNotes: admPrivateNote })
      });
      if (!res.ok) throw new Error("Failed to post notes");
      toast.success("Admin private records saved securely.");
      refreshData();
    } catch (err) {
      console.error(err);
      toast.error("Notes failed to persist.");
    }
  };

  const handleSendAdminChatMessage = async (id: string) => {
    if (!admChatText.trim()) return;
    try {
      const res = await fetch(`/api/admin/bookings/${id}/communication`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: admChatText, sender: "admin" })
      });
      if (!res.ok) throw new Error("Error posting");
      setAdmChatText('');
      refreshData();
      // update inspection drawer
      if (selectedBookingDetails && selectedBookingDetails.id === id) {
        const currentLogs = selectedBookingDetails.communicationLog || [];
        const nextLogs = [...currentLogs, { sender: 'admin' as const, text: admChatText, timestamp: new Date().toISOString() }];
        setSelectedBookingDetails({ ...selectedBookingDetails, communicationLog: nextLogs });
      }
    } catch (err) {
      console.error(err);
      toast.error("Failed to post chat.");
    }
  };

  // Block Dates management
  const handleAddBlockedDate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!blockDateStr) return;
    try {
      const res = await fetch('/api/admin/blocked-dates', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          date: blockDateStr,
          reason: blockReason,
          timeSlot: blockTimeSlot
        })
      });
      if (!res.ok) throw new Error("Block failed");
      toast.success(`Date ${blockDateStr} blocked on master calendar successfully!`);
      setBlockDateStr('');
      setBlockReason('');
      refreshData();
    } catch (err) {
      console.error(err);
      toast.error("Failed blocking date on calendar.");
    }
  };

  const handleDeleteBlockedDate = async (date: string) => {
    if (confirm(`Remove manual schedule block on: ${date}?`)) {
      try {
        const res = await fetch(`/api/admin/blocked-dates/${date}`, {
          method: 'DELETE'
        });
        if (!res.ok) throw new Error("Unblock failed");
        toast.success(`Schedule unblocked on ${date}.`);
        refreshData();
      } catch (err) {
        console.error(err);
        toast.error("Failed to unblock.");
      }
    }
  };

  // WhatsApp template triggers
  const triggerWhatsAppRedirect = (booking: Booking, type: 'confirm' | 'reschedule' | 'reminder') => {
    const rawNum = booking.whatsapp || booking.phone;
    const cleanPhone = rawNum.replace(/[^0-9]/g, '');
    let textStr = "";

    if (type === 'confirm') {
      textStr = `Hello ${booking.userName}, this is Deepak Prajapati from DPartic Flow. Your live painting commission for your event on ${booking.date} (${booking.timing}) is officially accepted and confirmed! Studio preparation is underway. View your live dashboard here: ${window.location.origin}/dashboard`;
    } else if (type === 'reschedule') {
      textStr = `Hello ${booking.userName}, regarding your live painting order with DPartic Flow, I have proposed a scheduling adjustment. Please check your personal customer dashboard to view proposed slots or connect with us here: ${window.location.origin}/dashboard`;
    } else {
      textStr = `Hello ${booking.userName}, this is a gentle reminder that our live painting session is active on ${booking.date} approaching at ${booking.timing}. I look forward to capturing your grandest memories onto Belgian linen!`;
    }

    const encText = encodeURIComponent(textStr);
    const destination = cleanPhone.startsWith('91') || cleanPhone.length > 10 ? cleanPhone : `91${cleanPhone}`;
    window.open(`https://wa.me/${destination}?text=${encText}`, '_blank');
  };

  // Gallery Add
  const handleGalleryUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!uploadFile) return;
    setUploading(true);
    setUploadProgress(20);
    try {
      const formData = new FormData();
      formData.append('file', uploadFile);
      setUploadProgress(60);

      const hostRes = await fetch(`/api/media/upload?folder=gallery`, {
        method: 'POST',
        body: formData
      });
      if (!hostRes.ok) throw new Error("Cloudinary upload failed");
      let hosted: any;
      try {
        hosted = await hostRes.json();
      } catch (e) {
        throw new Error("Invalid non-JSON response from server during gallery upload");
      }
      setUploadProgress(80);

      const publishRes = await fetch('/api/admin/gallery', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: uploadData.title,
          description: uploadData.description,
          category: uploadData.category,
          mediaType: uploadData.mediaType,
          mediaUrl: hosted.url
        })
      });
      if (!publishRes.ok) throw new Error("Document logging failed");

      setUploadFile(null);
      setUploadData({
        title: '',
        description: '',
        category: 'Wedding Paintings',
        mediaType: 'image'
      });
      toast.success('Artwork added to gallery! 🖼️');
      refreshData();
    } catch (err) {
      console.error(err);
      toast.error('Failed to publish into studio gallery');
    } finally {
      setUploading(false);
      setUploadProgress(0);
    }
  };

  // Service Add
  const handleServiceAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    setServiceUploading(true);
    setUploadProgress(20);
    try {
      let finalImageUrl = serviceData.image || '';
      let finalMediaType = serviceData.mediaType || 'image';

      if (serviceFile) {
        const formData = new FormData();
        formData.append('file', serviceFile);
        setUploadProgress(50);

        const hostRes = await fetch(`/api/media/upload?folder=services`, {
          method: 'POST',
          body: formData
        });
        if (!hostRes.ok) throw new Error("Cover upload failed");
        let hosted: any;
        try {
          hosted = await hostRes.json();
        } catch (e) {
          throw new Error("Invalid non-JSON response from server during category cover upload");
        }
        finalImageUrl = hosted.url;
        finalMediaType = serviceFile.type.startsWith('video/') ? 'video' : 'image';
      }

      setUploadProgress(80);

      const publishRes = await fetch('/api/admin/services', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: serviceData.title,
          description: serviceData.description,
          price: Number(serviceData.price),
          premiumPrice: serviceData.premiumPrice ? Number(serviceData.premiumPrice) : null,
          duration: serviceData.duration,
          materials: serviceData.materials,
          deliveryTime: serviceData.deliveryTime,
          discountOffer: Number(serviceData.discountOffer),
          category: serviceData.category,
          image: finalImageUrl,
          mediaType: finalMediaType,
          isActive: true
        })
      });
      if (!publishRes.ok) throw new Error("Service creation failed");

      setServiceFile(null);
      setServiceData({
        title: '',
        description: '',
        price: 0,
        premiumPrice: 0,
        duration: '4-6 Hours Live Painting + Studio Detailing',
        materials: 'Premium Belgian Linen Canvas & Professional Golden High-Light Acrylics/Oils',
        deliveryTime: 'Same Night Unveiling + Safe Transport Packing',
        discountOffer: 0,
        category: 'Wedding Paintings',
        image: '',
        mediaType: 'image'
      });
      toast.success('Bespoke service published! 🎨');
      refreshData();
    } catch (err: any) {
      console.error(err);
      toast.error('Failed to add service: ' + (err.message || String(err)));
    } finally {
      setServiceUploading(false);
      setUploadProgress(0);
    }
  };

  const handleHeroUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!heroUploadFile) return;
    setHeroUploading(true);
    setUploadProgress(25);
    try {
      const formData = new FormData();
      formData.append('file', heroUploadFile);
      setUploadProgress(65);
      const hostRes = await fetch(`/api/media/upload?folder=hero`, {
        method: 'POST',
        body: formData
      });
      if (!hostRes.ok) throw new Error("Asset upload failed");
      let hosted: any;
      try {
        hosted = await hostRes.json();
      } catch (e) {
        throw new Error("Invalid non-JSON response from server during hero asset upload");
      }

      setUploadProgress(85);
      const recordRes = await fetch('/api/admin/hero-media', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: heroUploadData.title,
          mediaType: heroUploadData.mediaType,
          videoStartTime: heroUploadData.mediaType === 'video' ? Number(heroUploadData.videoStartTime) || 0 : undefined,
          videoEndTime: (heroUploadData.mediaType === 'video' && heroUploadData.videoEndTime !== '') ? Number(heroUploadData.videoEndTime) : undefined,
          videoVolume: heroUploadData.mediaType === 'video' ? Number(heroUploadData.videoVolume) : undefined,
          videoSpeed: heroUploadData.mediaType === 'video' ? Number(heroUploadData.videoSpeed) || 1.0 : undefined,
          mediaUrl: hosted.url,
          publicId: hosted.public_id,
          uploadedAt: new Date().toISOString()
        })
      });
      if (!recordRes.ok) throw new Error("Db logging failure");

      setHeroUploadFile(null);
      setHeroUploadData({
        title: '',
        mediaType: 'image',
        videoStartTime: 0,
        videoEndTime: '',
        videoVolume: 0.0,
        videoSpeed: 1.0
      });
      toast.success('Hero media added! ✨');
      refreshData();
    } catch (err) {
      console.error(err);
      toast.error('Failed to upload hero media');
    } finally {
      setHeroUploading(false);
      setUploadProgress(0);
    }
  };

  const handleDeleteHero = async (id: string) => {
    if (confirm("Delete hero media?")) {
      try {
        const res = await fetch(`/api/admin/hero-media/${id}`, {
          method: 'DELETE'
        });
        if (!res.ok) throw new Error("Delete failed");
        toast.success('Hero media deleted');
        refreshData();
      } catch (err) {
        console.error(err);
        toast.error('Delete failed');
      }
    }
  };

  const handleToggleFeaturedHero = async (id: string, currentStatus: boolean) => {
    try {
      const res = await fetch(`/api/admin/hero-media/${id}/feature`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isFeatured: !currentStatus })
      });
      if (!res.ok) throw new Error("Feature switch failed");
      toast.success(currentStatus ? 'Hero media unfeatured' : 'Hero media featured! 🌟');
      refreshData();
    } catch (err) {
      console.error(err);
      toast.error('Action failed');
    }
  };

  const handleUpdateSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings)
      });
      if (!res.ok) throw new Error("Save settings failed");
      toast.success('Settings saved successfully');
      refreshData();
    } catch (err) {
      console.error(err);
      toast.error('Failed to save settings');
    }
  };

  const triggerDeleteGallery = (item: GalleryItem, permanent = false) => {
    setDeleteModal({
      isOpen: true,
      itemId: item.id,
      itemTitle: item.title,
      itemType: permanent ? 'gallery-permanent' : 'gallery'
    });
  };

  const handleConfirmDelete = async () => {
    if (!deleteModal.itemId) return;
    setIsDeleting(true);
    try {
      const isPermanent = deleteModal.itemType === 'gallery-permanent';
      const url = `/api/admin/gallery/${deleteModal.itemId}${isPermanent ? '?permanent=true' : ''}`;
      const res = await fetch(url, { method: 'DELETE' });
      if (!res.ok) throw new Error();
      
      toast.success(isPermanent ? "Artwork deleted successfully" : "Artwork moved to Trash.");
      refreshData();
    } catch (err) {
      console.error(err);
      toast.error("Failed to delete artwork");
    } finally {
      setIsDeleting(false);
      setDeleteModal(prev => ({ ...prev, isOpen: false }));
    }
  };

  const handleRestoreGallery = async (id: string) => {
    try {
      const res = await fetch(`/api/admin/gallery/${id}/restore`, { method: 'POST' });
      if (!res.ok) throw new Error();
      toast.success("Artwork restored successfully!");
      refreshData();
    } catch (err) {
      console.error(err);
      toast.error("Failed to restore artwork.");
    }
  };

  const handleDeleteService = async (id: string) => {
    if (confirm("Permanently delete service listing?")) {
      try {
        const res = await fetch(`/api/admin/services/${id}`, { method: 'DELETE' });
        if (!res.ok) throw new Error();
        toast.success("Service deleted.");
        refreshData();
      } catch (err) {
        toast.error("Delete failed.");
      }
    }
  };

  if (authLoading || loading) return <div className="min-h-screen bg-black flex items-center justify-center"><Loader2 className="h-10 w-10 text-amber-500 animate-spin" /></div>;
  if (!isAdmin) return <div className="min-h-screen bg-black flex items-center justify-center p-4 text-white font-mono font-bold tracking-wider">Access Denied</div>;

  // Compute stats on the fly
  const totalBookingsCount = bookings.length;
  const pendingRequestsCount = bookings.filter(b => b.status === 'pending').length;
  const activeCommissionsCount = bookings.filter(b => b.status === 'accepted' || b.status === 'in_progress').length;
  const completedOrdersCount = bookings.filter(b => b.status === 'completed').length;
  
  // Earnings calculated from total realized bookings with paid retainer amounts
  const totalFinancialEarnings = bookings
    .filter(b => b.paymentStatus === 'paid')
    .reduce((currSum, b) => currSum + (b.amount || 0), 0);

  // Service popular index
  const popularServiceRanks: Record<string, number> = {};
  bookings.forEach(b => {
    const originalCat = b.artCategory.replace(/-/g, ' ');
    popularServiceRanks[originalCat] = (popularServiceRanks[originalCat] || 0) + 1;
  });
  const mostPopularCategory = Object.entries(popularServiceRanks)
    .sort((a, b) => b[1] - a[1])[0]?.[0] || "Live Paintings";

  // Build Month Calendar Coordinate Map
  const monthNames = [
    "January", "February", "March", "April", "May", "June", 
    "July", "August", "September", "October", "November", "December"
  ];

  const handlePrevMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear(currentYear - 1);
    } else {
      setCurrentMonth(currentMonth - 1);
    }
  };

  const handleNextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear(currentYear + 1);
    } else {
      setCurrentMonth(currentMonth + 1);
    }
  };

  const getDaysInMonth = (m: number, y: number) => new Date(y, m + 1, 0).getDate();
  const getFirstDayIndex = (m: number, y: number) => new Date(y, m, 1).getDay();

  const daysCount = getDaysInMonth(currentMonth, currentYear);
  const startDayIdx = getFirstDayIndex(currentMonth, currentYear);

  // Array of days grid slots
  const daysGrid: Array<{ day: number | null; dateStr: string | null }> = [];
  for (let i = 0; i < startDayIdx; i++) {
    daysGrid.push({ day: null, dateStr: null });
  }
  for (let d = 1; d <= daysCount; d++) {
    const formattedD = String(d).padStart(2, '0');
    const formattedM = String(currentMonth + 1).padStart(2, '0');
    const dateStr = `${currentYear}-${formattedM}-${formattedD}`;
    daysGrid.push({ day: d, dateStr });
  }

  // Filter and search bookings list
  const filteredBookings = bookings.filter(booking => {
    const todayStr = new Date().toISOString().split('T')[0];
    
    let matchesStatus = false;
    if (statusFilter === 'all') {
      matchesStatus = true;
    } else if (statusFilter === 'upcoming') {
      matchesStatus = (booking.status === 'accepted' || booking.status === 'in_progress' || booking.status === 'pending') && booking.date >= todayStr;
    } else if (statusFilter === 'past') {
      matchesStatus = booking.date < todayStr;
    } else {
      matchesStatus = booking.status === statusFilter;
    }

    let matchesCategory = true;
    if (categoryFilter !== 'all') {
      matchesCategory = (booking.artCategory || '').toLowerCase() === categoryFilter.toLowerCase();
    }

    let matchesDateRange = true;
    if (startDateFilter) {
      matchesDateRange = matchesDateRange && booking.date >= startDateFilter;
    }
    if (endDateFilter) {
      matchesDateRange = matchesDateRange && booking.date <= endDateFilter;
    }

    const clientName = booking.userName || '';
    const clientEmail = booking.userEmail || '';
    const clientPhone = booking.phone || '';
    const clientWhatsapp = booking.whatsapp || '';
    const bookingId = booking.id || '';
    const clientLoc = booking.location || '';
    const serviceTitle = booking.artCategory || '';

    const matchesSearch = 
      clientName.toLowerCase().includes(searchQuery.toLowerCase()) || 
      clientEmail.toLowerCase().includes(searchQuery.toLowerCase()) ||
      clientPhone.toLowerCase().includes(searchQuery.toLowerCase()) ||
      clientWhatsapp.toLowerCase().includes(searchQuery.toLowerCase()) ||
      bookingId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      clientLoc.toLowerCase().includes(searchQuery.toLowerCase()) ||
      serviceTitle.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesStatus && matchesCategory && matchesDateRange && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-black pt-32 pb-20 px-4 md:px-8">
      <div className="max-w-7xl mx-auto">
        
        {/* Header and Branding */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-12">
          <div>
            <span className="text-amber-500 text-xs font-bold uppercase tracking-[0.4em] mb-2 block">Grand Atelier Controller</span>
            <h1 className="text-4xl md:text-6xl font-serif font-bold text-white tracking-tighter">STUDIO <span className="text-amber-500 italic">ADMIN</span></h1>
          </div>
          
          <div className="flex flex-wrap gap-1 p-1 bg-zinc-900 border border-white/5 rounded-2xl">
            {[
              { id: 'overview', icon: LayoutDashboard, label: 'Overview' },
              { id: 'calendar', icon: Calendar, label: 'Master Schedule' },
              { id: 'bookings', icon: ClipboardList, label: 'Bookings (History)' },
              { id: 'upload-media', icon: Upload, label: 'Publish Art/Services' },
              { id: 'hero-manager', icon: Palette, label: 'Hero Cinemagraphs' },
              { id: 'gallery-manager', icon: ImageIcon, label: 'Portfolio Library' },
              { id: 'users', icon: Users, label: 'Collectors' },
              { id: 'settings', icon: SettingsIcon, label: 'Settings' },
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id);
                  setInspectedDate(null);
                }}
                className={cn(
                  "flex items-center space-x-2 px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-widest transition-all cursor-pointer",
                  activeTab === tab.id ? "bg-amber-500 text-black shadow-lg" : "text-gray-400 hover:text-amber-500"
                )}
              >
                <tab.icon className="h-4 w-4 shrink-0" />
                <span className="hidden lg:inline">{tab.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Tab content view container */}
        <div className="bg-zinc-900/45 border border-white/5 rounded-[2.5rem] p-8 md:p-12 min-h-[600px] backdrop-blur-xl">
          <AnimatePresence mode="wait">
            
            {/* 1. OVERVIEW TABS */}
            {activeTab === 'overview' && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-12">
                {/* Analytics bento grids */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {[
                    { label: 'Total Retainer Realised', value: formatCurrency(totalFinancialEarnings), icon: DollarSign, color: "text-emerald-500" },
                    { label: 'Total Commissions', value: totalBookingsCount, icon: Package, color: "text-amber-500" },
                    { label: 'Active Event Schedules', value: activeCommissionsCount, icon: CalendarDays, color: "text-blue-400" },
                    { label: 'Popular Masterwork service', value: mostPopularCategory.replace(/-/g, ' '), icon: Sparkles, color: "text-purple-400", isLabelText: true },
                  ].map((stat, i) => (
                    <div key={i} className="p-6.5 p-6 bg-black/40 border border-white/5 rounded-3xl relative overflow-hidden group">
                      <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
                        <stat.icon className="h-16 w-16 text-white" />
                      </div>
                      <div className="relative z-10 space-y-2">
                        <div className="text-gray-500 text-[10px] font-bold uppercase tracking-widest">{stat.label}</div>
                        <div className={cn("font-bold text-white tracking-tight truncate", stat.isLabelText ? "text-lg md:text-xl uppercase font-serif block mt-1" : "text-3xl")}>
                          {stat.value}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Sub-grid: Double Booking Warns + Quick Calendar + Recent logs */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  
                  {/* Calendar / Schedule quick state */}
                  <div className="bg-black/30 p-6 rounded-3xl border border-white/5 space-y-4 lg:col-span-2">
                    <div className="flex items-center justify-between border-b border-white/5 pb-3">
                      <h3 className="text-amber-500 font-serif text-lg">Recent Event Register</h3>
                      <button onClick={() => setActiveTab('calendar')} className="text-xs uppercase font-mono tracking-widest text-zinc-400 hover:text-amber-500 flex items-center gap-1">
                        <span>Load Full Calendar</span>
                        <ArrowRight className="h-3 w-3" />
                      </button>
                    </div>

                    {/* Double booking security audit checker (Goal: Prevent & Audit multiple bookings on same slot) */}
                    {(() => {
                      const activeDatesList = bookings
                        .filter(b => b.status === 'accepted' || b.status === 'in_progress' || b.status === 'completed')
                        .map(b => b.date);
                      
                      const duplicates = activeDatesList.filter((item, index) => activeDatesList.indexOf(item) !== index);
                      const uniqueDuplicates = Array.from(new Set(duplicates));

                      if (uniqueDuplicates.length > 0) {
                        return (
                          <div className="p-4 bg-red-500/5-border border border-red-500/10 rounded-2xl bg-red-500/5 text-xs text-red-400 flex items-start gap-3">
                            <AlertTriangle className="h-5 w-5 shrink-0 text-red-500 animate-pulse" />
                            <div>
                              <span className="font-bold uppercase font-mono tracking-wider block text-[10px]">⚠️ Double Booking Safety Conflict Warning</span>
                              <p className="mt-1">
                                Multiple active event commissions are confirmed on the same date: <strong>{uniqueDuplicates.join(', ')}</strong>. Consider rescheduling or blocking conflicting dates in the scheduler.
                              </p>
                            </div>
                          </div>
                        );
                      }
                      return (
                        <div className="p-4 bg-emerald-500/5 border border-emerald-500/10 rounded-2xl text-xs text-emerald-400 flex items-center gap-2.5">
                          <ShieldCheck className="h-5 w-5 shrink-0 text-emerald-500" />
                          <span className="font-bold uppercase font-mono tracking-wider text-[10px]">Master Schedule Audit: All calendars are clear. No slot overlaps.</span>
                        </div>
                      );
                    })()}

                    {/* Pending bookings warning lists */}
                    <div className="space-y-3">
                      <h4 className="text-[10px] text-gray-500 uppercase tracking-widest font-mono">Pending Artist Review ({pendingRequestsCount})</h4>
                      <div className="space-y-2">
                        {bookings.filter(b => b.status === 'pending').slice(0, 3).map(booking => (
                          <div key={booking.id} className="flex justify-between items-center p-4 bg-black/40 rounded-xl border border-white/5 hover:border-amber-500/20 transition-all">
                            <div className="min-w-0">
                              <span className="text-[10px] text-zinc-500 uppercase font-bold tracking-wider block">{booking.userName}</span>
                              <span className="text-xs font-bold text-white uppercase block mt-0.5 truncate">{booking.artCategory.replace(/-/g, ' ')}</span>
                              <span className="text-[9px] text-gray-500 font-mono block">{booking.date} | {booking.location}</span>
                            </div>
                            <button
                              onClick={() => {
                                setSelectedBookingDetails(booking);
                                setAdmPrivateNote(booking.adminNotes || '');
                              }}
                              className="px-3 py-1 bg-amber-500 text-black text-[9px] font-bold uppercase tracking-widest rounded-lg hover:bg-amber-400 cursor-pointer"
                            >
                              Review & Audit
                            </button>
                          </div>
                        ))}
                        {pendingRequestsCount === 0 && (
                          <p className="text-[10px] text-gray-500 font-mono text-center py-2">No pending schedules require review today.</p>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Quick stats service leaderboards */}
                  <div className="bg-black/30 p-6 rounded-3xl border border-white/5 space-y-4">
                    <h3 className="text-amber-500 font-serif text-lg border-b border-white/5 pb-2">Commission Popularity Index</h3>
                    <div className="space-y-4 pr-1">
                      {Object.entries(popularServiceRanks).length > 0 ? (
                        Object.entries(popularServiceRanks).sort((a,b)=>b[1]-a[1]).map(([srv, count], idx) => (
                          <div key={srv} className="space-y-1">
                            <div className="flex justify-between items-center text-xs">
                              <span className="text-white font-mono uppercase text-[10px] tracking-wider truncate max-w-xs">{srv}</span>
                              <span className="text-amber-500 font-bold font-mono">{count} orders</span>
                            </div>
                            <div className="w-full h-1 bg-zinc-800 rounded-full overflow-hidden">
                              <div className="h-full bg-amber-550 bg-amber-500" style={{ width: `${Math.min(100, (count / totalBookingsCount) * 100)}%` }} />
                            </div>
                          </div>
                        ))
                      ) : (
                        <p className="text-[10px] text-gray-500 font-mono py-8 text-center text-gray-400">Order placements pending to index ranks.</p>
                      )}
                    </div>
                  </div>

                </div>
              </motion.div>
            )}

            {/* 2. SCHEDULING CALENDAR & BLOCKS TAB */}
            {activeTab === 'calendar' && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-8">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  
                  {/* Main Month Calendar rendering Grid (Goal: Administrative calendar UI display) */}
                  <div className="lg:col-span-2 bg-black/30 p-6 rounded-3xl border border-white/5 space-y-6">
                    <div className="flex justify-between items-center border-b border-white/5 pb-4">
                      <div className="flex items-center space-x-2">
                        <CalendarDays className="h-5 w-5 text-amber-500" />
                        <h3 className="text-xl font-serif text-white">{monthNames[currentMonth]} <span className="text-amber-500 italic">{currentYear}</span></h3>
                      </div>
                      <div className="flex gap-2 text-zinc-400">
                        <button onClick={handlePrevMonth} className="p-2 border border-white/5 bg-zinc-950 rounded-xl hover:text-white hover:border-amber-550 cursor-pointer"><ArrowLeft className="h-4 w-4" /></button>
                        <button onClick={handleNextMonth} className="p-2 border border-white/5 bg-zinc-950 rounded-xl hover:text-white hover:border-amber-550 cursor-pointer"><ArrowRight className="h-4 w-4" /></button>
                      </div>
                    </div>

                    {/* Days Headings */}
                    <div className="grid grid-cols-7 gap-1 text-center text-zinc-500 font-mono text-[10px] uppercase font-bold tracking-widest">
                      {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map(dh => <div key={dh} className="py-2">{dh}</div>)}
                    </div>

                    {/* Days Numbers Grid Grid cells */}
                    <div className="grid grid-cols-7 gap-1">
                      {daysGrid.map((cell, idx) => {
                        if (!cell.day) {
                          return <div key={`empty-${idx}`} className="bg-zinc-900/10 min-h-[70px] rounded-lg opacity-10" />;
                        }

                        // Inspect bookings confirmed/pending on this dateStr!
                        const matchedBookingsOnDay = bookings.filter(b => b.date === cell.dateStr);
                        const matchedBlocksOnDay = blockedDates.filter(b => b.date === cell.dateStr);

                        const hasConfirmedBooking = matchedBookingsOnDay.some(b => b.status === 'accepted' || b.status === 'in_progress' || b.status === 'completed');
                        const hasPendingBooking = matchedBookingsOnDay.some(b => b.status === 'pending');
                        const hasBlockFlag = matchedBlocksOnDay.length > 0;
                        const isMultiBooked = matchedBookingsOnDay.filter(b => b.status === 'accepted' || b.status === 'in_progress').length > 1;

                        return (
                          <div
                            key={cell.dateStr}
                            onClick={() => {
                              if (cell.dateStr) {
                                setInspectedDate(cell.dateStr);
                              }
                            }}
                            className={cn(
                              "min-h-[75px] p-2 bg-black/40 border rounded-lg flex flex-col justify-between hover:bg-zinc-900/40 hover:border-amber-500/20 transition-all cursor-pointer relative",
                              inspectedDate === cell.dateStr ? "border-amber-500 bg-amber-500/5 shadow-inner" : "border-white/5",
                              hasBlockFlag ? "bg-zinc-900/30 border-dashed border-zinc-700 font-mono" : ""
                            )}
                          >
                            <div className="flex justify-between items-start">
                              <span className={cn("text-xs font-mono font-bold", isInspectedToday(cell.dateStr) ? "bg-amber-500 text-black px-1.5 py-0.5 rounded-full" : "text-gray-400")}>
                                {cell.day}
                              </span>
                              
                              {isMultiBooked && (
                                <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping absolute top-1 right-1" title="Double Booking overlap conflict!" />
                              )}
                            </div>

                            {/* Little graphical status indicators for that day cell */}
                            <div className="space-y-1">
                              {/* Confirmed bookings bar */}
                              {hasConfirmedBooking && (
                                <div className="h-1 bg-emerald-500 rounded-full block mx-0.5" title="Confirmed fine-art commission scheduled" />
                              )}
                              
                              {/* Pending booking items indicator */}
                              {hasPendingBooking && (
                                <div className="h-1 bg-amber-500 rounded-full block mx-0.5" title="Pending reviewer request" />
                              )}

                              {/* Blocked date schedule bar */}
                              {hasBlockFlag && (
                                <div className="text-[7px] text-zinc-500 font-mono scale-95 uppercase leading-none truncate max-w-full">
                                  🏢 Busy
                                </div>
                              )}
                            </div>

                          </div>
                        );
                      })}
                    </div>

                    <div className="flex flex-wrap gap-4 text-[9px] font-mono tracking-wider uppercase justify-center mt-4">
                      <div className="flex items-center space-x-1.5"><span className="w-2.5 h-1 bg-emerald-500 rounded-full" /> <span className="text-zinc-400">Masterwork Confirmed</span></div>
                      <div className="flex items-center space-x-1.5"><span className="w-2.5 h-1 bg-amber-500 rounded-full" /> <span className="text-zinc-400">Collector Request</span></div>
                      <div className="flex items-center space-x-1.5"><span className="w-2.5 h-1.5 bg-dashed border border-zinc-500 rounded-sm" /> <span className="text-zinc-400">Manually Blocked</span></div>
                      <div className="flex items-center space-x-1.5"><span className="w-2.5 h-2.5 bg-red-500 rounded-full" /> <span className="text-zinc-400">Over-Scheduling Conflict</span></div>
                    </div>
                  </div>

                  {/* Inspector / Blocking drawer controls */}
                  <div className="space-y-6">
                    
                    {/* Date Block Builder */}
                    <form onSubmit={handleAddBlockedDate} className="bg-black/35 p-6 rounded-3xl border border-white/5 space-y-4">
                      <h4 className="text-amber-500 font-bold uppercase tracking-widest text-[10px] border-b border-white/5 pb-2">Manual Out-of-Office Scheduler</h4>
                      <div className="space-y-3">
                        <div className="space-y-1 text-xs">
                          <label className="text-[10px] text-gray-500 uppercase tracking-widest">Select Date to Block</label>
                          <input 
                            type="date" 
                            required 
                            className="w-full bg-black/50 border border-white/10 p-3 rounded-xl text-white outline-none focus:border-amber-500 text-xs"
                            value={blockDateStr}
                            onChange={e => setBlockDateStr(e.target.value)}
                          />
                        </div>
                        <div className="space-y-1 text-xs">
                          <label className="text-[10px] text-gray-500 uppercase tracking-widest">Reason / Memo</label>
                          <input 
                            type="text" 
                            required 
                            placeholder="e.g. Vacation, Masterpiece Solo Exhibit, Studio Prep" 
                            className="w-full bg-black/50 border border-white/10 p-3 rounded-xl text-white outline-none focus:border-amber-500 text-xs"
                            value={blockReason}
                            onChange={e => setBlockReason(e.target.value)}
                          />
                        </div>
                        <div className="space-y-1 text-xs">
                          <label className="text-[10px] text-gray-500 uppercase tracking-widest">Time Coverage</label>
                          <select 
                            className="w-full bg-black/50 border border-white/10 p-3 rounded-xl text-white outline-none focus:border-amber-500 text-xs"
                            value={blockTimeSlot}
                            onChange={e => setBlockTimeSlot(e.target.value)}
                          >
                            <option value="all_day">Block Entire Day (All-Day)</option>
                            <option value="morning">Morning Only (9 AM - 1 PM)</option>
                            <option value="evening">Afternoon/Evening Only (4 PM - 9 PM)</option>
                          </select>
                        </div>
                      </div>
                      <button 
                        type="submit" 
                        className="w-full py-3 bg-amber-500 hover:bg-amber-400 text-black font-semibold text-xs rounded-xl uppercase tracking-widest transition-all cursor-pointer"
                      >
                         Publish Block
                      </button>
                    </form>

                    {/* Inspected Date Bookings Display Drawer */}
                    <div className="bg-black/35 p-6 rounded-3xl border border-white/5 space-y-4">
                      <h4 className="text-amber-500 font-bold uppercase tracking-widest text-[10px] border-b border-white/5 pb-2">
                        Inspect Slot Details: {inspectedDate || "Click any Calendar Date"}
                      </h4>
                      {inspectedDate ? (
                        <div className="space-y-4 max-h-[250px] overflow-y-auto">
                          {/* Bookings on Day */}
                          {(() => {
                            const bookingsOnDay = bookings.filter(b => b.date === inspectedDate);
                            const blocksOnDay = blockedDates.filter(b => b.date === inspectedDate);

                            return (
                              <div className="space-y-3">
                                {blocksOnDay.map((block, bIdx) => (
                                  <div key={bIdx} className="p-3 bg-zinc-950/80 rounded-xl border border-dashed border-zinc-700 flex justify-between items-center text-xs">
                                    <div className="max-w-[70%]">
                                      <span className="font-bold text-red-400 font-mono uppercase tracking-widest text-[8px] block">Blocked Blocked Out</span>
                                      <p className="text-white mt-1">"{block.reason}"</p>
                                      <span className="text-[9px] text-gray-500">{block.timeSlot?.replace('_', ' ')}</span>
                                    </div>
                                    <button 
                                      onClick={() => handleDeleteBlockedDate(inspectedDate)}
                                      className="p-1.5 bg-red-550/10 text-red-500 hover:bg-red-500 hover:text-white rounded-lg transition-colors cursor-pointer"
                                    >
                                      <Trash2 className="h-3.5 w-3.5" />
                                    </button>
                                  </div>
                                ))}

                                {bookingsOnDay.map((bk, bkIdx) => (
                                  <div key={bkIdx} className="p-4 bg-zinc-950/80 rounded-xl border border-white/5 space-y-2 text-xs">
                                    <div className="flex justify-between items-center">
                                      <span className="font-bold text-white tracking-tight uppercase">{bk.userName}</span>
                                      <span className="text-amber-500 font-mono font-bold">{bk.timing}</span>
                                    </div>
                                    <p className="text-zinc-400 text-[10px] uppercase font-bold tracking-wider">{bk.artCategory.replace(/-/g, ' ')}</p>
                                    <div className="pt-2 border-t border-white/5 flex justify-between items-center">
                                      <span className="text-[9px] text-gray-500 uppercase font-mono">{bk.status}</span>
                                      <button 
                                        onClick={() => {
                                          setSelectedBookingDetails(bk);
                                          setAdmPrivateNote(bk.adminNotes || '');
                                        }}
                                        className="text-[9px] text-amber-500 hover:underline uppercase font-bold tracking-wider cursor-pointer font-mono"
                                      >
                                        Detailed Review
                                      </button>
                                    </div>
                                  </div>
                                ))}

                                {bookingsOnDay.length === 0 && blocksOnDay.length === 0 && (
                                  <p className="text-[10px] text-gray-500 font-mono text-center py-6 uppercase tracking-wider">Atelier is totally open. Zero commitments scheduled.</p>
                                )}
                              </div>
                            );
                          })()}
                        </div>
                      ) : (
                        <p className="text-[10px] text-gray-505 font-mono py-8 text-center uppercase tracking-wide text-gray-500">Select any day cell to list events or delete blocked frames.</p>
                      )}
                    </div>

                  </div>
                </div>
              </motion.div>
            )}

            {/* 3. BOOKINGS REGISTER & HISTORY TABLE TAB */}
            {activeTab === 'bookings' && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-8">
                 
                 {/* Sub-tabs segment control */}
                 <div className="flex border-b border-white/5 pb-4 gap-6 items-center">
                   <button
                     onClick={() => setBookingsSubTab('registry')}
                     className={cn(
                       "relative py-2 text-xs font-bold uppercase tracking-widest transition-all cursor-pointer font-mono flex items-center gap-2",
                       bookingsSubTab === 'registry' ? "text-amber-500 font-bold" : "text-zinc-500 hover:text-zinc-300"
                     )}
                   >
                     <ClipboardList className="h-4 w-4" />
                     <span>Booking Registry</span>
                     {bookingsSubTab === 'registry' && (
                       <motion.div layoutId="subtab-indicator" className="absolute bottom-0 left-0 right-0 h-[2px] bg-amber-500" />
                     )}
                   </button>
                   <button
                     onClick={() => setBookingsSubTab('analytics')}
                     className={cn(
                       "relative py-2 text-xs font-bold uppercase tracking-widest transition-all cursor-pointer font-mono flex items-center gap-2",
                       bookingsSubTab === 'analytics' ? "text-amber-500 font-bold" : "text-zinc-500 hover:text-zinc-300"
                     )}
                   >
                     <TrendingUp className="h-4 w-4" />
                     <span>Atelier Business Intelligence</span>
                     {bookingsSubTab === 'analytics' && (
                       <motion.div layoutId="subtab-indicator" className="absolute bottom-0 left-0 right-0 h-[2px] bg-amber-500" />
                     )}
                   </button>
                 </div>
                 
                 {/* Premium Booking Analytics Dashboard Bento Header */}
                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 animate-fade-in">
                   
                   {/* Card 1: Total & Pendings */}
                   <div className="p-6 bg-gradient-to-br from-zinc-950 via-zinc-900/60 to-black border border-white/5 rounded-3xl relative overflow-hidden group">
                     <div className="absolute top-0 right-0 p-4 opacity-[0.03] group-hover:opacity-[0.08] transition-opacity">
                       <ClipboardList className="h-16 w-16 text-amber-500" />
                     </div>
                     <span className="text-[8px] font-mono tracking-[0.25em] text-zinc-500 uppercase block font-bold">Registry Volume</span>
                     <h4 className="text-3xl font-serif text-white font-bold tracking-tight mt-1">{bookings.length}</h4>
                     <p className="text-[9px] text-zinc-400 mt-2 font-mono flex items-center gap-1.5">
                       <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
                       <span>{bookings.filter(b => b.status === 'pending').length} pending requests awaiting review</span>
                     </p>
                   </div>

                   {/* Card 2: Upcoming Confirmed Schedule */}
                   <div className="p-6 bg-gradient-to-br from-zinc-950 via-zinc-900/60 to-black border border-white/5 rounded-3xl relative overflow-hidden group">
                     <div className="absolute top-0 right-0 p-4 opacity-[0.03] group-hover:opacity-[0.08] transition-opacity">
                       <CalendarDays className="h-16 w-16 text-amber-500" />
                     </div>
                     <span className="text-[8px] font-mono tracking-[0.25em] text-zinc-500 uppercase block font-bold">Confirmed Atelier Schedules</span>
                     <h4 className="text-3xl font-serif text-white font-bold tracking-tight mt-1">
                       {bookings.filter(b => b.status === 'accepted' || b.status === 'in_progress').length}
                     </h4>
                     <p className="text-[9px] text-zinc-400 mt-2 font-mono flex items-center gap-1.5">
                       <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                       <span>
                         {bookings.filter(b => {
                           const today = new Date().toISOString().split('T')[0];
                           return (b.status === 'accepted' || b.status === 'in_progress') && b.date >= today;
                         }).length} upcoming events active
                       </span>
                     </p>
                   </div>

                   {/* Card 3: Cancelled / Archive Safeguard */}
                   <div className="p-6 bg-gradient-to-br from-zinc-950 via-zinc-900/60 to-black border border-white/5 rounded-3xl relative overflow-hidden group">
                     <div className="absolute top-0 right-0 p-4 opacity-[0.03] group-hover:opacity-[0.08] transition-opacity">
                       <Trash2 className="h-16 w-16 text-amber-500" />
                     </div>
                     <span className="text-[8px] font-mono tracking-[0.25em] text-zinc-500 uppercase block font-bold">Cancelled & Soft Archived</span>
                     <h4 className="text-3xl font-serif text-white font-bold tracking-tight mt-1">
                       {bookings.filter(b => b.status === 'cancelled').length}
                     </h4>
                     <p className="text-[9px] text-zinc-400 mt-2 font-mono">
                       Preserved in history secure index. Cancel reasons and timestamps safe for auditing.
                     </p>
                   </div>

                   {/* Card 4: Seasonal Commission Velocity (Month graph list) */}
                   <div className="p-6 bg-gradient-to-br from-zinc-950 via-zinc-900/60 to-black border border-white/5 rounded-3xl relative overflow-hidden">
                     <span className="text-[8px] font-mono tracking-[0.25em] text-zinc-500 uppercase block font-bold">Command Seasonal Velocity</span>
                     <div className="flex items-end justify-between h-10 mt-2 gap-1 px-1">
                       {(() => {
                         const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                         const stats = months.map(m => {
                           const cnt = bookings.filter(b => b.date && b.date.split('-')[1] && parseInt(b.date.split('-')[1], 10) === months.indexOf(m) + 1).length;
                           return { month: m, count: cnt };
                         });
                         const max = Math.max(...stats.map(s => s.count), 1);
                         
                         return stats.map((s, idx) => (
                           <div key={idx} className="flex-1 flex flex-col items-center group/bar cursor-pointer" title={`${s.month}: ${s.count} Commissions`}>
                             <div className="w-full bg-zinc-800 rounded-sm relative h-8 overflow-hidden flex items-end">
                               <div 
                                 className="w-full bg-gradient-to-t from-amber-600 to-amber-400 group-hover/bar:from-amber-400 group-hover/bar:to-amber-300 transition-all rounded-sm" 
                                 style={{ height: `${(s.count / max) * 100}%` }}
                               />
                             </div>
                             <span className="text-[6px] text-zinc-650 font-mono mt-0.5 select-none">{s.month}</span>
                           </div>
                         ));
                       })()}
                     </div>
                   </div>

                 </div>

                 {bookingsSubTab === 'registry' ? (
                   <>
                     {/* Filters and search headers */}
                     <div className="space-y-4 bg-zinc-950/60 p-6 rounded-3xl border border-white/5">
                        <div className="flex flex-col lg:flex-row gap-4 justify-between items-center">
                           <div className="relative flex-1 w-full text-xs">
                              <Search className="h-4 w-4 text-zinc-500 absolute left-3 top-3.5" />
                              <input 
                                type="text" 
                                placeholder="Filter registry by client name, email, grand location, canvas specifications..."
                                className="w-full bg-black/60 border border-white/10 py-3 pl-10 pr-4 text-white rounded-xl focus:border-amber-500 outline-none text-xs font-mono"
                                value={searchQuery}
                                onChange={e => setSearchQuery(e.target.value)}
                              />
                           </div>
                           <div className="flex gap-2 w-full lg:w-auto">
                              {/* CSV Download Button */}
                              <button
                                onClick={handleDownloadCSV}
                                className="px-5 py-3 w-full sm:w-auto bg-gradient-to-r from-amber-600 to-amber-400 text-black font-mono font-bold uppercase tracking-wider text-[10px] rounded-xl hover:from-amber-400 hover:to-amber-300 shadow-md shadow-amber-500/10 transition-all cursor-pointer flex items-center justify-center gap-1.5"
                              >
                                <Upload className="h-3.5 w-3.5 rotate-180" />
                                <span>Download CSV</span>
                              </button>
                           </div>
                        </div>

                        {/* Filters details grids */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 text-xs">
                           
                           {/* Status Select */}
                           <div className="space-y-1">
                              <label className="text-zinc-500 text-[8.5px] font-mono font-bold uppercase tracking-wider">Registry Status</label>
                              <div className="flex space-x-2 items-center">
                                <Filter className="h-3.5 w-3.5 text-amber-500 shrink-0" />
                                <select 
                                  className="w-full bg-black border border-white/10 p-2 text-white outline-none focus:border-amber-500 text-xs text-amber-500 font-bold rounded-lg font-mono"
                                  value={statusFilter}
                                  onChange={e => setStatusFilter(e.target.value)}
                                >
                                   <option value="all">Display All Schedules</option>
                                   <option value="pending">Pending Requests</option>
                                   <option value="accepted">Confirmed Bookings</option>
                                   <option value="in_progress">In Prep/Execution</option>
                                   <option value="completed">Completed Delivery</option>
                                   <option value="cancelled">Cancelled Bookings</option>
                                   <option value="upcoming">Upcoming Events ONLY</option>
                                   <option value="past">Past Events ONLY</option>
                                </select>
                              </div>
                           </div>

                           {/* Service Category Select */}
                           <div className="space-y-1">
                              <label className="text-zinc-500 text-[8.5px] font-mono font-bold uppercase tracking-wider">Service Selected</label>
                              <div className="flex space-x-2 items-center">
                                <Palette className="h-3.5 w-3.5 text-amber-500 shrink-0" />
                                <select 
                                  className="w-full bg-black border border-white/10 p-2 text-white outline-none focus:border-amber-500 text-xs rounded-lg font-mono"
                                  value={categoryFilter}
                                  onChange={e => setCategoryFilter(e.target.value)}
                                >
                                   <option value="all">All Service Types</option>
                                   {Array.from(new Set(bookings.map(b => b.artCategory).filter(Boolean))).map(cat => (
                                     <option key={cat as string} value={cat as string}>
                                       {(cat as string).replace(/-/g, ' ')}
                                     </option>
                                   ))}
                                </select>
                              </div>
                           </div>

                           {/* Start Date */}
                           <div className="space-y-1">
                              <label className="text-zinc-500 text-[8.5px] font-mono font-bold uppercase tracking-wider">Start Date Range</label>
                              <div className="flex space-x-2 items-center">
                                <Calendar className="h-3.5 w-3.5 text-amber-500 shrink-0" />
                                <input 
                                  type="date"
                                  className="w-full bg-black border border-white/10 p-2 text-white outline-none focus:border-amber-500 text-xs rounded-lg font-mono text-zinc-300"
                                  value={startDateFilter}
                                  onChange={e => setStartDateFilter(e.target.value)}
                                />
                              </div>
                           </div>

                           {/* End Date */}
                           <div className="space-y-1">
                              <label className="text-zinc-500 text-[8.5px] font-mono font-bold uppercase tracking-wider">End Date Range</label>
                              <div className="flex space-x-2 items-center">
                                <Calendar className="h-3.5 w-3.5 text-amber-500 shrink-0" />
                                <input 
                                  type="date"
                                  className="w-full bg-black border border-white/10 p-2 text-white outline-none focus:border-amber-500 text-xs rounded-lg font-mono text-zinc-300"
                                  value={endDateFilter}
                                  onChange={e => setEndDateFilter(e.target.value)}
                                />
                              </div>
                           </div>

                        </div>

                        {/* Quick filter buttons */}
                        <div className="flex flex-wrap gap-1.5 pt-3 border-t border-white/5 items-center">
                           <span className="text-[8px] font-mono text-zinc-500 uppercase tracking-widest mr-1">Quick Filters:</span>
                           {[
                             { label: "All Logs", action: () => { setStartDateFilter(''); setEndDateFilter(''); setStatusFilter('all'); setCategoryFilter('all'); } },
                             { label: "This Week", action: () => {
                                 const today = new Date();
                                 const dayOfWeek = today.getDay();
                                 const start = new Date(today);
                                 start.setDate(today.getDate() - dayOfWeek);
                                 const end = new Date(today);
                                 end.setDate(today.getDate() + (6 - dayOfWeek));
                                 setStartDateFilter(start.toISOString().split('T')[0]);
                                 setEndDateFilter(end.toISOString().split('T')[0]);
                             } },
                             { label: "This Month", action: () => {
                                 const today = new Date();
                                 const start = new Date(today.getFullYear(), today.getMonth(), 1);
                                 const end = new Date(today.getFullYear(), today.getMonth() + 1, 0);
                                 setStartDateFilter(start.toISOString().split('T')[0]);
                                 setEndDateFilter(end.toISOString().split('T')[0]);
                             } },
                             { label: "Wedding Peak (Oct-Dec)", action: () => {
                                 const yr = new Date().getFullYear();
                                 setStartDateFilter(`${yr}-10-01`);
                                 setEndDateFilter(`${yr}-12-31`);
                             } },
                             { label: "Summer Peak (May-Jul)", action: () => {
                                 const yr = new Date().getFullYear();
                                 setStartDateFilter(`${yr}-05-01`);
                                 setEndDateFilter(`${yr}-07-31`);
                             } },
                             { label: "Pending Requests Only", action: () => { setStatusFilter('pending'); } },
                             { label: "Upcoming Targets Only", action: () => { setStatusFilter('upcoming'); } },
                           ].map((q, idx) => (
                             <button
                               key={idx}
                               onClick={q.action}
                               className="px-2.5 py-1 bg-zinc-900 override-bg-amber-hover border border-white/5 hover:border-amber-500/20 text-zinc-400 hover:text-white rounded-full text-[8px] font-mono uppercase tracking-wider transition-all cursor-pointer"
                             >
                               {q.label}
                             </button>
                           ))}
                        </div>
                     </div>

                 {/* History Table grid */}
                 <div className="overflow-x-auto">
                    <table className="w-full text-left border-separate border-spacing-y-3">
                      <thead>
                        <tr className="text-gray-500 text-[10px] font-bold uppercase tracking-widest">
                          <th className="px-6 pb-2">Client Details & Registry Time</th>
                          <th className="px-6 pb-2">Bespoke Specifications</th>
                          <th className="px-6 pb-2">Target Schedule</th>
                          <th className="px-6 pb-2 text-center">Status</th>
                          <th className="px-6 pb-2 text-right">Administrative Execution</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredBookings.map(booking => (
                          <tr key={booking.id} className="bg-black/20 hover:bg-black/40 transition-colors">
                            <td className="px-6 py-4 rounded-l-2xl">
                               <div className="font-bold text-white text-sm">{booking.userName}</div>
                               <div className="text-[10px] text-zinc-500 font-mono mt-0.5">{booking.userEmail}</div>
                               <div className="flex flex-col gap-1 mt-1 font-mono text-[10px]">
                                  <div className="flex items-center gap-1.5 text-zinc-400">
                                     <span className="text-[8px] uppercase font-bold tracking-wider text-zinc-500">Call:</span>
                                     <span>{booking.phone}</span>
                                     <a 
                                        href={`tel:${booking.phone}`} 
                                        className="text-amber-500 hover:text-amber-400 p-0.5 bg-amber-500/10 rounded transition-all ml-1"
                                        title="Call Customer"
                                     >
                                        <Phone className="h-2.5 w-2.5" />
                                     </a>
                                  </div>
                                  <div className="flex items-center gap-1.5 text-zinc-400">
                                     <span className="text-[8px] uppercase font-bold tracking-wider text-zinc-500">WA:</span>
                                     <span>{booking.whatsapp || booking.phone}</span>
                                     <a 
                                        href={`https://wa.me/${(booking.whatsapp || booking.phone).replace(/[^0-9]/g, '')}`} 
                                        target="_blank" 
                                        rel="noopener noreferrer" 
                                        className="text-green-500 hover:text-green-400 p-0.5 bg-green-500/10 rounded transition-all ml-1"
                                        title="Chat on WhatsApp"
                                     >
                                        <MessageSquare className="h-2.5 w-2.5" />
                                     </a>
                                  </div>
                               </div>
                               
                               <div className="mt-3 pt-2.5 border-t border-white/5 space-y-0.5 text-[8.5px] font-mono text-zinc-500 select-none">
                                  <div>Booked on: <span className="text-zinc-400">{booking.createdAt ? new Date(booking.createdAt).toLocaleString(undefined, { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : 'Unknown'}</span></div>
                                  <div>Last update: <span className="text-amber-500/80 font-bold">{booking.statusHistory && booking.statusHistory.length > 0 ? new Date(booking.statusHistory[booking.statusHistory.length - 1].timestamp).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : (booking.createdAt ? new Date(booking.createdAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : 'Never')}</span></div>
                               </div>
                            </td>
                            <td className="px-6 py-4">
                               <span className="font-bold text-amber-500 text-[11px] uppercase tracking-wider">{booking.artCategory.replace(/-/g, ' ')}</span>
                               <span className="text-[10px] text-gray-500 block font-mono mt-0.5">Price: {formatCurrency(booking.amount)}</span>
                                <span className="text-[9px] text-zinc-500 italic block mt-1 line-clamp-2 max-w-[200px]" title={booking.requirements}>"{booking.requirements || 'No custom preferences'}"</span>
                            </td>
                            <td className="px-6 py-4 text-xs font-mono">
                               <span className="text-gray-300 block font-bold">{booking.date}</span>
                               <span className="text-gray-500 text-[10px] block mt-0.5">{booking.timing}</span>
                               <span className="text-gray-500 text-[9px] block text-amber-500 max-w-[150px] truncate mb-1.5">{booking.location}</span>
                            </td>
                            <td className="px-6 py-4 text-center">
                              <span className={cn(
                                "px-3 py-1 rounded-full text-[9px] font-mono font-bold uppercase tracking-widest border",
                                booking.status === 'pending' ? "text-amber-500 border-amber-500/10 bg-amber-500/5" :
                                booking.status === 'accepted' ? "text-blue-500 border-blue-500/10 bg-blue-500/5" :
                                booking.status === 'in_progress' ? "text-purple-400 border-purple-400/10 bg-purple-400/5" :
                                booking.status === 'completed' ? "text-green-500 border-green-500/10 bg-green-500/5" :
                                "text-red-500 border-red-500/10 bg-red-500/5"
                              )}>
                                 {booking.status === 'in_progress' ? 'In Prep' : booking.status}
                              </span>
                            </td>
                            <td className="px-6 py-4 text-right rounded-r-2xl">
                               <div className="flex justify-end gap-2">


                                  <button
                                    onClick={() => {
                                      setSelectedBookingDetails(booking);
                                      setAdmPrivateNote(booking.adminNotes || '');
                                    }}
                                    className="p-2.5 bg-zinc-900 border border-white/5 hover:border-amber-500/20 text-zinc-300 hover:text-amber-500 rounded-xl transition-all cursor-pointer"
                                    title="Open full administrative control ledger & chat Dialogue drawer"
                                  >
                                     <Sliders className="h-4 w-4" />
                                  </button>

                                  {/* Direct quick action confirmation buttons */}
                                  {booking.status === 'pending' && (
                                    <>
                                      <button onClick={() => handleUpdateStatus(booking.id, 'accepted')} className="p-2.5 bg-emerald-500/10 text-emerald-500 rounded-xl hover:bg-emerald-500 hover:text-black transition-all cursor-pointer"><Check className="h-4 w-4" /></button>
                                      <button onClick={() => handleUpdateStatus(booking.id, 'cancelled')} className="p-2.5 bg-red-500/10 text-red-500 rounded-xl hover:bg-red-500 hover:text-white transition-all cursor-pointer"><X className="h-4 w-4" /></button>
                                    </>
                                  )}
                               </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                 </div>
                   </>
                 ) : (
                   /* ATELIER BUSINESS INTELLIGENCE (ANALYTICS) DASHBOARD PART */
                   <div className="space-y-8 animate-fade-in">
                     
                     {/* Dashboard Filters Menu */}
                     <div className="flex flex-col sm:flex-row gap-4 justify-between items-center bg-zinc-950/60 p-5 rounded-3xl border border-white/5 text-xs">
                       <span className="font-serif text-white tracking-wide text-sm font-medium">Business Intelligence Dynamic Console</span>
                       <div className="flex flex-wrap gap-2 items-center">
                         {/* Timeframe Dropdown */}
                         <div className="flex items-center space-x-1 font-mono">
                           <span className="text-zinc-500 text-[10px] uppercase">Period:</span>
                           <select
                             className="bg-black border border-white/10 p-2 text-white rounded-lg outline-none text-[11px] text-amber-500 font-medium font-mono focus:border-amber-500"
                             value={analyticsTimeframe}
                             onChange={e => setAnalyticsTimeframe(e.target.value as any)}
                           >
                             <option value="weekly">Last 7 Days (Weekly)</option>
                             <option value="monthly">Last 30 Days (Monthly)</option>
                             <option value="yearly">Last 12 Months (Yearly)</option>
                             <option value="all">All-Time Cumulative</option>
                           </select>
                         </div>

                         {/* category filter */}
                         <div className="flex items-center space-x-1 font-mono">
                           <span className="text-zinc-500 text-[10px] uppercase">Service:</span>
                           <select
                             className="bg-black border border-white/10 p-2 text-white rounded-lg outline-none text-[11px] font-mono focus:border-amber-500"
                             value={analyticsCategoryFilter}
                             onChange={e => setAnalyticsCategoryFilter(e.target.value)}
                           >
                             <option value="all">All Services</option>
                             {Array.from(new Set(bookings.map(b => b.artCategory).filter(Boolean))).map(cat => (
                               <option key={cat as string} value={cat as string}>{(cat as string).replace(/-/g, ' ')}</option>
                             ))}
                           </select>
                         </div>
                       </div>
                     </div>

                     {/* Analytics Dynamic calculations block */}
                     {(() => {
                        const targetBookingsSet = bookings.filter(b => {
                          if (!b.date) return false;
                          const bDate = new Date(b.date);
                          const today = new Date();
                          let inTimeframe = true;

                          if (analyticsTimeframe === 'weekly') {
                            const ago = new Date(); ago.setDate(today.getDate() - 7);
                            inTimeframe = bDate >= ago && bDate <= today;
                          } else if (analyticsTimeframe === 'monthly') {
                            const ago = new Date(); ago.setMonth(today.getMonth() - 1);
                            inTimeframe = bDate >= ago && bDate <= today;
                          } else if (analyticsTimeframe === 'yearly') {
                            const ago = new Date(); ago.setFullYear(today.getFullYear() - 1);
                            inTimeframe = bDate >= ago && bDate <= today;
                          }

                          let inCategory = true;
                          if (analyticsCategoryFilter !== 'all') {
                            inCategory = (b.artCategory || '').toLowerCase() === analyticsCategoryFilter.toLowerCase();
                          }

                          return inTimeframe && inCategory;
                        });

                        const totalAmountVal = targetBookingsSet.reduce((sum, item) => sum + (item.amount || 0), 0);
                        const statusCountsCount = targetBookingsSet.reduce((acc, b) => {
                          const s = b.status || 'pending';
                          acc[s] = (acc[s] || 0) + 1;
                          return acc;
                        }, { pending: 0, accepted: 0, in_progress: 0, completed: 0, cancelled: 0 } as Record<string, number>);

                        // Service distribution popularities
                        const rawServiceMap = targetBookingsSet.reduce((acc, b) => {
                          const rawCat = b.artCategory || 'general';
                          acc[rawCat] = (acc[rawCat] || 0) + 1;
                          return acc;
                        }, {} as Record<string, number>);

                        const rankedServices = Object.entries(rawServiceMap).sort((ax, bx) => (bx[1] as number) - (ax[1] as number)) as [string, number][];
                        const dominantService = rankedServices[0] ? rankedServices[0][0].replace(/-/g, ' ') : "None";

                        // Revenue Trend monthly data inside frame
                        const monthlyTrendSet = targetBookingsSet.reduce((acc, item) => {
                          if (item.status !== 'cancelled' && item.date) {
                            const mLabel = new Date(item.date).toLocaleString(undefined, { month: 'short', year: 'numeric' });
                            acc[mLabel] = (acc[mLabel] || 0) + (item.amount || 0);
                          }
                          return acc;
                        }, {} as Record<string, number>);
                        const sortedTrendLines = Object.entries(monthlyTrendSet) as [string, number][];

                        // Upcoming schedules review (next 3)
                        const rawUpcomingList = bookings.filter(b => {
                          const todayStr = new Date().toISOString().split('T')[0];
                          return (b.status === 'accepted' || b.status === "in_progress" || b.status === "pending") && b.date >= todayStr;
                        }).sort((a,b) => a.date.localeCompare(b.date)).slice(0, 3);

                        return (
                          <div className="space-y-8">
                             {/* Statistic Widgets */}
                             <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
                                <div className="p-5 bg-gradient-to-b from-zinc-950/80 to-black border border-white/5 rounded-2xl">
                                  <span className="text-[8px] font-mono uppercase tracking-widest text-zinc-500 block">Earnings Realised</span>
                                  <h5 className="text-xl font-serif text-emerald-500 font-bold tracking-tight mt-1">{formatCurrency(totalAmountVal)}</h5>
                                  <span className="text-[7.5px] font-mono text-zinc-650 block mt-1">Based on active query</span>
                                </div>
                                <div className="p-5 bg-gradient-to-b from-zinc-950/80 to-black border border-white/5 rounded-2xl">
                                  <span className="text-[8px] font-mono uppercase tracking-widest text-zinc-500 block">Total Inbound Requests</span>
                                  <h5 className="text-xl font-serif text-white font-bold tracking-tight mt-1">{targetBookingsSet.length}</h5>
                                  <span className="text-[7.5px] font-mono text-zinc-650 block mt-1">{statusCountsCount.pending} pending approvals</span>
                                </div>
                                <div className="p-5 bg-gradient-to-b from-zinc-950/80 to-black border border-white/5 rounded-2xl">
                                  <span className="text-[8px] font-mono uppercase tracking-widest text-zinc-500 block">Completion Rate</span>
                                  <h5 className="text-xl font-serif text-green-500 font-bold tracking-tight mt-1">
                                    {targetBookingsSet.length ? Math.round((statusCountsCount.completed / targetBookingsSet.length) * 100) : 0}%
                                  </h5>
                                  <span className="text-[7.5px] font-mono text-zinc-650 block mt-1">{statusCountsCount.completed} delivery cycles closed</span>
                                </div>
                                <div className="p-5 bg-gradient-to-b from-zinc-950/80 to-black border border-white/5 rounded-2xl">
                                  <span className="text-[8px] font-mono uppercase tracking-widest text-zinc-500 block">Cancelled/Void</span>
                                  <h5 className="text-xl font-serif text-red-500 font-bold tracking-tight mt-1">{statusCountsCount.cancelled}</h5>
                                  <span className="text-[7.5px] font-mono text-zinc-650 block mt-1 font-bold">Safeguarded logs preservation</span>
                                </div>
                                <div className="p-5 bg-gradient-to-b from-zinc-950/80 to-black border border-white/5 rounded-2xl">
                                  <span className="text-[8px] font-mono uppercase tracking-widest text-zinc-500 block">Dominated Niche</span>
                                  <h5 className="text-xs font-mono text-amber-500 font-bold tracking-wide mt-2 truncate uppercase" title={dominantService}>{dominantService}</h5>
                                  <span className="text-[7.5px] font-mono text-zinc-650 block mt-1">Highest frequency count</span>
                                </div>
                             </div>

                             {/* Visual Analytics Graphs */}
                             <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

                                {/* Monthly Revenue Trend SVG Visualizer */}
                                <div className="p-6 bg-zinc-950/80 border border-white/5 rounded-3xl space-y-4">
                                   <div className="flex items-center justify-between">
                                      <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-500">Monthly Revenue Velocity</span>
                                      <span className="text-[8px] font-mono text-zinc-500">Active periods logged: {sortedTrendLines.length}</span>
                                   </div>
                                   <div className="h-64 flex items-end justify-between gap-3 pt-6 relative px-2">
                                     {/* Background yLines */}
                                     <div className="absolute inset-0 flex flex-col justify-between pointer-events-none select-none py-1 text-zinc-800 text-[6.5px] font-mono pt-6">
                                       <div className="w-full border-t border-zinc-900 pr-1 text-right">MAX EARNINGS</div>
                                       <div className="w-full border-t border-zinc-900 pr-1 text-right font-bold">MEDIAN</div>
                                       <div className="w-full border-t border-zinc-900 pr-1 text-right">0.00</div>
                                     </div>

                                     {sortedTrendLines.length > 0 ? (
                                       (() => {
                                          const maxVal = Math.max(...sortedTrendLines.map(t => t[1]), 1000);
                                          return sortedTrendLines.map(([mLabel, mVal], idx) => (
                                            <div key={idx} className="flex-1 flex flex-col items-center group/chart duration-300 relative">
                                               {/* Floating amount note on hover */}
                                               <div className="absolute -top-6 bg-amber-500 text-black text-[7.5px] font-mono px-1.5 py-0.5 rounded opacity-0 group-hover/chart:opacity-100 transition-opacity z-10 pointer-events-none whitespace-nowrap font-bold">
                                                 {formatCurrency(mVal)}
                                               </div>
                                               
                                               <div className="w-full bg-zinc-900 rounded-lg relative h-44 overflow-hidden flex items-end">
                                                  <div 
                                                    className="w-full bg-gradient-to-t from-amber-600 via-amber-500 to-amber-300 rounded-lg transition-all shadow-[0_0_12px_rgba(245,158,11,0.15)] group-hover/chart:brightness-110"
                                                    style={{ height: `${(mVal / maxVal) * 100}%` }}
                                                  />
                                               </div>
                                               <span className="text-[8px] font-mono text-zinc-550 mt-2 whitespace-nowrap overflow-hidden text-ellipsis max-w-full text-center">{mLabel}</span>
                                            </div>
                                          ));
                                       })()
                                     ) : (
                                       <div className="absolute inset-0 flex items-center justify-center text-[10px] font-mono text-zinc-500 italic">
                                         No revenue trends to plot in active query parameters boundaries.
                                       </div>
                                     )}
                                   </div>
                                </div>

                                {/* Service Type Popularity segmented list block */}
                                <div className="p-6 bg-zinc-950/80 border border-white/5 rounded-3xl space-y-5">
                                   <div className="flex items-center justify-between">
                                      <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-500">Service Popularity Distribution</span>
                                      <div className="text-[8px] font-mono text-zinc-550 flex items-center gap-1">
                                        <div className="w-1.5 h-1.5 bg-amber-500 rounded-full" />
                                        <span>Percentage share</span>
                                      </div>
                                   </div>

                                   <div className="space-y-4 pt-1 max-h-56 overflow-y-auto font-mono">
                                     {rankedServices.length > 0 ? (
                                        rankedServices.map(([srvTitle, srvQty], idx) => {
                                          const percentShare = Math.round((srvQty / targetBookingsSet.length) * 100);
                                          return (
                                            <div key={idx} className="space-y-1.5 group/pop select-none">
                                               <div className="flex justify-between items-center text-[11px]">
                                                 <span className="text-zinc-200 capitalize group-hover/pop:text-amber-500 transition-colors">{srvTitle.replace(/-/g, ' ')}</span>
                                                 <span className="text-zinc-400 font-bold">{srvQty} reservations <span className="text-amber-500">({percentShare}%)</span></span>
                                               </div>
                                               <div className="w-full bg-zinc-900 h-2 rounded-full overflow-hidden border border-white/5">
                                                  <motion.div 
                                                    initial={{ width: 0 }}
                                                    animate={{ width: `${percentShare}%` }}
                                                    transition={{ duration: 1, ease: 'easeOut' }}
                                                    className="h-full bg-gradient-to-r from-amber-600 to-amber-400 rounded-full"
                                                  />
                                               </div>
                                            </div>
                                          );
                                       })
                                     ) : (
                                       <div className="text-center py-16 italic text-zinc-500 text-[10.5px]">
                                         Zero service transactions recorded in timeline window.
                                       </div>
                                     )}
                                   </div>
                                </div>

                             </div>

                             {/* Upcoming events preview drawer shortcut block */}
                             <div className="p-6 bg-zinc-950/80 border border-white/5 rounded-3xl space-y-4">
                                <div className="flex justify-between items-center">
                                   <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-500 flex items-center gap-2">
                                      <History className="h-3.5 w-3.5" />
                                      <span>Execution Pipeline Checklist: Next 3 Immediate Bookings</span>
                                   </span>
                                   <span className="text-[8px] font-mono text-zinc-500">Total Pipeline: {bookings.filter(b => b.status === 'accepted' || b.status === 'in_progress').length} Active</span>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                   {rawUpcomingList.length > 0 ? (
                                      rawUpcomingList.map((bk, bIdx) => (
                                        <div key={bk.id} className="p-4 bg-black/40 border border-white/5 rounded-2xl relative space-y-2 text-xs flex flex-col justify-between">
                                           <div className="space-y-1">
                                              <div className="flex justify-between items-start">
                                                 <h6 className="font-bold text-white uppercase overflow-hidden text-ellipsis whitespace-nowrap max-w-[120px]">{bk.userName}</h6>
                                                 <span className="text-[7.5px] font-mono uppercase bg-zinc-900 px-2 py-0.5 text-zinc-505 text-zinc-400 rounded border border-white/5">{bk.status}</span>
                                              </div>
                                              <p className="text-amber-500/95 font-mono text-[9px] font-bold uppercase">{bk.artCategory.replace(/-/g, ' ')}</p>
                                              <div className="text-zinc-400 font-mono text-[9px] space-y-0.5">
                                                 <div>Date: <strong className="text-zinc-200">{bk.date}</strong></div>
                                                 <div>Location: {bk.location}</div>
                                              </div>
                                           </div>
                                           
                                           <div className="pt-2 border-t border-white/5 mt-2 flex justify-between items-center">
                                              <span className="text-[9px] font-mono text-emerald-500 font-bold">{formatCurrency(bk.amount)}</span>
                                              <button 
                                                onClick={() => {
                                                  setSelectedBookingDetails(bk);
                                                  setAdmPrivateNote(bk.adminNotes || '');
                                                }}
                                                className="text-[9px] font-bold text-amber-500 hover:text-amber-400 font-mono flex items-center gap-1 hover:underline cursor-pointer"
                                              >
                                                <span>Inspect</span>
                                                <ArrowRight className="h-2.5 w-2.5" />
                                              </button>
                                           </div>
                                        </div>
                                      ))
                                   ) : (
                                      <div className="col-span-3 text-center py-12 text-zinc-500 italic font-mono text-[10.5px]">No schedules pending in immediate future pipeline.</div>
                                   )}
                                </div>
                             </div>

                          </div>
                        );
                     })()}

                   </div>
                 )}
              </motion.div>
            )}

            {/* 4. PUBLISH SERVICES AND ART DETAILS */}
            {activeTab === 'upload-media' && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-12">
                 <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                    
                    {/* Add service form */}
                    <form onSubmit={handleServiceAdd} className="bg-zinc-950/60 p-8 rounded-[2rem] border border-white/5 space-y-6">
                        <div className="flex items-center justify-between border-b border-white/5 pb-4">
                           <h3 className="text-amber-500 font-mono text-[10px] font-bold uppercase tracking-widest">Publish New Canvas Service</h3>
                           <Palette className="h-4 w-4 text-amber-500" />
                        </div>

                        {/* Visual Media Preview Banner (Live Preview before publish) */}
                        <div className="relative h-44 w-full rounded-2xl overflow-hidden bg-black border border-white/10 flex flex-col items-center justify-center p-4">
                          {serviceFile || serviceData.image ? (
                            <div className="absolute inset-0 w-full h-full">
                              {serviceFile ? (
                                serviceFile.type.startsWith('video/') ? (
                                  <video src={URL.createObjectURL(serviceFile)} autoPlay muted loop className="w-full h-full object-cover text-center" />
                                ) : (
                                  <img src={URL.createObjectURL(serviceFile)} className="w-full h-full object-cover text-center" alt="Service Preview" />
                                )
                              ) : (
                                serviceData.mediaType === 'video' ? (
                                  <video src={serviceData.image} autoPlay muted loop className="w-full h-full object-cover text-center" />
                                ) : (
                                  <img src={serviceData.image} className="w-full h-full object-cover text-center" alt="Service Preview" />
                                )
                              )}
                              <div className="absolute inset-0 bg-black/60 pointer-events-none" />
                              <button
                                type="button"
                                onClick={() => {
                                  setServiceFile(null);
                                  setServiceData(prev => ({ ...prev, image: '' }));
                                }}
                                className="absolute top-3 right-3 bg-red-500 hover:bg-red-650 p-1.5 rounded-full text-white text-xs transition duration-200 cursor-pointer z-10"
                                title="Remove selected media"
                              >
                                <X className="h-3.5 w-3.5" />
                              </button>
                            </div>
                          ) : null}

                          <div className="relative z-10 flex flex-col items-center justify-center text-center space-y-1">
                            <Sparkles className="h-5 w-5 text-amber-500/40 mb-1 animate-pulse" />
                            <span className="text-[8px] text-amber-500/50 uppercase tracking-[0.2em] font-bold">Atelier Canvas Preview</span>
                            <span className="text-[10px] text-zinc-400 italic">No image or video mounted yet</span>
                          </div>
                        </div>

                        {/* Upload Zone & Manual Paste Box */}
                        <div className="space-y-3">
                          <div {...getServiceRootProps()} className="group border border-dashed border-white/10 p-6 rounded-2xl text-center cursor-pointer hover:border-amber-500/30 transition bg-black/40">
                            <input {...getServiceInputProps()} />
                            <Upload className="h-5 w-5 text-zinc-500 mx-auto mb-2 group-hover:text-amber-500 transition-colors" />
                            <p className="text-zinc-400 text-[10px] font-mono uppercase tracking-wider">Drag & Drop Image/Video Here</p>
                            <p className="text-zinc-600 text-[9px] mt-1">Supports JPG, PNG, WEBP, and MP4 files</p>
                          </div>

                          <div className="relative flex items-center gap-2">
                            <div className="h-px bg-white/5 flex-grow" />
                            <span className="text-[8px] font-mono text-zinc-650 uppercase">or paste artwork url</span>
                            <div className="h-px bg-white/5 flex-grow" />
                          </div>

                          <div className="grid grid-cols-1">
                            <input 
                              type="text" 
                              placeholder="Image or Video URL" 
                              className="bg-black/40 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white focus:border-amber-500 outline-none w-full"
                              value={serviceData.image}
                              onChange={e => setServiceData(prev => ({ ...prev, image: e.target.value }))}
                            />
                          </div>

                          <div className="flex items-center gap-4 text-[9px] font-mono text-zinc-500 pl-1">
                            <span>Image URL Media Type:</span>
                            <label className="flex items-center gap-1 cursor-pointer">
                              <input 
                                type="radio" 
                                name="addServiceMediaType" 
                                checked={serviceData.mediaType === 'image'} 
                                onChange={() => setServiceData(prev => ({ ...prev, mediaType: 'image' }))} 
                              />
                              <span>Image</span>
                            </label>
                            <label className="flex items-center gap-1 cursor-pointer">
                              <input 
                                type="radio" 
                                name="addServiceMediaType" 
                                checked={serviceData.mediaType === 'video'} 
                                onChange={() => setServiceData(prev => ({ ...prev, mediaType: 'video' }))} 
                              />
                              <span>Video</span>
                            </label>
                          </div>
                        </div>

                        {/* Standard parameters */}
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-1">
                            <label className="text-[8px] uppercase font-mono tracking-widest text-zinc-500">Service Title</label>
                            <input type="text" placeholder="e.g. Imperial Live Portrait Painting" required className="bg-black/30 border border-white/10 rounded-xl px-3 py-2 text-xs outline-none w-full text-white focus:border-amber-500" value={serviceData.title} onChange={e => setServiceData({...serviceData, title: e.target.value})} />
                          </div>
                          <div className="space-y-1">
                            <label className="text-[8px] uppercase font-mono tracking-widest text-zinc-500">Service Class</label>
                            <select className="bg-black/30 border border-white/10 rounded-xl px-3 py-2 text-zinc-400 font-mono text-xs outline-none w-full focus:border-amber-500 cursor-pointer" value={serviceData.category} onChange={e => setServiceData({...serviceData, category: e.target.value})}>
                                <option>Couple Portraits</option>
                                <option>Live Wedding Sketches</option>
                                <option>Clay Art</option>
                                <option>Caricatures</option>
                                <option>Custom Gifts</option>
                                <option>Pencil Sketches</option>
                                <option>Acrylic Paintings</option>
                                <option>Event Artwork</option>
                                <option>Wedding Paintings</option>
                                <option>Temporary Tattoo Art</option>
                                <option>Live Sketches</option>
                                <option>Live Doodle Art</option>
                                <option>Live Mandap Painting</option>
                                <option>Magical Portrait</option>
                                <option>Pottery Art</option>
                            </select>
                          </div>
                        </div>

                        {/* Pricing details */}
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-1">
                            <label className="text-[8px] uppercase font-mono tracking-widest text-zinc-500">Classic Retainer Price (₹)</label>
                            <input type="number" placeholder="e.g. 15000" required className="bg-black/30 border border-white/10 rounded-xl px-3 py-2 text-xs outline-none w-full text-white focus:border-amber-500" value={serviceData.price || ''} onChange={e => setServiceData({...serviceData, price: Number(e.target.value)})} />
                          </div>
                          <div className="space-y-1">
                            <label className="text-[8px] uppercase font-mono tracking-widest text-zinc-500">Imperial Full Package (₹)</label>
                            <input type="number" placeholder="e.g. 29000" required className="bg-black/30 border border-white/10 rounded-xl px-3 py-2 text-xs outline-none w-full text-white focus:border-amber-500" value={serviceData.premiumPrice || ''} onChange={e => setServiceData({...serviceData, premiumPrice: Number(e.target.value)})} />
                          </div>
                        </div>

                        {/* Supplementary parameters */}
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-1">
                            <label className="text-[8px] uppercase font-mono tracking-widest text-zinc-500">Session Span / Duration Limit</label>
                            <input type="text" placeholder="e.g. 4-6 Hours live setup" required className="bg-black/30 border border-white/10 rounded-xl px-3 py-2 text-xs outline-none w-full text-white focus:border-amber-500" value={serviceData.duration} onChange={e => setServiceData({...serviceData, duration: e.target.value})} />
                          </div>
                          <div className="space-y-1">
                            <label className="text-[8px] uppercase font-mono tracking-widest text-zinc-500">Active Materials Specification</label>
                            <input type="text" placeholder="e.g. Belgian Linen & Oil Paints" required className="bg-black/30 border border-white/10 rounded-xl px-3 py-2 text-xs outline-none w-full text-white focus:border-amber-500" value={serviceData.materials} onChange={e => setServiceData({...serviceData, materials: e.target.value})} />
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-1">
                            <label className="text-[8px] uppercase font-mono tracking-widest text-zinc-500">Delivery Time Frame Description</label>
                            <input type="text" placeholder="e.g. Next morning Studio Pickup" required className="bg-black/30 border border-white/10 rounded-xl px-3 py-2 text-xs outline-none w-full text-white focus:border-amber-500" value={serviceData.deliveryTime} onChange={e => setServiceData({...serviceData, deliveryTime: e.target.value})} />
                          </div>
                          <div className="space-y-1">
                            <label className="text-[8px] uppercase font-mono tracking-widest text-zinc-500">Discount Offer Percentage (%)</label>
                            <input type="number" placeholder="e.g. 10 for 10% OFF" className="bg-black/30 border border-white/10 rounded-xl px-3 py-2 text-xs outline-none w-full text-white focus:border-amber-500" value={serviceData.discountOffer || ''} onChange={e => setServiceData({...serviceData, discountOffer: Number(e.target.value)})} />
                          </div>
                        </div>

                        <div className="space-y-1">
                          <label className="text-[8px] uppercase font-mono tracking-widest text-zinc-500">Bespoke Workshop Specs & Scope</label>
                          <textarea placeholder="Specify size dimensions, brush specifications, custom gold leaves support..." required className="bg-black/30 border border-white/10 p-4 rounded-xl text-xs w-full outline-none text-white focus:border-amber-500" rows={3} value={serviceData.description} onChange={e => setServiceData({...serviceData, description: e.target.value})} />
                        </div>

                        <button type="submit" disabled={serviceUploading} className="w-full py-4 bg-amber-500 hover:bg-amber-450 text-black font-bold uppercase text-[10px] tracking-widest rounded-xl transition-all select-none duration-300 transform hover:-translate-y-0.5 cursor-pointer">
                          {serviceUploading ? "Publishing to Cloud..." : "Publish Premium Service"}
                        </button>
                    </form>

                    {/* Publish gallery artwork form */}
                    <form onSubmit={handleGalleryUpload} className="bg-black/20 p-8 rounded-3xl border border-white/5 space-y-6">
                        <div className="flex items-center justify-between border-b border-white/5 pb-4">
                           <h3 className="text-amber-500 font-bold uppercase tracking-widest text-xs">Publish Completed Art to Gallery</h3>
                           <ImageIcon className="h-4 w-4 text-gray-500" />
                        </div>
                        <div {...getGalleryRootProps()} className="group relative border-2 border-dashed border-amber-555 border-amber-500/10 p-8 rounded-2xl text-center cursor-pointer hover:border-amber-500/30 transition-colors bg-black/40 overflow-hidden">
                          <input {...getGalleryInputProps()} />
                          {uploadFile ? (
                            <div className="space-y-2">
                               {uploadFile.type.startsWith('image/') ? (
                                 <img src={URL.createObjectURL(uploadFile)} className="w-20 h-20 object-cover rounded-xl mx-auto border border-amber-500/20" alt="Preview" />
                               ) : (
                                 <video src={URL.createObjectURL(uploadFile)} className="w-full max-h-40 rounded-xl mx-auto border border-amber-500/20" controls />
                               )}
                               <p className="text-amber-500 text-xs font-bold truncate px-4">{uploadFile.name}</p>
                            </div>
                          ) : <p className="text-gray-400 text-xs lowercase">Drag & drop final canvas images or timelapse MP4s</p>}
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <input type="text" placeholder="Artwork Artwork Title" required className="bg-transparent border-b border-amber-500/30 py-2 text-sm outline-none w-full text-white" value={uploadData.title} onChange={e => setUploadData({...uploadData, title: e.target.value})} />
                          <select className="bg-transparent border-b border-amber-500/30 py-2 text-sm outline-none w-full text-zinc-400 font-bold" value={uploadData.category} onChange={e => setUploadData({...uploadData, category: e.target.value})}>
                              <option>Couple Portraits</option>
                              <option>Live Wedding Sketches</option>
                              <option>Clay Art</option>
                              <option>Caricatures</option>
                              <option>Custom Gifts</option>
                              <option>Pencil Sketches</option>
                              <option>Acrylic Paintings</option>
                              <option>Event Artwork</option>
                              <option>Wedding Paintings</option>
                              <option>Temporary Tattoo Art</option>
                              <option>Live Sketches</option>
                              <option>Live Doodle Art</option>
                              <option>Live Mandap Painting</option>
                              <option>Magical Portrait</option>
                              <option>Pottery Art</option>
                          </select>
                        </div>
                        <div className="flex gap-4">
                            <button type="button" onClick={() => setUploadData({...uploadData, mediaType: 'image'})} className={cn("px-4 py-1 text-[9px] uppercase border font-mono tracking-widest", uploadData.mediaType === 'image' ? "border-amber-500 text-amber-500" : "border-white/10 text-gray-400")}>Image</button>
                            <button type="button" onClick={() => setUploadData({...uploadData, mediaType: 'video'})} className={cn("px-4 py-1 text-[9px] uppercase border font-mono tracking-widest", uploadData.mediaType === 'video' ? "border-amber-500 text-amber-500" : "border-white/10 text-gray-400")}>Timelapse Video</button>
                        </div>
                        <button type="submit" disabled={uploading} className="w-full py-4 bg-amber-500 text-black font-bold uppercase text-[11px] tracking-widest hover:bg-amber-400 transition-colors cursor-pointer">
                          {uploading ? "Publishing Canvas..." : "Publish to Gallery"}
                        </button>
                    </form>

                 </div>

                  {/* MASTER PRICING & ACTIVE SERVICES MANAGER */}
                  <div className="bg-zinc-950/40 p-8 rounded-[2rem] border border-white/5 space-y-8 mt-12">
                     <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/5 pb-4">
                        <div>
                           <h3 className="text-amber-500 font-bold uppercase tracking-[0.2em] text-xs">Dynamic Services Price & Package Manager</h3>
                           <p className="text-zinc-500 text-[10px] mt-1 font-light">Directly modify base rates, premium packages, duration targets, specific material characteristics & discount campaigns.</p>
                        </div>
                        <span className="bg-amber-500/10 text-amber-500 text-[10px] font-mono px-3 py-1 rounded-full border border-amber-500/20 font-bold h-max flex items-center justify-center">
                           {services?.length || 0} Active Services
                        </span>
                     </div>

                     <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        {services && services.map((s: ArtService) => (
                           <ServiceAdminCard key={s.id || (s as any)._id} service={s} onRefresh={refreshData} />
                        ))}
                        {(!services || services.length === 0) && (
                          <div className="text-zinc-500 text-xs italic py-4 col-span-2 text-center">No active custom-published services found. FALLBACK standard defaults are configured automatically for customers online.</div>
                        )}
                     </div>
                  </div>

                  {/* TRASH / DELETED SERVICES RECOVERY PANEL */}
                  {deletedServices && deletedServices.length > 0 && (
                     <div className="bg-red-950/10 p-8 rounded-[2rem] border border-red-500/10 space-y-6 mt-8">
                        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-red-500/5 pb-4">
                           <div>
                              <h3 className="text-red-400 font-bold uppercase tracking-[0.2em] text-xs flex items-center gap-2">
                                 <Trash2 className="h-4 w-4" /> Service Archive (Trash Basket)
                              </h3>
                              <p className="text-zinc-500 text-[10px] mt-1 font-light">Temporarily archived services. You can restore them to restore public pricing instantly, or perform a permanent erase.</p>
                           </div>
                           <span className="bg-red-500/10 text-red-400 text-[10px] font-mono px-3 py-1 rounded-full border border-red-500/20 font-bold h-max flex items-center justify-center">
                              {deletedServices.length} Archived Items
                           </span>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                           {deletedServices.map((s: ArtService) => (
                              <ServiceTrashCard key={s.id || (s as any)._id} service={s} onRefresh={refreshData} />
                           ))}
                        </div>
                     </div>
                  )}

              </motion.div>
            )}

            {/* 5. HERO MANAGEMENT TABS */}
            {activeTab === 'hero-manager' && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-12">
                 <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
                    <form onSubmit={handleHeroUpload} className="lg:col-span-1 bg-black/20 p-8 rounded-3xl border border-white/5 space-y-6">
                        <div className="flex items-center justify-between border-b border-white/5 pb-4">
                           <h3 className="text-amber-500 font-bold uppercase tracking-widest text-xs">Upload Hero loops</h3>
                           <Sparkles className="h-4 w-4 text-gray-500" />
                        </div>
                        <div {...getHeroRootProps()} className="group relative border-2 border-dashed border-amber-500/20 p-8 rounded-2xl text-center cursor-pointer hover:border-amber-500/40 transition-colors bg-black/40 overflow-hidden">
                          <input {...getHeroInputProps()} />
                          {heroUploadFile ? (
                            <div className="space-y-2">
                              {heroUploadFile.type.startsWith('image/') ? (
                                 <img src={URL.createObjectURL(heroUploadFile)} className="w-20 h-20 object-cover rounded-xl mx-auto border border-amber-500/20" alt="Preview" />
                               ) : (
                                 <video src={URL.createObjectURL(heroUploadFile)} className="w-full max-h-40 rounded-xl mx-auto border border-amber-500/20" controls />
                               )}
                               <p className="text-amber-550 text-amber-500 text-xs font-bold truncate px-4">{heroUploadFile.name}</p>
                            </div>
                          ) : <p className="text-gray-400 text-xs lowercase">Drop cinematic loop MP4 or images</p>}
                        </div>
                        <div className="space-y-4">
                           <input type="text" placeholder="Hero Title" required className="bg-transparent border-b border-amber-500/30 py-2 text-sm outline-none w-full text-white" value={heroUploadData.title} onChange={e => setHeroUploadData({...heroUploadData, title: e.target.value})} />
                           <div className="flex gap-4">
                              <button type="button" onClick={() => setHeroUploadData({...heroUploadData, mediaType: 'image'})} className={cn("px-4 py-1 text-[9px] uppercase border font-mono tracking-widest", heroUploadData.mediaType === 'image' ? "border-amber-500 text-amber-500" : "border-white/10 text-gray-400")}>Image</button>
                              <button type="button" onClick={() => setHeroUploadData({...heroUploadData, mediaType: 'video'})} className={cn("px-4 py-1 text-[9px] uppercase border font-mono tracking-widest", heroUploadData.mediaType === 'video' ? "border-amber-500 text-amber-500" : "border-white/10 text-gray-400")}>Video</button>
                           </div>
                        </div>
                        <button type="submit" disabled={heroUploading} className="w-full py-4 bg-amber-500 text-black font-bold uppercase text-[11px] tracking-widest hover:bg-amber-400 transition-colors cursor-pointer">
                          {heroUploading ? "Publishing media..." : "Publish Hero Media"}
                        </button>
                    </form>

                    <div className="lg:col-span-2 space-y-6">
                      <h4 className="text-white font-serif text-xl border-b border-white/5 pb-2">Active Hero Slides</h4>
                      <div className="grid grid-cols-2 gap-4">
                         {heroMedia.map(item => (
                            <div key={item.id} className="p-4 bg-black/40 border border-white/5 rounded-2xl flex flex-col justify-between">
                               <div>
                                  <div className="w-full h-24 rounded-lg bg-zinc-900 border overflow-hidden">
                                     {item.mediaType === 'image' ? <img src={item.mediaUrl} onError={handleImageError} className="w-full h-full object-cover" /> : <video src={item.mediaUrl} className="w-full h-full object-cover" controls />}
                                  </div>
                                  <div className="text-white font-serif text-sm mt-2">{item.title}</div>
                               </div>
                               <div className="flex justify-between items-center mt-4 pt-2 border-t border-white/5">
                                 <button onClick={() => handleToggleFeaturedHero(item.id, item.isFeatured)} className={cn("px-3 py-1 text-[8px] uppercase font-mono tracking-widest font-bold", item.isFeatured ? "bg-amber-500 text-black rounded-lg" : "border border-white/10 text-gray-400")}>
                                     {item.isFeatured ? "Featured" : "Set Featured"}
                                 </button>
                                 <button onClick={() => handleDeleteHero(item.id)} className="p-2 bg-red-500/10 text-red-400 rounded-lg hover:bg-red-500 hover:text-white transition-colors cursor-pointer">
                                    <Trash2 className="h-4 w-4" />
                                 </button>
                               </div>
                            </div>
                         ))}
                      </div>
                    </div>
                 </div>
              </motion.div>
            )}

            {/* 6. ADMIN PORTFOLIO LIBRARY */}
            {activeTab === 'gallery-manager' && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-6">
                 <h3 className="text-white font-serif text-2xl border-b border-white/5 pb-2">Portfolio Library Catalog ({gallery.length})</h3>
                 <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                    {gallery.map(item => (
                       <div key={item.id} className="p-4 bg-black/40 border border-white/5 rounded-2xl flex flex-col justify-between">
                          <div>
                             {item.mediaType === 'video' ? (
                               <video src={item.mediaUrl} className="w-full h-32 object-cover rounded-lg border border-white/5" muted autoPlay loop playsInline />
                             ) : (
                               <img src={item.mediaUrl} onError={handleImageError} className="w-full h-32 object-cover rounded-lg border border-white/5" alt="Gall" />
                             )}
                             <h4 className="text-white font-serif text-sm mt-2 truncate">{item.title}</h4>
                             <span className="text-[9px] font-mono uppercase tracking-widest text-amber-500 block mt-1">{item.category}</span>
                          </div>
                          <div className="flex justify-between items-center pt-2 mt-4 border-t border-white/5">
                             <span className="text-[7px] text-gray-500 font-mono">ID: {item.id.substring(item.id.length-6)}</span>
                             <button onClick={() => triggerDeleteGallery(item, false)} className="p-1.5 bg-red-500/10 text-red-400 hover:bg-red-500 hover:text-white rounded-lg transition-colors cursor-pointer" title="Move to Trash">
                                <Trash2 className="h-3.5 w-3.5" />
                             </button>
                          </div>
                       </div>
                    ))}
                 </div>

                 {/* Portfolio recovery basket / trash list */}
                 {deletedGallery && deletedGallery.length > 0 && (
                    <div className="bg-red-950/10 p-8 rounded-[2rem] border border-red-500/10 space-y-6 mt-12 animate-fade-in">
                       <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-red-500/5 pb-4">
                          <div>
                             <h4 className="text-red-400 font-bold uppercase tracking-[0.2em] text-xs flex items-center gap-2">
                                <Trash2 className="h-4 w-4" /> Portfolio Trash Basket (Soft Deleted)
                             </h4>
                             <p className="text-zinc-500 text-[10px] mt-1 font-light">Temporarily archived artworks. You can restore them back to the active public catalog or delete them permanently from Cloudinary space.</p>
                          </div>
                          <span className="bg-red-500/10 text-red-400 text-[10px] font-mono px-3 py-1 rounded-full border border-red-500/20 font-bold h-max flex items-center justify-center">
                             {deletedGallery.length} Archived Items
                          </span>
                       </div>

                       <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                          {deletedGallery.map(item => (
                             <div key={item.id} className="p-4 bg-zinc-950/60 border border-red-500/10 rounded-2xl flex flex-col justify-between hover:border-red-500/20 transition-all">
                                <div>
                                   <div className="relative group overflow-hidden rounded-lg">
                                      {item.mediaType === 'video' ? (
                                        <video src={item.mediaUrl} className="w-full h-32 object-cover opacity-50 grayscale transition-all group-hover:opacity-75 group-hover:grayscale-0" muted autoPlay loop playsInline />
                                      ) : (
                                        <img src={item.mediaUrl} onError={handleImageError} className="w-full h-32 object-cover opacity-50 grayscale transition-all group-hover:opacity-75 group-hover:grayscale-0" alt="Gall text" />
                                      )}
                                      <span className="absolute top-2 right-2 bg-red-950 border border-red-500/25 px-2 py-0.5 rounded text-[8px] font-mono uppercase tracking-wider text-red-400 font-bold">Deleted</span>
                                   </div>
                                   <h4 className="text-zinc-400 font-serif text-sm mt-3 truncate">{item.title}</h4>
                                   <span className="text-[9px] font-mono uppercase tracking-widest text-zinc-650 block mt-1">{item.category}</span>
                                </div>
                                <div className="flex justify-between items-center pt-2 mt-4 border-t border-white/5 gap-2">
                                   <button 
                                      onClick={() => handleRestoreGallery(item.id)} 
                                      className="flex-1 py-1.5 px-3 bg-zinc-900 border border-zinc-800 hover:border-amber-500/30 hover:bg-zinc-950 text-amber-550 text-[10px] font-mono uppercase tracking-wider text-center text-amber-500 rounded-lg transition-colors cursor-pointer"
                                   >
                                      Restore
                                   </button>
                                   <button 
                                      onClick={() => triggerDeleteGallery(item, true)} 
                                      className="p-2 bg-red-500/15 text-red-400 hover:bg-red-500 hover:text-white rounded-lg transition-colors cursor-pointer"
                                      title="Permanently Erase"
                                   >
                                      <Trash2 className="h-3.5 w-3.5" />
                                   </button>
                                </div>
                             </div>
                          ))}
                       </div>
                    </div>
                 )}
              </motion.div>
            )}

            {/* 7. COLLECTORS DIRECTORY */}
            {activeTab === 'users' && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-6">
                 <h3 className="text-white font-serif text-2xl border-b border-white/5 pb-2">Collector Accounts ({users.length})</h3>
                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {users.map(usr => (
                       <div key={usr.uid} className="p-5 bg-black/40 border border-white/5 rounded-2xl flex items-center space-x-4">
                          <div className="w-12 h-12 bg-amber-500/10 border border-amber-500/20 rounded-full flex items-center justify-center font-bold text-amber-500 font-mono text-sm shrink-0 uppercase">
                             {usr.photoURL ? <img src={usr.photoURL} onError={handleAvatarError} className="w-full h-full rounded-full" /> : usr.displayName?.substring(0, 2) || "CL"}
                          </div>
                          <div className="min-w-0">
                             <div className="font-bold text-white text-sm truncate">{usr.displayName || "Anonymous Collector"}</div>
                             <p className="text-[10px] text-zinc-500 font-mono truncate">{usr.email}</p>
                             <div className="text-[8px] font-mono text-amber-500 uppercase font-bold tracking-widest mt-1">Role: {usr.role}</div>
                          </div>
                       </div>
                    ))}
                 </div>
              </motion.div>
            )}

            {/* 8. GENERAL CONFIG TABS */}
            {activeTab === 'settings' && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-6">
                <form onSubmit={handleUpdateSettings} className="bg-black/30 p-8 rounded-3xl border border-white/5 space-y-6 max-w-xl">
                    <h3 className="text-amber-500 font-serif text-xl border-b border-white/5 pb-3">Configure Concierge Coordinates</h3>
                    
                    <div className="space-y-4">
                       <div className="space-y-1 text-xs text-zinc-400">
                           <label className="text-[10px] uppercase font-bold tracking-widest">Public Support Phone (WhatsApp Direct)</label>
                           <input type="text" className="w-full bg-black border border-white/10 p-3.5 rounded-xl text-white outline-none focus:border-amber-500" value={settings.contactNumber} onChange={e => setSettings({...settings, contactNumber: e.target.value})} />
                       </div>
                       <div className="space-y-1 text-xs text-zinc-400">
                           <label className="text-[10px] uppercase font-bold tracking-widest">Atelier Admin Notification Inbox</label>
                           <input type="email" className="w-full bg-black border border-white/10 p-3.5 rounded-xl text-white outline-none focus:border-amber-500" value={settings.adminEmail} onChange={e => setSettings({...settings, adminEmail: e.target.value})} />
                       </div>
                       <div className="space-y-1 text-xs text-zinc-400">
                           <label className="text-[10px] uppercase font-bold tracking-widest">Instagram Handler URL</label>
                           <input type="text" className="w-full bg-black border border-white/10 p-3.5 rounded-xl text-white outline-none focus:border-amber-500" value={settings.instagramUrl} onChange={e => setSettings({...settings, instagramUrl: e.target.value})} />
                       </div>
                    </div>

                    <button type="submit" className="px-8 py-3.5 bg-amber-500 hover:bg-amber-400 text-black font-bold uppercase text-xs tracking-widest rounded-xl transition-all cursor-pointer">
                        Update Settings
                    </button>
                </form>
              </motion.div>
            )}

          </AnimatePresence>
        </div>
      </div>

      {/* 9. PORTFOLIO DELETION CONFIRMATION MODAL */}
      <AnimatePresence>
        {deleteModal.isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4"
          >
            {/* Backdrop click to cancel */}
            <div className="absolute inset-0" onClick={() => !isDeleting && setDeleteModal(prev => ({ ...prev, isOpen: false }))} />

            <motion.div
              initial={{ scale: 0.95, y: 10 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 10 }}
              transition={{ type: 'spring', duration: 0.4 }}
              className="relative w-full max-w-md bg-zinc-950 border border-amber-500/20 p-8 rounded-[2rem] shadow-2xl shadow-black/80 z-10 overflow-hidden"
            >
              {/* Gold light accent bar */}
              <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-amber-500/20 via-amber-500 to-amber-500/20" />

              <div className="flex flex-col items-center text-center space-y-4">
                <div className="w-12 h-12 bg-red-500/10 border border-red-500/20 rounded-full flex items-center justify-center text-red-500">
                  <Trash2 className="h-5 w-5" />
                </div>

                <div className="space-y-1.5">
                  <span className="text-[9px] font-mono uppercase tracking-[0.35em] text-amber-500 font-bold block">
                    {deleteModal.itemType === 'gallery-permanent' ? "Permanent Eradication" : "Atelier Archive Action"}
                  </span>
                  <h3 className="text-white font-serif text-lg font-bold">
                    {deleteModal.itemType === 'gallery-permanent' ? "Erase from Atelier?" : "Move Artwork to Trash?"}
                  </h3>
                  <p className="text-zinc-400 text-xs py-1 px-4 leading-relaxed font-light">
                    {deleteModal.itemType === 'gallery-permanent' 
                      ? `Are you sure you want to permanently delete "${deleteModal.itemTitle}"? This will free up Cloudinary CDN storage space and cannot be undone.`
                      : `Are you sure you want to archive "${deleteModal.itemTitle}"? It will be removed from your public gallery and placed in the Portfolio Trash Basket.`}
                  </p>
                </div>

                <div className="flex items-center gap-3 w-full pt-4 border-t border-white/5">
                  <button
                    type="button"
                    disabled={isDeleting}
                    onClick={() => setDeleteModal(prev => ({ ...prev, isOpen: false }))}
                    className="flex-1 py-3 px-4 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-400 hover:text-white font-mono uppercase text-[9px] font-bold tracking-widest rounded-xl transition duration-300 disabled:opacity-50 select-none cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    disabled={isDeleting}
                    onClick={handleConfirmDelete}
                    className={cn(
                      "flex-1 py-3 px-4 text-black font-mono uppercase text-[9px] font-bold tracking-widest rounded-xl transition duration-300 select-none cursor-pointer flex items-center justify-center gap-1.5 shadow-lg",
                      deleteModal.itemType === 'gallery-permanent'
                        ? "bg-red-500 hover:bg-red-650 shadow-red-500/5 hover:shadow-red-500/15 text-white"
                        : "bg-amber-500 hover:bg-amber-450 shadow-amber-500/5 hover:shadow-amber-500/15",
                      isDeleting && "opacity-50 pointer-events-none"
                    )}
                  >
                    {isDeleting ? (
                      <>
                        <Loader2 className="h-3.5 w-3.5 animate-spin text-black" />
                        <span>Processing...</span>
                      </>
                    ) : (
                      <span>{deleteModal.itemType === 'gallery-permanent' ? "Delete Forever" : "Move to Trash"}</span>
                    )}
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Extreme Deep Inspection Administrative Drawer Popover & Customer Logs (Goal: Appointment management rescheduling / admin notes / client chat logs) */}
      <AnimatePresence>
        {selectedBookingDetails && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/95 flex justify-end p-0"
          >
            {/* Click backdrop to exit */}
            <div className="absolute inset-0" onClick={() => setSelectedBookingDetails(null)} />

            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="relative w-full max-w-2xl bg-zinc-950 border-l border-white/10 h-full overflow-y-auto p-8 md:p-12 space-y-8 flex flex-col"
            >
              {/* Drawer header */}
              <div className="flex justify-between items-start border-b border-white/5 pb-6">
                <div>
                   <span className="text-amber-500 font-bold uppercase text-[9px] tracking-[0.3em] font-mono block">COMMISSION CONTROL SPECIFICATIONS</span>
                   <h2 className="text-2xl font-serif text-white tracking-tight mt-1">{selectedBookingDetails.userName}</h2>
                   <span className="text-[10px] font-mono text-gray-500">Ref ID: {selectedBookingDetails.id}</span>
                </div>
                <button
                  onClick={() => setSelectedBookingDetails(null)}
                  className="p-2 bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white rounded-full transition-colors cursor-pointer"
                  id="close-admin-inspect-drawer"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              {/* Drawer Content */}
              <div className="flex-1 space-y-8 pr-1">
                 
                 {/* Spec Panel */}
                 <div className="grid grid-cols-2 gap-4 text-xs">
                    <div className="p-4 bg-zinc-900/40 border border-white/5 rounded-2xl">
                       <span className="text-zinc-500 text-[9px] font-bold block uppercase tracking-wider">Masterwork Category</span>
                       <p className="text-white font-bold mt-1 uppercase text-[11px] font-mono">{selectedBookingDetails.artCategory.replace(/-/g, ' ')}</p>
                    </div>
                    <div className="p-4 bg-zinc-900/40 border border-white/5 rounded-2xl">
                       <span className="text-zinc-500 text-[9px] font-bold block uppercase tracking-wider">Retainer Settle</span>
                       <p className="text-emerald-500 font-bold mt-1 text-sm">{formatCurrency(selectedBookingDetails.amount)} (PAID)</p>
                    </div>
                    <div className="p-4 bg-zinc-900/40 border border-white/5 rounded-2xl col-span-2">
                       <span className="text-zinc-500 text-[9px] font-bold block uppercase tracking-wider">Event Coordination Venue</span>
                       <p className="text-zinc-200 mt-1">{selectedBookingDetails.location}</p>
                       <span className="text-[10px] text-zinc-500 block mt-1">Proposed timing: {selectedBookingDetails.timing} | Targets: {selectedBookingDetails.date}</span>
                      <div className="mt-4 pt-4 border-t border-white/5 space-y-3">
                        <span className="text-amber-500 text-[9px] font-bold block uppercase tracking-[0.2em] text-left">Customer Contact & Quick Channels</span>
                        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                          <div className="space-y-1 text-left">
                            <p className="text-zinc-300 text-xs">Email: <span className="text-white font-mono font-medium">{selectedBookingDetails.userEmail}</span></p>
                            <p className="text-zinc-300 text-xs">Mobile: <span className="text-white font-mono font-medium">{selectedBookingDetails.phone || 'None'}</span></p>
                            <p className="text-zinc-300 text-xs">WhatsApp: <span className="text-amber-500 font-mono font-bold">{selectedBookingDetails.whatsapp || selectedBookingDetails.phone || 'None'}</span></p>
                          </div>
                          <div className="flex gap-2 shrink-0">
                            {selectedBookingDetails.phone && (
                              <a 
                                href={`tel:${selectedBookingDetails.phone}`}
                                className="px-3 py-1.5 bg-zinc-950 hover:bg-zinc-800 text-white border border-white/5 hover:border-amber-500/40 font-mono uppercase text-[9px] font-bold tracking-wider rounded-xl transition-all inline-flex items-center gap-1.5"
                              >
                                <Phone className="h-3 w-3 text-amber-500" />
                                <span>Call</span>
                              </a>
                            )}
                            <a 
                              href={`https://wa.me/${(selectedBookingDetails.whatsapp || selectedBookingDetails.phone || '').replace(/[^0-9]/g, '')}?text=${encodeURIComponent("Hi, relative to your high-end live sketch art reservation with Deepak Prajapati...")}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="px-3 py-1.5 bg-green-500/10 hover:bg-green-500/20 text-green-400 border border-green-500/10 hover:border-green-500/25 font-mono uppercase text-[9px] font-bold tracking-wider rounded-xl transition-all inline-flex items-center gap-1.5"
                            >
                              <MessageSquare className="h-3 w-3" />
                              <span>WhatsApp</span>
                            </a>
                          </div>
                        </div>
                      </div>
                    </div>
                    {selectedBookingDetails.requirements && (
                      <div className="p-4 bg-zinc-900/40 border border-white/5 rounded-2xl col-span-2">
                         <span className="text-zinc-500 text-[9px] font-bold block uppercase tracking-wider">Client Vision Specs</span>
                         <p className="text-zinc-300 italic mt-1 leading-relaxed bg-black/40 p-3 rounded-xl">"{selectedBookingDetails.requirements}"</p>
                      </div>
                    )}
                 </div>

                 {/* Action Status Toggles (Goal: Order Status Management) */}
                 <div className="space-y-3 bg-zinc-900/10 p-5 rounded-3xl border border-white/5">
                    <h3 className="text-amber-500 font-mono text-[10px] uppercase font-bold tracking-widest">Adjust Booking Status (Notify Client)</h3>
                    
                    <div className="flex flex-wrap gap-2">
                       {['pending', 'accepted', 'in_progress', 'completed', 'cancelled'].map(stVal => (
                          <button
                            key={stVal}
                            onClick={() => handleUpdateStatus(selectedBookingDetails.id, stVal)}
                            className={cn(
                              "px-3 py-2 text-[9px] font-mono font-bold uppercase tracking-widest rounded-xl transition-all cursor-pointer",
                              selectedBookingDetails.status === stVal 
                                ? "bg-amber-500 text-black shadow-lg shadow-amber-500/10" 
                                : "bg-black border border-white/10 text-gray-400 hover:text-white"
                            )}
                          >
                             {stVal === 'in_progress' ? 'In Prep' : stVal}
                          </button>
                       ))}
                    </div>

                    <div className="space-y-1 mt-3">
                       <input 
                         type="text" 
                         placeholder="Optional: Provide custom timeline message to client in status email notification..."
                         className="w-full bg-black border border-white/10 p-3 rounded-xl text-xs text-white"
                         value={statusActionNote}
                         onChange={e => setStatusActionNote(e.target.value)}
                       />
                    </div>
                 </div>

                 {/* Administrative Notes Persist Section (Goal: Persist admin comments) */}
                 <div className="space-y-3 p-5 bg-zinc-900/10 rounded-3xl border border-white/5">
                    <h3 className="text-amber-500 font-mono text-[10px] uppercase font-bold tracking-widest">Lead Artist Private Log</h3>
                    <textarea
                      placeholder="Record canvas sizes, pigment chemistry notes, transportation coordinates..."
                      className="w-full bg-black border border-white/10 p-4 rounded-xl text-xs text-white outline-none focus:border-amber-500 min-h-[85px]"
                      value={admPrivateNote}
                      onChange={e => setAdmPrivateNote(e.target.value)}
                    />
                    <button
                      onClick={() => handleSaveAdminPrivateNotes(selectedBookingDetails.id)}
                      className="px-5 py-2 bg-amber-500 text-black font-semibold text-[10px] uppercase tracking-widest rounded-lg hover:bg-amber-400 transition-colors cursor-pointer"
                    >
                       Save Private Note
                    </button>
                 </div>

                 {/* Commission Lifecycle Ledger (History Log timeline) */}
                  <div className="space-y-4 p-5 bg-gradient-to-b from-zinc-950/65 to-black/60 rounded-3xl border border-white/5">
                     <div className="flex items-center justify-between">
                       <h3 className="text-amber-500 font-mono text-[10px] uppercase font-bold tracking-widest flex items-center gap-2">
                         <History className="h-3.5 w-3.5 text-amber-500" />
                         <span>Commission Lifecycle Ledger & Activity Log</span>
                       </h3>
                       <span className="text-[8px] font-mono text-zinc-500 bg-zinc-900 border border-white/5 px-2 py-0.5 rounded-full select-none">
                         {selectedBookingDetails.statusHistory?.length || 0} Entries
                       </span>
                     </div>
                     
                     <div className="relative border-l border-zinc-900 pl-4 ml-2.5 space-y-4 max-h-56 overflow-y-auto pr-1 animate-fade-in">
                       {selectedBookingDetails.statusHistory && selectedBookingDetails.statusHistory.length > 0 ? (
                         [...selectedBookingDetails.statusHistory].reverse().map((item, index) => (
                           <div key={index} className="relative group">
                             {/* Bullet dot */}
                             <div className={cn(
                               "absolute -left-[21.5px] top-1.5 w-2 h-2 rounded-full border bg-black transition-all",
                               item.status === 'pending' ? "border-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.3)]" :
                               item.status === 'accepted' ? "border-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.3)]" :
                               item.status === 'in_progress' ? "border-purple-400 shadow-[0_0_8px_rgba(192,132,252,0.3)]" :
                               item.status === 'completed' ? "border-green-500 shadow-[0_0_8px_rgba(34,197,94,0.3)]" :
                               "border-red-500 shadow-[0_0_8px_rgba(239,68,68,0.3)]"
                             )} />
                             
                             <div className="space-y-0.5">
                               <div className="flex items-center justify-between">
                                 <span className={cn(
                                   "text-[9px] font-mono font-bold tracking-widest uppercase",
                                   item.status === 'pending' ? "text-amber-500" :
                                   item.status === 'accepted' ? "text-blue-500" :
                                   item.status === 'in_progress' ? "text-purple-400" :
                                   item.status === 'completed' ? "text-green-500" :
                                   "text-red-500"
                                 )}>
                                   {item.status === 'in_progress' ? 'In Prep/Execution' : item.status.replace(/_/g, ' ')}
                                 </span>
                                 <span className="text-[8px] font-mono text-zinc-500 font-medium">
                                   {new Date(item.timestamp).toLocaleString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                                 </span>
                               </div>
                               <p className="text-[10px] text-zinc-300 bg-zinc-900/40 p-2 border border-white/5 rounded-lg leading-relaxed font-mono">
                                 {item.note || `Status transition updated without description.`}
                               </p>
                             </div>
                           </div>
                         ))
                       ) : (
                         <div className="text-zinc-650 text-[10px] italic py-3 select-none font-mono">
                           No actions have been registered in the lifecycle ledger yet.
                         </div>
                       )}
                     </div>
                  </div>

                  {/* Reschedule Booking Module */}
                 <div className="space-y-3 p-5 bg-zinc-900/10 rounded-3xl border border-white/5">
                    <div className="flex justify-between items-center">
                       <h3 className="text-amber-500 font-mono text-[10px] uppercase font-bold tracking-widest">Atelier Schedule Editor</h3>
                       {selectedBookingDetails.rescheduleRequested && (
                         <span className="px-2 py-0.5 bg-purple-500/10 text-purple-400 text-[8px] font-mono font-bold uppercase tracking-widest rounded-sm border border-purple-500/20 animate-pulse">
                            Client Requested Reschedule
                         </span>
                       )}
                    </div>
                    {selectedBookingDetails.rescheduleRequested && (
                      <div className="p-3 bg-purple-950/20 rounded-xl border border-purple-500/10 text-[10px] text-purple-300">
                         Client suggested: <strong>{selectedBookingDetails.rescheduleDate}</strong> during <strong>{selectedBookingDetails.rescheduleTiming}</strong>.
                      </div>
                    )}
                    <div className="grid grid-cols-2 gap-3">
                       <input 
                         type="date" 
                         className="bg-black border border-white/10 p-3 rounded-xl text-xs text-white outline-none focus:border-amber-500"
                         value={admReschDate}
                         onChange={e => setAdmReschDate(e.target.value)}
                       />
                       <input 
                         type="text" 
                         placeholder="Timing (e.g. 5 PM - 9 PM)"
                         className="bg-black border border-white/10 p-3 rounded-xl text-xs text-white outline-none focus:border-amber-500"
                         value={admReschTiming}
                         onChange={e => setAdmReschTiming(e.target.value)}
                       />
                    </div>
                    <input 
                      type="text" 
                      placeholder="Comment / Reason for schedule edit..."
                      className="w-full bg-black border border-white/10 p-3 rounded-xl text-xs text-white outline-none focus:border-amber-500"
                      value={admReschNote}
                      onChange={e => setAdmReschNote(e.target.value)}
                    />
                    <button
                      onClick={() => handleAdminReschedule(selectedBookingDetails.id)}
                      className="px-5 py-2 bg-amber-500 text-black font-semibold text-[10px] uppercase tracking-widest rounded-lg hover:bg-amber-400 transition-colors cursor-pointer"
                    >
                       Apply & Commit Schedule Change
                    </button>
                 </div>

                 {/* Chat Dialogue section (Goal: Customer dialogue log & messaging) */}
                 <div className="space-y-4 p-5 bg-zinc-900/10 rounded-3xl border border-white/5 flex flex-col">
                    <h3 className="text-amber-500 font-mono text-[10px] uppercase font-bold tracking-widest">Active Client Dialogue Stream</h3>
                    
                    <div className="space-y-3 max-h-48 overflow-y-auto pr-1 flex flex-col">
                      {selectedBookingDetails.communicationLog && selectedBookingDetails.communicationLog.length > 0 ? (
                        selectedBookingDetails.communicationLog.map((log, lIdx) => {
                          const isClient = log.sender === 'customer';
                          return (
                            <div
                              key={lIdx}
                              className={cn(
                                "max-w-[75%] p-3.5 rounded-2xl text-xs flex flex-col",
                                isClient 
                                  ? "bg-zinc-805 bg-zinc-850 bg-zinc-900 text-white self-start border border-white/5" 
                                  : "bg-amber-500/10 text-white self-end border border-amber-500/10"
                              )}
                            >
                              <span className="text-[8px] font-bold uppercase tracking-widest text-zinc-500 mb-1">
                                {isClient ? "Client (Collector)" : "Lead Artist (Me)"}
                              </span>
                              <span>{log.text}</span>
                              <span className="text-[7px] text-zinc-500 mt-1 block text-right">
                                {new Date(log.timestamp).toLocaleString()}
                              </span>
                            </div>
                          );
                        })
                      ) : (
                        <p className="text-[10px] text-gray-500 font-mono text-center py-4 uppercase">Dialogue feed is completely empty.</p>
                      )}
                    </div>

                    <div className="flex gap-2">
                       <input 
                         type="text"
                         placeholder="Write response message..."
                         className="flex-1 bg-black border border-white/10 p-3 rounded-xl text-xs text-white outline-none"
                         value={admChatText}
                         onChange={e => setAdmChatText(e.target.value)}
                         onKeyDown={e => e.key === 'Enter' && handleSendAdminChatMessage(selectedBookingDetails.id)}
                       />
                       <button 
                         onClick={() => handleSendAdminChatMessage(selectedBookingDetails.id)}
                         disabled={!admChatText.trim()}
                         className="p-3 bg-amber-500 text-black rounded-xl hover:bg-amber-400 transition-all font-bold cursor-pointer"
                       >
                         <Send className="h-4 w-4" />
                       </button>
                    </div>
                 </div>

                 {/* WhatsApp Quick Templates actions (Goal: WhatsApp notification actions) */}
                 <div className="space-y-3 p-5 bg-zinc-900/10 rounded-3xl border border-white/5">
                    <h3 className="text-amber-500 font-mono text-[10px] uppercase font-bold tracking-widest flex items-center gap-1.5">
                       <Phone className="h-3.5 w-3.5" />
                       <span>WhatsApp Studio Alert Dispatcher</span>
                    </h3>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                       <button onClick={() => triggerWhatsAppRedirect(selectedBookingDetails, 'confirm')} className="py-2 px-3 bg-green-500/10 text-green-400 border border-green-500/10 rounded-xl text-[9px] font-mono uppercase tracking-wider hover:bg-green-500 hover:text-black transition-all cursor-pointer">
                          Confirm & Greet
                       </button>
                       <button onClick={() => triggerWhatsAppRedirect(selectedBookingDetails, 'reschedule')} className="py-2 px-3 bg-purple-500/10 text-purple-400 border border-purple-500/10 rounded-xl text-[9px] font-mono uppercase tracking-wider hover:bg-purple-500 hover:text-white transition-all cursor-pointer">
                          Propose Edit
                       </button>
                       <button onClick={() => triggerWhatsAppRedirect(selectedBookingDetails, 'reminder')} className="py-2 px-3 bg-blue-500/10 text-blue-400 border border-blue-500/10 rounded-xl text-[9px] font-mono uppercase tracking-wider hover:bg-blue-500 hover:text-white transition-all cursor-pointer">
                          Send Reminder Alert
                       </button>
                    </div>
                 </div>

              </div>

              {/* Close footer link */}
              <button 
                 onClick={() => setSelectedBookingDetails(null)}
                 className="w-full py-4 bg-zinc-900 border border-white/5 hover:bg-zinc-800 text-white hover:text-amber-500 font-bold tracking-widest uppercase text-xs rounded-xl mt-6 cursor-pointer"
              >
                 Dismiss Audit
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}

// Local calendar helper checks
function isInspectedToday(dateStr: string | null): boolean {
  if (!dateStr) return false;
  const today = new Date();
  const formattedD = String(today.getDate()).padStart(2, '0');
  const formattedM = String(today.getMonth() + 1).padStart(2, '0');
  const todayStr = `${today.getFullYear()}-${formattedM}-${formattedD}`;
  return dateStr === todayStr;
}

// Fallback handlers for broken images
function handleImageError(e: React.SyntheticEvent<HTMLImageElement, Event>) {
  e.currentTarget.src = "https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?q=80&w=1000";
}

function handleAvatarError(e: React.SyntheticEvent<HTMLImageElement, Event>) {
  e.currentTarget.src = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?q=80&w=300";
}

// Interactive Premium Dynamic Price & Package Administrator Card Component
function ServiceAdminCard({ service, onRefresh }: { service: ArtService; onRefresh: () => any; key?: any }) {
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  
  // Local edit states
  const [price, setPrice] = useState(service.price);
  const [premiumPrice, setPremiumPrice] = useState(service.premiumPrice || Math.floor(service.price * 1.5));
  const [duration, setDuration] = useState(service.duration || '4 to 6 active live hours');
  const [deliveryTime, setDeliveryTime] = useState(service.deliveryTime || 'On-site / 4 Days');
  const [materials, setMaterials] = useState(service.materials || 'Premium Canvas Cotton');
  const [discountOffer, setDiscountOffer] = useState(service.discountOffer || 0);
  const [title, setTitle] = useState(service.title);
  const [description, setDescription] = useState(service.description);
  const [image, setImage] = useState(service.image || '');
  const [mediaType, setMediaType] = useState<'image' | 'video'>(service.mediaType || 'image');
  const [uploadingMedia, setUploadingMedia] = useState(false);

  const handleMediaUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingMedia(true);
    const formData = new FormData();
    formData.append('file', file);

    try {
      const res = await fetch(`/api/media/upload?folder=services`, {
        method: 'POST',
        body: formData
      });
      if (!res.ok) throw new Error("Upload failed");
      const data = await res.json();
      
      setImage(data.url);
      setMediaType(file.type.startsWith('video/') ? 'video' : 'image');
      toast.success("Service illustration uploaded successfully! ✨");
    } catch (err) {
      console.error(err);
      toast.error("Failed to upload service cover media.");
    } finally {
      setUploadingMedia(false);
    }
  };

  const handleImageError = (e: React.SyntheticEvent<HTMLImageElement, Event>) => {
    e.currentTarget.src = "https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?q=80&w=1000";
  };

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const targetId = (service as any)._id || service.id;
      const res = await fetch('/api/admin/services/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: targetId,
          price: Number(price),
          premiumPrice: Number(premiumPrice),
          duration,
          deliveryTime,
          materials,
          discountOffer: Number(discountOffer),
          title,
          description,
          image,
          mediaType
        })
      });
      if (res.ok) {
        toast.success(`Service "${title}" details updated! ✨`);
        setEditing(false);
        onRefresh();
      } else {
        throw new Error();
      }
    } catch (err) {
      toast.error("Failed to update service details.");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    setDeleting(true);
    try {
      const targetId = (service as any)._id || service.id;
      const res = await fetch(`/api/admin/services/${targetId}`, {
        method: 'DELETE'
      });
      if (res.ok) {
        toast.success(`Service "${title}" archived to Trash! 🗑️`);
        onRefresh();
      } else {
        throw new Error();
      }
    } catch (err) {
      toast.error("Failed to move service to Trash.");
    } finally {
      setDeleting(false);
      setConfirmDelete(false);
    }
  };

  return (
    <div className="p-6 bg-black/40 border border-white/5 rounded-2xl space-y-4 hover:border-amber-500/20 transition-all flex flex-col justify-between">
      <div>
        {/* Service Visual Preview Banner */}
        <div className="relative h-44 w-full rounded-xl overflow-hidden bg-black border border-white/5 mb-3 flex items-center justify-center group/banner">
          {image ? (
            mediaType === 'video' ? (
              <video 
                src={image} 
                autoPlay 
                muted 
                loop 
                playsInline 
                className="w-full h-full object-cover transition-transform duration-700 group-hover/banner:scale-105" 
              />
            ) : (
              <img 
                src={image} 
                alt={title} 
                className="w-full h-full object-cover transition-transform duration-700 group-hover/banner:scale-105" 
                onError={handleImageError}
              />
            )
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-zinc-950 via-[#121212] to-black flex flex-col items-center justify-center p-4">
              <Sparkles className="h-5 w-5 text-amber-500/30 mb-2 animate-pulse" />
              <span className="text-[8px] text-amber-500/40 uppercase tracking-[0.2em] font-bold">Atelier Standard</span>
              <span className="text-[10px] text-zinc-650 font-serif italic mt-1 font-semibold">{title}</span>
            </div>
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent pointer-events-none" />
          
          <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between z-10">
            <span className="bg-black/80 backdrop-blur-md px-2 py-0.5 rounded border border-white/5 text-[8px] uppercase font-mono text-zinc-400">
              {mediaType || 'image'}
            </span>
            {discountOffer > 0 && (
              <span className="bg-red-500/25 border border-red-500/30 text-red-400 text-[8px] font-mono px-1.5 py-0.5 rounded uppercase font-bold">
                -{discountOffer}% Off
              </span>
            )}
          </div>
        </div>

        <div className="flex items-center justify-between border-b border-white/5 pb-3">
          <div>
            <h4 className="text-white font-bold text-sm tracking-wide">{service.title}</h4>
            <span className="text-[9px] text-zinc-500 font-mono capitalize">{service.category}</span>
          </div>
          
          {confirmDelete ? (
            <div className="flex gap-2 shrink-0">
              <span className="text-[9px] text-red-400 font-mono flex items-center justify-center mr-1">Archive?</span>
              <button 
                type="button" 
                disabled={deleting}
                onClick={handleDelete} 
                className="px-2 py-0.5 text-[8px] font-mono border border-red-500 bg-red-500/20 text-red-100 hover:bg-red-500 hover:text-black rounded-md uppercase tracking-wider cursor-pointer font-bold shrink-0"
              >
                {deleting ? "Archiving..." : "Yes, Trash"}
              </button>
              <button 
                type="button" 
                onClick={() => setConfirmDelete(false)} 
                className="px-2 py-0.5 text-[8px] font-mono border border-zinc-500 hover:border-zinc-300 text-zinc-300 rounded-md uppercase tracking-wider cursor-pointer shrink-0"
              >
                Cancel
              </button>
            </div>
          ) : (
            <div className="flex gap-2">
              <button 
                type="button" 
                onClick={() => setEditing(!editing)} 
                className="px-2.5 py-1 text-[8px] font-mono border border-amber-500/20 hover:border-amber-500/50 text-amber-500 rounded-md uppercase tracking-wider cursor-pointer"
              >
                {editing ? "Cancel" : "Edit Rates"}
              </button>
              <button 
                type="button" 
                onClick={() => setConfirmDelete(true)} 
                className="px-2.5 py-1 text-[8px] font-mono border border-red-500/25 hover:border-red-500 text-red-400 rounded-md uppercase tracking-wider h-max align-middle cursor-pointer"
              >
                Delete
              </button>
            </div>
          )}
        </div>

        {editing ? (
          <form onSubmit={handleUpdate} className="space-y-4 pt-3 text-xs">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-[8px] uppercase tracking-wider font-mono text-zinc-500">Service Title</label>
                <input type="text" className="w-full bg-black/80 border border-white/10 rounded-lg py-1.5 px-2 text-white text-xs outline-none focus:border-amber-500" value={title} onChange={e => setTitle(e.target.value)} required />
              </div>
              <div className="space-y-1">
                <label className="text-[8px] uppercase tracking-wider font-mono text-zinc-500">Starting Price (₹)</label>
                <input type="number" className="w-full bg-black/80 border border-white/10 rounded-lg py-1.5 px-2 text-white text-xs outline-none focus:border-amber-500" value={price} onChange={e => setPrice(Number(e.target.value))} required />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-[8px] uppercase tracking-wider font-mono text-zinc-500">Premium Package (₹)</label>
                <input type="number" className="w-full bg-black/80 border border-white/10 rounded-lg py-1.5 px-2 text-white text-xs outline-none focus:border-amber-500" value={premiumPrice} onChange={e => setPremiumPrice(Number(e.target.value))} required />
              </div>
              <div className="space-y-1">
                <label className="text-[8px] uppercase tracking-wider font-mono text-zinc-500">Discount Offer (%)</label>
                <input type="number" className="w-full bg-black/80 border border-white/10 rounded-lg py-1.5 px-2 text-white text-xs outline-none focus:border-amber-500" value={discountOffer} onChange={e => setDiscountOffer(Number(e.target.value))} placeholder="0" />
              </div>
            </div>

            {/* Premium artwork attachment / upload system */}
            <div className="p-3 bg-white/[0.02] border border-white/5 rounded-xl space-y-2">
              <div className="flex justify-between items-center">
                <label className="text-[8px] uppercase tracking-wider font-mono text-zinc-500">Service Banner Artwork</label>
                <span className="text-[8px] font-mono text-amber-500">{uploadingMedia ? "Uploading..." : "Ready"}</span>
              </div>
              
              <div className="flex gap-2">
                <input 
                  type="text" 
                  className="flex-1 bg-black/80 border border-white/10 rounded-lg py-1 px-2 text-[10px] text-zinc-300 outline-none focus:border-amber-500" 
                  value={image} 
                  onChange={e => setImage(e.target.value)} 
                  placeholder="Paste URL or upload file →" 
                />
                
                <label className="bg-zinc-900 border border-white/10 hover:border-amber-500/40 text-white hover:text-amber-500 px-3 py-1 rounded-lg text-[9px] font-mono uppercase tracking-wider cursor-pointer duration-300 flex items-center gap-1">
                  {uploadingMedia ? (
                    <Loader2 className="h-3 w-3 animate-spin text-amber-500" />
                  ) : (
                    <Upload className="h-3 w-3" />
                  )}
                  <span>Upload</span>
                  <input type="file" accept="image/*,video/*" className="hidden" onChange={handleMediaUpload} disabled={uploadingMedia} />
                </label>
              </div>

              <div className="flex items-center gap-4 text-[9px] font-mono text-zinc-500 pt-1">
                <span>Media Type:</span>
                <label className="flex items-center gap-1 cursor-pointer">
                  <input type="radio" name={`mediaType-${service.id}`} checked={mediaType === 'image'} onChange={() => setMediaType('image')} />
                  <span>Image</span>
                </label>
                <label className="flex items-center gap-1 cursor-pointer">
                  <input type="radio" name={`mediaType-${service.id}`} checked={mediaType === 'video'} onChange={() => setMediaType('video')} />
                  <span>Video</span>
                </label>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <div className="space-y-1">
                <label className="text-[8px] uppercase tracking-wider font-mono text-zinc-500">Duration Limit</label>
                <input type="text" className="w-full bg-black/80 border border-white/10 rounded-lg py-1.5 px-2 text-white text-[10px] outline-none focus:border-amber-500" value={duration} onChange={e => setDuration(e.target.value)} required />
              </div>
              <div className="space-y-1">
                <label className="text-[8px] uppercase tracking-wider font-mono text-zinc-500">Delivery Span</label>
                <input type="text" className="w-full bg-black/80 border border-white/10 rounded-lg py-1.5 px-2 text-white text-[10px] outline-none focus:border-amber-500" value={deliveryTime} onChange={e => setDeliveryTime(e.target.value)} required />
              </div>
              <div className="space-y-1">
                <label className="text-[8px] uppercase tracking-wider font-mono text-zinc-500">Materials Used</label>
                <input type="text" className="w-full bg-black/80 border border-white/10 rounded-lg py-1.5 px-2 text-white text-[10px] outline-none focus:border-amber-500" value={materials} onChange={e => setMaterials(e.target.value)} required />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[8px] uppercase tracking-wider font-mono text-zinc-500">Specs / Details Description</label>
              <textarea className="w-full bg-black/80 border border-white/10 rounded-lg py-1.5 px-2 text-white text-[11px] outline-none focus:border-amber-500" rows={2} value={description} onChange={e => setDescription(e.target.value)} required />
            </div>

            <button type="submit" disabled={saving} className="w-full py-2 bg-amber-500 text-black text-[10px] font-bold uppercase tracking-wider rounded-lg hover:bg-amber-400 transition-colors cursor-pointer">
              {saving ? "Updating Atelier Rates..." : "Save Pricing Parameters"}
            </button>
          </form>
        ) : (
          <div className="pt-3 spacing-y-2 text-xs text-zinc-400 space-y-1">
            <p className="line-clamp-2 text-[11px] italic font-light leading-relaxed">{service.description}</p>
            <div className="grid grid-cols-2 gap-2 text-[10px] pt-3 font-mono text-zinc-500">
              <div>Base price: <span className="text-white font-sans">{formatCurrency(service.price)}</span></div>
              <div>Premium pack: <span className="text-amber-500 font-sans">{formatCurrency(premiumPrice)}</span></div>
              <div>Duration: <span className="text-zinc-300 font-sans">{duration}</span></div>
              <div>Delivery: <span className="text-zinc-300 font-sans">{deliveryTime}</span></div>
              <div className="col-span-2">Materials: <span className="text-zinc-350">{materials}</span></div>
              {discountOffer > 0 ? (
                <div className="col-span-2 text-red-400">Discount Option Active: {discountOffer}% off</div>
              ) : null}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// Service Archived Trash Card for Restoration / Permanent Purging
function ServiceTrashCard({ service, onRefresh }: { service: ArtService; onRefresh: () => any; key?: any }) {
  const [restoring, setRestoring] = useState(false);
  const [purging, setPurging] = useState(false);
  const [confirmPurge, setConfirmPurge] = useState(false);

  const handleRestore = async () => {
    setRestoring(true);
    try {
      const targetId = (service as any)._id || service.id;
      const res = await fetch(`/api/admin/services/${targetId}/restore`, {
        method: 'POST'
      });
      if (res.ok) {
        toast.success(`"${service.title}" successfully restored at official atelier! ✨`);
        onRefresh();
      } else {
        throw new Error();
      }
    } catch (err) {
      toast.error("Failed to restore archived service.");
    } finally {
      setRestoring(false);
    }
  };

  const handlePermanentPurge = async () => {
    setPurging(true);
    try {
      const targetId = (service as any)._id || service.id;
      const res = await fetch(`/api/admin/services/${targetId}?permanent=true`, {
        method: 'DELETE'
      });
      if (res.ok) {
        toast.success(`"${service.title}" has been permanently purged from records.`);
        onRefresh();
      } else {
        throw new Error();
      }
    } catch (err) {
      toast.error("Failed to permanently delete service.");
    } finally {
      setPurging(false);
      setConfirmPurge(false);
    }
  };

  return (
    <div className="p-6 bg-red-950/10 border border-red-900/10 rounded-2xl space-y-4 flex flex-col justify-between opacity-85 hover:opacity-100 transition-all">
      <div>
        <div className="flex items-center justify-between border-b border-red-950/20 pb-3">
          <div>
            <h4 className="text-zinc-200 font-bold text-sm tracking-wide line-through decoration-red-900/60">{service.title}</h4>
            <span className="text-[9px] text-zinc-500 font-mono capitalize">{service.category}</span>
          </div>
          
          {confirmPurge ? (
            <div className="flex gap-2">
              <button 
                type="button" 
                disabled={purging}
                onClick={handlePermanentPurge} 
                className="px-2 py-0.5 text-[8px] font-mono border border-red-600 bg-red-600 text-white rounded-md uppercase tracking-wider cursor-pointer font-bold"
              >
                {purging ? "Purging..." : "Confirm Erase"}
              </button>
              <button 
                type="button" 
                onClick={() => setConfirmPurge(false)} 
                className="px-2 py-0.5 text-[8px] font-mono border border-zinc-600 text-zinc-400 rounded-md uppercase tracking-wider cursor-pointer"
              >
                Cancel
              </button>
            </div>
          ) : (
            <div className="flex gap-2">
              <button 
                type="button" 
                disabled={restoring}
                onClick={handleRestore} 
                className="px-2.5 py-1 text-[8px] font-mono border border-green-500/20 hover:border-green-500 hover:text-black hover:bg-green-500/10 text-green-400 rounded-md uppercase tracking-wider cursor-pointer"
              >
                {restoring ? "Restoring..." : "Restore"}
              </button>
              <button 
                type="button" 
                onClick={() => setConfirmPurge(true)} 
                className="px-2.5 py-1 text-[8px] font-mono border border-red-500/25 hover:border-red-500 hover:text-black hover:bg-red-500/10 text-red-400 rounded-md uppercase tracking-wider cursor-pointer"
              >
                Erase
              </button>
            </div>
          )}
        </div>
        <p className="text-zinc-500 text-xs italic mt-2 line-clamp-2">{service.description}</p>
        <span className="text-[9px] font-mono text-zinc-600 mt-2 block">Archived on: {new Date((service as any).deletedAt || Date.now()).toLocaleDateString()}</span>
      </div>
    </div>
  );
}
