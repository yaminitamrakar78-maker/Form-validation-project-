import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { Booking, CustomerMessage, StatusHistoryItem } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import {
  Calendar,
  MapPin,
  Clock,
  Package,
  User as UserIcon,
  LogOut,
  CreditCard,
  CalendarPlus,
  ExternalLink,
  Sparkles,
  Receipt,
  MessageSquare,
  Send,
  CalendarDays,
  Printer,
  X,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  History,
  TrendingUp
} from 'lucide-react';
import { cn, formatCurrency } from '../lib/utils';
import { ART_SERVICES } from '../constants';
import { downloadIcsFile, getGoogleCalendarUrl } from '../lib/calendar';
import toast from 'react-hot-toast';

const handleImageError = (e: React.SyntheticEvent<HTMLImageElement, Event>) => {
  e.currentTarget.src = "https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?q=80&w=1000";
};

const handleAvatarError = (e: React.SyntheticEvent<HTMLImageElement, Event>) => {
  e.currentTarget.src = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?q=80&w=300";
};

export default function Dashboard() {
  const { user, profile, logout } = useAuth();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);

  // UI state variables
  const [activeInvoice, setActiveInvoice] = useState<Booking | null>(null);
  const [activeRescheduleId, setActiveRescheduleId] = useState<string | null>(null);
  const [rescheduleDate, setRescheduleDate] = useState('');
  const [rescheduleTiming, setRescheduleTiming] = useState('');
  const [rescheduleNote, setRescheduleNote] = useState('');

  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [chatText, setChatText] = useState('');
  const [sendingChat, setSendingChat] = useState(false);
  const [expandedHistoryId, setExpandedHistoryId] = useState<string | null>(null);

  const fetchBookings = async () => {
    if (!user) return;
    try {
      const res = await fetch(`/api/bookings/user/${user.uid}`);
      if (res.ok && res.headers.get('content-type')?.includes('application/json')) {
        const data = await res.json();
        setBookings(data);
      }
    } catch (error) {
      console.error("Error fetching user bookings:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBookings();
  }, [user]);

  const handleRescheduleSubmit = async (bookingId: string) => {
    if (!rescheduleDate || !rescheduleTiming) {
      toast.error("Please fill in both Date and Timing windows.");
      return;
    }
    toast.loading("Submitting reschedule request...", { id: 'resched' });
    try {
      const res = await fetch(`/api/bookings/${bookingId}/reschedule-request`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          rescheduleDate,
          rescheduleTiming,
          note: rescheduleNote
        })
      });
      if (!res.ok) throw new Error("Request failed");
      toast.success("Reschedule request submitted to Deepak Prajapati! 🎨 Check communication log underneath.", { id: 'resched' });
      setActiveRescheduleId(null);
      setRescheduleDate('');
      setRescheduleTiming('');
      setRescheduleNote('');
      fetchBookings();
    } catch (err) {
      console.error("Reschedule failure:", err);
      toast.error("Failed to post reschedule request.", { id: 'resched' });
    }
  };

  const handleSendChatMessage = async (bookingId: string) => {
    if (!chatText.trim()) return;
    setSendingChat(true);
    try {
      const res = await fetch(`/api/admin/bookings/${bookingId}/communication`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: chatText,
          sender: "customer"
        })
      });
      if (!res.ok) throw new Error("Message failure");
      setChatText('');
      fetchBookings();
    } catch (err) {
      console.error(err);
      toast.error("Message failed to send.");
    } finally {
      setSendingChat(false);
    }
  };

  const handlePrintInvoice = () => {
    window.print();
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center pt-20">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-white mb-4">Please log in to see your dashboard</h2>
        </div>
      </div>
    );
  }

  // Visual Tracker Step Array Map
  const progressSteps = [
    { id: 'pending', label: 'Submitted', desc: 'Atelier Review' },
    { id: 'accepted', label: 'Confirmed', desc: 'Securely Scheduled' },
    { id: 'in_progress', label: 'In Design', desc: 'Creative Setup' },
    { id: 'completed', label: 'Completed', desc: 'Mastery Delivered' }
  ];

  const getStepIndex = (status: string) => {
    if (status === 'pending') return 0;
    if (status === 'accepted') return 1;
    if (status === 'in_progress') return 2;
    if (status === 'completed') return 3;
    return -1; // cancelled or unknown
  };

  return (
    <div className="min-h-screen bg-black pt-32 pb-20 px-4 md:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            <div className="p-8 bg-zinc-900/50 border border-amber-500/10 rounded-[2rem] text-center">
              <div className="w-20 h-20 bg-amber-500/10 rounded-full flex items-center justify-center mx-auto mb-6 border border-amber-500/20">
                {profile?.photoURL ? (
                  <img src={profile.photoURL || undefined} onError={handleAvatarError} alt="Profile" className="w-full h-full rounded-full" />
                ) : (
                  <UserIcon className="h-10 w-10 text-amber-500" />
                )}
              </div>
              <h2 className="text-xl font-bold text-white mb-1 truncate">{profile?.displayName || 'User'}</h2>
              <p className="text-gray-505 text-xs truncate mb-6 text-gray-400">{user.email}</p>
              
              <div className="pt-6 border-t border-white/5 space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-gray-500 uppercase tracking-widest">Branding</span>
                  <span className="text-amber-500 font-bold uppercase tracking-widest">Collector Account</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-gray-500 uppercase tracking-widest">Active Commissions</span>
                  <span className="text-white font-bold">{bookings.length}</span>
                </div>
              </div>

              <button 
                onClick={logout}
                className="w-full mt-8 flex items-center justify-center space-x-2 py-3 bg-red-500/10 text-red-400 rounded-2xl hover:bg-red-500 hover:text-white transition-all text-xs font-bold uppercase tracking-widest cursor-pointer"
              >
                <LogOut className="h-4 w-4" />
                <span>Logout</span>
              </button>
            </div>

            <div className="p-8 bg-amber-500/5 border border-amber-500/10 rounded-[2rem]">
              <h3 className="text-xs font-bold text-amber-500 uppercase tracking-[0.2em] mb-4">Studio Assistant Desk</h3>
              <p className="text-[10px] text-gray-400 uppercase tracking-widest leading-relaxed">
                Need customized support? Message Deepak directly inside the booking logs below, or contact concierge: <br />
                <a href="https://wa.me/919131051376" target="_blank" rel="noopener noreferrer" className="text-amber-500/80 hover:text-amber-500 transition-colors block mt-2 font-bold underline">WhatsApp: +91 91310 51376</a>
              </p>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3 space-y-8">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <h1 className="text-3xl md:text-5xl font-serif font-bold text-white tracking-tighter">My <span className="text-amber-500 italic">COMMISSIONS</span></h1>
              <div className="flex items-center space-x-2 text-xs text-gray-500 uppercase tracking-widest bg-zinc-900/50 px-4 py-2 rounded-full border border-white/5">
                <Package className="h-4 w-4 text-amber-500 animate-pulse" />
                <span>Real-Time Production Sync</span>
              </div>
            </div>

            {loading ? (
              <div className="py-20 flex justify-center">
                <div className="w-12 h-12 border-4 border-amber-500/20 border-t-amber-500 rounded-full animate-spin" />
              </div>
            ) : bookings.length === 0 ? (
              <div className="py-20 text-center border-2 border-dashed border-white/5 rounded-[3rem] bg-zinc-950/20">
                <h3 className="text-xl font-bold text-gray-500 uppercase tracking-widest mb-4">No commissions registered yet</h3>
                <button 
                  onClick={() => window.location.href = '/booking'}
                  className="px-8 py-3 bg-amber-500 text-black font-bold rounded-full uppercase tracking-widest text-xs hover:bg-amber-400 transition-all cursor-pointer"
                >
                  Commission Live Masterpiece
                </button>
              </div>
            ) : (
              <div className="space-y-8">
                {bookings.map((booking, index) => {
                  const service = ART_SERVICES.find(s => s.id === booking.artCategory);
                  const stepIdx = getStepIndex(booking.status);
                  const isCancelled = booking.status === 'cancelled';

                  return (
                    <motion.div
                      key={booking.id}
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.05 }}
                      className="group bg-zinc-900/30 border border-white/5 rounded-[2rem] p-6 md:p-8 hover:border-amber-500/20 transition-all shadow-xl"
                    >
                      {/* Booking Summary Row */}
                      <div className="flex flex-col md:flex-row gap-6 items-start">
                        <div className="w-full md:w-44 h-28 rounded-2xl overflow-hidden relative border border-white/10 shrink-0">
                          <img src={service?.image || "/fallback-art.jpg"} onError={handleImageError} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" alt="Service" />
                          <div className="absolute inset-0 bg-black/50" />
                          <div className="absolute inset-0 flex items-center justify-center p-2 text-center">
                            <span className="text-white text-[9px] uppercase font-bold tracking-widest">{booking.artCategory.replace(/-/g, ' ')}</span>
                          </div>
                        </div>

                        <div className="flex-1 space-y-3 w-full">
                          <div className="flex flex-wrap justify-between items-start gap-4">
                            <div>
                              <h3 className="text-xl md:text-2xl font-serif text-white tracking-tight">{service?.title || booking.artCategory}</h3>
                              <div className="flex flex-wrap gap-4 mt-2">
                                <div className="flex items-center text-xs text-gray-400 space-x-1">
                                  <Calendar className="h-3.5 w-3.5 text-amber-500" />
                                  <span>{booking.date}</span>
                                </div>
                                <div className="flex items-center text-xs text-gray-400 space-x-1">
                                  <Clock className="h-3.5 w-3.5 text-amber-500" />
                                  <span>{booking.timing}</span>
                                </div>
                                <div className="flex items-center text-xs text-gray-400 space-x-1">
                                  <MapPin className="h-3.5 w-3.5 text-amber-500" />
                                  <span className="truncate max-w-[150px]">{booking.location}</span>
                                </div>
                              </div>
                            </div>

                            <div className="flex flex-col items-end gap-2 shrink-0">
                              <span className={cn(
                                "px-3 py-1 rounded-full text-[9px] font-mono font-bold uppercase tracking-widest border",
                                booking.status === 'pending' ? "text-amber-500 border-amber-500/20 bg-amber-500/5" :
                                booking.status === 'accepted' ? "text-blue-500 border-blue-500/20 bg-blue-500/5" :
                                booking.status === 'in_progress' ? "text-purple-400 border-purple-400/20 bg-purple-400/5" :
                                booking.status === 'completed' ? "text-green-500 border-green-500/20 bg-green-500/5" :
                                "text-red-500 border-red-500/20 bg-red-500/5"
                              )}>
                                {booking.status === 'in_progress' ? 'In Preparation' : booking.status}
                              </span>

                              <span className="text-[10px] text-gray-400 bg-white/5 px-2.5 py-1 rounded-full flex items-center space-x-1 border border-white/5">
                                <CreditCard className="h-3 w-3 text-emerald-500" />
                                <span>{booking.paymentStatus === 'paid' ? 'Paid (Retainer)' : 'Retainer Check'}</span>
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Visual Progress Stepper (Goal: Customer Status Tracking) */}
                      {!isCancelled ? (
                        <div className="mt-8 pt-6 border-t border-white/5">
                          <h4 className="text-[10px] text-gray-500 uppercase tracking-widest font-mono mb-4">Masterwork Phase Tracking</h4>
                          <div className="grid grid-cols-4 gap-2 relative">
                            {/* Connector Line */}
                            <div className="absolute top-4 left-[12.5%] right-[12.5%] h-0.5 bg-zinc-800 z-0">
                              <div 
                                className="h-full bg-gradient-to-r from-amber-600 to-amber-400 transition-all duration-700"
                                style={{ width: stepIdx <= 0 ? '0%' : stepIdx === 1 ? '33.33%' : stepIdx === 2 ? '66.66%' : '100%' }}
                              />
                            </div>

                            {progressSteps.map((pStep, index) => {
                              const isCompletedStep = index <= stepIdx;
                              const isActiveStep = index === stepIdx;

                              return (
                                <div key={pStep.id} className="relative z-10 text-center flex flex-col items-center">
                                  <div className={cn(
                                    "w-8 h-8 rounded-full flex items-center justify-center transition-all duration-500 border text-[10px] font-bold font-mono",
                                    isCompletedStep 
                                      ? "bg-amber-500 border-amber-600 text-black shadow-lg shadow-amber-500/20" 
                                      : "bg-black border-zinc-700 text-zinc-500"
                                  )}>
                                    {isActiveStep ? (
                                      <motion.span animate={{ rotate: 360 }} transition={{ duration: 4, repeat: Infinity, ease: 'linear' }}>✦</motion.span>
                                    ) : (
                                      index + 1
                                    )}
                                  </div>
                                  <span className={cn(
                                    "text-[10px] font-bold mt-2",
                                    isCompletedStep ? "text-amber-500" : "text-zinc-650 text-zinc-500"
                                  )}>{pStep.label}</span>
                                  <span className="text-[8px] text-zinc-500 hidden sm:block truncate max-w-full">{pStep.desc}</span>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      ) : (
                        <div className="mt-8 pt-4 pb-2 px-6 bg-red-500/5 rounded-2xl border border-red-500/10 flex items-center space-x-3">
                          <AlertTriangle className="h-5 w-5 text-red-500 shrink-0" />
                          <p className="text-[11px] text-red-400 leading-relaxed font-mono uppercase tracking-wide">
                            Notice: This schedule slot is cancelled or postponed. Contact Deepak for direct support.
                          </p>
                        </div>
                      )}

                      {/* Expandable History Thread Section */}
                      {booking.statusHistory && booking.statusHistory.length > 0 && (
                        <div className="mt-4">
                          <button
                            onClick={() => setExpandedHistoryId(expandedHistoryId === booking.id ? null : booking.id)}
                            className="text-[9px] uppercase tracking-widest text-zinc-500 hover:text-amber-550 flex items-center gap-1 hover:text-amber-500 transition-colors"
                          >
                            <History className="h-3.5 w-3.5 text-amber-500" />
                            <span>{expandedHistoryId === booking.id ? "Hide Journey Log" : "View Commission History Metrics"}</span>
                          </button>

                          {expandedHistoryId === booking.id && (
                            <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} className="mt-4 p-4 bg-zinc-950/60 rounded-2xl border border-white/5 space-y-3">
                              {booking.statusHistory.map((item, idx) => (
                                <div key={idx} className="flex gap-3 text-xs border-l-2 border-amber-500/20 pl-4 py-1">
                                  <div className="text-[10px] text-gray-500 font-mono shrink-0">
                                    {new Date(item.timestamp).toLocaleDateString()}
                                  </div>
                                  <div>
                                    <div className="font-bold text-white uppercase text-[10px] tracking-wider">
                                      Status Changed to: <span className="text-amber-500">{item.status}</span>
                                    </div>
                                    <p className="text-gray-450 text-gray-400 mt-0.5">{item.note}</p>
                                  </div>
                                </div>
                              ))}
                            </motion.div>
                          )}
                        </div>
                      )}

                      {/* Sync with Calendars (Only for Accepted or In Preparation bookings) */}
                      {(booking.status === 'accepted' || booking.status === 'in_progress') && (
                        <div className="mt-6 p-4 rounded-2xl bg-amber-500/5 border border-amber-500/10 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                          <div className="space-y-0.5">
                            <h4 className="text-xs font-bold text-amber-500 uppercase tracking-widest flex items-center gap-1.5">
                              <Sparkles className="h-3.5 w-3.5" />
                              <span>Live Calendar Sync Ready</span>
                            </h4>
                            <p className="text-[9px] text-zinc-400 uppercase tracking-wider">
                              Keep your schedule synced. Generate a calendar card download (.ics) or direct Google Calendar link.
                            </p>
                          </div>
                          <div className="flex flex-wrap gap-2 w-full sm:w-auto shrink-0">
                            <button
                              type="button"
                              onClick={() => downloadIcsFile({
                                id: booking.id,
                                artCategory: service?.title || booking.artCategory,
                                date: booking.date,
                                timing: booking.timing,
                                location: booking.location,
                                requirements: booking.requirements
                              })}
                              className="flex-1 sm:flex-initial px-3 py-2 bg-zinc-950 hover:bg-zinc-900 border border-white/10 hover:border-amber-500/20 text-white rounded-xl text-[10px] font-mono uppercase tracking-widest flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                            >
                              <CalendarPlus className="h-3.5 w-3.5 text-amber-500" />
                              <span>iCal Card</span>
                            </button>
                            <a
                              href={getGoogleCalendarUrl({
                                id: booking.id,
                                artCategory: service?.title || booking.artCategory,
                                date: booking.date,
                                timing: booking.timing,
                                location: booking.location,
                                requirements: booking.requirements
                              })}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="flex-1 sm:flex-initial px-3 py-2 bg-amber-500 hover:bg-amber-400 text-black font-extrabold rounded-xl text-[10px] uppercase tracking-widest flex items-center justify-center gap-1.5 transition-all"
                            >
                              <ExternalLink className="h-3.5 w-3.5" />
                              <span>Google Calendar</span>
                            </a>
                          </div>
                        </div>
                      )}

                      {/* Action Menu (Invoice, Reschedule, Messenger) */}
                      <div className="mt-6 pt-6 border-t border-white/5 flex flex-wrap gap-3 items-center justify-between">
                        {/* Digital Invoice link */}
                        <button
                          onClick={() => setActiveInvoice(booking)}
                          className="flex items-center space-x-1.5 px-4 py-2 bg-zinc-950 hover:bg-zinc-900 border border-white/10 text-white hover:text-amber-500 rounded-xl text-[10px] font-mono uppercase tracking-wider transition-all cursor-pointer"
                        >
                          <Receipt className="h-3.5 w-3.5 text-amber-500" />
                          <span>View Invoice Reciept</span>
                        </button>

                        <div className="flex gap-2">
                          {/* Chat Messenger Trigger */}
                          <button
                            onClick={() => setActiveChatId(activeChatId === booking.id ? null : booking.id)}
                            className="flex items-center space-x-1.5 px-4 py-2 bg-zinc-950 hover:bg-zinc-900 border border-white/10 text-zinc-400 hover:text-amber-500 rounded-xl text-[10px] font-mono uppercase tracking-wider transition-all cursor-pointer"
                          >
                            <MessageSquare className="h-3.5 w-3.5 text-amber-500" />
                            <span>{activeChatId === booking.id ? "Close Atelier Log" : "Studio Communication Log"}</span>
                          </button>

                          {/* Reschedule Request Trigger */}
                          {!isCancelled && booking.status !== 'completed' && (
                            <button
                              onClick={() => {
                                setRescheduleDate('');
                                setRescheduleTiming('');
                                setRescheduleNote('');
                                setActiveRescheduleId(activeRescheduleId === booking.id ? null : booking.id);
                              }}
                              className="flex items-center space-x-1.5 px-4 py-2 bg-zinc-950 hover:bg-zinc-900 border border-white/10 text-zinc-400 hover:text-amber-500 rounded-xl text-[10px] font-mono uppercase tracking-wider transition-all cursor-pointer"
                            >
                              <CalendarDays className="h-3.5 w-3.5 text-amber-500" />
                              <span>Reschedule</span>
                            </button>
                          )}
                        </div>
                      </div>

                      {/* Inline Reschedule Dialog Board */}
                      <AnimatePresence>
                        {activeRescheduleId === booking.id && (
                          <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            className="mt-4 p-6 bg-zinc-950/80 border border-amber-500/10 rounded-2xl space-y-4"
                          >
                            <div className="flex items-center justify-between border-b border-white/5 pb-2">
                              <span className="text-amber-500 font-mono text-[10px] uppercase font-bold tracking-widest">Reschedule Masterpiece Event</span>
                              <X className="h-4 w-4 text-gray-500 hover:text-white cursor-pointer" onClick={() => setActiveRescheduleId(null)} />
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div className="space-y-1">
                                <label className="text-[10px] uppercase tracking-wider text-gray-500 block">Proposed Date</label>
                                <input 
                                  type="date" 
                                  className="w-full bg-black border border-white/10 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-amber-500"
                                  value={rescheduleDate}
                                  onChange={e => setRescheduleDate(e.target.value)}
                                />
                              </div>
                              <div className="space-y-1">
                                <label className="text-[10px] uppercase tracking-wider text-gray-500 block">Proposed Time Window</label>
                                <input 
                                  type="text" 
                                  placeholder="e.g. 5 PM - 9 PM"
                                  className="w-full bg-black border border-white/10 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-amber-500"
                                  value={rescheduleTiming}
                                  onChange={e => setRescheduleTiming(e.target.value)}
                                />
                              </div>
                            </div>
                            <div className="space-y-1">
                              <label className="text-[10px] uppercase tracking-wider text-gray-500 block">Reason / Details for Deepak</label>
                              <textarea 
                                placeholder="Explain why a schedule shift is requested..."
                                className="w-full bg-black border border-white/10 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-amber-500 min-h-[60px]"
                                value={rescheduleNote}
                                onChange={e => setRescheduleNote(e.target.value)}
                              />
                            </div>
                            <button
                              onClick={() => handleRescheduleSubmit(booking.id)}
                              className="px-6 py-2.5 bg-amber-500 text-black rounded-lg text-[10px] font-bold uppercase tracking-widest hover:bg-amber-400 transition-all cursor-pointer"
                            >
                              Transmit Request
                            </button>
                          </motion.div>
                        )}
                      </AnimatePresence>

                      {/* Client-Admin Chat Stream panel (Customer Communication Feed) */}
                      <AnimatePresence>
                        {activeChatId === booking.id && (
                          <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            className="mt-4 p-5 bg-zinc-950/90 border border-white/5 rounded-2xl space-y-4"
                          >
                            <div className="flex items-center justify-between border-b border-white/5 pb-2">
                              <span className="text-amber-500 font-mono text-[10px] uppercase font-bold tracking-widest">Deepak's Studio Converse</span>
                              <X className="h-4 w-4 text-gray-500 hover:text-white cursor-pointer" onClick={() => setActiveChatId(null)} />
                            </div>

                            {/* Dialogue List */}
                            <div className="space-y-3 max-h-48 overflow-y-auto pr-2 flex flex-col">
                              {booking.communicationLog && booking.communicationLog.length > 0 ? (
                                booking.communicationLog.map((log, lIdx) => {
                                  const isAdmin = log.sender === 'admin';
                                  return (
                                    <div
                                      key={lIdx}
                                      className={cn(
                                        "max-w-[75%] p-3 rounded-2xl text-xs flex flex-col",
                                        isAdmin 
                                          ? "bg-amber-500/10 text-white self-start border border-amber-500/10" 
                                          : "bg-zinc-805 bg-zinc-800 text-zinc-100 self-end"
                                      )}
                                    >
                                      <span className="text-[8px] font-bold uppercase tracking-widest text-zinc-500 mb-1">
                                        {isAdmin ? "Deepak Prajapati" : "Me"}
                                      </span>
                                      <span className="leading-relaxed">{log.text}</span>
                                      <span className="text-[7px] text-zinc-500 text-right mt-1">
                                        {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                      </span>
                                    </div>
                                  );
                                })
                              ) : (
                                <p className="text-[10px] text-gray-505 font-mono uppercase tracking-wider text-center py-4 text-gray-500">No dialogue submitted yet. Write a message below to coordinate.</p>
                              )}
                            </div>

                            {/* Message input */}
                            <div className="flex gap-2">
                              <input
                                type="text"
                                placeholder="Query/reference note regarding venue setups, delays, or color palettes..."
                                className="flex-1 bg-black border border-white/10 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-amber-500"
                                value={chatText}
                                onChange={e => setChatText(e.target.value)}
                                onKeyDown={e => e.key === 'Enter' && handleSendChatMessage(booking.id)}
                              />
                              <button
                                disabled={sendingChat || !chatText.trim()}
                                onClick={() => handleSendChatMessage(booking.id)}
                                className="p-3 bg-amber-500 disabled:opacity-50 text-black rounded-xl hover:bg-amber-400 transition-colors cursor-pointer"
                              >
                                <Send className="h-4 w-4" />
                              </button>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>

                    </motion.div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Luxury Digital Invoice Printing Overlay (Goal: Printable Receipt Generation) */}
      <AnimatePresence>
        {activeInvoice && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4 backdrop-blur-md overflow-y-auto print:absolute print:inset-0 print:bg-white print:text-black print:p-0"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="max-w-2xl w-full bg-zinc-950 border border-white/10 rounded-3xl p-8 shadow-2xl space-y-6 relative my-8 print:border-0 print:p-0 print:rounded-0 print:bg-white print:text-black"
              id="printable-invoice-container"
            >
              <button
                onClick={() => setActiveInvoice(null)}
                className="absolute top-6 right-6 p-1.5 bg-white/5 rounded-full text-zinc-400 hover:text-white transition-colors print:hidden hover:bg-white/10"
                id="close-invoice-dialog"
              >
                <X className="h-5 w-5" />
              </button>

              {/* Printing Document Core */}
              <div className="space-y-6 print:text-black print:bg-white">
                <div className="flex justify-between items-start border-b border-white/10 pb-6 print:border-zinc-300">
                  <div>
                    <span className="text-amber-500 font-bold uppercase text-[9px] tracking-[0.3em] font-mono block print:text-amber-800">ATELIER RECEIPT & TRANSCRIPT</span>
                    <h2 className="text-2xl font-serif text-white tracking-tight mt-1 print:text-black">DPartic Flow</h2>
                    <p className="text-[10px] text-zinc-500 mt-1 uppercase tracking-wider print:text-black">Indira Kala Sangeet Vishwavidyalaya Alumnus</p>
                  </div>
                  <div className="text-right">
                    <span className="text-[9px] font-bold text-zinc-500 uppercase font-mono block">INVOICE NUMBER</span>
                    <span className="text-xs font-bold text-white uppercase print:text-black">INV-{activeInvoice.id.substring(activeInvoice.id.length - 8).toUpperCase()}</span>
                    <span className="text-[8px] text-zinc-500 font-mono block mt-1">DATE: {new Date(activeInvoice.createdAt || Date.now()).toLocaleDateString()}</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 text-xs font-mono">
                  <div>
                    <span className="text-zinc-500 text-[10px] uppercase font-bold block">COLLECTOR DETAILS</span>
                    <span className="text-white font-bold block mt-1 print:text-black">{activeInvoice.userName}</span>
                    <span className="text-zinc-400 block print:text-black">{activeInvoice.userEmail}</span>
                    <span className="text-zinc-400 block print:text-black">{activeInvoice.phone}</span>
                  </div>
                  <div>
                    <span className="text-zinc-500 text-[10px] uppercase font-bold block">ATELIER CONTACT</span>
                    <span className="text-white font-bold block mt-1 print:text-black">Deepak Prajapati</span>
                    <span className="text-zinc-400 block print:text-black">kalavantdeepak1712@gmail.com</span>
                    <span className="text-zinc-400 block print:text-black">Chhattisgarh, India</span>
                  </div>
                </div>

                {/* Service Itemization Table */}
                <div className="bg-zinc-900/40 border border-white/5 rounded-2xl p-5 space-y-4 print:border-zinc-300 print:bg-zinc-100">
                  <div className="flex justify-between text-[10px] text-zinc-500 font-mono border-b border-white/10 pb-2 uppercase tracking-widest font-bold">
                    <span>Masterpiece Specification</span>
                    <span>Fees (INR)</span>
                  </div>
                  
                  <div className="flex justify-between items-center text-xs">
                    <div>
                      <span className="text-white font-bold print:text-black uppercase block">{activeInvoice.artCategory.replace(/-/g, ' ')}</span>
                      <span className="text-zinc-400 text-[10px] block mt-0.5 print:text-black">Live Event Painting Session | Hand-crafted Archival Acrylic Canvas</span>
                      <span className="text-zinc-505 text-[9px] text-zinc-500 uppercase tracking-wider block mt-0.5">Venue: {activeInvoice.location} | Date: {activeInvoice.date}</span>
                    </div>
                    <span className="text-amber-500 font-bold print:text-black">{formatCurrency(activeInvoice.amount)}</span>
                  </div>

                  <div className="border-t border-white/10 pt-4 flex justify-between items-center font-bold print:border-zinc-300">
                    <span className="text-xs text-zinc-500">RETAINER FEE REALISED</span>
                    <span className="text-base text-amber-500 print:text-black">{formatCurrency(activeInvoice.amount)} INR</span>
                  </div>
                </div>

                {/* Fine Art Terms Statement */}
                <div className="p-4 bg-zinc-950 border border-white/5 rounded-xl space-y-2 print:bg-white print:border-zinc-200">
                  <span className="text-[8px] text-amber-500 font-bold uppercase tracking-widest font-mono block print:text-amber-800">ATELIER COMMISSION COVENANT</span>
                  <p className="text-[9px] text-zinc-500 leading-relaxed print:text-black">
                     All paintings executed by Deepak Prajapati are hand-crafted original works on prime archival canvases using standard lightfast artist acrylic colors. Retainer fee ensures active venue scheduling, sketch layouts preparation, and studio transportation. Balance and framing are handled custom per project specifications.
                  </p>
                </div>

                {/* Footer seal */}
                <div className="text-center pt-4 flex flex-col items-center">
                  <div className="text-zinc-400 text-[10px] uppercase font-mono tracking-[0.2em] print:text-black">
                     DEEPAK PRAJAPATI STUDIOS
                  </div>
                  <span className="text-[8px] text-zinc-600 uppercase font-mono mt-1">INDIRA KALA SANGEET VISHWAVIDYALAYA FINE ART GRADUATE</span>
                </div>
              </div>

              {/* Printable Trigger Button */}
              <div className="flex gap-4 print:hidden">
                <button
                  onClick={handlePrintInvoice}
                  className="flex-1 py-4 bg-amber-500 text-black font-semibold rounded-2xl uppercase tracking-widest text-[11px] hover:bg-amber-400 transition-colors flex items-center justify-center space-x-2 cursor-pointer"
                >
                  <Printer className="h-4 w-4" />
                  <span>Print Receipt / Save PDF</span>
                </button>
                <button
                  onClick={() => setActiveInvoice(null)}
                  className="flex-1 py-4 bg-zinc-900 border border-white/10 text-white font-semibold rounded-2xl uppercase tracking-widest text-[11px] hover:bg-zinc-800 transition-colors cursor-pointer"
                >
                  Close Receipt
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
