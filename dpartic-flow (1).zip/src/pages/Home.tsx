import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowRight, Star, Play, Palette, Sparkles, Users, Award, 
  MessageCircle, X, Instagram, ExternalLink, Volume2, VolumeX, 
  Heart, Calendar, Compass, ShieldCheck, CheckCircle, ChevronRight,
  MapPin, Clock, RefreshCw, Send
} from 'lucide-react';
import { Link } from 'react-router-dom';
import toast from 'react-hot-toast';
import { ArtService, GalleryItem, HeroMedia } from '../types';
import { ART_SERVICES } from '../constants';

function HeroVideoPlayer({ media }: { media: HeroMedia }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isMuted, setIsMuted] = useState(true);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const handlePassiveTouch = () => {
      // Passive handler to reduce main-thread interaction overhead and prevent scroll blocking
    };

    video.addEventListener("touchstart", handlePassiveTouch, { passive: true });
    video.addEventListener("touchmove", handlePassiveTouch, { passive: true });

    return () => {
      video.removeEventListener("touchstart", handlePassiveTouch);
      video.removeEventListener("touchmove", handlePassiveTouch);
    };
  }, []);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    if (media.videoSpeed) {
      video.playbackRate = media.videoSpeed;
    } else {
      video.playbackRate = 1.0;
    }

    if (media.videoVolume !== undefined) {
      video.volume = media.videoVolume;
    } else {
      video.volume = 0.5;
    }
  }, [media, isMuted]);

  const handleLoadedMetadata = () => {
    const video = videoRef.current;
    if (!video) return;
    
    if (media.videoStartTime) {
      video.currentTime = media.videoStartTime;
    }
    
    video.play().catch(err => {
      console.log("Autoplay was prevented:", err);
    });
  };

  const handleTimeUpdate = () => {
    const video = videoRef.current;
    if (!video) return;

    const start = media.videoStartTime || 0;
    const end = media.videoEndTime;

    if (end && video.currentTime >= end) {
      video.currentTime = start;
      video.play().catch(() => {});
    }
  };

  const toggleMute = () => {
    const video = videoRef.current;
    if (!video) return;
    
    if (isMuted) {
      video.muted = false;
      setIsMuted(false);
      video.play().catch(() => {});
    } else {
      video.muted = true;
      setIsMuted(true);
    }
  };

  return (
    <div className="relative w-full h-full flex items-center justify-center p-2 bg-black">
      <video
        ref={videoRef}
        autoPlay
        muted={isMuted}
        playsInline
        onLoadedMetadata={handleLoadedMetadata}
        onTimeUpdate={handleTimeUpdate}
        className="max-w-full max-h-full object-contain rounded-xl select-none mx-auto"
        src={media.mediaUrl || null}
      />
      {media.videoVolume !== 0 && (
        <button
          type="button"
          onClick={toggleMute}
          className="absolute bottom-4 right-4 z-[80] flex items-center gap-2 bg-black/85 hover:bg-black backdrop-blur-md border border-amber-500/30 px-3.5 py-1.5 rounded-full cursor-pointer transition-colors text-[9px] font-bold uppercase tracking-widest text-amber-500"
        >
          {isMuted ? (
            <>
              <VolumeX className="h-3.5 w-3.5" />
              <span>Unmute</span>
            </>
          ) : (
            <>
              <Volume2 className="h-3.5 w-3.5 animate-pulse text-amber-300" />
              <span>Mute</span>
            </>
          )}
        </button>
      )}
    </div>
  );
}

const handleImageError = (e: React.SyntheticEvent<HTMLImageElement, Event>) => {
  e.currentTarget.src = "https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?q=80&w=1000";
};

export default function Home() {
  const [services, setServices] = useState<ArtService[]>(ART_SERVICES.slice(0, 3));
  const [gallery, setGallery] = useState<GalleryItem[]>([]);
  const [heroMedia, setHeroMedia] = useState<HeroMedia | null>(null);
  const [loading, setLoading] = useState(true);
  const [showWhatsApp, setShowWhatsApp] = useState(false);
  const [activeStep, setActiveStep] = useState(0);
  const [activeFaq, setActiveFaq] = useState<number | null>(null);

  const sliderRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const slider = sliderRef.current;
    if (!slider) return;

    const handleTouch = () => {
      // Passive handler to optimize mobile scrolling on the horizontal gallery list container
    };

    slider.addEventListener('touchstart', handleTouch, { passive: true });
    slider.addEventListener('touchmove', handleTouch, { passive: true });

    return () => {
      slider.removeEventListener('touchstart', handleTouch);
      slider.removeEventListener('touchmove', handleTouch);
    };
  }, [gallery]);

  // High-converting lead capturing state
  const [conciergeForm, setConciergeForm] = useState({
    name: '',
    phone: '',
    eventDate: '',
    location: '',
    preference: 'Wedding Artwork',
    notes: ''
  });
  const [formSubmitted, setFormSubmitted] = useState(false);

  // Pre-seeded luxurious fallback gallery items
  const DEFAULT_GALLERY: GalleryItem[] = [
    {
      id: 'gallery-1',
      title: 'Eternal Wedding Vows Live Painting',
      category: 'Wedding Paintings',
      mediaUrl: 'https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&w=800&q=80',
      mediaType: 'image',
      description: 'Hand-painted live acrylic on premium Belgian linen capturing the royal exchange of vows.',
      createdAt: ''
    },
    {
      id: 'gallery-2',
      title: 'Sunkissed Heritage Couple Sketch',
      category: 'Couple Portraits',
      mediaUrl: 'https://images.unsplash.com/photo-1512486130939-2c4f79935e4f?auto=format&fit=crop&w=800&q=80',
      mediaType: 'image',
      description: 'Elegant live minimal pencil portrait catching the subtle gleam of joy.',
      createdAt: ''
    },
    {
      id: 'gallery-3',
      title: 'The Golden Mandap Horizon',
      category: 'Live Mandap Painting',
      mediaUrl: 'https://images.unsplash.com/photo-1549417229-aa67d3263c09?auto=format&fit=crop&w=800&q=80',
      mediaType: 'image',
      description: 'Bespoke live landscape of the floral altar during high-end seaside sunset vows.',
      createdAt: ''
    },
    {
      id: 'gallery-4',
      title: 'Cinematic Metal Dust Portrait Reveal',
      category: 'Magical Portrait',
      mediaUrl: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=800&q=80',
      mediaType: 'image',
      description: 'Interactive gold & brass glitter-dust portrait revealing the couple. Perfect event entertainment.',
      createdAt: ''
    },
    {
      id: 'gallery-5',
      title: 'Live Minimal guests portraits log',
      category: 'Live Sketches',
      mediaUrl: 'https://images.unsplash.com/photo-1513364776144-60967b0f800f?auto=format&fit=crop&w=800&q=80',
      mediaType: 'image',
      description: 'Guests premium charcoal sketch souvenirs produced live in under five minutes.',
      createdAt: ''
    },
    {
      id: 'gallery-6',
      title: 'Royal Mandap oil canvas close up',
      category: 'Wedding Paintings',
      mediaUrl: 'https://images.unsplash.com/photo-1518156677180-95a2893f3e9f?auto=format&fit=crop&w=800&q=80',
      mediaType: 'image',
      description: 'Immaculate structural painting captures sacred flame of pheras.',
      createdAt: ''
    },
  ];

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch Services
        const servicesRes = await fetch('/api/public/services');
        if (servicesRes.ok && servicesRes.headers.get('content-type')?.includes('application/json')) {
          const servicesData = await servicesRes.json();
          if (servicesData.length > 0) {
            setServices(servicesData.slice(0, 3));
          }
        }

        // Fetch Gallery
        const galleryRes = await fetch('/api/public/gallery');
        if (galleryRes.ok && galleryRes.headers.get('content-type')?.includes('application/json')) {
          const galleryData = await galleryRes.json();
          if (galleryData.length > 0) {
            setGallery(galleryData.slice(0, 6));
          } else {
            setGallery(DEFAULT_GALLERY);
          }
        } else {
          setGallery(DEFAULT_GALLERY);
        }

        // Fetch Hero Media
        const heroRes = await fetch('/api/public/hero-media');
        if (heroRes.ok && heroRes.headers.get('content-type')?.includes('application/json')) {
          const heroData = await heroRes.json() as HeroMedia[];
          const featured = heroData.find(h => h.isFeatured);
          if (featured) {
            setHeroMedia(featured);
          } else if (heroData.length > 0) {
            setHeroMedia(heroData[0]);
          } else {
            // High end static fallback
            setHeroMedia({
              id: 'fallback-hero',
              title: 'Sacred Pheras on Live Linen Canvas',
              mediaUrl: 'https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&w=1200&q=80',
              mediaType: 'image',
              isFeatured: true,
              isActive: true,
              createdAt: ''
            });
          }
        } else {
          setHeroMedia({
            id: 'fallback-hero',
            title: 'Sacred Pheras on Live Linen Canvas',
            mediaUrl: 'https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&w=1200&q=80',
            mediaType: 'image',
            isFeatured: true,
            isActive: true,
            createdAt: ''
          });
        }
      } catch (error) {
        console.error("Error fetching homepage dynamic data:", error);
        setGallery(DEFAULT_GALLERY);
      } finally {
        setLoading(false);
      }
    };

    fetchData();

    const timer = setTimeout(() => setShowWhatsApp(true), 4000);
    return () => clearTimeout(timer);
  }, []);

  const testimonials = [
    {
      name: "Sanjana Kapoor",
      event: "Elite Palace Wedding, Udaipur",
      review: "Deepak did not just capture our vows; he captured the sacred fragrance, the candlelit warmth, and the heavy emotion. Guests stood mesmerized. It is now the focal point of our main living space.",
      rating: 5,
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=120&q=80"
    },
    {
      name: "Rohan Mehta",
      event: "Corporate Golden Jubilee, Mumbai",
      review: "His live sketches are pure wizardry. Watching a raw Belgian linen transform during the gala dinner added an exquisite layer of luxury entertainment that our high-net-worth clients won't ever forget.",
      rating: 5,
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=120&q=80"
    },
    {
      name: "Ananya Iyer",
      event: "Royal Anniversary Soiree, Goa",
      review: "The glitter reveal transition was sensory theater at its best! When he threw the golden metallic dust and our portraits sparkled into existence, there were literally gasps and tears of absolute awe.",
      rating: 5,
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80"
    }
  ];

  const steps = [
    {
      title: "Soul Consultation",
      tagline: "Unveiling the Vision",
      desc: "We align on your schedule, color palettes, favorite flowers, and specific focal people to form the emotional base."
    },
    {
      title: "Reserving the Date",
      tagline: "Locking the Canvas",
      desc: "Secure Deepak's exclusive availability with a partial deposit. We prepare custom premium wood-backed linen."
    },
    {
      title: "The Live Masterpiece",
      tagline: "Watch under Candlelight",
      desc: "Deepak paints live during your vows, pheras, or entry. Guests active engagement creates instant event theater."
    },
    {
      title: "Forever Heirloom",
      tagline: "Varnish & Direct Hand-Off",
      desc: "After final studio glazes and anti-uv protection overlays, we package the artwork in a custom velvet sleeve for safe delivery."
    }
  ];

  const handleConciergeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormSubmitted(true);
    setTimeout(() => {
      setFormSubmitted(false);
      setConciergeForm({ name: '', phone: '', eventDate: '', location: '', preference: 'Wedding Artwork', notes: '' });
    }, 5000);
  };

  return (
    <div className="bg-black text-beige-100 overflow-hidden font-sans">
      
      {/* Floating Concierge WhatsApp Action */}
      <AnimatePresence>
        {showWhatsApp && (
          <motion.div 
            initial={{ scale: 0.8, opacity: 0, y: 30 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.8, opacity: 0 }}
            className="fixed bottom-6 right-6 z-[100] flex flex-col items-end"
          >
            <div className="bg-zinc-900/95 border border-amber-500/20 shadow-[-10px_20px_40px_rgba(0,0,0,0.8)] backdrop-blur-xl p-5 rounded-[2rem] mb-4 max-w-[280px] relative text-left">
              <button 
                onClick={() => setShowWhatsApp(false)}
                className="absolute top-3 right-3 bg-white/5 hover:bg-white/10 rounded-full p-1.5 border border-white/5 text-amber-500 hover:text-amber-400 cursor-pointer"
              >
                <X className="h-3 w-3" />
              </button>
              <div className="flex items-center gap-2 mb-2">
                <div className="relative">
                  <div className="w-2.5 h-2.5 bg-green-500 rounded-full animate-ping absolute inset-0" />
                  <div className="w-2.5 h-2.5 bg-green-500 rounded-full relative" />
                </div>
                <span className="text-[10px] uppercase font-bold tracking-[0.2em] text-amber-500">Deepak's Atelier desk</span>
              </div>
              <p className="text-xs text-zinc-300 leading-relaxed font-light mb-3">
                "Let's craft something precious together. Text my studio directly to check booking slots!"
              </p>
              <p className="text-[10px] italic text-zinc-500">— Deepak Prajapati</p>
            </div>
            <a 
              href="https://wa.me/919131051376?text=Hi,%20I%20want%20to%20book%20live%20sketch%20artwork%20for%20my%20wedding%20event." 
              target="_blank" 
              rel="noopener noreferrer"
              className="bg-green-600 hover:bg-green-500 p-4.5 rounded-full shadow-[0_8px_30px_rgb(22,163,74,0.3)] hover:scale-110 active:scale-95 transition-all text-white border border-green-400/20"
              title="Chat on WhatsApp"
            >
              <MessageCircle className="h-6 w-6 text-white" />
            </a>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Hero Section */}
      <section className="relative min-h-[95vh] flex items-center justify-center overflow-hidden pt-28 pb-12 lg:py-0">
        <div className="absolute inset-0 z-0">
          <AnimatePresence mode="wait">
            {heroMedia ? (
              <motion.div 
                key={`hero-bg-${heroMedia.id}`}
                initial={{ opacity: 0 }}
                animate={{ opacity: 0.35 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 1.5 }}
                className="absolute inset-0 w-full h-full"
              >
                <img 
                  src={heroMedia.mediaUrl || null} 
                  className="w-full h-full object-cover blur-3xl scale-125 select-none pointer-events-none opacity-40"
                  alt=""
                />
              </motion.div>
            ) : (
              <div className="absolute inset-0 bg-gradient-to-tr from-[#080808] via-[#101010] to-[#1a120a]" />
            )}
          </AnimatePresence>
          {/* Subtle grid mesh overlays to make it look professional creative studio */}
          <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.015)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.015)_1px,transparent_1px)] bg-[size:40px_40px] pointer-events-none" />
          <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/40 to-black pointer-events-none" />
          {/* Candlelight warm highlight */}
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl" />
        </div>

        <div className="max-w-7xl mx-auto px-4 lg:px-8 w-full relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
            
            {/* Poetic & High-Converting Headline Details */}
            <div className="lg:col-span-7 text-center lg:text-left flex flex-col items-center lg:items-start select-none">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 1.2 }}
                className="space-y-6 md:space-y-8"
              >
                <div className="inline-flex items-center gap-3 px-4.5 py-2 border border-amber-500/20 rounded-full text-amber-500 text-[10px] font-bold uppercase tracking-[0.3em] bg-amber-500/5 backdrop-blur-sm">
                  <Sparkles className="h-3.5 w-3.5 text-amber-500 animate-spin" />
                  <span>The Live Luxury Masterpiece Experience</span>
                </div>
                
                <h1 className="text-3xl sm:text-5xl md:text-6xl lg:text-7xl font-serif font-extrabold tracking-tight text-white leading-[1.1] text-balance">
                  Where Your <span className="text-amber-500 italic font-normal">Sweetest Vows</span> Become Fine Art
                </h1>
                
                <p className="text-sm md:text-base text-zinc-300 max-w-xl mx-auto lg:mx-0 font-light leading-relaxed tracking-wide text-balance">
                  Precious moments fade, but canvas is immortal. DPartic Flow, founded by fine artist <span className="text-amber-500 font-semibold line-under-text">Deepak Prajapati (Post Graduate in Fine Arts, Indira Kala Vishwavidyalaya)</span>, translates the sacred warmth, fleeting smiles, and golden atmosphere of your celebration into majestic heirlooms on real-time premium Belgian linen.
                </p>

                {/* Highly structured trust counters in hero */}
                <div className="grid grid-cols-3 gap-4 border-y border-white/5 py-4 max-w-lg mx-auto lg:mx-0">
                  <div className="text-center lg:text-left">
                    <p className="text-xl sm:text-2xl font-serif font-bold text-amber-500">100%</p>
                    <p className="text-[9px] uppercase tracking-wider text-zinc-500 mt-0.5">Custom Live Canvas</p>
                  </div>
                  <div className="text-center lg:text-left border-x border-white/5 px-2">
                    <p className="text-xl sm:text-2xl font-serif font-bold text-amber-400">100+</p>
                    <p className="text-[9px] uppercase tracking-wider text-zinc-500 mt-0.5">High-End Weddings</p>
                  </div>
                  <div className="text-center lg:text-left">
                    <p className="text-xl sm:text-2xl font-serif font-bold text-amber-500">5+ Yrs</p>
                    <p className="text-[9px] uppercase tracking-wider text-zinc-500 mt-0.5">Active Experience</p>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-3">
                  <Link
                    to="/booking"
                    className="group relative px-9 py-4.5 bg-gradient-to-r from-amber-500 to-amber-600 text-black font-extrabold rounded-full overflow-hidden transition-all hover:shadow-[0_8px_30px_rgba(197,160,89,0.3)] w-full sm:w-auto text-center cursor-pointer"
                  >
                    <span className="relative z-10 uppercase tracking-widest text-xs">RESERVE WEDDING DATE</span>
                    <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
                  </Link>
                  <Link
                    to="/gallery"
                    className="flex items-center justify-center space-x-3 px-8 py-4.5 border border-white/10 text-zinc-300 font-extrabold rounded-full hover:bg-white/5 hover:border-amber-500/40 transition-all uppercase tracking-widest text-xs w-full sm:w-auto text-center"
                  >
                    <Play className="h-3.5 w-3.5 fill-amber-500 text-amber-500" />
                    <span>Witness The Gallery</span>
                  </Link>
                </div>
              </motion.div>
            </div>

            {/* Cinematic Antique Media Frame */}
            <div className="lg:col-span-5 flex items-center justify-center">
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 1.2, delay: 0.2 }}
                className="relative w-full max-w-sm aspect-[4/5] rounded-[3rem] p-4 bg-zinc-900/60 border border-amber-500/20 shadow-2xl flex flex-col justify-between overflow-hidden backdrop-blur-md"
              >
                {/* Antique corner accents */}
                <span className="absolute top-4 left-4 text-xs font-mono text-amber-500/30">✦</span>
                <span className="absolute top-4 right-4 text-xs font-mono text-amber-500/30">✦</span>
                <span className="absolute bottom-4 left-4 text-xs font-mono text-amber-500/30">✦</span>
                <span className="absolute bottom-4 right-4 text-xs font-mono text-amber-500/30">✦</span>

                {/* Media Container */}
                <div className="relative w-full flex-grow rounded-2xl overflow-hidden bg-black flex items-center justify-center border border-white/5">
                  <AnimatePresence mode="wait">
                    {heroMedia ? (
                      <motion.div 
                        key={heroMedia.id}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 0.8 }}
                        className="w-full h-full flex items-center justify-center p-2"
                      >
                        {heroMedia.mediaType === 'video' ? (
                          <div className="relative w-full h-full flex items-center justify-center bg-black">
                            <HeroVideoPlayer media={heroMedia} />
                          </div>
                        ) : (
                          <img 
                            src={heroMedia.mediaUrl || undefined} 
                            onError={handleImageError}
                            className="max-w-full max-h-full object-contain rounded-xl select-none"
                            alt={heroMedia.title}
                          />
                        )}
                      </motion.div>
                    ) : (
                      <div className="flex flex-col items-center justify-center text-center p-8">
                        <Palette className="h-10 w-10 text-amber-500/40 mb-3 animate-pulse" />
                        <h4 className="text-sm font-bold text-gray-400 uppercase tracking-widest">Masterpiece Showcase</h4>
                        <p className="text-xs text-gray-500 max-w-xs mt-2">Loading performance reels...</p>
                      </div>
                    )}
                  </AnimatePresence>
                </div>

                {/* Subtitle description card */}
                {heroMedia && (
                  <div className="pt-4 px-2 mt-2 border-t border-white/5 flex items-center justify-between">
                    <div className="text-left">
                      <span className="text-[8px] font-mono text-amber-500 uppercase tracking-[0.25em] font-bold block mb-0.5">Exquisite Focus</span>
                      <h3 className="text-xs font-serif font-bold text-white tracking-wide truncate max-w-[210px]">{heroMedia.title}</h3>
                    </div>
                    <span className="px-2.5 py-1 bg-amber-500/10 text-amber-500 rounded-full text-[8px] uppercase font-mono tracking-widest border border-amber-500/20">
                      {heroMedia.mediaType === 'video' ? 'Live Event' : 'Canvas Original'}
                    </span>
                  </div>
                )}
              </motion.div>
            </div>
            
          </div>
        </div>

        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex flex-col items-center hidden lg:flex">
          <div className="w-[1px] h-10 bg-gradient-to-b from-amber-500/50 to-transparent animate-pulse" />
          <span className="text-[8px] text-amber-500/40 uppercase tracking-[0.4em] mt-1">Scent of Paint</span>
        </div>
      </section>

      {/* Narrative Section: Turning Moments Into Art */}
      <section className="py-24 px-4 bg-zinc-950 relative overflow-hidden">
        {/* Subtle background golden brush element */}
        <div className="absolute right-0 top-0 w-80 h-80 bg-amber-500/[0.02] rounded-full blur-3xl" />
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="text-amber-500 text-[10px] uppercase font-bold tracking-[0.4em] mb-4 block">Our Philosophy</span>
            <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-6">
              Three Pillars of Your <span className="text-amber-500 italic">Family Heirloom</span>
            </h2>
            <p className="text-sm text-zinc-400 font-light leading-relaxed">
              We stand apart from rigid digital printing and mechanical photography. Our art involves physical sweat, custom textured strokes, and authentic spirit.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-8 bg-black/60 border border-white/5 rounded-[2rem] hover:border-amber-500/20 transition-all duration-300 relative group">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/10 flex items-center justify-center mb-6 border border-amber-500/20 relative">
                <Heart className="h-5 w-5 text-amber-500" />
                <div className="absolute inset-0 bg-amber-500/5 rounded-2xl scale-125 opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
              <h3 className="text-lg font-serif font-bold text-white mb-3">Post-Event Heritage Glow</h3>
              <p className="text-zinc-400 text-xs leading-relaxed font-light">
                Colors are harmonized to match your home salon's decor. A live painting doesn't stay hidden in a hard drive; it resides on your wall, triggering soft memories of perfume and laughter daily.
              </p>
              <div className="mt-6 text-[10px] uppercase font-bold tracking-widest text-amber-500">“Art That Lives Beyond Events”</div>
            </div>

            <div className="p-8 bg-zinc-900/40 border border-amber-500/10 rounded-[2rem] hover:border-amber-500/35 transition-all duration-300 relative group">
              <span className="absolute top-6 right-6 text-amber-500 text-xs">✦</span>
              <div className="w-12 h-12 rounded-2xl bg-amber-500/10 flex items-center justify-center mb-6 border border-amber-500/20 relative">
                <Palette className="h-5 w-5 text-amber-500" />
              </div>
              <h3 className="text-lg font-serif font-bold text-white mb-3">Egyptian Gold & Archival Linen</h3>
              <p className="text-zinc-300 text-xs leading-relaxed font-light">
                We craft using heavy-body pigment acrylic, pure gold leaf gilding, and thick anti-acid Belgian weaves. This ensures your vows stay protected against humidity and fading for over 150 years.
              </p>
              <div className="mt-6 text-[10px] uppercase font-bold tracking-widest text-amber-500 font-semibold">“Crafted With Passion”</div>
            </div>

            <div className="p-8 bg-black/60 border border-white/5 rounded-[2rem] hover:border-amber-500/20 transition-all duration-300 relative group">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/10 flex items-center justify-center mb-6 border border-amber-500/20">
                <Sparkles className="h-5 w-5 text-amber-500" />
              </div>
              <h3 className="text-lg font-serif font-bold text-white mb-3">Live Interactive Magic</h3>
              <p className="text-zinc-400 text-xs leading-relaxed font-light">
                Watching an artist layer paint to model three-dimensional faces acts as live high-society entertainment. Guests gather around the easel as oil textures take romantic shape.
              </p>
              <div className="mt-6 text-[10px] uppercase font-bold tracking-widest text-amber-500">“Turning Moments Into Art”</div>
            </div>
          </div>
        </div>
      </section>

      {/* About The Artist Section: Deepak Prajapati */}
      <section className="py-28 px-4 bg-gradient-to-b from-black via-zinc-950 to-black relative overflow-hidden">
        {/* Soft elegant watercolor-like ambient highlight */}
        <div className="absolute top-1/4 left-10 w-96 h-96 bg-amber-500/[0.03] rounded-full blur-3xl pointer-events-none animate-pulse" />
        <div className="absolute bottom-1/4 right-10 w-96 h-96 bg-amber-500/[0.01] rounded-full blur-3xl pointer-events-none" />
        
        <div className="max-w-7xl mx-auto">
          {/* Main Bio Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-center mb-24">
            
            {/* Artist picture with dual-layered luxury gold framing */}
            <div className="lg:col-span-5 flex justify-center">
              <div className="relative">
                {/* Decorative canvas frame drop behind */}
                <div className="absolute -inset-4 border border-amber-500/10 rounded-[2.5rem] transform translate-x-3 translate-y-3 pointer-events-none" />
                <div className="absolute -inset-4 border border-amber-500/20 rounded-[2.5rem] pointer-events-none animate-pulse" />
                
                <div className="relative w-80 sm:w-96 aspect-[3/4.2] bg-zinc-900 rounded-[2rem] overflow-hidden shadow-2xl border border-white/10 group">
                  <img 
                    src="https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=800&q=80" 
                    className="w-full h-full object-cover grayscale brightness-90 group-hover:grayscale-0 group-hover:scale-102 transition-all duration-[1200ms]" 
                    alt="Deepak Prajapati, Professional Fine Artist" 
                  />
                  {/* Elegant floating badge */}
                  <div className="absolute top-4 left-4 bg-black/85 backdrop-blur-md px-3.5 py-1.5 rounded-full border border-amber-500/30 text-[8px] font-bold uppercase tracking-widest text-amber-500">
                    Fine Art Post Graduate
                  </div>
                  {/* Subtle dark filter to align with luxurious aesthetic */}
                  <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black via-black/50 to-transparent p-6 text-left">
                    <span className="text-[9px] uppercase font-mono tracking-widest text-amber-400 font-bold">PROFESSIONAL FINE ARTIST</span>
                    <h4 className="text-2xl font-serif text-white tracking-wide mt-1">Deepak Prajapati</h4>
                    <p className="text-[10px] text-zinc-400 max-w-xs mt-1">Master of Fine Arts (Indira Kala Sangeet Vishwavidyalaya)</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Emotional storytelling of the artist journey */}
            <div className="lg:col-span-7 space-y-8 text-left">
              <div>
                <span className="text-amber-500 text-[10px] uppercase font-bold tracking-[0.4em] mb-4 block">Professional Credentials</span>
                <h2 className="text-3xl md:text-5xl font-serif font-bold text-white leading-tight">
                  Academic Mastery <br />
                  Meets <span className="text-amber-500 italic">Fleeting Emotion</span>
                </h2>
              </div>
              
              <div className="space-y-5 text-xs sm:text-sm text-zinc-400 font-light leading-relaxed">
                <p>
                  As an academically trained painter, I anchor my live performances in deep classical discipline. I completed my post-graduate specialization in fine arts from the prestigious <span className="text-amber-400 font-medium">Indira Kala Sangeet Vishwavidyalaya</span> (Khairagarh) — Asia's first and highly celebrated university dedicated solely to fine arts and classical music. 
                </p>
                <p>
                  This extensive training gave me an intimate understanding of anatomical precision, pigment chemistry, and light physics. I spent years translating classical studio workflows into dynamic, high-pressure live environments, mastering the fast and fluid accuracy required to render gorgeous oil & acrylic masterpieces under candlelight.
                </p>
                <p>
                  Established as a premium art brand, <span className="text-amber-500">DPartic Flow</span> represents the highest standard of interactive luxury entertainment. We do not engage in simple photography or modern prints; we craft real, living history. 
                </p>
                <p className="italic text-zinc-300 border-l-2 border-amber-500/40 pl-4 py-1">
                  “The canvas is not merely a recording of a date; it is an organic archive of space, fragrance, and sacred warmth. I bring a lifetime of academic devotion to your wedding day.”
                </p>
              </div>

              {/* Hand signature & elegant detail */}
              <div className="flex flex-wrap items-center gap-6 pt-6 border-t border-white/5">
                <div>
                  <span className="font-script text-4xl sm:text-5xl text-amber-500 block transform -rotate-2 select-none leading-none">
                    Deepak Prajapati
                  </span>
                  <span className="text-[9px] uppercase tracking-widest font-mono text-zinc-500 mt-2 block">
                    Founder & chief fine artist, DPartic Flow
                  </span>
                </div>
                <div className="hidden sm:block h-10 w-[1px] bg-white/10" />
                <div className="text-left font-mono">
                  <span className="text-lg text-white font-serif block">M.F.A.</span>
                  <span className="text-[8px] uppercase tracking-wider text-zinc-500">Post Graduate Honor</span>
                </div>
                <div className="h-10 w-[1px] bg-white/10" />
                <div className="text-left font-mono">
                  <span className="text-lg text-white font-serif block">200+</span>
                  <span className="text-[8px] uppercase tracking-wider text-zinc-500">Live Royal Canvas</span>
                </div>
              </div>
            </div>

          </div>

          {/* Academic Accolades & Exhibitions Panel */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-24 text-left">
            <div className="p-6 bg-zinc-950/40 border border-white/5 rounded-3xl hover:border-amber-500/10 transition-all">
              <span className="text-amber-500 font-mono text-[10px] uppercase font-bold tracking-widest block mb-2">Academic Background</span>
              <h4 className="text-white font-serif font-bold text-sm mb-2">Indira Kala Sangeet Vishwavidyalaya</h4>
              <p className="text-zinc-500 text-[11px] leading-relaxed font-light">
                Completed exhaustive Post-Graduation (M.F.A) specializing in Portraiture, composition rendering, and classical pigments. Trained under living masters of classical Indian art.
              </p>
            </div>
            <div className="p-6 bg-zinc-950/40 border border-white/5 rounded-3xl hover:border-amber-500/10 transition-all">
              <span className="text-amber-500 font-mono text-[10px] uppercase font-bold tracking-widest block mb-2">Selected Exhibitions</span>
              <h4 className="text-white font-serif font-bold text-sm mb-2">National Art Festivals</h4>
              <p className="text-zinc-500 text-[11px] leading-relaxed font-light">
                Artworks showcased in regional Lalit Kala Akademi selections, state galleries, and luxury resort collectives across Jaipur, Udaipur, and Raipur.
              </p>
            </div>
            <div className="p-6 bg-zinc-950/40 border border-white/5 rounded-3xl hover:border-amber-500/10 transition-all">
              <span className="text-amber-500 font-mono text-[10px] uppercase font-bold tracking-widest block mb-2">Interactive Curation</span>
              <h4 className="text-white font-serif font-bold text-sm mb-2">Masterclasses & Symposia</h4>
              <p className="text-zinc-500 text-[11px] leading-relaxed font-light">
                Demonstrated high-speed charcoal portraiture and interactive live gold-dust canvas physics to over 5,000+ patrons and fine art scholars.
              </p>
            </div>
          </div>

          {/* Cinematic Artist Studio Visuals & BTS section */}
          <div className="mb-24">
            <div className="text-left mb-10 max-w-xl">
              <span className="text-amber-500 text-[10px] uppercase font-bold tracking-[0.4em] mb-2 block">Behind The Brush</span>
              <h2 className="text-2xl md:text-4xl font-serif font-bold text-white">Cinematic Studio <span className="text-amber-500 italic">Environments</span></h2>
              <p className="text-zinc-400 text-xs font-light mt-1">
                Where heavy oils are custom-ground with linseed, Belgian linen fiber is primed, and golden leaf dust meets high-society portraits.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {/* Studio Image 1 */}
              <div className="md:col-span-2 aspect-[4/3] rounded-3xl overflow-hidden border border-white/5 relative group bg-black">
                <img 
                  src="https://images.unsplash.com/photo-1513364776144-60967b0f800f?auto=format&fit=crop&w=800&q=80" 
                  className="w-full h-full object-cover brightness-75 group-hover:scale-103 transition-transform duration-700"
                  alt="Mixing paint on classical wooden palette"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent p-5 flex flex-col justify-end text-left">
                  <span className="text-amber-500 text-[8px] font-mono uppercase tracking-widest">BTS: Pigment Alchemy</span>
                  <h4 className="text-white text-xs sm:text-sm font-serif font-bold mt-1">Grinding premium heavy acrylic resins manually</h4>
                </div>
              </div>
              {/* Studio Image 2 */}
              <div className="aspect-[4/5] md:aspect-auto rounded-3xl overflow-hidden border border-white/5 relative group bg-black">
                <img 
                  src="https://images.unsplash.com/photo-1579783928621-7a13d66a6211?auto=format&fit=crop&w=800&q=80" 
                  className="w-full h-full object-cover brightness-75 group-hover:scale-103 transition-transform duration-700"
                  alt="Linen sketches detailing visual outline"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent p-5 flex flex-col justify-end text-left">
                  <span className="text-amber-500 text-[8px] font-mono uppercase tracking-widest">BTS: Sketch Studies</span>
                  <h4 className="text-white text-xs sm:text-sm font-serif font-bold mt-1">Skeletal guidelines for exact facial anatomy mapping</h4>
                </div>
              </div>
              {/* Studio Image 3 */}
              <div className="aspect-[4/5] md:aspect-auto rounded-3xl overflow-hidden border border-white/5 relative group bg-black">
                <img 
                  src="https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&w=800&q=80" 
                  className="w-full h-full object-cover brightness-75 group-hover:scale-103 transition-transform duration-700"
                  alt="DPartic Flow custom gold-leaf gilding process"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent p-5 flex flex-col justify-end text-left">
                  <span className="text-amber-500 text-[8px] font-mono uppercase tracking-widest">BTS: Gilded Detailing</span>
                  <h4 className="text-white text-xs sm:text-sm font-serif font-bold mt-1">Adding authentic gold-gilded metallic flakes</h4>
                </div>
              </div>
            </div>
          </div>

          {/* Why Choose Deepak & Academic Foundation section */}
          <div className="mb-24 py-16 px-8 bg-zinc-950/80 border border-white/5 rounded-[2.5rem] relative">
            <div className="absolute top-6 right-8 text-amber-500/20 text-7xl font-serif select-none pointer-events-none">✦</div>
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
              
              <div className="lg:col-span-5 text-left space-y-4">
                <span className="text-amber-500 text-[10px] uppercase font-bold tracking-[0.3em] block">Fine Art Credentials</span>
                <h3 className="text-2xl md:text-3.5xl font-serif font-bold text-white tracking-tight">Why Patrons Choose <br /><span className="text-amber-500 italic">This Fine Art brand</span></h3>
                <p className="text-zinc-400 text-xs font-light leading-relaxed">
                  DPartic Flow stands apart from digital artists and amateur painters. We deliver a meticulously academic, luxury fine art collection.
                </p>
                <div className="pt-3">
                  <Link to="/booking" className="inline-flex items-center gap-2 text-xs font-bold text-amber-500 uppercase tracking-widest pb-1 border-b border-amber-500/20 hover:border-amber-500/70 transition-colors">
                    Check Date Availability <ArrowRight className="h-3 w-3" />
                  </Link>
                </div>
              </div>

              <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-6 text-left">
                <div className="space-y-1">
                  <h4 className="text-sm font-serif font-semibold text-white flex items-center gap-2">
                    <span className="text-amber-500">✦</span> Academic Rigor
                  </h4>
                  <p className="text-zinc-500 text-[11px] leading-relaxed pl-4">
                    Master of Fine Arts means flawless human proportions, balanced values, and structural color harmony instead of rushed, blurry portraits.
                  </p>
                </div>
                <div className="space-y-1">
                  <h4 className="text-sm font-serif font-semibold text-white flex items-center gap-2">
                    <span className="text-amber-500">✦</span> 150-Year Archival Guard
                  </h4>
                  <p className="text-zinc-500 text-[11px] leading-relaxed pl-4">
                    We exclusively employ pure Belgian heavy linen, anti-acid primers, and professional UV shielding glazes to prevent cracking or yellowing.
                  </p>
                </div>
                <div className="space-y-1">
                  <h4 className="text-sm font-serif font-semibold text-white flex items-center gap-2">
                    <span className="text-amber-500">✦</span> Luxury Live Event Theatre
                  </h4>
                  <p className="text-zinc-500 text-[11px] leading-relaxed pl-4">
                    Deepak's active performance creates premium high-society engagement, giving guests an exquisite visual memory of classical creation.
                  </p>
                </div>
                <div className="space-y-1">
                  <h4 className="text-sm font-serif font-semibold text-white flex items-center gap-2">
                    <span className="text-amber-500">✦</span> Absolute Interior Harmony
                  </h4>
                  <p className="text-zinc-500 text-[11px] leading-relaxed pl-4">
                    We consult on your interior space's color rules to ensure the completed heirloom fits perfectly on your royal salon walls.
                  </p>
                </div>
              </div>

            </div>
          </div>

          {/* Elegant timeline of artistic journey */}
          <div>
            <div className="text-center mb-12 max-w-xl mx-auto">
              <span className="text-amber-500 text-[10px] uppercase font-bold tracking-[0.4em] mb-2 block">The Lineage</span>
              <h2 className="text-2xl md:text-4xl font-serif font-bold text-white">The Golden <span className="text-amber-500 italic">Timeline</span></h2>
              <p className="text-zinc-400 text-xs font-light mt-1">
                A Decade of Classical Fine Art Practice & Luxurious Live Painting Evolution.
              </p>
            </div>

            <div className="max-w-4xl mx-auto relative text-left">
              {/* Vertical line helper */}
              <div className="absolute left-4 md:left-1/2 top-2 bottom-2 w-[1px] bg-white/5 md:-translate-x-1/2" />

              <div className="space-y-10">
                {/* Year Item 1: Left on desk, right on mobile */}
                <div className="relative flex flex-col md:flex-row md:justify-between items-start md:items-center">
                  <div className="absolute left-4 md:left-1/2 w-3 h-3 bg-amber-500 rounded-full border-4 border-black -translate-x-1/2 z-10" />
                  <div className="md:w-[45%] pl-10 md:pl-0 md:text-right space-y-1">
                    <span className="text-amber-500 font-mono text-[10px] uppercase font-bold tracking-widest block">2014—2018</span>
                    <h4 className="text-white font-serif font-bold text-sm">Fine Arts Academic Awakening</h4>
                    <p className="text-zinc-500 text-[11px] leading-relaxed font-light">
                      Pursued Bachelor of Fine Arts at Indira Kala Sangeet Vishwavidyalaya. Rigorous classical study, sketching 12 hours a day, studying live anatomy and pigments.
                    </p>
                  </div>
                  <div className="md:w-[45%] hidden md:block" />
                </div>

                {/* Year Item 2 */}
                <div className="relative flex flex-col md:flex-row md:justify-between items-start md:items-center">
                  <div className="absolute left-4 md:left-1/2 w-3 h-3 bg-amber-500 rounded-full border-4 border-black -translate-x-1/2 z-10" />
                  <div className="md:w-[45%] hidden md:block" />
                  <div className="md:w-[45%] pl-10 md:pl-10 space-y-1">
                    <span className="text-amber-500 font-mono text-[10px] uppercase font-bold tracking-widest block">2019</span>
                    <h4 className="text-white font-serif font-bold text-sm">Post Graduate Portfolios (M.F.A.)</h4>
                    <p className="text-zinc-500 text-[11px] leading-relaxed font-light">
                      Awarded Post-Graduate distinction at Khairagarh. Earned critical focus on spatial lighting and complex color compositions. Began showcasing in national collective exhibitions.
                    </p>
                  </div>
                </div>

                {/* Year Item 3 */}
                <div className="relative flex flex-col md:flex-row md:justify-between items-start md:items-center">
                  <div className="absolute left-4 md:left-1/2 w-3 h-3 bg-amber-500 rounded-full border-4 border-black -translate-x-1/2 z-10" />
                  <div className="md:w-[45%] pl-10 md:pl-0 md:text-right space-y-1">
                    <span className="text-amber-500 font-mono text-[10px] uppercase font-bold tracking-widest block">2020—2022</span>
                    <h4 className="text-white font-serif font-bold text-sm">The Synthesis of DPartic Flow</h4>
                    <p className="text-zinc-500 text-[11px] leading-relaxed font-light">
                      Launched a specialized fine art live agency. Pioneered the interactive "Glitter & Gold Reveal" wedding formats and live sketches, performing across major Indian heritage venues.
                    </p>
                  </div>
                  <div className="md:w-[45%] hidden md:block opacity-0" />
                </div>

                {/* Year Item 4 */}
                <div className="relative flex flex-col md:flex-row md:justify-between items-start md:items-center">
                  <div className="absolute left-4 md:left-1/2 w-3 h-3 bg-amber-500 rounded-full border-4 border-black -translate-x-1/2 z-10" />
                  <div className="md:w-[45%] hidden md:block" />
                  <div className="md:w-[45%] pl-10 md:pl-10 space-y-1">
                    <span className="text-amber-500 font-mono text-[10px] uppercase font-bold tracking-widest block">2023—2026</span>
                    <h4 className="text-white font-serif font-bold text-sm">Global Commissions & Elite Branding</h4>
                    <p className="text-zinc-500 text-[11px] leading-relaxed font-light">
                      Collaborated with Marriott luxury hubs, Udaipur palace events, and premium private collectors. Booking priority dates up to 12 months in advance.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* Trust & Prestige Partners section */}
      <section className="py-12 bg-black border-y border-amber-500/10">
        <div className="max-w-7xl mx-auto px-4">
          <p className="text-center text-[10px] uppercase tracking-[0.25em] text-zinc-500 mb-8 font-semibold">
            In Elite Collaboration & Trusted By High-End Venues
          </p>
          <div className="flex flex-wrap justify-center items-center gap-x-12 gap-y-6 opacity-40 select-none">
            <span className="text-sm font-serif uppercase tracking-widest hover:opacity-100 transition-opacity">The Taj Resorts, Udaipur</span>
            <span className="text-sm font-serif uppercase tracking-widest hover:opacity-100 transition-opacity">Marriott Bonvoy</span>
            <span className="text-sm font-serif uppercase tracking-widest hover:opacity-100 transition-opacity">Hyatt Regency</span>
            <span className="text-sm font-serif uppercase tracking-widest hover:opacity-100 transition-opacity">The Radisson Blu, Goa</span>
            <span className="text-sm font-serif uppercase tracking-widest hover:opacity-100 transition-opacity">DLF Emporio</span>
          </div>
        </div>
      </section>

      {/* Signature Services Section */}
      <section className="py-24 px-4 bg-zinc-950/40 relative">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row items-end justify-between mb-16 gap-6 text-left">
            <div className="max-w-2xl">
              <h2 className="text-amber-500 text-[10px] uppercase font-bold tracking-[0.3em] mb-4 flex items-center gap-2">
                <Sparkles className="h-3.5 w-3.5" /> Curated Experience Modules
              </h2>
              <h3 className="text-3xl md:text-5xl font-serif font-bold text-white leading-tight">
                Signature Live <span className="text-amber-500 italic">Art Offerings</span>
              </h3>
              <p className="text-xs text-zinc-400 mt-2">
                Every service is structured around flawless guest engagement and a timeless museum-grade final hand-delivered masterpiece.
              </p>
            </div>
            <Link 
              to="/services" 
              className="text-amber-500 text-xs font-bold uppercase tracking-widest flex items-center gap-2 hover:translate-x-2 transition-transform border-b border-amber-500/20 pb-1"
            >
              Explore Full Atelier Catalog <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <motion.div
                key={service.id}
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                className="group relative min-h-[460px] h-full overflow-hidden rounded-[2rem] bg-zinc-900/30 border border-white/5 flex flex-col justify-between hover:border-amber-500/25 hover:bg-zinc-900/65 transition-all duration-300 shadow-xl"
              >
                {/* Photo fit upper section */}
                <div className="relative h-56 w-full shrink-0 overflow-hidden bg-black flex items-center justify-center border-b border-white/[0.04]">
                  {service.image ? (
                    <>
                      <img 
                        src={service.image || undefined} 
                        onError={handleImageError}
                        className="absolute inset-0 w-full h-full object-cover blur-xl opacity-20 scale-110 select-none" 
                        alt="" 
                      />
                      {service.mediaType === 'video' ? (
                        <video 
                          src={service.image || undefined} 
                          autoPlay 
                          muted 
                          loop 
                          playsInline 
                          className="relative z-10 max-w-full max-h-full object-contain group-hover:scale-102 transition-transform duration-1000" 
                        />
                      ) : (
                        <img 
                          src={service.image || undefined} 
                          onError={handleImageError}
                          className="relative z-10 max-w-full max-h-full object-contain group-hover:scale-103 transition-transform duration-1000" 
                          alt={service.title}
                        />
                      )}
                    </>
                  ) : (
                    <div className="absolute inset-0 bg-gradient-to-br from-[#0c0c0c] via-[#050505] to-black flex flex-col items-center justify-center p-6 text-center select-none overflow-hidden">
                      {/* Decorative gold background sparkles */}
                      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(245,158,11,0.03)_0%,transparent_70%)]" />
                      <div className="absolute -inset-10 opacity-20 border border-amber-500/10 rounded-full scale-75 animate-pulse" />
                      
                      <div className="relative z-10 w-12 h-12 bg-amber-500/[0.03] border border-amber-500/20 rounded-full flex items-center justify-center mb-3 shadow-[0_0_15px_rgba(245,158,11,0.05)] text-amber-500 group-hover:rotate-12 transition-transform duration-500">
                        <Sparkles className="h-5 w-5" />
                      </div>
                      
                      <span className="relative z-10 text-[7px] text-amber-500/50 font-mono uppercase tracking-[0.4em] font-bold">Atelier Reserve</span>
                      <h4 className="relative z-10 text-[10px] font-serif italic text-zinc-400 mt-1.5 font-semibold group-hover:text-amber-500/80 transition-colors duration-300">{service.title}</h4>
                      <span className="relative z-10 text-[7px] text-zinc-650 font-light tracking-wide mt-1 block">Exquisite Custom Medium Commission</span>
                    </div>
                  )}
                  {/* Subtle luxurious category label float */}
                  <span className="absolute top-4 left-4 bg-black/70 backdrop-blur-md px-3 py-1 text-[8px] text-amber-500 uppercase tracking-widest font-mono rounded-full border border-white/5">
                    {service.category}
                  </span>
                </div>

                {/* Info Lower Section */}
                <div className="p-6 flex-grow flex flex-col justify-between">
                  <div className="text-left">
                    <p className="text-amber-500 text-[10px] uppercase font-mono tracking-widest mb-1.5 block">Premium Tier</p>
                    <h4 className="text-lg font-serif font-bold text-white mb-2 group-hover:text-amber-400 transition-colors">
                      {service.title}
                    </h4>
                    <p className="text-zinc-400 text-xs font-light mb-4 line-clamp-3 leading-relaxed">
                      {service.description}
                    </p>
                  </div>
                  
                  <div className="flex items-center justify-between border-t border-white/5 pt-4 mt-auto">
                    <div>
                      <span className="text-[8px] uppercase tracking-wider text-zinc-500 block">Pricing starts at</span>
                      <span className="text-amber-500 text-sm font-bold">₹{service.price.toLocaleString('en-IN')}</span>
                    </div>
                    <Link
                      to={`/booking?service=${service.id}`}
                      className="inline-flex items-center text-[10px] font-bold text-white uppercase tracking-widest group-hover:text-amber-400 transition-colors border-b border-amber-500/40 pb-0.5 hover:border-amber-400"
                    >
                      Book Date <ChevronRight className="h-3 w-3 ml-1" />
                    </Link>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Curated Masterpiece Gallery (Improved Portfolio/Bento layout) */}
      <section className="py-24 bg-black overflow-hidden relative">
        <div className="max-w-7xl mx-auto px-4 mb-16 text-left">
           <span className="text-amber-500 text-[10px] uppercase font-bold tracking-[0.3em] mb-4 block">The Living Proof</span>
           <div className="flex flex-col md:flex-row items-start md:items-end justify-between gap-6">
             <div>
               <h3 className="text-3xl md:text-5xl font-serif font-bold text-white">Moments immortalized in <span className="text-amber-500 italic">Oil & Gold</span></h3>
               <p className="text-zinc-400 text-xs font-light tracking-wide max-w-xl mt-2">
                 These are true snippets of actual weddings and luxury corporate events captured live. Every face carries authentic, paint-molded romance.
               </p>
             </div>
             <Link 
               to="/gallery" 
               className="px-6 py-3 border border-amber-500/20 hover:border-amber-500/60 rounded-full text-xs text-amber-500 uppercase font-mono tracking-widest hover:bg-amber-500/5 transition-all w-full md:w-auto text-center"
             >
               View Whole Fine Gallery
             </Link>
           </div>
        </div>
        
        {/* Cinematic horizontal scroll slider with interactive hover narration */}
        <div ref={sliderRef} className="flex gap-6 overflow-x-auto pb-10 px-4 md:px-8 scrollbar-thin scrollbar-thumb-amber-500/20 snap-x">
          {gallery.map((item, idx) => (
            <div 
              key={item.id || idx} 
              className="flex-none w-[280px] sm:w-[320px] h-[410px] rounded-[2rem] overflow-hidden border border-white/5 group relative bg-zinc-950 flex flex-col justify-between snap-center hover:border-amber-500/20 transition-all duration-500"
            >
              {/* Media Container (100% responsive containment) */}
              <div className="relative w-full h-[73%] overflow-hidden flex items-center justify-center bg-black border-b border-white/5">
                <img 
                  src={item.mediaUrl || null} 
                  className="absolute inset-0 w-full h-full object-cover blur-xl opacity-25 scale-110 select-none" 
                  alt="" 
                />
                <img 
                  src={item.mediaUrl || null} 
                  className="relative z-10 max-w-full max-h-full object-contain group-hover:scale-104 transition-transform duration-[1200ms] ease-out p-1" 
                  alt={item.title} 
                />
              </div>
              
              {/* Text info lower segment */}
              <div className="h-[27%] p-4 bg-zinc-950 flex flex-col justify-center text-center">
                <span className="text-amber-500 text-[8px] uppercase tracking-[0.25em] font-mono font-bold block mb-1">
                  {item.category}
                </span>
                <p className="text-white text-xs font-serif font-semibold italic truncate px-2">
                  {item.title}
                </p>
                <p className="text-zinc-500 text-[9px] line-clamp-1 mt-1 px-3">
                  {item.description || "Captured live in luxury venue"}
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Step-by-Step Custom Booking Guide */}
      <section className="py-24 px-4 bg-zinc-950 border-t border-amber-500/10">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-amber-500 text-[10px] uppercase font-bold tracking-[0.4em] mb-4 block">The Process</span>
            <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-4">
              How We Create <span className="text-amber-500 italic">Your Keepsake</span>
            </h2>
            <p className="text-zinc-400 text-xs font-light leading-relaxed">
              Reserving a high-society live artist is designed to be seamless, respectful, and highly customized.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 relative">
            {/* Background connection line */}
            <div className="absolute top-1/3 left-0 right-0 h-[10px] bg-[linear-gradient(90deg,rgba(197,160,89,0.15)_50%,transparent_50%)] bg-[size:20px_100%] hidden md:block z-0 pointer-events-none" />
            
            {steps.map((st, idx) => (
              <div 
                key={idx} 
                className={`p-6 rounded-[2rem] bg-black/40 border transition-all duration-300 relative z-10 text-left group cursor-pointer ${
                  activeStep === idx 
                    ? 'border-amber-500 bg-[#12100d] shadow-lg shadow-amber-500/5' 
                    : 'border-white/5 hover:border-amber-500/20'
                }`}
                onClick={() => setActiveStep(idx)}
              >
                <div className="flex justify-between items-center mb-6">
                  <span className="text-3xl font-serif font-black text-amber-500/25 group-hover:text-amber-500/60 transition-colors">
                    0{idx + 1}
                  </span>
                  <span className="text-[8px] uppercase tracking-widest bg-amber-500/10 text-amber-500 px-2.5 py-0.5 rounded-full font-mono border border-amber-500/20">
                    Step
                  </span>
                </div>
                
                <h3 className="text-white font-serif font-bold text-lg mb-1">{st.title}</h3>
                <p className="text-amber-500/60 text-[10px] uppercase tracking-widest font-mono font-semibold mb-4 block">{st.tagline}</p>
                <p className="text-zinc-400 text-xs leading-relaxed font-light">{st.desc}</p>
              </div>
            ))}
          </div>
          
          <div className="mt-12 text-center p-6 bg-zinc-900/30 border border-amber-500/5 rounded-3xl max-w-xl mx-auto flex items-center justify-center gap-3">
            <ShieldCheck className="h-4 w-4 text-amber-500 select-none flex-shrink-0" />
            <p className="text-[10px] uppercase tracking-wider text-zinc-300">
              Only <strong>2 priority bookings</strong> secured per weekend to ensure pristine canvas attention.
            </p>
          </div>
        </div>
      </section>

      {/* Voices of Art (Testimonials with high quality face presentation) */}
      <section className="py-24 px-4 bg-black">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <span className="text-amber-500 text-[10px] uppercase font-bold tracking-[0.4em] mb-block">Patron Reviews</span>
            <h3 className="text-3xl md:text-5xl font-serif font-bold text-white mt-1">Letters of <span className="text-amber-500">Endorsement</span></h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((t, i) => (
              <div 
                key={i} 
                className="p-8 bg-zinc-950/80 border border-white/5 rounded-[2rem] backdrop-blur-sm hover:border-amber-500/15 transition-all text-left relative flex flex-col justify-between"
              >
                <div>
                  <div className="flex text-amber-500 mb-6 gap-0.5">
                    {[...Array(t.rating)].map((_, i) => <Star key={i} className="h-3 w-3 fill-amber-500 text-amber-500" />)}
                  </div>
                  <p className="text-zinc-300 italic mb-8 font-light text-sm sm:text-base leading-relaxed">
                    "{t.review}"
                  </p>
                </div>
                
                {/* Person details with profile photo */}
                <div className="flex items-center gap-4 pt-4 border-t border-white/5 mt-auto">
                  <div className="w-12 h-12 rounded-full overflow-hidden border border-amber-500/30 bg-zinc-900 flex-shrink-0">
                    <img src={t.avatar} className="w-full h-full object-cover" alt={t.name} />
                  </div>
                  <div>
                    <div className="text-white font-serif font-bold text-xs uppercase tracking-widest">{t.name}</div>
                    <div className="text-amber-500/70 text-[9px] uppercase tracking-widest font-mono mt-0.5">{t.event}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Cinematic Instagram Live Atelier Feed Section (Goal: Section 9 Upgrade) */}
      <section className="py-24 px-4 bg-black border-t border-white/[0.03] relative overflow-hidden text-left">
        <div className="absolute top-1/2 left-0 w-80 h-80 bg-amber-500/[0.01] rounded-full blur-3xl pointer-events-none" />
        <div className="max-w-7xl mx-auto">
          
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-16">
            <div>
              <span className="text-amber-500 text-[10px] uppercase font-bold tracking-[0.4em] mb-4 block">Social Footprint</span>
              <h2 className="text-3xl md:text-5xl font-serif font-bold text-white leading-tight">
                Atelier <span className="text-amber-500 italic">In Motion</span>
              </h2>
              <p className="text-xs text-zinc-400 mt-2 font-light max-w-xl">
                We document our interactive luxury art performances across high-society weddings, elite events, and studio processes daily. Witness Deepak Prajapati live in Udaipur, Goa, and Mumbai.
              </p>
            </div>
            
            <a 
              href="https://www.instagram.com/dpartic_flow" 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-flex items-center gap-3 px-6 py-3 border border-amber-500/20 text-amber-500 font-bold rounded-full hover:bg-amber-500/5 hover:border-amber-500 text-xs tracking-widest uppercase transition-all whitespace-nowrap self-start animate-pulse"
            >
              <Instagram className="h-4 w-4" />
              <span>Follow @dpartic_flow</span>
              <ExternalLink className="h-3 w-3" />
            </a>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                title: "Bridal Entry Gold Reveal at Taj Lake Palace, Udaipur. Watch till the metallic flakes sparkled.",
                likes: "14.2K",
                views: "185K",
                img: "https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&w=600&q=80",
                category: "Wedding Art Live"
              },
              {
                title: "Behind the process: How our Master of Fine Arts custom primes double woven Belgian linen.",
                likes: "8.5K",
                views: "92K",
                img: "https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=600&q=80",
                category: "Studio Process BTS"
              },
              {
                title: "5-Minute guest portrait marathon live in Mumbai. Quick charcoal wizardry.",
                likes: "19.8K",
                views: "245K",
                img: "https://images.unsplash.com/photo-1513364776144-60967b0f800f?auto=format&fit=crop&w=600&q=80",
                category: "Live Sketches Marathon"
              },
              {
                title: "Clay sovereign Mandir custom gilded with 24k gold leaf flakes.",
                likes: "6.3K",
                views: "74K",
                img: "https://images.unsplash.com/photo-1576016770956-debb63d900ad?auto=format&fit=crop&w=600&q=80",
                category: "Clay & Gilded Ornaments"
              }
            ].map((post, pIdx) => (
              <div 
                key={pIdx}
                className="group bg-zinc-950 border border-white/5 rounded-3xl overflow-hidden relative transition-all duration-300 hover:border-amber-500/25 flex flex-col justify-between"
              >
                {/* Visual Image container mimicking a phone screen / post layout */}
                <div className="relative aspect-[4/5] bg-black overflow-hidden flex items-center justify-center">
                  <img 
                    src={post.img} 
                    className="w-full h-full object-cover brightness-75 group-hover:scale-103 group-hover:brightness-60 transition-all duration-700" 
                    alt={post.title} 
                  />
                  {/* Overlay badge with category */}
                  <span className="absolute top-4 left-4 bg-black/85 border border-white/5 text-[8px] font-mono uppercase tracking-widest text-amber-500 px-3 py-1 rounded-full z-10 select-none">
                    {post.category}
                  </span>

                  {/* Icon view count */}
                  <div className="absolute bottom-4 left-4 flex items-center gap-3 z-10 text-white font-mono text-[10px] font-bold bg-black/50 px-3 py-1 rounded-full backdrop-blur-sm">
                    <span className="flex items-center gap-1">🎥 {post.views}</span>
                    <span className="flex items-center gap-1">❤️ {post.likes}</span>
                  </div>

                  {/* Interactive hover details */}
                  <div className="absolute inset-0 bg-black/50 flex flex-col justify-center items-center opacity-0 group-hover:opacity-100 transition-opacity z-20 gap-3 p-6 text-center">
                    <p className="text-white text-xs font-light max-w-xs leading-relaxed">{post.title}</p>
                    <button 
                      type="button"
                      onClick={() => {
                        if (navigator.clipboard) {
                          navigator.clipboard.writeText("https://www.instagram.com/dpartic_flow");
                          toast.success("Studio Instagram handle copied! Share with your loved ones. ✨");
                        } else {
                          toast.success("Find Deepak Prajapati at @dpartic_flow on Instagram!");
                        }
                      }}
                      className="px-4 py-1.5 bg-amber-500 text-black rounded-full text-[9px] uppercase font-bold tracking-widest hover:bg-amber-400 active:scale-95 transition-all outline-none cursor-pointer"
                    >
                      Share Link
                    </button>
                  </div>
                </div>

                {/* Subtitle bottom footer */}
                <div className="p-4 bg-zinc-900 border-t border-white/[0.02] flex justify-between items-center text-left">
                  <div className="flex items-center gap-2">
                    <div className="w-5 h-5 rounded-full bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-500 font-bold text-[8px]">DP</div>
                    <span className="text-[10px] text-zinc-400 font-mono">@dpartic_flow</span>
                  </div>
                  <span className="text-zinc-600 text-xs">✦</span>
                </div>
              </div>
            ))}
          </div>

        </div>
      </section>

      {/* Frequently Asked Questions Accords Section (Goal: Section 10 Upgrade) */}
      <section className="py-24 px-4 bg-zinc-950 border-t border-white/[0.03] relative overflow-hidden text-left">
        <div className="absolute top-1/4 right-[10%] w-[350px] h-[350px] bg-amber-500/[0.01] rounded-full blur-3xl pointer-events-none" />
        <div className="max-w-4xl mx-auto">
          
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-amber-500 text-[10px] uppercase font-bold tracking-[0.4em] mb-4 block">Atelier Guidance</span>
            <h2 className="text-3xl md:text-5xl font-serif font-bold text-white">
              Curated <span className="text-amber-500 italic">Advisory FAQs</span>
            </h2>
            <p className="text-xs text-zinc-400 font-light mt-2 leading-relaxed">
              Find instant professional answers regarding commission structures, travel accommodations, custom framing styles, and schedule timelines.
            </p>
          </div>

          <div className="space-y-4">
            {[
              {
                q: "How does the live booking process work?",
                a: "Booking is extremely simple and secure. Once you submit a booking request for your chosen date, our studio and chief artist Deepak Prajapati assess availability and confirm. Secured by a partial reservation deposit, the date is locked exclusively on our master scheduler. You can track all active commissions, private visual logs, and direct chat dialog in real-time inside your collector dashboard."
              },
              {
                q: "Is an advance payment deposit required to secure my date?",
                a: "Yes, a minor retaining deposit is routed via our payment system to secure Deepak's exclusive travel calendar and reserve your date. This covers initial visual sketches, premium primed wood stretcher preparation, and custom heavy Belgian linen priming, preventing other collectors from scheduling overlapping bookings for that day."
              },
              {
                q: "Do you travel across India and globally for high-end events?",
                a: "Absolutely. Deepak travels for premium destination events across Udaipur, Jaipur, Goa, Mumbai, Delhi, Raipur and international private holiday retreats. Air travel and lodging are harmonized in your contract details, and Deepak travels with specialized custom luggage to transport canvases and tools safely."
              },
              {
                q: "How long does a live painting or couple sketch take?",
                a: "During live events, guests have front-row seats as the painting unfolds. Deepak paints the primary composition, light-atmosphere, and live anatomical layout within 5 to 6 hours during your vows, mandap pheras, or entry. The canvas is safely wrapped in a custom protective sleeve and varnished with studio glazes and anti-UV top layers for direct handoff."
              },
              {
                q: "Can artworks, color formats, and size dimensions be fully customized?",
                a: "Yes. Every commission begins with a digital consultation where color pallets, home layouts, favorite flowers, and focus guests are discussed. The completed masterpiece is crafted to match your future home salon's decor, ensuring the family heirloom resides perfectly on your wall."
              }
            ].map((faq, fIdx) => {
              const isOpen = activeFaq === fIdx;
              return (
                <div 
                  key={fIdx}
                  className="bg-black/40 border border-white/5 rounded-2xl md:rounded-3xl overflow-hidden transition-colors hover:border-amber-500/15"
                >
                  <button 
                    type="button"
                    onClick={() => setActiveFaq(isOpen ? null : fIdx)}
                    className="w-full flex justify-between items-center p-6 md:p-8 text-left focus:outline-none cursor-pointer border-none bg-transparent"
                  >
                    <span className="text-sm md:text-base font-serif font-bold text-white pr-4">{faq.q}</span>
                    <span className="text-amber-500 text-lg font-mono transition-transform duration-300" style={{ transform: isOpen ? 'rotate(45deg)' : 'rotate(0deg)' }}>
                      {isOpen ? "×" : "+"}
                    </span>
                  </button>
                  
                  <AnimatePresence initial={false}>
                    {isOpen && (
                      <motion.div 
                        key={`faq-ans-${fIdx}`}
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.3 }}
                        className="overflow-hidden"
                      >
                        <div className="p-6 md:p-8 pt-0 border-t border-white/[0.02] text-xs md:text-sm text-zinc-400 leading-relaxed font-light">
                          {faq.a}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            })}
          </div>

        </div>
      </section>

      {/* High-Converting Concierge Enquiry & Premium Form Section */}
      <section className="py-24 px-4 bg-zinc-950 border-t border-amber-500/10 relative overflow-hidden">
        {/* Candlelight ambient background */}
        <div className="absolute bottom-0 right-1/4 w-[350px] h-[350px] bg-amber-500/[0.015] rounded-full blur-3xl pointer-events-none" />
        
        <div className="max-w-5xl mx-auto relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center text-left">
            
            {/* Left Content Column */}
            <div className="lg:col-span-5 space-y-6">
              <span className="text-amber-500 text-[10px] uppercase font-bold tracking-[0.4em] block">Exclusive Inquiry</span>
              <h3 className="text-3xl md:text-5xl font-serif font-bold text-white tracking-tight leading-tight">
                Claim Your <span className="text-amber-500 italic block">Canvas Slots</span>
              </h3>
              <p className="text-zinc-400 text-xs font-light leading-relaxed">
                Deepak is available for bespoke travel commissions across Udaipur, Goa, Jaipur, Mumbai, Raipur and international holiday resorts. Secure standard booking consultation details below.
              </p>
              
              <div className="space-y-4 pt-4">
                <div className="flex items-center gap-3">
                  <MapPin className="h-4.5 w-4.5 text-amber-500" />
                  <span className="text-xs text-zinc-300">Chhattisgarh Studio & Destination Travels</span>
                </div>
                <div className="flex items-center gap-3">
                  <Clock className="h-4.5 w-4.5 text-amber-500" />
                  <span className="text-xs text-zinc-300">Quick response within 12 Hours</span>
                </div>
                <div className="flex items-center gap-3">
                  <Heart className="h-4.5 w-4.5 text-amber-600 fill-amber-500" />
                  <span className="text-xs text-zinc-300">Bespoke luxury framing guidance included</span>
                </div>
              </div>
            </div>

            {/* Right Form Column */}
            <div className="lg:col-span-7 bg-black/60 border border-white/5 rounded-[2.5rem] p-8 sm:p-10 backdrop-blur-xl relative">
              <AnimatePresence mode="wait">
                {formSubmitted ? (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0 }}
                    className="text-center py-12 space-y-4"
                  >
                    <div className="w-16 h-16 bg-amber-500/10 border border-amber-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                      <CheckCircle className="h-8 w-8 text-amber-500" />
                    </div>
                    <h4 className="text-xl font-serif text-white uppercase tracking-wider font-bold">Enquiry Acknowledged</h4>
                    <p className="text-zinc-400 text-xs font-light max-w-sm mx-auto">
                      Thank you for choosing Deepak to paint your story. Our concierge desk will review dates and reach out over Phone and WhatsApp within the morning.
                    </p>
                    <p className="text-[10px] text-zinc-500 italic">Please stand by...</p>
                  </motion.div>
                ) : (
                  <form onSubmit={handleConciergeSubmit} className="space-y-4">
                    <div className="text-center lg:text-left border-b border-white/5 pb-4 mb-2">
                      <p className="text-xs text-amber-500 uppercase font-mono tracking-widest font-bold">Priority Booking Sheet</p>
                      <p className="text-[10px] text-zinc-400 font-light mt-0.5">Please fill with care to ensure immediate slot check</p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-[9px] uppercase tracking-widest text-zinc-500">Full Name</label>
                        <input 
                          type="text" 
                          required
                          placeholder="Lord or Lady Name"
                          className="w-full bg-zinc-950/85 border border-white/10 rounded-xl py-3 px-4 text-xs text-white focus:outline-none focus:border-amber-500 transition-colors placeholder:text-zinc-700 font-light"
                          value={conciergeForm.name}
                          onChange={e => setConciergeForm({...conciergeForm, name: e.target.value})}
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[9px] uppercase tracking-widest text-zinc-500">Contact Number (WhatsApp)</label>
                        <input 
                          type="tel" 
                          required
                          placeholder="+91 XXXXX XXXXX"
                          className="w-full bg-zinc-950/85 border border-white/10 rounded-xl py-3 px-4 text-xs text-white focus:outline-none focus:border-amber-500 transition-colors placeholder:text-zinc-700 font-light"
                          value={conciergeForm.phone}
                          onChange={e => setConciergeForm({...conciergeForm, phone: e.target.value})}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-[9px] uppercase tracking-widest text-zinc-500">Proposed Event Date</label>
                        <input 
                          type="date" 
                          required
                          className="w-full bg-zinc-950/85 border border-white/10 rounded-xl py-3 px-4 text-xs text-white focus:outline-none focus:border-amber-500 transition-colors font-light"
                          value={conciergeForm.eventDate}
                          onChange={e => setConciergeForm({...conciergeForm, eventDate: e.target.value})}
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[9px] uppercase tracking-widest text-zinc-500">Destination Location</label>
                        <input 
                          type="text" 
                          required
                          placeholder="e.g. Goa Taj Altar"
                          className="w-full bg-zinc-950/85 border border-white/10 rounded-xl py-3 px-4 text-xs text-white focus:outline-none focus:border-amber-500 transition-colors placeholder:text-zinc-700 font-light"
                          value={conciergeForm.location}
                          onChange={e => setConciergeForm({...conciergeForm, location: e.target.value})}
                        />
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[9px] uppercase tracking-widest text-zinc-500">Experience Desired</label>
                      <select 
                        className="w-full bg-zinc-950/100 border border-white/10 rounded-xl py-3 px-4 text-xs text-amber-500 focus:outline-none focus:border-amber-500 transition-colors font-serif font-semibold"
                        value={conciergeForm.preference}
                        onChange={e => setConciergeForm({...conciergeForm, preference: e.target.value})}
                      >
                        <option value="Wedding Artwork">Wedding Canvas painting live</option>
                        <option value="Couple Portraits">Couple metal dust live portraits</option>
                        <option value="Guests Face Sketches">Guests charcoal sketches log</option>
                        <option value="Custom Commissions">Bespoke Studio commission</option>
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[9px] uppercase tracking-widest text-zinc-500">Special Notes / Family Vows</label>
                      <textarea 
                        className="w-full bg-zinc-950/85 border border-white/10 rounded-xl py-3 px-4 text-xs text-white focus:outline-none focus:border-amber-500 transition-colors min-h-[70px] placeholder:text-zinc-700 font-light"
                        placeholder="Any custom framing layout or surprise ideas you have..."
                        value={conciergeForm.notes}
                        onChange={e => setConciergeForm({...conciergeForm, notes: e.target.value})}
                      />
                    </div>

                    <button 
                      type="submit" 
                      className="w-full py-4.5 bg-amber-500 text-black font-extrabold rounded-xl uppercase tracking-[0.2em] flex items-center justify-center space-x-2.5 hover:bg-amber-400 active:scale-99 transition-all cursor-pointer shadow-lg text-xs"
                    >
                      <Send className="h-4 w-4" />
                      <span>Transmit Priority enquirySheet</span>
                    </button>
                  </form>
                )}
              </AnimatePresence>
            </div>

          </div>
        </div>
      </section>

    </div>
  );
}
