import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Link, useNavigate } from 'react-router-dom';
import { ArtService } from '../types';
import { 
  Sparkles, ArrowRight, Loader2, DollarSign, Calculator, Info,
  Check, Phone, Mail, Image as ImageIcon, MapPin, ToggleLeft, ShieldCheck, 
  Clock, Package, Star, MessageSquare
} from 'lucide-react';
import { formatCurrency } from '../lib/utils';
import { useAuth } from '../context/AuthContext';
import { ART_SERVICES } from '../constants';
import toast from 'react-hot-toast';

// Default custom metadata options if not defined on database records
const DEFAULT_SIZE_PRICING = [
  { code: 'A4', label: 'A4 Fine Art Portfolio', priceModifier: 0, desc: 'Ideal for intimate desk frames or hand-held memory folders (21 x 29.7 cm)' },
  { code: 'A3', label: 'A3 Salon Masterpiece', priceModifier: 1999, desc: 'Highly requested size for living spaces and couple lounges (29.7 x 42 cm)' },
  { code: 'A2', label: 'A2 Imperial Castle Canvas', priceModifier: 3499, desc: 'Exquisite, commanding display for high-ceiling reception walls (42 x 59.4 cm)' }
];

const DEFAULT_CUSTOMIZATIONS = [
  { id: 'frame', label: 'Premium Gold Gilded / Floating Frame', cost: 1500, desc: 'Museum-quality hand-painted gold leaf borders' },
  { id: 'canvas', label: 'Heavy Belgian Prime Cotton Linen', cost: 800, desc: 'Archival-safe gesso-primed textured canvas surface' },
  { id: 'express', label: 'Express Tracker Courier (48h)', cost: 500, desc: 'Guaranteed safe speed transit with protective wrapping' },
  { id: 'packaging', label: 'Deluxe Velvet Keepsake Storage Box', cost: 600, desc: 'Embossed Royal Blue box lined with elegant satin' }
];

const handleImageError = (e: React.SyntheticEvent<HTMLImageElement, Event>) => {
  e.currentTarget.src = "https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?q=80&w=1000";
};

interface ServiceCardProps {
  key?: any;
  service: any;
  index: number;
  setSelectedCalcService: (id: string) => void;
  formatCurrency: (value: number) => string;
}

function ServiceCard({ service, index, setSelectedCalcService, formatCurrency }: ServiceCardProps) {
  const [mediaLoading, setMediaLoading] = useState(true);
  const discount = service.discountOffer || 0;
  const startingPrice = service.price;
  const premiumPrice = service.premiumPrice || Math.floor(startingPrice * 1.5);
  const materials = service.materials || "Premium Archival Gesso Cotton Canvas";
  const duration = service.duration || "4 to 6 active live hours";
  const deliveryTime = service.deliveryTime || "Delivered live at event or tracked courier in 4 days";

  const handleLoadComplete = () => {
    setMediaLoading(false);
  };

  useEffect(() => {
    if (!service.image) {
      setMediaLoading(false);
    }
  }, [service.image]);

  return (
    <motion.div
      key={service.id}
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.7, delay: index * 0.08, ease: [0.16, 1, 0.3, 1] }}
      className="group bg-black border border-zinc-800/80 rounded-[2rem] overflow-hidden flex flex-col justify-between hover:border-amber-500/40 hover:bg-zinc-950 hover:shadow-[0_0_40px_rgba(245,158,11,0.08)] transition-all duration-500 transform hover:-translate-y-1"
    >
      <div>
        {/* Premium 3:2 aspect artistic viewport with dark gradient masks */}
        <div className="relative aspect-[3/2] overflow-hidden bg-[#0a0a0a] flex items-center justify-center border-b border-white/5">
          {/* SKELETON LOAD LOADER WITH SMOOTH SHIMMER ANIMATION */}
          {mediaLoading && service.image && (
            <div className="absolute inset-x-0 inset-y-0 bg-gradient-to-r from-zinc-950 via-zinc-900 to-zinc-950 bg-[length:200%_100%] animate-shimmer z-20" />
          )}

          {service.image ? (
            <>
              {/* Blur ambient glow background behind the image */}
              <img 
                src={service.image} 
                onError={(e) => {
                  handleImageError(e);
                  handleLoadComplete();
                }}
                className="absolute inset-0 w-full h-full object-cover blur-2xl opacity-15 scale-125 select-none pointer-events-none transition-transform duration-700" 
                alt="" 
              />
              {service.mediaType === 'video' ? (
                <video 
                  src={service.image} 
                  autoPlay 
                  muted 
                  loop 
                  playsInline 
                  onLoadedData={handleLoadComplete}
                  className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" 
                />
              ) : (
                <img 
                  src={service.image} 
                  onError={(e) => {
                    handleImageError(e);
                    handleLoadComplete();
                  }}
                  onLoad={handleLoadComplete}
                  alt={service.title}
                  className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
              )}
            </>
          ) : (
            /* Custom Gilded Luxury Placeholder (If no artwork exists) */
            <div className="absolute inset-0 bg-gradient-to-br from-[#0c0c0c] via-[#050505] to-black flex flex-col items-center justify-center p-6 text-center select-none overflow-hidden">
              {/* Decorative gold background sparkles */}
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(245,158,11,0.03)_0%,transparent_70%)]" />
              <div className="absolute -inset-10 opacity-20 border border-amber-500/10 rounded-full scale-75 animate-pulse" />
              
              <div className="relative z-10 w-12 h-12 bg-amber-500/[0.03] border border-amber-500/20 rounded-full flex items-center justify-center mb-3 shadow-[0_0_15px_rgba(245,158,11,0.05)] text-amber-500 group-hover:rotate-12 transition-transform duration-500">
                <Sparkles className="h-5 w-5" />
              </div>
              
              <span className="relative z-10 text-[7px] text-amber-500/50 font-mono uppercase tracking-[0.4em] font-bold">Atelier Reserve</span>
              <h4 className="relative z-10 text-xs font-serif italic text-zinc-400 mt-1.5 font-semibold group-hover:text-amber-500/80 transition-colors duration-300">{service.title}</h4>
              <span className="relative z-10 text-[7px] text-zinc-650 font-light tracking-wide mt-1 block">Exquisite Custom Medium Commission</span>
            </div>
          )}
          
          {/* Premium cinematic cinematic gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/10 transition-opacity duration-500" />
          
          <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between z-10">
            <span className="bg-black/80 backdrop-blur-md px-2.5 py-1 rounded-md border border-white/10 text-[8px] font-mono text-zinc-400 uppercase tracking-widest font-semibold">
              {service.category || "Atelier"}
            </span>
            {discount > 0 && (
              <span className="bg-gradient-to-r from-red-650 to-red-500 text-white text-[8px] font-mono font-bold px-2 py-0.5 rounded-md border border-red-500/30 shadow-[0_0_10px_rgba(239,68,68,0.2)]">
                -{discount}% OFF
              </span>
            )}
          </div>
        </div>

        {/* Info & Core parameters */}
        <div className="p-7 space-y-5">
          <div>
            <div className="flex items-center gap-1.5 mb-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-550 block animate-pulse" />
              <span className="text-[8px] uppercase font-mono tracking-widest text-zinc-500 font-bold">Deepak Prajapati Original</span>
            </div>
            
            <h3 className="text-xl font-serif text-white hover:text-amber-500 transition-colors duration-300 tracking-wide line-clamp-1">
              {service.title}
            </h3>
            <p className="text-zinc-500 text-xs font-light line-clamp-2 leading-relaxed mt-2">
              {service.description}
            </p>
          </div>

          {/* Metallic / Monotypographical Parameters Details */}
          <div className="grid grid-cols-2 gap-y-3 gap-x-4 py-4 border-y border-zinc-900 font-mono text-[9px] text-zinc-400">
            <div className="space-y-1">
              <span className="text-zinc-600 block text-[8px] uppercase font-bold tracking-widest">Atelier Base Materials</span>
              <span className="text-white font-sans font-light line-clamp-1">{materials}</span>
            </div>
            <div className="space-y-1">
              <span className="text-zinc-600 block text-[8px] uppercase font-bold tracking-widest">Active Canvas Span</span>
              <span className="text-white font-sans font-light line-clamp-1">{duration}</span>
            </div>
            <div className="space-y-1 col-span-2">
              <span className="text-zinc-600 block text-[8px] uppercase font-bold tracking-widest">Shipment & Delivery Timeline</span>
              <span className="text-white font-sans font-light line-clamp-1">{deliveryTime}</span>
            </div>
          </div>

          {/* Gold comparison rates */}
          <div className="p-4 bg-amber-500/[0.01] border border-amber-500/10 rounded-2xl flex items-center justify-between">
            <div>
              <span className="text-[7px] uppercase text-zinc-500 font-bold tracking-widest block mb-0.5">Classic Canvas</span>
              <p className="font-serif italic text-white text-base font-bold">{formatCurrency(startingPrice)}</p>
            </div>
            <div className="w-px h-8 bg-zinc-800" />
            <div className="text-right">
              <span className="text-[7px] uppercase text-zinc-500 font-bold tracking-widest block mb-0.5">Imperial Package</span>
              <p className="font-serif italic text-amber-500 text-base font-bold">{formatCurrency(premiumPrice)}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="p-7 pt-0 flex gap-3">
        <button
          onClick={() => {
            setSelectedCalcService(service.id);
            const element = document.getElementById('price-builder-sandbox');
            if (element) {
              element.scrollIntoView({ behavior: 'smooth' });
            }
          }}
          className="flex-1 py-3 px-4 bg-zinc-950/80 border border-zinc-800 hover:border-amber-500/35 hover:bg-black text-zinc-300 hover:text-white font-mono uppercase text-[9px] font-bold tracking-wider rounded-xl transition-all duration-300 inline-flex items-center justify-center gap-1.5"
        >
          <Calculator className="h-3 w-3 text-amber-500" />
          <span>Build Estimates</span>
        </button>
        
        <Link
          to={`/booking?service=${service.id}`}
          className="py-3 px-5 bg-amber-500 hover:bg-amber-450 text-black font-mono uppercase text-[9px] font-bold tracking-widest rounded-xl transition-all duration-300 flex items-center justify-center shadow-lg shadow-amber-500/5 hover:shadow-amber-500/15"
        >
          <span>Reserve</span>
        </Link>
      </div>
    </motion.div>
  );
}

export default function Services() {
  const [services, setServices] = useState<ArtService[]>(ART_SERVICES);
  const [loading, setLoading] = useState(true);
  const { user, openAuthModal } = useAuth();
  const navigate = useNavigate();

  // Price sandbox calculator state
  const [selectedCalcService, setSelectedCalcService] = useState<string>('wedding-paintings');
  const [selectedSize, setSelectedSize] = useState<string>('A3');
  const [checkedOptions, setCheckedOptions] = useState<Record<string, boolean>>({
    frame: true,
    canvas: false,
    express: false,
    packaging: true
  });
  const [rushOrder, setRushOrder] = useState<boolean>(false);
  const [peakSeason, setPeakSeason] = useState<boolean>(false);
  const [travelDistance, setTravelDistance] = useState<number>(0);

  // Inquiry Popovers & Custom Quote submission fields
  const [showInquiryModal, setShowInquiryModal] = useState(false);
  const [customInquiry, setCustomInquiry] = useState({
    name: '',
    email: '',
    phone: '',
    whatsapp: '',
    serviceId: 'wedding-paintings',
    sizePreferred: 'A3',
    requirements: '',
    approxBudget: ''
  });
  const [submittingInquiry, setSubmittingInquiry] = useState(false);

  useEffect(() => {
    const fetchServices = async () => {
      try {
        const res = await fetch('/api/public/services');
        if (res.ok && res.headers.get('content-type')?.includes('application/json')) {
          const data = await res.json();
          if (data && data.length > 0) {
            setServices(data);
            setSelectedCalcService(data[0].id || 'wedding-paintings');
          } else {
            setServices(ART_SERVICES);
          }
        } else {
          setServices(ART_SERVICES);
        }
      } catch (error) {
        console.error("Error loading services:", error);
        setServices(ART_SERVICES);
      } finally {
        setLoading(false);
      }
    };
    fetchServices();
  }, []);

  // Find active selected service details for configuration
  const currentServiceDetails = services.find(s => s.id === selectedCalcService) || services[0] || ART_SERVICES[0];

  // Price Calculation Logic
  const calculateEstimate = () => {
    if (!currentServiceDetails) return 0;
    
    // 1. Base Starting Price
    let total = currentServiceDetails.price;

    // 2. Sizing modifiers
    const sizeObj = DEFAULT_SIZE_PRICING.find(s => s.code === selectedSize);
    if (sizeObj) {
      total += sizeObj.priceModifier;
    }

    // 3. Optional customizations
    DEFAULT_CUSTOMIZATIONS.forEach(opt => {
      if (checkedOptions[opt.id]) {
        total += opt.cost;
      }
    });

    // 4. Advanced Modifiers
    if (rushOrder) total += 1500; // Rush Fee: ₹1500
    if (peakSeason) total += Math.floor(currentServiceDetails.price * 0.15); // Peak Surge: +15%
    if (travelDistance > 0) total += travelDistance * 15; // Travel: ₹15 per km

    // Apply any dynamic discount offers active on this service record
    if (currentServiceDetails.discountOffer && currentServiceDetails.discountOffer > 0) {
      total = Math.floor(total * (1 - (currentServiceDetails.discountOffer / 100)));
    }

    return total;
  };

  const finalCalcPrice = calculateEstimate();

  // Pre-prepare a detailed summary of configuration
  const getSpecsSummaryText = () => {
    const sizeName = DEFAULT_SIZE_PRICING.find(s => s.code === selectedSize)?.label || selectedSize;
    const activeOpts = DEFAULT_CUSTOMIZATIONS
      .filter(opt => checkedOptions[opt.id])
      .map(opt => opt.label)
      .join(', ');
    
    let specs = `Service: ${currentServiceDetails?.title} | Size: ${sizeName}`;
    if (activeOpts) specs += ` | Customizations: [${activeOpts}]`;
    if (rushOrder) specs += ` | Rush Processing Enabled`;
    if (peakSeason) specs += ` | Festival Season Priority Reserved`;
    if (travelDistance > 0) specs += ` | Est. Travel distance: ${travelDistance} km`;
    
    return specs;
  };

  // Direct Redirect to Booking with Calculator parameters
  const handleProceedToBooking = () => {
    if (!user) {
      toast.error("Please authentication before entering the checkout suite.", { id: 'booking-alert' });
      openAuthModal('signin');
      return;
    }
    const sum = getSpecsSummaryText();
    navigate(`/booking?service=${selectedCalcService}&price=${finalCalcPrice}&specs=${encodeURIComponent(sum)}`);
  };

  // Custom Inquiry Direct Submission to Booking table as inquiry entry
  const handleInquirySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmittingInquiry(true);

    try {
      const selectedS = services.find(s => s.id === customInquiry.serviceId) || currentServiceDetails;
      const specsSummary = `QUOTE REQUEST FOR: ${selectedS.title} | Size: ${customInquiry.sizePreferred} | Budg: ₹${customInquiry.approxBudget || 'TBD'} | User Specs: ${customInquiry.requirements}`;

      const inquiryDoc = {
        userId: user?.uid || 'guest_prospect',
        userEmail: customInquiry.email,
        userName: customInquiry.name,
        artCategory: selectedS.title,
        date: new Date(Date.now() + 7 * 24 * 3600 * 1000).toISOString().split('T')[0], // proposed 1 week from now
        timing: 'Flexible Afternoon (Standard Appointment)',
        location: 'Inquiry Lead / Online Delivery Address',
        phone: customInquiry.phone,
        whatsapp: customInquiry.whatsapp || customInquiry.phone,
        requirements: specsSummary,
        referenceImages: [],
        paymentStatus: 'pending',
        amount: finalCalcPrice || selectedS.price,
        status: 'pending', // Will show in Admin overview with custom notes
        adminNotes: `PROSPECT CUSTOM QUOTE INQUIRY. Preferred Budget: ${customInquiry.approxBudget || 'Open'}`,
        createdAt: new Date().toISOString()
      };

      const saveRes = await fetch('/api/bookings/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(inquiryDoc)
      });

      if (!saveRes.ok) throw new Error("Inquiry could not post.");

      toast.success("Golden Canvas Quote submitted! Deepak Prajapati has received your request. ✨");
      setShowInquiryModal(false);
      setCustomInquiry({
        name: '',
        email: '',
        phone: '',
        whatsapp: '',
        serviceId: 'wedding-paintings',
        sizePreferred: 'A3',
        requirements: '',
        approxBudget: ''
      });
    } catch (err) {
      toast.error("Failed to lodge request. Please use WhatsApp direct inquiry channel.");
    } finally {
      setSubmittingInquiry(false);
    }
  };

  // WhatsApp instant link trigger
  const triggerWhatsAppInquiry = () => {
    const textStr = `Hi Deepak Prajapati! I am inquiring about one of your premium art services:\n\n*Service:* ${currentServiceDetails?.title}\n*Est. Base Rate:* ${formatCurrency(currentServiceDetails?.price)}\n\n*My Premium Custom Configuration:*\n- *Size:* ${selectedSize} (${DEFAULT_SIZE_PRICING.find(s => s.code === selectedSize)?.label})\n${DEFAULT_CUSTOMIZATIONS.filter(o => checkedOptions[o.id]).map(o => `- *Custom:* ${o.label} (+₹${o.cost})`).join('\n')}${rushOrder ? '\n- *Rush Processing:* Enabled (+₹1,500)' : ''}${peakSeason ? '\n- *Peak Season Surge:* Enabled' : ''}${travelDistance > 0 ? `\n- *Travel Distance:* ${travelDistance} km` : ''}\n\n*Live Estimated Quote:* ~ ${formatCurrency(finalCalcPrice)}\n\nPlease advise if the studio has open calendar slots for my event! ✨`;
    const cleanPhone = "91" + "9988776655"; // Replaces with appropriate fallback or admin contact
    window.open(`https://wa.me/${cleanPhone}?text=${encodeURIComponent(textStr)}`, '_blank');
  };

  return (
    <div className="bg-black min-h-screen pt-32 pb-20 px-4 text-white">
      <div className="max-w-7xl mx-auto">
        
        {/* UPPER TITLE HEADER */}
        <div className="mb-20 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-4"
          >
            <span className="text-amber-500 text-xs font-bold uppercase tracking-[0.4em] mb-4 block">Fine Art Packages & Transparent Valuations</span>
            <h1 className="text-4xl md:text-6xl font-serif italic text-amber-500 tracking-tighter mb-4">
              CHRONICLE MASTERPIECE COSTING
            </h1>
            <p className="text-zinc-400 max-w-3xl mx-auto font-light leading-relaxed tracking-wide text-sm md:text-base">
              A high-end, dynamic pricing ecosystem structured for collectors, couples, and premium event hosts. Select customized formats, sizes, framing layers, and instantly reserve or procure custom quotes on-demand.
            </p>
          </motion.div>
        </div>

        {/* SECTION 1: MASTER ART SERVICE DIRECTORY */}
        <div className="mb-20">
          <div className="flex items-center gap-3 mb-8 border-b border-white/5 pb-4">
            <Sparkles className="h-5 w-5 text-amber-500" />
            <h2 className="text-xl font-serif text-white tracking-wider">FINE ART CATALOGUE & RETAINERS</h2>
          </div>

          {loading ? (
            <div className="flex justify-center py-20">
              <Loader2 className="h-10 w-10 text-amber-500 animate-spin" />
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {services.map((service, index) => (
                <ServiceCard 
                  key={service.id} 
                  service={service} 
                  index={index} 
                  setSelectedCalcService={setSelectedCalcService}
                  formatCurrency={formatCurrency}
                />
              ))}
            </div>
          )}
        </div>

        {/* SECTION 2: THE DYNAMIC FINE ART CUSTOMIZATION SANDBOX (COMPUTATION ENGINE ON CLIENT) */}
        <div id="price-builder-sandbox" className="grid grid-cols-1 lg:grid-cols-3 gap-10 bg-gradient-to-br from-[#0c0c0c] to-zinc-950 border border-amber-500/10 rounded-[3rem] p-8 md:p-12 mb-20 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/5 blur-[120px] rounded-full pointer-events-none" />
          
          <div className="lg:col-span-2 space-y-8">
            <div>
              <span className="text-amber-500 font-mono text-[9px] font-bold uppercase tracking-[0.3em] block mb-2">Artisanal Suite Sandbox</span>
              <h2 className="text-3xl font-serif text-white font-medium">LUXURY SPECIFICATION CALCULATOR</h2>
              <p className="text-zinc-500 text-xs mt-1 max-w-xl font-light">Select sizes, exclusive hand-woven canvases, gilded frames and event timelines. See instant estimates live with total breakdown validation before committing to a booking.</p>
            </div>

            {/* Selector parameters */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Select Service */}
              <div className="space-y-3">
                <label className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest pl-1">Selected Master Service</label>
                <select 
                  className="w-full bg-black/60 border border-white/10 rounded-2xl p-4 text-sm text-beige-100 outline-none focus:border-amber-500 font-medium cursor-pointer"
                  value={selectedCalcService}
                  onChange={e => setSelectedCalcService(e.target.value)}
                >
                  {services.map(s => (
                    <option key={s.id} value={s.id} className="bg-zinc-950 text-white">
                      {s.title}
                    </option>
                  ))}
                </select>
                <div className="p-3 bg-black/30 rounded-xl border border-white/5">
                  <span className="text-[8px] uppercase tracking-wider text-zinc-600 block mb-1">Standard Base Price includes:</span>
                  <p className="text-[10px] text-zinc-400 font-light line-clamp-2">
                    {currentServiceDetails?.description}
                  </p>
                </div>
              </div>

              {/* Sizing Parameters */}
              <div className="space-y-3">
                <label className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest pl-1">Sizing Preference (Fine Canvas)</label>
                <div className="grid grid-cols-3 gap-2">
                  {DEFAULT_SIZE_PRICING.map(size => (
                    <button
                      type="button"
                      key={size.code}
                      onClick={() => setSelectedSize(size.code)}
                      className={`py-3 px-1.5 rounded-xl border font-mono text-[10px] font-bold tracking-widest transition-all ${
                        selectedSize === size.code 
                          ? "border-amber-500 bg-amber-500/10 text-amber-400" 
                          : "border-white/5 bg-black/30 text-zinc-500 hover:border-white/20 hover:text-white"
                      }`}
                    >
                      {size.code}
                      <span className="block text-[8px] font-normal leading-tight text-zinc-600 mt-1">
                        {size.priceModifier === 0 ? "Standard" : `+₹${size.priceModifier}`}
                      </span>
                    </button>
                  ))}
                </div>
                <div className="p-3 bg-black/30 rounded-xl border border-white/5">
                  <span className="text-[8px] uppercase tracking-wider text-zinc-600 block mb-1">Size Specification:</span>
                  <p className="text-[10px] text-zinc-400 font-light">
                    {DEFAULT_SIZE_PRICING.find(s => s.code === selectedSize)?.desc}
                  </p>
                </div>
              </div>
            </div>

            {/* Customization Options Grid checkboxes */}
            <div className="space-y-4">
              <label className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest block pl-1">Luxury Custom Add-On Elements</label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {DEFAULT_CUSTOMIZATIONS.map(opt => (
                  <div 
                    key={opt.id}
                    onClick={() => setCheckedOptions({...checkedOptions, [opt.id]: !checkedOptions[opt.id]})}
                    className={`flex items-start justify-between p-4 bg-black/40 border rounded-2xl cursor-pointer select-none transition-all ${
                      checkedOptions[opt.id] 
                        ? "border-amber-500/20 bg-amber-500/[0.01] text-white" 
                        : "border-white/5 text-zinc-400 hover:border-white/10"
                    }`}
                  >
                    <div className="space-y-1 pr-4">
                      <span className="text-xs font-medium block">{opt.label}</span>
                      <span className="text-[9px] text-zinc-500 font-light leading-relaxed block">{opt.desc}</span>
                    </div>
                    <div className="flex flex-col items-end shrink-0">
                      <span className="text-amber-500 font-mono text-xs font-semibold">+₹{opt.cost}</span>
                      <div className={`mt-2 h-4 w-4 rounded border flex items-center justify-center transition-all ${
                        checkedOptions[opt.id] ? "bg-amber-500 border-amber-500 text-black" : "border-white/20"
                      }`}>
                        {checkedOptions[opt.id] && <Check className="h-3 w-3 stroke-[3]" />}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Dynamic Modifiers */}
            <div className="space-y-4 border-t border-white/5 pt-6">
              <label className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest block pl-1">Advanced Travel & Priority Options</label>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                
                {/* Distance range */}
                <div className="space-y-2 bg-black/30 p-4 border border-white/5 rounded-2xl">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-zinc-450 text-[10px] uppercase font-bold tracking-wider">Travel Distance</span>
                    <span className="text-amber-500 font-mono font-bold">{travelDistance} km</span>
                  </div>
                  <input 
                    type="range" 
                    min="0" 
                    max="500" 
                    step="10"
                    className="w-full accent-amber-500 bg-zinc-900 cursor-ew-resize"
                    value={travelDistance}
                    onChange={e => setTravelDistance(Number(e.target.value))}
                  />
                  <span className="text-[8px] text-zinc-600 block font-mono">Travel Charge: ₹15/km (Standard artist carriage)</span>
                </div>

                {/* Rush toggle */}
                <div 
                  onClick={() => setRushOrder(!rushOrder)}
                  className={`p-4 border rounded-2xl cursor-pointer select-none transition-all flex items-center justify-between ${
                    rushOrder ? "border-red-500/40 bg-red-500/[0.02]" : "bg-black/30 border-white/5"
                  }`}
                >
                  <div className="space-y-0.5">
                    <span className="text-[10px] uppercase font-bold text-zinc-500 block tracking-wider">Rush processing</span>
                    <span className="text-xs font-semibold text-white block">Speed Dispatch</span>
                    <p className="text-[8px] text-zinc-650 leading-relaxed font-light">Guarantee complete dry artwork in 4 hours (+₹1500)</p>
                  </div>
                  <div className={`h-5 w-10 rounded-full p-0.5 flex transition-colors duration-300 ${
                    rushOrder ? "bg-red-500 justify-end" : "bg-zinc-800 justify-start"
                  }`}>
                    <div className="bg-white h-4 w-4 rounded-full shadow" />
                  </div>
                </div>

                {/* Peak Season toggle */}
                <div 
                  onClick={() => setPeakSeason(!peakSeason)}
                  className={`p-4 border rounded-2xl cursor-pointer select-none transition-all flex items-center justify-between ${
                    peakSeason ? "border-amber-500/40 bg-amber-500/[0.02]" : "bg-black/30 border-white/5"
                  }`}
                >
                  <div className="space-y-0.5">
                    <span className="text-[10px] uppercase font-bold text-zinc-500 block tracking-wider">Wedding season</span>
                    <span className="text-xs font-semibold text-white block">Peak Priority Queue</span>
                    <p className="text-[8px] text-zinc-650 leading-relaxed font-light">Active festival / high-demand priority surge (+15%)</p>
                  </div>
                  <div className={`h-5 w-10 rounded-full p-0.5 flex transition-colors duration-300 ${
                    peakSeason ? "bg-amber-500 justify-end" : "bg-zinc-800 justify-start"
                  }`}>
                    <div className="bg-white h-4 w-4 rounded-full shadow" />
                  </div>
                </div>

              </div>
            </div>
          </div>

          {/* DYNAMIC SUMMARIZED CERTIFICATE SIDE PANEL */}
          <div className="bg-black/40 border border-amber-500/15 p-8 rounded-[2rem] flex flex-col justify-between relative">
            <div className="absolute inset-0 bg-gradient-to-b from-amber-555/5 to-transparent pointer-events-none rounded-[2rem]" />
            <div className="space-y-6 relative z-10">
              <div className="text-center border-b border-white/5 pb-4">
                <Star className="h-6 w-6 text-amber-500 mx-auto mb-2 animate-spin-slow" />
                <span className="text-[9px] uppercase tracking-[0.25em] text-zinc-500 font-bold block">Quotation Assessment</span>
                <span className="text-white text-xs font-mono tracking-tight block mt-1">DPartic Flow Atelier</span>
              </div>

              {/* Dynamic specs details list */}
              <div className="space-y-3 font-mono text-[10px] text-zinc-400">
                <div className="flex justify-between">
                  <span>Base Retainer:</span>
                  <span className="text-white">{formatCurrency(currentServiceDetails?.price)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Canvas Size modifier:</span>
                  <span className="text-amber-500/80">
                    +{formatCurrency(DEFAULT_SIZE_PRICING.find(s => s.code === selectedSize)?.priceModifier || 0)}
                  </span>
                </div>
                
                {/* Individual options costs */}
                {DEFAULT_CUSTOMIZATIONS.map(o => {
                  if (!checkedOptions[o.id]) return null;
                  return (
                    <div key={o.id} className="flex justify-between text-zinc-500">
                      <span className="max-w-[150px] truncate">{o.label}:</span>
                      <span>+{formatCurrency(o.cost)}</span>
                    </div>
                  );
                })}

                {/* Extra parameters breakdown */}
                {rushOrder && (
                  <div className="flex justify-between text-red-400">
                    <span>Rush Dry Delivery:</span>
                    <span>+₹1,500</span>
                  </div>
                )}
                {peakSeason && (
                  <div className="flex justify-between text-amber-400">
                    <span>Peak Surge Limit:</span>
                    <span>+{formatCurrency(Math.floor(currentServiceDetails?.price * 0.15))}</span>
                  </div>
                )}
                {travelDistance > 0 && (
                  <div className="flex justify-between text-zinc-555 text-zinc-400">
                    <span>Travel ({travelDistance} km):</span>
                    <span>+{formatCurrency(travelDistance * 15)}</span>
                  </div>
                )}
                
                {currentServiceDetails?.discountOffer && currentServiceDetails.discountOffer > 0 ? (
                  <div className="flex justify-between text-emerald-400">
                    <span>Atelier Promo ({currentServiceDetails.discountOffer}%):</span>
                    <span>-{currentServiceDetails.discountOffer}%</span>
                  </div>
                ) : null}
              </div>

              {/* Gold Box calculated estimate price */}
              <div className="p-4 bg-gradient-to-tr from-amber-500/10 to-transparent border border-amber-500/20 rounded-2xl text-center space-y-1">
                <span className="text-[8px] uppercase tracking-widest text-zinc-450 block font-bold">Estimated Cost</span>
                <p className="text-3xl font-serif font-black text-amber-500">{formatCurrency(finalCalcPrice)}</p>
                <div className="inline-flex items-center gap-1.5 text-[8px] text-zinc-500 font-mono">
                  <ShieldCheck className="h-3 w-3 text-emerald-500" />
                  <span>Verified Archival Commission</span>
                </div>
              </div>
            </div>

            {/* Sizing/Custom Request quote actions */}
            <div className="space-y-3 mt-8 relative z-10">
              <button
                type="button"
                onClick={handleProceedToBooking}
                className="w-full py-3.5 bg-amber-500 hover:bg-amber-400 text-black font-bold uppercase text-[10px] tracking-widest rounded-xl transition-all shadow-lg shadow-amber-500/10 flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Book Dynamic Quote</span>
                <ArrowRight className="h-4.5 w-4.5" />
              </button>

              <button
                type="button"
                onClick={triggerWhatsAppInquiry}
                className="w-full py-3 bg-zinc-950 hover:bg-zinc-900 text-green-400 border border-green-500/20 hover:border-green-500/40 text-[10px] font-mono font-bold uppercase tracking-wider rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <MessageSquare className="h-4.5 w-4.5 text-green-500" />
                <span>WhatsApp pricing inquiry</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setCustomInquiry(prev => ({
                    ...prev,
                    serviceId: selectedCalcService,
                    sizePreferred: selectedSize
                  }));
                  setShowInquiryModal(true);
                }}
                className="w-full py-2.5 text-zinc-400 hover:text-white text-[9px] font-mono uppercase tracking-widest transition-colors flex items-center justify-center gap-1.5"
              >
                <Mail className="h-3.5 w-3.5 text-amber-500/60" />
                <span>Request custom Quote</span>
              </button>
            </div>
          </div>
        </div>

        {/* SECTION 3: LUXURY PACKAGE COMPARISON MATRIX */}
        <div className="mb-20">
          <div className="flex items-center gap-3 mb-8 border-b border-white/5 pb-4">
            <Star className="h-5 w-5 text-amber-500" />
            <h2 className="text-xl font-serif text-white tracking-wider">FINE ART SERVICE COMPARISON METRICS</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Standard Package */}
            <div className="p-8 bg-zinc-900/20 border border-white/5 rounded-3xl space-y-6 relative hover:border-white/10 transition-all">
              <div className="space-y-1">
                <span className="text-zinc-500 text-[9px] uppercase tracking-widest block font-bold">Category Line 01</span>
                <h3 className="text-xl font-bold text-white">ATELIER CORE SERIES</h3>
                <p className="text-zinc-400 text-xs font-light leading-relaxed">Perfect for intimate portfolios, live party charcoal drafts, and family keepsake files.</p>
              </div>

              <div className="space-y-4 font-mono text-[10px] text-zinc-400 border-t border-white/5 pt-4">
                <div className="flex items-center gap-2"><Check className="h-4.5 w-4.5 text-amber-500 shrink-0" /> <span>Standard Canvas Cardstock & Acid-free fibers</span></div>
                <div className="flex items-center gap-2"><Check className="h-4.5 w-4.5 text-amber-500 shrink-0" /> <span>Up to 4 Hours pure live sketching / live work</span></div>
                <div className="flex items-center gap-2"><Check className="h-4.5 w-4.5 text-amber-500 shrink-0" /> <span>Standard high-resolution scans and digitizations</span></div>
                <div className="flex items-center gap-2 text-zinc-650 opacity-40"><Check className="h-4.5 w-4.5 text-amber-500 shrink-0" /> <span>Gilded leaf frames (Available as add-on)</span></div>
                <div className="flex items-center gap-2 text-zinc-650 opacity-40"><Check className="h-4.5 w-4.5 text-amber-500 shrink-0" /> <span>Protective Velvet heirloom keepsakes display</span></div>
              </div>

              <div className="pt-4 border-t border-white/5">
                <span className="text-[9px] uppercase text-zinc-500 block tracking-wider">Estimated standard rate</span>
                <p className="text-2xl font-serif font-black text-white mt-1">Starting From ₹999</p>
                <span className="text-[9px] text-zinc-600 block mt-1 font-mono">Based on selected art format sizing</span>
              </div>
            </div>

            {/* Premium Gold Gilded / Floating Package (LUXURY HIGHLIGHT) */}
            <div className="p-8 bg-gradient-to-b from-amber-500/[0.03] to-transparent border border-amber-500/30 rounded-3xl space-y-6 relative hover:border-amber-500/50 transition-all shadow-2xl shadow-amber-500/5">
              <div className="absolute top-4 right-4 bg-amber-500 text-black text-[8px] font-mono font-black py-0.5 px-2 rounded-full uppercase tracking-wider">
                Most Chosen
              </div>
              
              <div className="space-y-1">
                <span className="text-amber-500 text-[9px] uppercase tracking-widest block font-bold">Category Line 02</span>
                <h3 className="text-xl font-bold text-amber-400">SOVEREIGN ATELIER PREMIUM</h3>
                <p className="text-zinc-300 text-xs font-light leading-relaxed">The luxury standard for grand weddings, large banquets, and customized corporate reveals.</p>
              </div>

              <div className="space-y-4 font-mono text-[10px] text-zinc-300 border-t border-white/10 pt-4">
                <div className="flex items-center gap-2"><Check className="h-4.5 w-4.5 text-amber-500 shrink-0" /> <span>Heavy Belgian Prime Cotton Linen canvas frame</span></div>
                <div className="flex items-center gap-2"><Check className="h-4.5 w-4.5 text-amber-500 shrink-0" /> <span>Untethered session (Up to 8 interactive hours)</span></div>
                <div className="flex items-center gap-2"><Check className="h-4.5 w-4.5 text-amber-500 shrink-0" /> <span>Premium Wood / Floating Framing package</span></div>
                <div className="flex items-center gap-2"><Check className="h-4.5 w-4.5 text-amber-500 shrink-0" /> <span>Deluxe Satin Velvet storage container</span></div>
                <div className="flex items-center gap-2"><Check className="h-4.5 w-4.5 text-amber-500 shrink-0" /> <span>Full ultra-HD video timelapse file included</span></div>
              </div>

              <div className="pt-4 border-t border-white/10">
                <span className="text-[9px] uppercase text-zinc-400 block tracking-wider">Premium package rate</span>
                <p className="text-2xl font-serif font-black text-amber-500 mt-1">Starting From ₹15,000</p>
                <span className="text-[9px] text-zinc-550 block mt-1 font-mono">Varies dynamically by category scale</span>
              </div>
            </div>

            {/* Bespoke Grand Heirloom */}
            <div className="p-8 bg-zinc-900/20 border border-white/5 rounded-3xl space-y-6 relative hover:border-white/10 transition-all">
              <div className="space-y-1">
                <span className="text-zinc-555 text-zinc-500 text-[9px] uppercase tracking-widest block font-bold">Category Line 03</span>
                <h3 className="text-xl font-bold text-white">GRAND HEIRLOOM BESPOKE</h3>
                <p className="text-zinc-400 text-xs font-light leading-relaxed">Fully customizable, bespoke multi-day visual assets, oil mural installations, or estate scale canvases.</p>
              </div>

              <div className="space-y-4 font-mono text-[10px] text-zinc-400 border-t border-white/5 pt-4">
                <div className="flex items-center gap-2"><Check className="h-4.5 w-4.5 text-amber-500 shrink-0" /> <span>Bespoke medium scale, oil paints or multi-panels</span></div>
                <div className="flex items-center gap-2"><Check className="h-4.5 w-4.5 text-amber-500 shrink-0" /> <span>Unlimited multi-day on-site artist participation</span></div>
                <div className="flex items-center gap-2"><Check className="h-4.5 w-4.5 text-amber-500 shrink-0" /> <span>Custom framing matching your interior style</span></div>
                <div className="flex items-center gap-2"><Check className="h-4.5 w-4.5 text-amber-500 shrink-0" /> <span>Signature Certificate of Authenticity</span></div>
                <div className="flex items-center gap-2"><Check className="h-4.5 w-4.5 text-amber-500 shrink-0" /> <span>Express secure travel & flight carriage logs</span></div>
              </div>

              <div className="pt-4 border-t border-white/5">
                <span className="text-[9px] uppercase text-zinc-500 block tracking-wider">Custom premium pricing</span>
                <p className="text-2xl font-serif font-black text-zinc-400 mt-1">Custom Quotes Available</p>
                <span className="text-[9px] text-zinc-600 block mt-1 font-mono">Detailed pricing assessment upon inquiry</span>
              </div>
            </div>
          </div>
        </div>

        {/* REVEAL INQUIRY FORM MODAL */}
        <AnimatePresence>
          {showInquiryModal && (
            <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="bg-zinc-950 border border-white/10 rounded-[2.5rem] max-w-lg w-full p-8 space-y-6 overflow-hidden relative shadow-2xl"
              >
                <div className="flex justify-between items-center border-b border-white/5 pb-4">
                  <div className="flex items-center gap-2">
                    <Mail className="h-4 w-4 text-amber-500" />
                    <h3 className="text-white text-sm font-bold uppercase tracking-wider font-mono">Bespoke Fine Art Inquiry</h3>
                  </div>
                  <button 
                    onClick={() => setShowInquiryModal(false)}
                    className="text-zinc-500 hover:text-white transition-colors font-mono uppercase text-[9px] tracking-wider cursor-pointer"
                  >
                    Close [x]
                  </button>
                </div>

                <form onSubmit={handleInquirySubmit} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-[8px] uppercase tracking-widest text-zinc-500 font-mono">Your Name</label>
                      <input 
                        type="text" 
                        required 
                        className="w-full bg-black/50 border border-white/10 rounded-xl py-3 px-3.5 text-xs text-white focus:outline-none focus:border-amber-500"
                        placeholder="Elizabeth Bennett"
                        value={customInquiry.name}
                        onChange={e => setCustomInquiry({...customInquiry, name: e.target.value})}
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[8px] uppercase tracking-widest text-zinc-500 font-mono">Email Address</label>
                      <input 
                        type="email" 
                        required 
                        className="w-full bg-black/50 border border-white/10 rounded-xl py-3 px-3.5 text-xs text-white focus:outline-none focus:border-amber-500"
                        placeholder="elizabeth@darcyestate.com"
                        value={customInquiry.email}
                        onChange={e => setCustomInquiry({...customInquiry, email: e.target.value})}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-[8px] uppercase tracking-widest text-zinc-500 font-mono">Phone Number</label>
                      <input 
                        type="tel" 
                        required 
                        className="w-full bg-black/50 border border-white/10 rounded-xl py-3 px-3.5 text-xs text-white focus:outline-none focus:border-amber-500"
                        placeholder="+91 XXXXX XXXXX"
                        value={customInquiry.phone}
                        onChange={e => setCustomInquiry({...customInquiry, phone: e.target.value})}
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[8px] uppercase tracking-widest text-zinc-500 font-mono">Preferred Size</label>
                      <input 
                        type="text" 
                        required 
                        className="w-full bg-black/50 border border-white/10 rounded-xl py-3 px-3.5 text-xs text-white focus:outline-none focus:border-amber-500"
                        placeholder="A3, A2 or Custom Size"
                        value={customInquiry.sizePreferred}
                        onChange={e => setCustomInquiry({...customInquiry, sizePreferred: e.target.value})}
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[8px] uppercase tracking-widest text-zinc-500 font-mono">Approx Budget (₹)</label>
                    <input 
                      type="text" 
                      className="w-full bg-black/50 border border-white/10 rounded-xl py-3 px-3.5 text-xs text-white focus:outline-none focus:border-amber-500"
                      placeholder="e.g. ₹15,000 to ₹25,000"
                      value={customInquiry.approxBudget}
                      onChange={e => setCustomInquiry({...customInquiry, approxBudget: e.target.value})}
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[8px] uppercase tracking-widest text-zinc-500 font-mono">Detailed Requirements & Aesthetic Mood</label>
                    <textarea 
                      required 
                      className="w-full bg-black/50 border border-white/10 rounded-xl py-3 px-3.5 text-xs text-white focus:outline-none focus:border-amber-500 font-light"
                      rows={4}
                      placeholder="Describe venue theme, wedding schedule, key individuals to paint, travel distance requirements..."
                      value={customInquiry.requirements}
                      onChange={e => setCustomInquiry({...customInquiry, requirements: e.target.value})}
                    />
                  </div>

                  <button 
                    type="submit" 
                    disabled={submittingInquiry}
                    className="w-full py-4 bg-amber-500 hover:bg-amber-400 text-black font-bold uppercase text-[10px] tracking-widest rounded-xl transition-all font-mono"
                  >
                    {submittingInquiry ? "transmitting secure details..." : "transmit quote inquiry"}
                  </button>
                </form>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

      </div>
    </div>
  );
}
