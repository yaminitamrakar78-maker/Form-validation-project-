import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import Navbar from './components/layout/Navbar';
import Footer from './components/layout/Footer';
import Home from './pages/Home';
import Services from './pages/Services';
import Gallery from './pages/Gallery';
import Booking from './pages/Booking';
import Contact from './pages/Contact';
import Dashboard from './pages/Dashboard';
import Admin from './pages/Admin';
import { Toaster } from 'react-hot-toast';
import { Loader2 } from 'lucide-react';
import AuthModal from './components/auth/AuthModal';

function PrivateRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="min-h-screen bg-black flex items-center justify-center"><Loader2 className="h-10 w-10 text-amber-500 animate-spin" /></div>;
  return user ? <>{children}</> : <Navigate to="/" />;
}

function AdminRoute({ children }: { children: React.ReactNode }) {
  const { isAdmin, loading } = useAuth();
  if (loading) return <div className="min-h-screen bg-black flex items-center justify-center"><Loader2 className="h-10 w-10 text-amber-500 animate-spin" /></div>;
  return isAdmin ? <>{children}</> : <Navigate to="/" />;
}

function AppContent() {
  return (
    <div className="flex flex-col min-h-screen bg-black font-sans selection:bg-amber-500 selection:text-black">
      <Toaster 
        position="top-right"
        toastOptions={{
          duration: 4000,
          className: 'premium-toast',
          style: {
            background: 'rgba(0, 0, 0, 0.8)',
            color: '#fff',
            backdropFilter: 'blur(12px)',
            border: '1px solid rgba(245, 158, 11, 0.2)',
            padding: '16px 24px',
            borderRadius: '1.25rem',
            fontSize: '11px',
            textTransform: 'uppercase',
            letterSpacing: '0.15em',
            fontWeight: '700',
            boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.5), 0 10px 10px -5px rgba(0, 0, 0, 0.4)',
          },
          success: {
            iconTheme: {
              primary: '#f59e0b',
              secondary: '#111',
            },
          },
          error: {
            iconTheme: {
              primary: '#ef4444',
              secondary: '#111',
            },
            style: {
              border: '1px solid rgba(239, 68, 68, 0.2)',
            }
          }
        }}
      />
      <AuthModal />
      <Navbar />
      <main className="flex-grow">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/services" element={<Services />} />
          <Route path="/gallery" element={<Gallery />} />
          <Route path="/booking" element={<Booking />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/dashboard" element={<PrivateRoute><Dashboard /></PrivateRoute>} />
          <Route path="/admin" element={<AdminRoute><Admin /></AdminRoute>} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <AppContent />
      </Router>
    </AuthProvider>
  );
}
