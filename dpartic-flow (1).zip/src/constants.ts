import { ArtService } from './types';

export const ART_SERVICES: ArtService[] = [
  {
    id: 'wedding-paintings',
    title: 'Wedding Paintings',
    description: 'Bespoke live painting of your wedding, capturing the holy atmosphere and joyous union on canvas in real-time.',
    price: 35000,
    image: '',
    category: 'Wedding Paintings',
    isActive: true
  },
  {
    id: 'temporary-tattoo-art',
    title: 'Temporary Tattoo Art',
    description: 'Pain-free, premium body art featuring custom temporary designs crafted carefully by live artists.',
    price: 15000,
    image: '',
    category: 'Temporary Tattoo Art',
    isActive: true
  },
  {
    id: 'live-sketches',
    title: 'Live Sketches',
    description: 'Fast, graceful, and highly detailed live hand sketches captured during your special occasion.',
    price: 12000,
    image: '',
    category: 'Live Sketches',
    isActive: true
  },
  {
    id: 'live-caricature',
    title: 'Live Caricature',
    description: 'Humorous, vibrant, and fun-filled live cartoon portraits to engage your guests and generate endless laughter.',
    price: 10000,
    image: '',
    category: 'Live Caricature',
    isActive: true
  },
  {
    id: 'live-doodle-art',
    title: 'Live Doodle Art',
    description: 'Modern live doodles created interactively, inspired by your event theme and guests reactions.',
    price: 8000,
    image: '',
    category: 'Live Doodle Art',
    isActive: true
  },
  {
    id: 'live-mandap-painting',
    title: 'Live Mandap Painting',
    description: 'Exquisite, spiritual live oil-acrylic art of the sacred marriage altar and rituals as they unfold.',
    price: 25000,
    image: '',
    category: 'Live Mandap Painting',
    isActive: true
  },
  {
    id: 'magical-portrait',
    title: 'Magical Portrait',
    description: 'Breathtaking reveal style portraits using metallic dust, stickers, or turmeric - a true crowd favorite.',
    price: 20000,
    image: '',
    category: 'Magical Portrait',
    isActive: true
  },
  {
    id: 'clay-art',
    title: 'Clay Art',
    description: 'Live sculpture modeling and tactile clay session hosting that thrills both adult and child guests alike.',
    price: 12000,
    image: '',
    category: 'Clay Art',
    isActive: true
  },
  {
    id: 'pottery-art',
    title: 'Pottery Art',
    description: 'Mesmerizing porter\'s wheel live display featuring active guest participation and immediate souvenirs.',
    price: 15000,
    image: '',
    category: 'Pottery Art',
    isActive: true
  }
];
