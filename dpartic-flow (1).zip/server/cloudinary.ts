import { v2 as cloudinary } from 'cloudinary';
import { Readable } from 'stream';
import fs from 'fs';
import path from 'path';

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME || 'artflow_placeholder_cloud',
  api_key: process.env.CLOUDINARY_API_KEY || 'artflow_placeholder_key',
  api_secret: process.env.CLOUDINARY_API_SECRET || 'artflow_placeholder_secret',
  secure: true
});

export { cloudinary };

/**
 * Uploads a file buffer directly to Cloudinary.
 * Bypasses local disc and handles images or videos efficiently.
 * Generates secure media URLs.
 */
export function uploadBufferToCloudinary(
  fileBuffer: Buffer, 
  folder: string, 
  resourceType: 'image' | 'video' | 'auto' = 'auto'
): Promise<{ secure_url: string; public_id: string; duration?: number }> {
  return new Promise((resolve, reject) => {
    // If credentials are empty or placeholders, fallback gracefully with a mock link so the flow still works flawlessly in demo
    const isMock = !process.env.CLOUDINARY_CLOUD_NAME || 
                   !process.env.CLOUDINARY_API_KEY || 
                   !process.env.CLOUDINARY_API_SECRET ||
                   process.env.CLOUDINARY_CLOUD_NAME.includes("placeholder") ||
                   process.env.CLOUDINARY_API_KEY.includes("placeholder");

    if (isMock) {
      console.warn("WARNING: Cloudinary credentials are mock or missing. Emulating successful upload via demo placeholder assets.");
      
      let mockUrl = "https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?q=80&w=1000";
      if (resourceType === 'video' || folder === 'hero') {
        mockUrl = "https://images.unsplash.com/photo-1460661419201-fd4cecdf8a8b?q=80&w=1000";
      } else if (folder === 'services') {
        mockUrl = "https://images.unsplash.com/photo-1513364776144-60967b0f800f?q=80&w=1000";
      } else if (folder === 'gallery') {
        mockUrl = "https://images.unsplash.com/photo-1541701494587-cb58502866ab?q=80&w=1000";
      }

      return resolve({
        secure_url: mockUrl,
        public_id: "placeholder_id",
        duration: resourceType === 'video' ? 12 : undefined
      });
    }

    const options = {
      folder,
      resource_type: 'auto' as const
    };

    // Use upload_chunked_stream for video or files starting with large sizes to ensure high reliability
    const isVideoOrLarge = resourceType === 'video' || (fileBuffer.length > 5 * 1024 * 1024);
    
    const handleResponse = (error: any, result: any) => {
      if (error) {
        console.error("Cloudinary upload error:", error);
        try {
          fs.appendFileSync(
            path.join(process.cwd(), 'cloudinary_error.log'),
            `[${new Date().toISOString()}] Folder: ${folder}, ResourceType: ${resourceType}, Error: ${JSON.stringify(error, null, 2)}\nStack: ${error.stack}\n\n`
          );
        } catch (e) {
          console.error("Failed to write to cloudinary_error.log", e);
        }
        return reject(error);
      }
      if (!result) {
        return reject(new Error("Cloudinary returned a null result"));
      }
      resolve({
        secure_url: result.secure_url,
        public_id: result.public_id,
        duration: result.duration
      });
    };

    const uploadStream = isVideoOrLarge
      ? cloudinary.uploader.upload_chunked_stream(
          { ...options, chunk_size: 6000000 },
          handleResponse
        )
      : cloudinary.uploader.upload_stream(
          options,
          handleResponse
        );

    const stream = new Readable();
    stream.push(fileBuffer);
    stream.push(null);
    stream.pipe(uploadStream);
  });
}
