import nodemailer from "nodemailer";

interface BookingEmailData {
  id: string;
  userEmail: string;
  userName: string;
  userPhone: string;
  date: string;
  timing: string;
  location: string;
  requirements?: string;
  artCategory: string;
  amount: number;
  createdAt: string;
  status?: string;
}

/**
 * Returns a configured Nodemailer Transporter or null if SMTP is not set up.
 */
function getTransporter() {
  const host = process.env.SMTP_HOST;
  const port = process.env.SMTP_PORT ? parseInt(process.env.SMTP_PORT, 10) : 587;
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;

  if (!host || !user || !pass) {
    return null;
  }

  return nodemailer.createTransport({
    host,
    port,
    secure: port === 465,
    auth: {
      user,
      pass,
    },
  });
}

function formatEventDate(dateStr: string): string {
  try {
    const dateObj = new Date(dateStr);
    if (!isNaN(dateObj.getTime())) {
      return dateObj.toLocaleDateString("en-US", {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
      });
    }
  } catch (e) {
    // Return raw
  }
  return dateStr;
}

function formatINR(amount: number): string {
  const formatter = new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  });
  return formatter.format(amount);
}

/**
 * HTML Shell to keep the luxury brand cohesive across all updates.
 */
function wrapEmailTemplate(contentHtml: string) {
  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>DPartic Flow Atelier</title>
  <style>
    body {
      font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
      background-color: #050505;
      color: #e4e4e7;
      margin: 0;
      padding: 0;
      -webkit-font-smoothing: antialiased;
    }
    .wrapper {
      width: 100%;
      background-color: #050505;
      padding: 40px 0;
    }
    .container {
      max-width: 600px;
      margin: 0 auto;
      background-color: #0c0c0e;
      border: 1px solid #1f1f23;
      border-radius: 24px;
      overflow: hidden;
      box-shadow: 0 20px 40px rgba(0,0,0,0.5);
    }
    .header {
      background-color: #0c0c0e;
      padding: 40px 32px 24px 32px;
      text-align: center;
      border-bottom: 1px solid #1a1a1e;
    }
    .logo-badge {
      color: #f59e0b;
      font-size: 11px;
      text-transform: uppercase;
      letter-spacing: 0.3em;
      margin-bottom: 8px;
      display: block;
      font-weight: 700;
    }
    .title {
      font-family: Georgia, serif;
      color: #ffffff;
      font-size: 26px;
      font-weight: normal;
      margin: 0;
      letter-spacing: -0.01em;
    }
    .body {
      padding: 36px 32px;
    }
    .greeting {
      font-size: 15px;
      line-height: 1.6;
      color: #e4e4e7;
      margin-bottom: 24px;
      font-weight: 300;
    }
    .booking-summary {
      background-color: #121215;
      border: 1px solid #222226;
      border-radius: 16px;
      padding: 24px;
      margin-bottom: 28px;
    }
    .summary-heading {
      color: #f59e0b;
      font-size: 11px;
      text-transform: uppercase;
      font-weight: bold;
      letter-spacing: 0.15em;
      margin-top: 0;
      margin-bottom: 16px;
    }
    .summary-row {
      display: table;
      width: 100%;
      margin-bottom: 10px;
    }
    .summary-label {
      display: table-cell;
      width: 35%;
      font-size: 11px;
      text-transform: uppercase;
      font-weight: bold;
      letter-spacing: 0.05em;
      color: #71717a;
    }
    .summary-val {
      display: table-cell;
      width: 65%;
      font-size: 13px;
      color: #f4f4f5;
    }
    .status-badge {
      display: inline-block;
      padding: 4px 12px;
      border-radius: 99px;
      font-size: 10px;
      font-weight: bold;
      text-transform: uppercase;
      letter-spacing: 0.1em;
    }
    .status-pending { background-color: rgba(245,158,11,0.1); color: #f59e0b; border: 1px solid rgba(245,158,11,0.2); }
    .status-accepted { background-color: rgba(16,185,129,0.1); color: #10b981; border: 1px solid rgba(16,185,129,0.2); }
    .status-in_progress { background-color: rgba(59,130,246,0.1); color: #3b82f6; border: 1px solid rgba(59,130,246,0.2); }
    .status-completed { background-color: rgba(167,139,250,0.1); color: #a78bfa; border: 1px solid rgba(167,139,250,0.2); }
    .status-cancelled { background-color: rgba(239,68,68,0.1); color: #ef4444; border: 1px solid rgba(239,68,68,0.2); }

    .divider {
      height: 1px;
      background-color: #1f1f23;
      margin: 28px 0;
    }
    .bio-section {
      background-color: #141416;
      border-radius: 20px;
      border: 1px dashed #303036;
      padding: 24px;
      margin-bottom: 24px;
    }
    .bio-title-badge {
      color: #f59e0b;
      font-size: 10px;
      text-transform: uppercase;
      font-weight: bold;
      letter-spacing: 0.2em;
      margin-bottom: 4px;
      display: block;
    }
    .bio-name {
      font-family: Georgia, serif;
      color: #ffffff;
      font-size: 18px;
      margin: 0 0 12px 0;
    }
    .bio-text {
      font-size: 12px;
      line-height: 1.6;
      color: #a1a1aa;
      margin: 0;
      font-weight: 300;
    }
    .button-container {
      text-align: center;
      margin: 28px 0;
    }
    .portfolio-button {
      display: inline-block;
      background-color: #f59e0b;
      color: #000000;
      text-decoration: none;
      padding: 14px 28px;
      border-radius: 12px;
      font-size: 12px;
      font-weight: bold;
      text-transform: uppercase;
      letter-spacing: 0.15em;
    }
    .footer {
      background-color: #0a0a0c;
      padding: 28px;
      text-align: center;
      font-size: 10px;
      color: #52525b;
      border-top: 1px solid #1a1a1e;
    }
    .signature {
      font-family: Georgia, serif;
      color: #ffffff;
      font-style: italic;
      font-size: 15px;
      margin-top: 24px;
    }
  </style>
</head>
<body>
  <div class="wrapper">
    <div class="container">
      ${contentHtml}
    </div>
  </div>
</body>
</html>
  `;
}

/**
 * Sends a professional booking confirmation email using nodemailer.
 */
export async function sendBookingConfirmationEmail(booking: BookingEmailData) {
  const portfolioUrl = process.env.APP_URL || "https://dparticflow.com";
  const fromEmail = process.env.SMTP_FROM_EMAIL || "DPartic Flow Studio <studio@dparticflow.com>";
  const formattedDate = formatEventDate(booking.date);
  const formattedAmount = formatINR(booking.amount);

  const htmlContent = wrapEmailTemplate(`
    <!-- Brand Header -->
    <div class="header">
      <span class="logo-badge">✦ DPartic Flow Atelier</span>
      <h1 class="title">Bespoke Fine Art Commission Created</h1>
    </div>
    
    <!-- Content Body -->
    <div class="body">
      <p class="greeting">
        Dear ${booking.userName},
      </p>
      <p class="greeting">
        Thank you for commissioning an direct live masterwork with <strong>DPartic Flow</strong>. We have successfully registered your booking and initiated the artistic prep work for your upcoming celebration. Inside this manifest, you will find your primary event summary, the academic identity behind your canvas, and a connection to our active portfolio.
      </p>
      
      <!-- Booking details table block -->
      <div class="booking-summary">
        <h3 class="summary-heading">Event Manifest</h3>
        
        <div class="summary-row">
          <div class="summary-label">Masterwork</div>
          <div class="summary-val" style="font-weight: bold; color: #ffffff;">${booking.artCategory.replace(/-/g, ' ')}</div>
        </div>
        
        <div class="summary-row">
          <div class="summary-label">Event Date</div>
          <div class="summary-val">${formattedDate}</div>
        </div>
        
        <div class="summary-row">
          <div class="summary-label">Event Timing</div>
          <div class="summary-val">${booking.timing}</div>
        </div>
        
        <div class="summary-row">
          <div class="summary-label">Grand Venue</div>
          <div class="summary-val">${booking.location}</div>
        </div>
        
        ${booking.requirements ? `
        <div class="summary-row">
          <div class="summary-label">Requirements</div>
          <div class="summary-val" style="font-style: italic; font-size: 11px; color: #a1a1aa;">${booking.requirements}</div>
        </div>
        ` : ''}
        
        <div class="summary-row">
          <div class="summary-label">Commission Status</div>
          <div class="summary-val">
            <span class="status-badge status-pending">Pending Approval</span>
          </div>
        </div>

        <div class="summary-row" style="margin-top: 16px; padding-top: 12px; border-top: 1px solid #222226;">
          <div class="summary-label" style="color: #a1a1aa;">Paid Retainer</div>
          <div class="summary-val" style="color: #f59e0b; font-size: 15px; font-weight: bold;">${formattedAmount} INR</div>
        </div>
      </div>

      <div class="divider"></div>

      <!-- Professional Artist Bio Section -->
      <div class="bio-section">
        <span class="bio-title-badge">Post Graduate Artist Profile</span>
        <h3 class="bio-name">Deepak Prajapati</h3>
        <p class="bio-text">
          Deepak Prajapati is an acclaimed professional fine artist who completed his post-graduation (Master of Fine Arts) from the nationally renowned <strong>Indira Kala Sangeet Vishwavidyalaya</strong> (Khairagarh) — Asia's premier university fully dedicated to fine arts and classical aesthetics.
        </p>
        <p class="bio-text" style="margin-top: 10px;">
          With a profound background in pure anatomical accuracy, pigment chemistry, and fluid real-time lighting studies, Deepak brings classical academic craftsmanship to high-pressure live environments, preserving your grandest life chapters onto archival Belgian linen.
        </p>
      </div>

      <!-- Button Link to Active Portfolio -->
      <div class="button-container">
        <a href="${portfolioUrl}/gallery" class="portfolio-button" style="background-color: #f59e0b; color: #000000; text-decoration: none; padding: 14px 28px; border-radius: 12px; font-size: 12px; font-weight: bold; text-transform: uppercase; letter-spacing: 0.15em; display: inline-block;" target="_blank">Explore Full Portfolio</a>
      </div>

      <p class="greeting" style="margin-top: 32px;">
        Our private studio and concierge desk will review your bespoke specifications and reach out via Phone and WhatsApp shortly.
      </p>

      <p class="signature">
        Warmest regards,<br />
        <span style="color: #f59e0b; font-weight: bold; font-family: Georgia, serif; font-size: 17px; display: block; margin-top: 6px;">Deepak Prajapati</span>
        <span style="font-size: 10px; font-family: monospace; text-transform: uppercase; letter-spacing: 0.1em; color: #71717a;">Founder & Principal Artist, DPartic Flow</span>
      </p>
    </div>

    <!-- Footer Info -->
    <div class="footer">
      <p>© 2026 DPartic Flow Atelier. All rights reserved.</p>
      <p>Commission Reference ID: ${booking.id}</p>
      <p style="margin-top: 12px;">This email is an official confirmation of high-end commission services. To reschedule or address tailored details, text the studio desk directly at +91 91310 51376.</p>
    </div>
  `);

  const textContent = `
DPartic Flow Atelier — Your Fine Art Commission Confirmed

Dear ${booking.userName},

Thank you for commissioning a direct live masterpieces with DPartic Flow. We have successfully registered your booking.

--- EVENT MANIFEST ---
Masterwork: ${booking.artCategory.replace(/-/g, ' ')}
Event Date: ${formattedDate}
Event Timing: ${booking.timing}
Grand Venue: ${booking.location}
Amount Retained: ${formattedAmount} INR
Commission ID: ${booking.id}

--- ARTIST BIO ---
Deepak Prajapati is an acclaimed professional fine artist who completed his post-graduation (M.F.A.) from the prestigious Indira Kala Sangeet Vishwavidyalaya. With classical academic discipline, Deepak translates spatial lighting and anatomical rendering into real-time living history on Belgian linen.

Explore Deepak's Complete Portfolio at: ${portfolioUrl}/gallery

Our concierge desk will review details and reach out on WhatsApp shortly.

Warmest regards,
Deepak Prajapati
Founder & Principal Artist, DPartic Flow
  `;

  await deliverEmail(booking.userEmail, `✦ Your Art Commission Confirmation — DPartic Flow [Ref: ${booking.id}]`, textContent, htmlContent);
}

/**
 * Notify the customer about manual or automatic booking status updates (Accepted, In Progress, Completed, Cancelled).
 */
export async function sendCustomerStatusUpdateEmail(booking: BookingEmailData, note?: string) {
  const portfolioUrl = process.env.APP_URL || "https://dparticflow.com";
  const statusLabels: Record<string, string> = {
    pending: "Under Studio Review",
    accepted: "Accepted & Confirmed by Studio",
    in_progress: "In Creative Preparation / Production",
    completed: "Masterwork Fully Completed & Delivered",
    cancelled: "Cancelled / Postponed"
  };

  const statusDescriptions: Record<string, string> = {
    pending: "Your booking is currently being reviewed by Deepak for venue logistics and sketch layouts.",
    accepted: "Deepak has reviewed and officially accepted your grand live art commission! Preparations of the linen support and bespoke acrylic mediums are underway.",
    in_progress: "Deepak is currently in the active creative execution or production phase of your commission. We are preparing the colors and setting up lighting presets.",
    completed: "Deepak has completed your live masterpiece! The canvas is ready for direct presentation or is already packaged securely with absolute archival safety measures.",
    cancelled: "Your art commission schedule has been cancelled or postponed. If this was an accident, or you need to reschedule immediately, please reach out to our desk."
  };

  const currentStatus = booking.status || "pending";
  const badgeClass = `status-${currentStatus}`;
  const statusHeading = statusLabels[currentStatus] || currentStatus.toUpperCase();
  const statusText = statusDescriptions[currentStatus] || "The schedule details have been updated by the lead artist.";
  const formattedDate = formatEventDate(booking.date);

  const htmlContent = wrapEmailTemplate(`
    <div class="header">
      <span class="logo-badge">✦ Studio Update Alert</span>
      <h1 class="title">Commission Status: <span style="color:#f59e0b; font-style:italic;">${currentStatus.replace(/_/g, ' ')}</span></h1>
    </div>

    <div class="body">
      <p class="greeting">Dear ${booking.userName},</p>
      
      <p class="greeting">
        We are reaching out to inform you of an official status change on your luxury fine art booking with <strong>DPartic Flow</strong>. Deepak Prajapati has updated your reservation details.
      </p>

      <div class="booking-summary" style="border: 1px solid rgba(245,158,11,0.2);">
        <h3 class="summary-heading">New Scheduling Summary</h3>
        
        <div class="summary-row">
          <div class="summary-label">Masterwork</div>
          <div class="summary-val" style="font-weight: bold; color: #ffffff;">${booking.artCategory.replace(/-/g, ' ')}</div>
        </div>

        <div class="summary-row">
          <div class="summary-label">Scheduled Date</div>
          <div class="summary-val">${formattedDate}</div>
        </div>

        <div class="summary-row">
          <div class="summary-label">Time Window</div>
          <div class="summary-val">${booking.timing}</div>
        </div>

        <div class="summary-row">
          <div class="summary-label">Current Status</div>
          <div class="summary-val">
            <span class="status-badge ${badgeClass}">${statusHeading}</span>
          </div>
        </div>

        ${note ? `
        <div class="divider" style="margin: 16px 0; background-color: #222226;"></div>
        <div class="summary-row">
          <div class="summary-label" style="color: #f59e0b;">Artist Note</div>
          <div class="summary-val" style="color: #ffffff; font-style: italic; font-size: 13px;">"${note}"</div>
        </div>
        ` : ""}
      </div>

      <div class="bio-section">
        <span class="bio-title-badge">What this means</span>
        <h3 class="bio-name" style="font-size: 15px; color: #ffffff;">Status Detail</h3>
        <p class="bio-text">${statusText}</p>
        <p class="bio-text" style="margin-top: 10px; font-size: 11px;">You can track real-time visual progress or download calendar sync elements direct from your private customer dashboard.</p>
      </div>

      <div class="button-container">
        <a href="${portfolioUrl}/dashboard" class="portfolio-button" style="background-color: #f59e0b; color: #000000; text-decoration: none; padding: 14px 28px; border-radius: 12px; font-size: 12px; font-weight: bold; text-transform: uppercase; letter-spacing: 0.15em; display: inline-block;">Go To Dashboard</a>
      </div>

      <p class="greeting">If you have tailored questions or wish to share immediate visual references, please contact our studio coordinate team.</p>

      <p class="signature">
        Warmest regards,<br />
        <span style="color: #f59e0b; font-weight: bold; font-family: Georgia, serif; font-size: 17px; display: block; margin-top: 6px;">Deepak Prajapati</span>
        <span style="font-size: 10px; font-family: monospace; text-transform: uppercase; letter-spacing: 0.1em; color: #71717a;">Lead Artist & Founder, DPartic Flow</span>
      </p>
    </div>

    <div class="footer">
      <p>© 2026 DPartic Flow Atelier. All rights reserved.</p>
      <p>Booking ID: ${booking.id}</p>
      <p style="margin-top: 10px;">Concierge: +91 91310 51376 | kalavantdeepak1712@gmail.com</p>
    </div>
  `);

  const textContent = `
DPartic Flow Atelier — Commission Status Updated: ${statusHeading.toUpperCase()}

Dear ${booking.userName},

We want to inform you that your booking status has been officially updated to: ${statusHeading}.

Event details:
- Masterwork: ${booking.artCategory.replace(/-/g, ' ')}
- Date: ${formattedDate}
- Time Window: ${booking.timing}
- Venue: ${booking.location}

Message from Artist: ${note ? `"${note}"` : "None"}

Please check your private customer dashboard for live tracking details: ${portfolioUrl}/dashboard

Warmest regards,
Deepak Prajapati
Lead Artist, DPartic Flow
  `;

  await deliverEmail(booking.userEmail, `✦ Commission Status Update — ${statusHeading} — DPartic Flow`, textContent, htmlContent);
}

/**
 * Send an email notification directly to Deepak (the admin) whenever a booking is placed or updated.
 */
export async function sendAdminNewBookingNotificationEmail(booking: BookingEmailData) {
  const adminEmail = process.env.SMTP_USER || "kalavantdeepak1712@gmail.com";
  const formattedDate = formatEventDate(booking.date);
  const formattedAmount = formatINR(booking.amount);

  const htmlContent = wrapEmailTemplate(`
    <div class="header">
      <span class="logo-badge" style="color: #ff5a5f;">✦ Admin Action Required</span>
      <h1 class="title">New Live Masterwork Order Placed!</h1>
    </div>

    <div class="body">
      <p class="greeting">Hey Deepak,</p>
      
      <p class="greeting">
        A new bespoke live masterpiece reservation has been successfully booked and paid for by a client. Please review the details below, confirm venue availability, and log into your control center to accept or reschedule the date.
      </p>

      <div class="booking-summary" style="background-color: #1a1a1f; border-color: #d1a15c;">
        <h3 class="summary-heading" style="color: #ff9100;">Client Manifest & Location</h3>
        
        <div class="summary-row">
          <div class="summary-label" style="color: #a1a1aa;">Client Name</div>
          <div class="summary-val" style="font-weight: bold; color: #fff;">${booking.userName}</div>
        </div>

        <div class="summary-row">
          <div class="summary-label" style="color: #a1a1aa;">Email IP</div>
          <div class="summary-val">${booking.userEmail}</div>
        </div>

        <div class="summary-row">
          <div class="summary-label" style="color: #a1a1aa;">Phone / WhatsApp</div>
          <div class="summary-val" style="color: #a78bfa; font-weight: bold;">${booking.userPhone}</div>
        </div>

        <div class="summary-row">
          <div class="summary-label" style="color: #a1a1aa;">Masterwork</div>
          <div class="summary-val" style="color: #f59e0b; font-weight: bold;">${booking.artCategory.replace(/-/g, ' ')}</div>
        </div>

        <div class="summary-row">
          <div class="summary-label" style="color: #a1a1aa;">Target Date</div>
          <div class="summary-val">${formattedDate}</div>
        </div>

        <div class="summary-row">
          <div class="summary-label" style="color: #a1a1aa;">Time Slot</div>
          <div class="summary-val">${booking.timing}</div>
        </div>

        <div class="summary-row">
          <div class="summary-label" style="color: #a1a1aa;">Grand Venue</div>
          <div class="summary-val">${booking.location}</div>
        </div>

        ${booking.requirements ? `
        <div class="summary-row">
          <div class="summary-label" style="color: #a1a1aa;">Client Notes</div>
          <div class="summary-val" style="font-style: italic; font-size: 11px; color: #e4e4e7;">"${booking.requirements}"</div>
        </div>
        ` : ""}

        <div class="summary-row" style="margin-top: 16px; padding-top: 12px; border-top: 1px solid #333;">
          <div class="summary-label" style="color: #a1a1aa;">Retainer Settled</div>
          <div class="summary-val" style="color: #10b981; font-size: 14px; font-weight: bold;">${formattedAmount} INR (Paid)</div>
        </div>
      </div>

      <p class="greeting">To prevent double-bookings or conflicting schedules, complete the approval protocol on the administrative grid.</p>

      <div class="button-container">
        <a href="${process.env.APP_URL || 'https://dparticflow.com'}/admin" class="portfolio-button" style="background-color: #f59e0b; color: #000000; text-decoration: none; padding: 14px 28px; border-radius: 12px; font-size: 12px; font-weight: bold; text-transform: uppercase; letter-spacing: 0.15em; display: inline-block;">Go To Admin Panel</a>
      </div>
    </div>

    <div class="footer">
      <p>© 2026 DPartic Flow Automation. System Logs.</p>
      <p>Booking ID: ${booking.id}</p>
    </div>
  `);

  const textContent = `
Hey Deepak,

A new live fine art commission has been placed!

Client details:
- Name: ${booking.userName}
- Phone: ${booking.userPhone}
- Email: ${booking.userEmail}
- Service: ${booking.artCategory.replace(/-/g, ' ')}
- Date: ${formattedDate}
- Venue: ${booking.location}
- Retainer Received: ${formattedAmount} INR (Paid)

Access control center immediately to manage/approve:
${process.env.APP_URL || 'https://dparticflow.com'}/admin
  `;

  await deliverEmail(adminEmail, `🚨 [NEW COMMISSION] ${booking.userName} booked ${booking.artCategory.replace(/-/g, ' ')}`, textContent, htmlContent);
}

/**
 * Generalized internal helper to coordinate nodemailer delivery or simulation logging
 */
async function deliverEmail(to: string, subject: string, text: string, html: string) {
  const fromEmail = process.env.SMTP_FROM_EMAIL || "DPartic Flow Studio <studio@dparticflow.com>";
  const transporter = getTransporter();

  if (transporter) {
    try {
      console.log(`[SMTP SENDER]: Attempting to send structured email to: ${to}`);
      const info = await transporter.sendMail({
        from: fromEmail,
        to,
        subject,
        text,
        html,
      });
      console.log(`[SMTP SENDER]: Email sent successfully. MessageId: ${info.messageId}`);
    } catch (err) {
      console.error("[SMTP SENDER] Error during SMTP transmit:", err);
    }
  } else {
    console.log(`
========================================================================
[EMAIL SENDER SIMULATION] - SMTP credentials not configured.
------------------------------------------------------------------------
To: ${to}
From: ${fromEmail}
Subject: ${subject}
------------------------------------------------------------------------
${text}
========================================================================
    `);
  }
}
