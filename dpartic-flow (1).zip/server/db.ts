import { MongoClient, Db, ObjectId } from 'mongodb';
import * as dotenv from 'dotenv';

dotenv.config();

let client: MongoClient | null = null;
let db: Db | null = null;
let useFallback = false;
let mockDbInstance: any = null;

const DEFAULT_SERVICES = [
  {
    id: 'wedding-paintings',
    title: 'Wedding Paintings',
    description: 'Bespoke live painting of your wedding, capturing the holy atmosphere and joyous union on canvas in real-time.',
    price: 35000,
    image: '',
    category: 'Wedding Paintings',
    isActive: true
  },
  {
    id: 'temporary-tattoo-art',
    title: 'Temporary Tattoo Art',
    description: 'Pain-free, premium body art featuring custom temporary designs crafted carefully by live artists.',
    price: 15000,
    image: '',
    category: 'Temporary Tattoo Art',
    isActive: true
  },
  {
    id: 'live-sketches',
    title: 'Live Sketches',
    description: 'Fast, graceful, and highly detailed live hand sketches captured during your special occasion.',
    price: 12000,
    image: '',
    category: 'Live Sketches',
    isActive: true
  },
  {
    id: 'live-caricature',
    title: 'Live Caricature',
    description: 'Humorous, vibrant, and fun-filled live cartoon portraits to engage your guests and generate endless laughter.',
    price: 10000,
    image: '',
    category: 'Live Caricature',
    isActive: true
  },
  {
    id: 'live-doodle-art',
    title: 'Live Doodle Art',
    description: 'Modern live doodles created interactively, inspired by your event theme and guests reactions.',
    price: 8000,
    image: '',
    category: 'Live Doodle Art',
    isActive: true
  },
  {
    id: 'live-mandap-painting',
    title: 'Live Mandap Painting',
    description: 'Exquisite, spiritual live oil-acrylic art of the sacred marriage altar and rituals as they unfold.',
    price: 25000,
    image: '',
    category: 'Live Mandap Painting',
    isActive: true
  },
  {
    id: 'magical-portrait',
    title: 'Magical Portrait',
    description: 'Breathtaking reveal style portraits using metallic dust, stickers, or turmeric - a true crowd favorite.',
    price: 20000,
    image: '',
    category: 'Magical Portrait',
    isActive: true
  },
  {
    id: 'clay-art',
    title: 'Clay Art',
    description: 'Live sculpture modeling and tactile clay session hosting that thrills both adult and child guests alike.',
    price: 12000,
    image: '',
    category: 'Clay Art',
    isActive: true
  },
  {
    id: 'pottery-art',
    title: 'Pottery Art',
    description: 'Mesmerizing potter\'s wheel live display featuring active guest participation and immediate souvenirs.',
    price: 15000,
    image: '',
    category: 'Pottery Art',
    isActive: true
  }
];

class MockCollection {
  name: string;
  data: any[];

  constructor(name: string, initialData: any[] = []) {
    this.name = name;
    this.data = initialData;
  }

  find(query: any = {}) {
    let filtered = [...this.data];
    if (query && Object.keys(query).length > 0) {
      filtered = filtered.filter(item => {
        for (const key in query) {
          const val = query[key];
          if (key === '_id') {
            const targetId = val?.toString ? val.toString() : val;
            const itemId = item._id?.toString ? item._id.toString() : item._id;
            if (itemId !== targetId) return false;
            continue;
          }
          if (item[key] !== val) return false;
        }
        return true;
      });
    }

    const chain = {
      sort: (sortSpec: any) => {
        const sortKeys = Object.keys(sortSpec);
        if (sortKeys.length > 0) {
          const sortKey = sortKeys[0];
          const direction = sortSpec[sortKey];
          filtered.sort((a, b) => {
            const valA = a[sortKey];
            const valB = b[sortKey];
            if (valA === undefined || valB === undefined) return 0;
            if (valA < valB) return direction === -1 ? 1 : -1;
            if (valA > valB) return direction === -1 ? -1 : 1;
            return 0;
          });
        }
        return chain;
      },
      toArray: async () => {
        return filtered;
      }
    };
    return chain;
  }

  async findOne(query: any = {}, options: any = {}) {
    const list = await this.find(query).sort(options?.sort || {}).toArray();
    return list[0] || null;
  }

  async insertOne(doc: any) {
    const newDoc = {
      _id: doc._id || new ObjectId().toString(),
      ...doc
    };
    this.data.push(newDoc);
    return {
      insertedId: newDoc._id,
      acknowledged: true
    };
  }

  async insertMany(docs: any[]) {
    const results = docs.map(doc => ({
      _id: doc._id || new ObjectId().toString(),
      ...doc
    }));
    this.data.push(...results);
    return {
      insertedIds: results.map(r => r._id),
      acknowledged: true
    };
  }

  async updateOne(query: any, update: any, options: any = {}) {
    let item = await this.findOne(query);
    if (!item && options.upsert) {
      item = { _id: query._id || new ObjectId().toString() };
      this.data.push(item);
    }
    if (item) {
      if (update.$set) {
        Object.assign(item, update.$set);
      }
      return { modifiedCount: 1, matchedCount: 1, acknowledged: true };
    }
    return { modifiedCount: 0, matchedCount: 0, acknowledged: true };
  }

  async updateMany(query: any, update: any) {
    const items = await this.find(query).toArray();
    let modifiedCount = 0;
    for (const item of items) {
      if (update.$set) {
        Object.assign(item, update.$set);
        modifiedCount++;
      }
    }
    return { modifiedCount, acknowledged: true };
  }

  async deleteOne(query: any) {
    const index = this.data.findIndex((item) => {
      for (const key in query) {
        const val = query[key];
        if (key === '_id') {
          const targetId = val?.toString ? val.toString() : val;
          const itemId = item._id?.toString ? item._id.toString() : item._id;
          if (itemId !== targetId) return false;
          continue;
        }
        if (item[key] !== val) return false;
      }
      return true;
    });
    if (index !== -1) {
      this.data.splice(index, 1);
      return { deletedCount: 1, acknowledged: true };
    }
    return { deletedCount: 0, acknowledged: true };
  }

  async deleteMany(query: any = {}) {
    if (Object.keys(query).length === 0) {
      const count = this.data.length;
      this.data = [];
      return { deletedCount: count, acknowledged: true };
    }
    const initialLength = this.data.length;
    this.data = this.data.filter(item => {
      for (const key in query) {
        const val = query[key];
        if (item[key] !== val) return true;
      }
      return false;
    });
    return { deletedCount: initialLength - this.data.length, acknowledged: true };
  }
}

class MockDb {
  collections: Record<string, MockCollection> = {};

  constructor() {
    this.collections['services'] = new MockCollection('services', [...DEFAULT_SERVICES]);
    this.collections['gallery'] = new MockCollection('gallery', [
      {
        _id: 'mock-gal-1',
        title: 'Celestial Wedding Mandala',
        description: 'Exquisite body art tattoo design featuring graceful geometric patterns crafted live for the bridal celebration.',
        category: 'Temporary Tattoo Art',
        mediaUrl: 'https://images.unsplash.com/photo-1511795409834-ef04bbd61622?auto=format&fit=crop&w=800&q=80',
        mediaType: 'image',
        createdAt: new Date().toISOString()
      },
      {
        _id: 'mock-gal-2',
        title: 'Modern Altar Caricature',
        description: 'Vibrant, lovely cartoon portraits custom created in real-time to bring absolute laughter to the guests.',
        category: 'Live Caricature',
        mediaUrl: 'https://images.unsplash.com/photo-1562967969-c07f437021e1?auto=format&fit=crop&w=800&q=80',
        mediaType: 'image',
        createdAt: new Date().toISOString()
      }
    ]);
    this.collections['heroMedia'] = new MockCollection('heroMedia', [
      {
        _id: 'mock-hero-1',
        title: 'The Sacred Canvas',
        description: 'Witness the breathtaking fine-art wedding live paintings painted in graceful real-time detailing.',
        category: 'Wedding Paintings',
        mediaUrl: 'https://player.vimeo.com/external/371433846.sd.mp4?s=236da2f3c054ba203810413bbacf2e2ef09eeac0&profile_id=165&oauth2_token_id=57447761',
        mediaType: 'video',
        videoStartTime: 0,
        videoEndTime: null,
        videoVolume: 0,
        videoSpeed: 1.0,
        uploadedAt: new Date().toISOString(),
        isFeatured: true
      }
    ]);
    this.collections['settings'] = new MockCollection('settings', [
      {
        _id: 'admin',
        contactNumber: '+91 91310 51376',
        adminEmail: 'yaminitamrakar78@gmail.com',
        instagramUrl: 'https://www.instagram.com/dpartic_flow',
        facebookUrl: '#',
        twitterUrl: '#'
      }
    ]);
    this.collections['users'] = new MockCollection('users', []);

    // Generate tomorrow's date representation to guarantee matching test conditions
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const tomorrowStr = tomorrow.toISOString().split('T')[0];

    this.collections['bookings'] = new MockCollection('bookings', [
      {
        _id: 'mock-booking-rem-1',
        userId: 'test-user-id',
        userName: 'Sulochana Patel',
        phone: '+919131051376',
        artCategory: 'Wedding Paintings',
        date: tomorrowStr,
        timing: '10:00 AM - 6:00 PM',
        location: 'Grand Hyatt Ballroom, Mumbai',
        status: 'accepted',
        whatsappAlertSent: false,
        communicationLog: [],
        createdAt: new Date().toISOString()
      }
    ]);
  }

  collection(name: string) {
    if (!this.collections[name]) {
      this.collections[name] = new MockCollection(name);
    }
    return this.collections[name];
  }
}

export async function connectToDb(): Promise<Db> {
  if (useFallback) {
    return mockDbInstance;
  }
  if (db) return db;
  
  const uri = process.env.MONGODB_URI;
  if (!uri) {
    console.warn("WARNING: MONGODB_URI environment variable is not defined. Falling back to in-memory Mock DB.");
    useFallback = true;
    if (!mockDbInstance) {
      mockDbInstance = new MockDb() as unknown as Db;
    }
    return mockDbInstance;
  }

  try {
    console.log("Connecting to MongoDB Atlas...");
    client = new MongoClient(uri, {
      serverSelectionTimeoutMS: 5000
    });
    await client.connect();
    db = client.db();
    console.log("Connected to MongoDB Atlas successfully!");
    await seedDb(db);
    return db;
  } catch (error) {
    console.error("Failed to connect to MongoDB Atlas. Falling back to in-memory Mock DB. Connection Error:", error);
    useFallback = true;
    if (!mockDbInstance) {
      mockDbInstance = new MockDb() as unknown as Db;
    }
    return mockDbInstance;
  }
}

export async function getDb(): Promise<Db> {
  return await connectToDb();
}

async function seedDb(targetDb: Db) {
  try {
    const val = await targetDb.collection('services').countDocuments();
    if (val === 0) {
      console.log('Seeding custom pure-live services in MongoDB...');
      await targetDb.collection('services').insertMany(DEFAULT_SERVICES);
    }

    const settingsCol = targetDb.collection('settings');
    const adminSettings = await settingsCol.findOne({ _id: 'admin' as any });
    if (!adminSettings) {
      console.log('Seeding default app settings in MongoDB...');
      await settingsCol.insertOne({
        _id: 'admin' as any,
        contactNumber: '+91 91310 51376',
        adminEmail: 'yaminitamrakar78@gmail.com',
        instagramUrl: 'https://www.instagram.com/dpartic_flow',
        facebookUrl: '#',
        twitterUrl: '#'
      });
    }

    // Seed test booking if none exist
    const bookingsCol = targetDb.collection('bookings');
    const bookingCount = await bookingsCol.countDocuments();
    if (bookingCount === 0) {
      console.log('Seeding simulated test wedding painting booking for tomorrow...');
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      const tomorrowStr = tomorrow.toISOString().split('T')[0];

      await bookingsCol.insertOne({
        userId: 'test-user-id',
        userName: 'Sulochana Patel',
        phone: '+919131051376',
        artCategory: 'Wedding Paintings',
        date: tomorrowStr,
        timing: '10:00 AM - 6:00 PM',
        location: 'Grand Hyatt Ballroom, Mumbai',
        status: 'accepted',
        whatsappAlertSent: false,
        communicationLog: [],
        createdAt: new Date().toISOString()
      });
    }
  } catch (error) {
    console.error('Error seeding database:', error);
  }
}

